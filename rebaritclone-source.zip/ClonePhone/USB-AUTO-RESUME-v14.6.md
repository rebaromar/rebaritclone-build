# REBARIT CLONE v14.6 — USB automatic byte resume

- No manual USB Resume button.
- If cable/USB session drops during transfer, the app automatically reconnects.
- Receiver keeps the authenticated partial file and negotiates its byte offset.
- Sender verifies the retained prefix with SHA-256 before continuing from that byte.
- Controller selection and old-phone consent are remembered during automatic reconnect, so the user is not asked again for the same interrupted transfer.
- Up to 12 automatic reconnect attempts; no manual “Resume interrupted transfer” button is shown for USB.
- Resume state is cleared after success, final failure, or a fresh USB transfer.
