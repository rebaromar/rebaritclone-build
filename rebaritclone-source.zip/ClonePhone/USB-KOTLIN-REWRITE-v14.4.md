# REBARIT CLONE v14.4 — clean USB rewrite

The previous Java USB transport/session/protocol was removed and rewritten in native Kotlin.

## Goals
- New phone remains the logical controller/receiver.
- Old phone remains the source and only approves the requested categories.
- Physical USB-C host/accessory role is auto-detected and kept independent from logical role.
- Android Open Accessory (AOA) is used when the physical host can switch its peer.
- Permission-protected USB serial numbers are never read during discovery.
- OEM `SecurityException` / malformed USB events are contained and cannot crash MainActivity.
- USB device manifest filter now claims only Google AOA IDs instead of every USB device.
- USB session and controller/source command protocol were versioned to v3/v2 respectively.
- The app still cannot override USB-C power-role policy or OEM/hardware limits.

## Rewritten files
- `UsbLink.kt`
- `UsbSession.kt`
- `UsbCloneProtocol.kt`

The previous Java versions of those files were deleted.
