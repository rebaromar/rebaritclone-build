# Automatic Wi-Fi selection — v12.1
Receiver now chooses the best managed Wi-Fi path automatically:
1. Try the existing high-speed 5 GHz / P2P-capable path first.
2. If the OEM/device rejects it, automatically retry using the existing standard/compatibility hotspot mode.
3. If a local address cannot be obtained, that failure also advances through the same automatic fallback.
4. Manual hotspot is shown only after both managed attempts fail.
5. A retry button restarts the automatic sequence from the fastest mode.
No claim is made that Android can force 5 GHz/Wi-Fi 6 on every OEM.
