# Kotlin migration — Step 2

- Migrated `PermissionPlan.java` to `PermissionPlan.kt`.
- Kept Java source compatibility with `@JvmStatic`, so `MainActivity.java` can continue calling `PermissionPlan.forRole(...)` and `PermissionPlan.forUsbSource(...)` unchanged.
- No UI, USB, Wi-Fi, transfer protocol, storage, or manifest behavior was changed.
- Migration stage advanced from 1 to 2.
