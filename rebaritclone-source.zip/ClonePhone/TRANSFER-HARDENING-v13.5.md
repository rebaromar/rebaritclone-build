# REBARIT CLONE v13.5 — Transfer hardening
Priority reliability hardening: USB/hotspot byte-offset resume, SHA-256 integrity verification, foreground dataSync transfer service, receiver partial-file checkpoint recovery, sender selection recovery, automatic reconnect.
