from pathlib import Path
import json
root=Path(__file__).resolve().parent
ckb=json.loads((root/'ckb.json').read_text())
rows={}
for line in (root/'translations.tsv').read_text().splitlines():
 n,en,ar=line.split('|');rows[int(n)]=[en.replace('\\n','\n'),ar.replace('\\n','\n')]
assert set(rows)==set(range(len(ckb)))
# Arabic fragments retain spaces at both ends when inserted between numbers.
rows[139][1]=' ساعة و ';rows[141][1]=' دقيقة و '
lines=['package com.abdulla.clonephone;','/** Generated from localization catalogs. Do not hand-edit. */','public final class Translations {','    public static final int COUNT='+str(len(ckb))+';','    private static final String[][] TEXT={']
for i,k in enumerate(ckb):lines.append('        {'+','.join(json.dumps(v,ensure_ascii=False) for v in [k,*rows[i]])+'},')
lines+=['    };','    public static String get(String language,int id){return TEXT[id]["en".equals(language)?1:"ar".equals(language)?2:0];}','    public static boolean rtl(String language){return !"en".equals(language);}','}']
(root.parent/'app/src/main/java/com/abdulla/clonephone/Translations.java').write_text('\n'.join(lines)+'\n')
