# USB receive fix v12.4
- New phone automatically enters USB receive/listen mode after opening the USB receiver page.
- Explicit Receive USB button remains as retry.
- AOA accessory matching tolerates OEM string behavior while still requiring a REBARIT marker.
- AOA host endpoint discovery now accepts any interface that actually exposes both bulk IN/OUT endpoints.
- Phone detection includes Android composite class 239 in addition to MTP/vendor-specific.
- AOA re-enumeration/open failures retry during a 3-minute window instead of aborting immediately.
- Polling interval reduced to 400 ms.
- Failure returns to the correct USB role screen with actionable Data-cable/Allow guidance.
