# v12.2 Home order
1. Mobile-to-Mobile
2. File Transfer
3. USB High Speed
USB is now the last main transfer option on the Home screen.
