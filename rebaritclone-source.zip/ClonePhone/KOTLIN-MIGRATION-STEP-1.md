# Kotlin migration — Step 1

- Android app module already had the Kotlin Android plugin configured.
- Java 17 and Kotlin JVM 17 are kept aligned.
- Added `KotlinBridge.kt` as a zero-side-effect Kotlin production source to validate Java/Kotlin coexistence.
- No USB, Hotspot/Wi-Fi, transfer, update, permissions, or UI behavior was rewritten in this step.
- Next step should migrate one small utility class, not `MainActivity` or the transfer engine.
