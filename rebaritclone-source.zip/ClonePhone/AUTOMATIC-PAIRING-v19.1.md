# REBARIT CLONE 19.1 (versionCode 191)

Phone Clone retains Scan QR and adds Automatic connection. Discover the new phone with Wi-Fi Direct or secure Bluetooth RFCOMM, request receiver approval, exchange hotspot credentials on that approved link, then transfer files over Wi-Fi. The sender does not enter a Wi-Fi password. Android may ask to confirm Bluetooth pairing and Wi-Fi connectivity.

Enable Wi-Fi and Bluetooth on both phones. On the new phone open New phone and approve visibility; on the old phone choose Automatic connection, select the receiver, and approve the connection. Use Make this phone visible again if discovery expires. QR is available as before.

The applicationId and existing signing configuration are preserved to update the original 18.9 installation. Version labels read PackageInfo.versionName. The existing GitHub workflow builds with the checked-in signing key and publishes the newer version via the existing update service; this release requires a successful build and publication before installed apps can see it.

The bulk file-transfer engine is preserved. Bluetooth bootstraps credentials; Wi-Fi carries the data. No throughput improvement is claimed. Real-device discovery and two-phone transfer were not tested in this workspace. NearbyProtocolTest provides 48 framing, rejection, cancellation, credential, and service-fingerprint checks.
