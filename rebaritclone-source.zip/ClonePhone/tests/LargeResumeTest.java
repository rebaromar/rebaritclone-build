import com.abdulla.clonephone.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/** 64-bit seek and protocol-state validation; a sparse file is not a 220GB transfer test. */
public class LargeResumeTest {
 static final long SIZE=220000000000L;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 public static void main(String[] args)throws Exception{
  File file=File.createTempFile("resume-large-sparse-",".part");
  try{
   ResumableFile.Entry sparse=new ResumableFile.Entry(file);byte[] tail=new byte[37];new Random(220).nextBytes(tail);
   try(ResumableFile.RandomAccess out=sparse.storage.openWrite()){out.seek(SIZE-tail.length);out.write(tail,0,tail.length);out.sync();}
   check(sparse.storage.length()==SIZE,"220GB destination offset truncated");
   try(InputStream in=sparse.storage.openRead()){
    check(in.skip(SIZE-tail.length)==SIZE-tail.length,"64-bit source skip truncated");
    byte[] actual=new byte[tail.length];new DataInputStream(in).readFully(actual);check(Arrays.equals(tail,actual)&&in.read()==-1,"large-offset tail corrupted");
   }
   // A completed checkpoint is reused after lost ACK/restart without reading or republishing storage.
   ResumableFile.Storage committed=new ResumableFile.Storage(){
    public long length(){throw new AssertionError("completed length reread");}
    public InputStream openRead(){throw new AssertionError("completed destination rescanned");}
    public ResumableFile.RandomAccess openWrite(){throw new AssertionError("completed destination rewritten");}
    public void discard(){throw new AssertionError("completed destination discarded");}
    public String identity(){return "committed-test";}
   };
   ResumableFile.Entry entry=new ResumableFile.Entry(committed);entry.done=true;entry.length=SIZE;entry.digest=new byte[32];
   byte[] key=SecureChannel.parseCode(SecureChannel.newCode());ExecutorService pool=Executors.newSingleThreadExecutor();
   try(ServerSocket listener=new ServerSocket(0)){
    Future<Long> result=pool.submit(()->{try(Socket socket=listener.accept()){
     socket.setSoTimeout(3000);SecureChannel channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,true);
     return ResumableFile.receiveDirect(channel,entry,SIZE,n->{if(n>=0)check(n==SIZE,"progress narrowed to int");},state->{throw new AssertionError("completed destination republished");});
    }});
    try(Socket socket=new Socket("127.0.0.1",listener.getLocalPort())){
     socket.setSoTimeout(3000);SecureChannel channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,false);
     DataInputStream state=new DataInputStream(new ByteArrayInputStream(channel.read()));
     check(state.readLong()==SIZE&&state.readBoolean(),"220GB offset truncated on wire");byte[] digest=new byte[32];state.readFully(digest);
     check(Arrays.equals(digest,entry.digest)&&state.available()==0,"checkpoint digest/format changed");channel.write(new byte[]{1});
    }
    check(result.get(5,TimeUnit.SECONDS)==SIZE,"returned byte count truncated");
   }finally{pool.shutdownNow();}
   System.out.println("PASS: 220GB sparse destination seek/write/read, exact 64-bit completed resume state and progress, no completed-file reread or duplicate publish; not a full 220GB transfer/device test");
  }finally{if(!file.delete())file.deleteOnExit();}
 }
}
