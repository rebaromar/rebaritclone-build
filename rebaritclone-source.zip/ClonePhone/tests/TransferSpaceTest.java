import com.abdulla.clonephone.TransferSpace;

public final class TransferSpaceTest {
    private static void equal(long actual, long expected, String reason) {
        if (actual != expected) throw new AssertionError(reason + ": " + actual + " != " + expected);
    }

    public static void main(String[] args) {
        equal(TransferSpace.remaining(new long[]{220_000_000_000L}, new long[]{0L}, new boolean[]{false}),
              220_000_000_000L, "220 GB direct destination requires one copy");
        if (!TransferSpace.fits(220_000_000_000L, 220_000_000_000L)) throw new AssertionError("Exact capacity rejected");
        if (TransferSpace.fits(220_000_000_000L, 219_999_999_999L)) throw new AssertionError("Insufficient capacity accepted");

        long resumed = TransferSpace.remaining(new long[]{220_000_000_000L, 80_000_000_000L, 10_000_000_000L},
                new long[]{200_000_000_000L, 80_000_000_000L, 0L}, new boolean[]{false, true, false});
        equal(resumed, 30_000_000_000L, "Retained prefix and completed files do not require duplicate space");
        if (!TransferSpace.fits(resumed, 30_000_000_000L) || TransferSpace.fits(resumed, 29_999_999_999L))
            throw new AssertionError("Resumed batch capacity");

        equal(TransferSpace.remaining(Long.MAX_VALUE, 220_000_000_000L, false),
              9_223_371_816_854_775_807L, "Subtraction preserves 64-bit sizes");
        equal(TransferSpace.remaining(new long[]{Long.MAX_VALUE, 1L}, new long[]{0L, 0L}, new boolean[]{false, false}),
              Long.MAX_VALUE, "Overflow cannot become a negative space requirement");
        equal(TransferSpace.remaining(new long[]{-1L, 0L, 10L, 10L}, new long[]{0L, 0L, 20L, -5L},
                new boolean[]{false, false, false, false}), 10L, "Unknown, empty and invalid retained lengths are bounded");
        if (!TransferSpace.fits(220_000_000_000L, -1L)) throw new AssertionError("Unreported provider capacity rejected");
        System.out.println("PASS: 220 GB direct writes, resumed batches, exact and insufficient capacity, 64-bit subtraction and saturated totals");
    }
}
