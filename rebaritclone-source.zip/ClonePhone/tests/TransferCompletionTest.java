import com.abdulla.clonephone.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Exercises final receipts using production encryption, file commit and transport wrappers. */
public class TransferCompletionTest {
    enum Case { NORMAL, LOST_THREE, LOST_FOUR, WRONG_THREE, WRONG_FOUR, LOST_FILE_ACK }
    static final byte[] DATA = new byte[65539];
    static final byte[] KEY = SecureChannel.parseCode(SecureChannel.newCode());
    static final AtomicInteger published = new AtomicInteger();

    static void check(boolean condition, String reason) {
        if (!condition) throw new AssertionError(reason);
    }

    static class DisconnectOutput extends FilterOutputStream {
        final Socket socket;
        volatile boolean armed;
        DisconnectOutput(Socket socket) throws IOException { super(socket.getOutputStream()); this.socket = socket; }
        void checkWire() throws IOException {
            if (armed) { socket.close(); throw new SocketException("Intentional final receipt disconnect"); }
        }
        @Override public void write(int value) throws IOException { checkWire(); out.write(value); }
        @Override public void write(byte[] bytes, int offset, int length) throws IOException {
            checkWire(); out.write(bytes, offset, length);
        }
        @Override public void flush() throws IOException { checkWire(); out.flush(); }
    }

    static void run(Case test, boolean usb, ResumableFile.Entry entry) throws Exception {
        ExecutorService worker = Executors.newSingleThreadExecutor();
        CountDownLatch senderReceivedFileAck = new CountDownLatch(1);
        AtomicInteger senderFinal = new AtomicInteger(), receiverFinal = new AtomicInteger();
        Exception senderError = null, receiverError = null;
        try (ServerSocket listener = new ServerSocket(0)) {
            Future<Void> server = worker.submit(() -> {
                try (Socket socket = listener.accept()) {
                    socket.setSoTimeout(1500);
                    DisconnectOutput output = new DisconnectOutput(socket);
                    InputStream input = socket.getInputStream();
                    SecureChannel channel = new SecureChannel(usb ? TransferFailure.usbInput(input) : input,
                            usb ? TransferFailure.usbOutput(output) : output, KEY, true);
                    ResumableFile.receive(channel, entry, DATA.length, ignored -> {}, file -> {
                        check(Arrays.equals(DATA, java.nio.file.Files.readAllBytes(file.toPath())), "Published bytes changed");
                        published.incrementAndGet();
                        if (test == Case.LOST_FILE_ACK) socket.close();
                    });
                    check(senderReceivedFileAck.await(3, TimeUnit.SECONDS), "Sender did not receive file ACK");
                    if (test == Case.WRONG_THREE) { channel.write(new byte[]{9}); return null; }
                    if (test == Case.LOST_THREE) output.armed = true;
                    receiverFinal.incrementAndGet();
                    TransferCompletion.receiver(channel, usb);
                    return null;
                }
            });
            try (Socket socket = new Socket("127.0.0.1", listener.getLocalPort())) {
                socket.setSoTimeout(1500);
                DisconnectOutput output = new DisconnectOutput(socket);
                InputStream input = socket.getInputStream();
                SecureChannel channel = new SecureChannel(usb ? TransferFailure.usbInput(input) : input,
                        usb ? TransferFailure.usbOutput(output) : output, KEY, false);
                ResumableFile.send(channel, new ByteArrayInputStream(DATA), DATA.length, 262144, ignored -> {});
                senderReceivedFileAck.countDown();
                if (test == Case.LOST_FOUR) output.armed = true;
                if (test == Case.WRONG_FOUR) {
                    check(Arrays.equals(channel.read(), new byte[]{3}), "Missing batch receipt");
                    channel.write(new byte[]{9});
                } else {
                    senderFinal.incrementAndGet();
                    TransferCompletion.sender(channel, usb);
                }
            } catch (Exception error) { senderError = error; }
            try { server.get(5, TimeUnit.SECONDS); }
            catch (ExecutionException error) { receiverError = (Exception)error.getCause(); }
        } finally { worker.shutdownNow(); }

        if (test == Case.WRONG_THREE) {
            check(senderError != null && "Invalid completion receipt".equals(senderError.getMessage()), "Wrong batch 3 accepted");
            check(receiverError == null, "Unexpected receiver error");
        } else if (test == Case.WRONG_FOUR) {
            check(receiverError != null && "Invalid completion receipt".equals(receiverError.getMessage()), "Wrong batch 4 accepted");
            check(senderError == null, "Unexpected sender error");
        } else if (test == Case.LOST_FILE_ACK) {
            check(senderError != null && receiverError != null, "Lost file ACK was treated as batch completion");
            check(senderFinal.get() == 0 && receiverFinal.get() == 0, "Completion ran before file ACKs finished");
            check(entry.done && entry.digest != null, "Durable file checkpoint lost before retry");
        } else {
            check(senderError == null && receiverError == null, "Final receipt transport loss caused failure: " + senderError + "/" + receiverError);
        }
    }

    public static void main(String[] args) throws Exception {
        new Random(119).nextBytes(DATA);
        for (boolean usb : new boolean[]{false, true}) {
            for (Case test : Case.values()) {
                File partial = File.createTempFile("completion-", ".part");
                ResumableFile.Entry entry = new ResumableFile.Entry(partial);
                int before = published.get();
                try {
                    run(test, usb, entry);
                    check(published.get() == before + 1, "File was not published exactly once");
                    if (test == Case.LOST_FILE_ACK) {
                        run(Case.NORMAL, usb, entry);
                        check(published.get() == before + 1, "Lost file ACK retry republished output");
                    }
                } finally { partial.delete(); }
            }
        }
        System.out.println("PASS: Wi-Fi/USB final 3/4 loss completes, wrong completion records rejected, lost file ACK still resumes without republishing");
    }
}
