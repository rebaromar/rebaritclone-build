import com.abdulla.clonephone.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import javax.crypto.AEADBadTagException;

public class TransferFailureTest {
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static void classification()throws Exception{
  IOException network=new IOException("outer",new SocketException("connection reset"));
  check(TransferFailure.network(network),"nested network loss not retryable");
  check(!TransferFailure.network(new EOFException("truncated local source")),"unmarked source EOF retried");
  check(!TransferFailure.network(new IOException("destination full")),"storage error retried");
  check(!TransferFailure.usb(new IOException("destination full")),"storage error retried as USB");
  check(!TransferFailure.network(new IOException("SOURCE_CHANGED",network)),"source corruption retried");
  check(!TransferFailure.usb(new IOException("Incomplete file",new IOException("USB_DISCONNECTED"))),"digest mismatch retried");
  check(!TransferFailure.network(new IOException("outer",new AEADBadTagException("authentication"))),"authentication error retried");
  check(!TransferFailure.usb(new IOException("CANCELLED",new IOException("USB_DISCONNECTED"))),"cancel retried");
  check(!TransferFailure.network(new IOException("Protocol mismatch: update both phones",network)),"incompatible peer retried");
  try{TransferFailure.usbInput(new ByteArrayInputStream(new byte[0])).read();throw new AssertionError("USB EOF unmarked");}
  catch(IOException expected){check("USB_DISCONNECTED".equals(expected.getMessage())&&TransferFailure.usb(expected)&&!TransferFailure.network(expected),"USB EOF classification");}
  OutputStream failed=new OutputStream(){public void write(int value)throws IOException{throw new IOException("EIO from accessory");}};
  try{TransferFailure.usbOutput(failed).write(new byte[]{3});throw new AssertionError("USB write unmarked");}
  catch(IOException expected){check(expected instanceof TransferFailure.TransportException&&TransferFailure.usb(new IOException("outer",expected)),"nested USB write classification");}
 }
 static void completedScopeDoesNotFail()throws Exception{
  byte[] key=SecureChannel.parseCode(SecureChannel.newCode());ExecutorService pool=Executors.newSingleThreadExecutor();
  AtomicBoolean fail=new AtomicBoolean();CountDownLatch timerFailed=new CountDownLatch(1);
  try(ServerSocket listener=new ServerSocket(0)){
   Future<?> server=pool.submit(()->{try(Socket socket=listener.accept()){
    socket.setSoTimeout(3000);SecureChannel channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,true);
    check(channel.read()[0]==4,"final payload");channel.write(new byte[]{2});
   }catch(Exception error){throw new RuntimeException(error);}});
   try(Socket socket=new Socket("127.0.0.1",listener.getLocalPort())){
    socket.setSoTimeout(3000);OutputStream unreliable=new FilterOutputStream(socket.getOutputStream()){
     @Override public void write(byte[] bytes,int offset,int length)throws IOException{
      if(fail.get()){timerFailed.countDown();throw new IOException("wire closed after ACK");}out.write(bytes,offset,length);
     }
    };
    SecureChannel channel=new SecureChannel(socket.getInputStream(),unreliable,key,false);
    // The application successfully read its final ACK; a later timer error is cleanup only.
    int result=channel.withKeepalive(10,()->{
     channel.write(new byte[]{4});check(channel.read()[0]==2,"final ACK");fail.set(true);
     check(timerFailed.await(1,TimeUnit.SECONDS),"timer did not reach expected wire failure");return 7;
    });
    check(result==7,"successful job turned into failure by scope close");
    try(SecureChannel.Keepalive keepalive=channel.startKeepalive(10)){
     // Failures during active work still surface as a known transport loss.
     Thread.sleep(40);
     try{keepalive.check();throw new AssertionError("active failure hidden");}
     catch(IOException expected){check(TransferFailure.network(expected)&&TransferFailure.usb(expected),"keepalive failure not recoverable");}
    }
   }
   server.get(3,TimeUnit.SECONDS);
  }finally{pool.shutdownNow();}
 }
 public static void main(String[] args)throws Exception{
  classification();completedScopeDoesNotFail();
  System.out.println("PASS: nested wire/USB failures recover, source/storage/integrity/protocol/cancel errors stay terminal, active timer failure is typed, successful final ACK survives timer cleanup");
 }
}
