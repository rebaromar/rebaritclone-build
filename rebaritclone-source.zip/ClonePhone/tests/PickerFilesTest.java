package com.abdulla.clonephone;
import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.FileTime;
import java.util.*;
public final class PickerFilesTest {
    static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);}
    static void file(Path root,String name)throws IOException{Path p=root.resolve(name);Files.createDirectories(p.getParent());Files.write(p,new byte[]{1});}
    static final class TrackedFile extends File {
        final boolean directory;final long modified;File[] children=new File[0];
        int fileChecks,readChecks,canonicalChecks,modifiedChecks,directoryChecks;
        TrackedFile(String path,boolean directory,long modified){super(path);this.directory=directory;this.modified=modified;}
        @Override public boolean isFile(){fileChecks++;return !directory;}
        @Override public boolean isDirectory(){directoryChecks++;return directory;}
        @Override public boolean canRead(){readChecks++;return true;}
        @Override public String getCanonicalPath(){canonicalChecks++;return getPath();}
        @Override public long lastModified(){modifiedChecks++;return modified;}
        @Override public File[] listFiles(){return children;}
    }
    static void packageScanCosts()throws Exception{
        TrackedFile root=new TrackedFile("/virtual-picker",true,0);
        TrackedFile photo=new TrackedFile("/virtual-picker/image.JPG",false,100);
        TrackedFile old=new TrackedFile("/virtual-picker/older.apk",false,10);
        TrackedFile newest=new TrackedFile("/virtual-picker/newer.APK",false,20);
        root.children=new File[]{photo,old,newest};
        List<File> found=PickerFiles.scanPackages(root,()->{},batch->{});
        check(found.equals(Arrays.asList(newest,old)),"packages sorted by cached modification time");
        check(photo.directoryChecks==1&&photo.fileChecks==0&&photo.readChecks==0&&photo.canonicalChecks==0&&photo.modifiedChecks==0,"non-package metadata skipped");
        check(old.modifiedChecks==1&&newest.modifiedChecks==1,"sort performs no additional timestamp stats");
    }
    static void packagePriorities()throws Exception{
        TrackedFile root=new TrackedFile("/priority-picker",true,0);
        TrackedFile ordinary=new TrackedFile("/priority-picker/Pictures",true,0);
        TrackedFile bluetooth=new TrackedFile("/priority-picker/Bluetooth",true,0);
        TrackedFile download=new TrackedFile("/priority-picker/Download",true,0);
        TrackedFile nested=new TrackedFile("/priority-picker/Download/nested",true,0);
        TrackedFile fromOther=new TrackedFile("/priority-picker/Pictures/other.apk",false,1);
        TrackedFile fromBluetooth=new TrackedFile("/priority-picker/Bluetooth/received.apk",false,1);
        TrackedFile fromDownload=new TrackedFile("/priority-picker/Download/nested/downloaded.apk",false,1);
        root.children=new File[]{ordinary,bluetooth,download};download.children=new File[]{nested};
        nested.children=new File[]{fromDownload};bluetooth.children=new File[]{fromBluetooth};ordinary.children=new File[]{fromOther};
        List<File> streamed=new ArrayList<>();
        PickerFiles.scanPackages(root,()->{},batch->streamed.addAll(batch));
        check(streamed.equals(Arrays.asList(fromDownload,fromBluetooth,fromOther)),"whole Download and Bluetooth trees precede other storage");
    }
    public static void main(String[] args)throws Exception{
        check(PickerFiles.packageFile("APP.APK")&&PickerFiles.packageFile("CapCut.rbapp")&&PickerFiles.packageFile("bundle.xapk"),"package types");
        check(!PickerFiles.packageFile("apk-notes.txt"),"false package rejected");
        check(PickerFiles.matches("report.XLSX",1,"","EXCEL"),"Excel");
        check(PickerFiles.matches("slides.pptx",1,"","PPT"),"PowerPoint");
        check(PickerFiles.matches("archive.7z",1,"","Zip")&&!PickerFiles.matches("archive.txt",1,"","Zip"),"archives");
        check(!PickerFiles.matches("large",50L*1024*1024,"","Large Files")&&PickerFiles.matches("large",50L*1024*1024+1,"","Large Files"),"large boundary");
        check(PickerFiles.matches("status.jpg",1,"/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses/status.jpg","Status"),"modern WhatsApp Status");
        check(!PickerFiles.matches("status.jpg",1,"/WhatsApp/Media/.Statuses/status.jpg","Media"),"status excluded from media");
        Path root=Files.createTempDirectory("picker-shared-");Path outside=Files.createTempFile("picker-outside-",".apk");
        try{
            file(root,"Download/app.apk");file(root,"Documents/report.pdf");file(root,"Android/media/com.whatsapp/WhatsApp/Media/.Statuses/image.jpg");
            file(root,"Android/data/private/file.apk");file(root,"Android/obb/private/game.obb");file(root,"Pictures/.nomedia");
            Files.createSymbolicLink(root.resolve("escape.apk"),outside);
            Files.createSymbolicLink(root.resolve("loop"),root);
            List<File> files=PickerFiles.scan(root.toFile(),()->{});check(files.size()==3,"shared files only; restricted folders, symlink escape and loop excluded");
            Set<String> names=new HashSet<>();for(File f:files)names.add(f.getName());check(names.containsAll(Arrays.asList("app.apk","report.pdf","image.jpg")),"discovered actual files");
            try{PickerFiles.scan(root.toFile(),()->{throw new IOException("cancelled");});throw new AssertionError("cancel ignored");}catch(IOException expected){check(expected.getMessage().equals("cancelled"),"cancel preserved");}

            file(root,"Download/nested/bundle.APkS");file(root,"Bluetooth/bundle.XAPK");
            file(root,"Documents/other.APKM");file(root,"Documents/export.RBAPP");
            file(root,"Documents/not-package.apk.txt");file(root,"Android/obb/private/hidden.apk");
            Files.createSymbolicLink(root.resolve("private-alias.apk"),root.resolve("Android/data/private/file.apk"));
            Files.createSymbolicLink(root.resolve("restricted-alias"),root.resolve("Android/data"));
            for(int i=0;i<50;i++)file(root,"Download/batch-"+i+".apk");
            Files.setLastModifiedTime(root.resolve("Documents/export.RBAPP"),FileTime.fromMillis(System.currentTimeMillis()+60_000));
            List<File> streamed=new ArrayList<>();List<Integer> batchSizes=new ArrayList<>();
            List<File> packages=PickerFiles.scanPackages(root.toFile(),()->{},batch->{
                batchSizes.add(batch.size());streamed.addAll(batch);
                try{batch.add(root.toFile());throw new AssertionError("mutable batch");}catch(UnsupportedOperationException expected){}
            });
            check(packages.size()==55,"all supported packages, excluding media and restricted aliases");
            check(streamed.size()==packages.size()&&new HashSet<>(streamed).equals(new HashSet<>(packages)),"incremental batches cover complete result");
            check(batchSizes.size()>2&&batchSizes.get(0)==1&&Collections.max(batchSizes)<=24,"first package streams immediately; subsequent batches bounded");
            check(packages.get(0).getName().equals("export.RBAPP"),"complete result sorted newest first");
            for(File f:packages)check(PickerFiles.packageFile(f.getName())&&!f.getName().equals("private-alias.apk"),"package and restricted path filtering");
            final boolean[] cancelled={false};final int[] checked={0};
            try{
                PickerFiles.scanPackages(root.toFile(),()->{checked[0]++;if(cancelled[0])throw new IOException("cancelled after first package");},batch->{cancelled[0]=true;});
                throw new AssertionError("streamed cancellation ignored");
            }catch(IOException expected){check(expected.getMessage().equals("cancelled after first package"),"cancellation interrupts immediately after callback");}
            check(checked[0]<100,"cancelled scan does not traverse all files");
        }finally{try(java.util.stream.Stream<Path> stream=Files.walk(root)){stream.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException ignored){}});}Files.deleteIfExists(outside);}
        packageScanCosts();packagePriorities();
        System.out.println("PASS: package-only discovery, early bounded batches, incoming-directory priority, cached timestamp sorting, skipped media metadata, restricted directories/symlinks, cancellation and document/media filters");
    }
}
