package com.abdulla.clonephone;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public final class PickerFilesTest {
    static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);}
    static void file(Path root,String name)throws IOException{Path p=root.resolve(name);Files.createDirectories(p.getParent());Files.write(p,new byte[]{1});}
    public static void main(String[] args)throws Exception{
        check(PickerFiles.packageFile("APP.APK")&&PickerFiles.packageFile("CapCut.rbapp")&&PickerFiles.packageFile("bundle.xapk"),"package types");
        check(!PickerFiles.packageFile("apk-notes.txt"),"false package rejected");
        check(PickerFiles.matches("report.XLSX",1,"","EXCEL"),"Excel");
        check(PickerFiles.matches("slides.pptx",1,"","PPT"),"PowerPoint");
        check(PickerFiles.matches("archive.7z",1,"","Zip")&&!PickerFiles.matches("archive.txt",1,"","Zip"),"archives");
        check(!PickerFiles.matches("large",50L*1024*1024,"","Large Files")&&PickerFiles.matches("large",50L*1024*1024+1,"","Large Files"),"large boundary");
        check(PickerFiles.matches("status.jpg",1,"/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses/status.jpg","Status"),"modern WhatsApp Status");
        check(!PickerFiles.matches("status.jpg",1,"/WhatsApp/Media/.Statuses/status.jpg","Media"),"status excluded from media");
        Path root=Files.createTempDirectory("picker-shared-");Path outside=Files.createTempFile("picker-outside-",".apk");
        try{
            file(root,"Download/app.apk");file(root,"Documents/report.pdf");file(root,"Android/media/com.whatsapp/WhatsApp/Media/.Statuses/image.jpg");
            file(root,"Android/data/private/file.apk");file(root,"Android/obb/private/game.obb");file(root,"Pictures/.nomedia");
            Files.createSymbolicLink(root.resolve("escape.apk"),outside);
            Files.createSymbolicLink(root.resolve("loop"),root);
            List<File> files=PickerFiles.scan(root.toFile(),()->{});check(files.size()==3,"shared files only; restricted folders, symlink escape and loop excluded");
            Set<String> names=new HashSet<>();for(File f:files)names.add(f.getName());check(names.containsAll(Arrays.asList("app.apk","report.pdf","image.jpg")),"discovered actual files");
            try{PickerFiles.scan(root.toFile(),()->{throw new IOException("cancelled");});throw new AssertionError("cancel ignored");}catch(IOException expected){check(expected.getMessage().equals("cancelled"),"cancel preserved");}
        }finally{try(java.util.stream.Stream<Path> stream=Files.walk(root)){stream.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException ignored){}});}Files.deleteIfExists(outside);}
        System.out.println("PASS: APK/bundle discovery, document filters, archive filters, >50MB boundary, WhatsApp paths, restricted directory exclusion, symlink confinement and cancellation");
    }
}
