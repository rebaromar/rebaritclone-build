package com.abdulla.clonephone;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.UUID;

public final class NearbyProtocolTest {
    private static int checks;
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        checks++;
    }
    private interface Task { void run() throws Exception; }
    private static void expect(String message, Task task) throws Exception {
        try { task.run(); throw new AssertionError("Expected " + message); }
        catch (IOException e) { check(message.equals(e.getMessage()), "Wrong error: " + e); }
    }
    private static DataInputStream input(String protocol, String name, int bands, String ready)
            throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeUTF(protocol);
        out.writeUTF(name);
        if ("REBAR-NEARBY-2".equals(protocol)) out.writeInt(bands);
        if (ready != null) out.writeUTF(ready);
        return new DataInputStream(new ByteArrayInputStream(bytes.toByteArray()));
    }
    private static void socketExchange(boolean accept) throws Exception {
        ExecutorService worker = Executors.newSingleThreadExecutor();
        try (ServerSocket server = new ServerSocket(0, 1, InetAddress.getLoopbackAddress())) {
            Future<Boolean> hosted = worker.submit(() -> {
                try (Socket socket = server.accept()) {
                    socket.setSoTimeout(3000);
                    return NearbyProtocol.serve(new DataInputStream(socket.getInputStream()),
                            new DataOutputStream(socket.getOutputStream()), (name, bands) -> {
                        check("Old phone".equals(name), "Peer identity changed");
                        check(bands == 3, "Band mask changed");
                        return accept ? "approved-pairing-payload" : null;
                    }, () -> true);
                }
            });
            try (Socket socket = new Socket(InetAddress.getLoopbackAddress(), server.getLocalPort())) {
                socket.setSoTimeout(3000);
                DataInputStream in = new DataInputStream(socket.getInputStream());
                DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                if (accept) {
                    String payload = NearbyProtocol.request(in, out, "Old phone", 3);
                    check("approved-pairing-payload".equals(payload), "Approved payload not received");
                    NearbyProtocol.confirm(in, out);
                } else expect("DECLINED", () -> NearbyProtocol.request(in, out, "Old phone", 3));
            }
            check(hosted.get(3, TimeUnit.SECONDS) == accept, "Approval did not control readiness");
        } finally { worker.shutdownNow(); }
    }
    public static void main(String[] args) throws Exception {
        socketExchange(true);
        socketExchange(false);

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        boolean legacy = NearbyProtocol.serve(input("REBAR-NEARBY-1", "Legacy phone", 0, null),
                new DataOutputStream(bytes), (name, bands) -> {
                    check(bands == 1, "Legacy band compatibility"); return "legacy-payload";
                }, () -> true);
        check(!legacy, "Legacy protocol must not wait for a modern confirmation");
        check("legacy-payload".equals(new DataInputStream(new ByteArrayInputStream(bytes.toByteArray())).readUTF()),
                "Legacy payload missing");

        final boolean[] approved = {false};
        NearbyProtocol.Approval approval = (name, bands) -> { approved[0] = true; return "secret-pairing"; };
        expect("PROTOCOL", () -> NearbyProtocol.serve(input("WRONG", "phone", 1, null),
                new DataOutputStream(new ByteArrayOutputStream()), approval, () -> true));
        check(!approved[0], "Unknown protocol requested approval");
        expect("PEER", () -> NearbyProtocol.serve(input("REBAR-NEARBY-2", new String(new char[101]), 1, null),
                new DataOutputStream(new ByteArrayOutputStream()), approval, () -> true));
        check(!approved[0], "Oversized peer requested approval");
        expect("PEER", () -> NearbyProtocol.serve(input("REBAR-NEARBY-2", "phone", 2, null),
                new DataOutputStream(new ByteArrayOutputStream()), approval, () -> true));
        check(!approved[0], "Incompatible peer requested approval");

        bytes.reset();
        check(!NearbyProtocol.serve(input("REBAR-NEARBY-2", "phone", 1, "READY"),
                new DataOutputStream(bytes), approval, () -> false), "Cancelled session reported success");
        check(bytes.size() == 0 && !approved[0], "Cancelled session leaked a pairing payload");

        final boolean[] alive = {true};
        bytes.reset();
        check(!NearbyProtocol.serve(input("REBAR-NEARBY-2", "phone", 1, "READY"),
                new DataOutputStream(bytes), (name, bands) -> { alive[0] = false; return "secret"; },
                () -> alive[0]), "Session cancelled during approval reported success");
        check(bytes.size() == 0, "Cancellation during approval leaked a key");

        expect("PAIR", () -> NearbyProtocol.serve(input("REBAR-NEARBY-2", "phone", 1, "WRONG"),
                new DataOutputStream(new ByteArrayOutputStream()), approval, () -> true));
        expect("PAIR", () -> NearbyProtocol.serve(input("REBAR-NEARBY-2", "phone", 1, "READY"),
                new DataOutputStream(new ByteArrayOutputStream()), (name, bands) -> new String(new char[701]), () -> true));

        ByteArrayOutputStream wrongResponse = new ByteArrayOutputStream();
        new DataOutputStream(wrongResponse).writeUTF("WRONG");
        expect("PAIR", () -> NearbyProtocol.confirm(new DataInputStream(new ByteArrayInputStream(wrongResponse.toByteArray())),
                new DataOutputStream(new ByteArrayOutputStream())));

        check(NearbyProtocol.hotspotName("DIRECT-rb-REBARIT-a12b34"), "New SSID not discoverable");
        check(NearbyProtocol.hotspotName("DIRECT-rb-a12b34"), "Existing app SSID not discoverable");
        check(NearbyProtocol.hotspotName("AndroidShare_1234"), "LocalOnlyHotspot fallback not discoverable");
        check(!NearbyProtocol.hotspotName("Neighbour's Wi-Fi"), "Unrelated Wi-Fi listed as this app");
        check(!NearbyProtocol.hotspotName(null), "Null SSID accepted");
        check(NearbyProtocol.validSsid("DIRECT-rb-REBARIT-a12b34"), "Generated SSID is too long");
        check(!NearbyProtocol.validSsid(new String(new char[33]).replace('\0', 'a')), "Oversized SSID accepted");
        check(!NearbyProtocol.validSsid("\u0000invalid"), "NUL SSID accepted");
        check(NearbyProtocol.validPassword("Abcdef1234567890"), "Hotspot password rejected");
        check(!NearbyProtocol.validPassword("short"), "Short password accepted");
        check(!NearbyProtocol.validPassword("contains\nnewline"), "Control character in password accepted");
        check(!NearbyProtocol.validPassword(new String(new char[64]).replace('\0', 'a')), "Long password accepted");
        String hotspot = "DIRECT-rb-REBARIT-a12b34";
        UUID service = NearbyProtocol.bluetoothService(hotspot);
        check(service.equals(NearbyProtocol.bluetoothService(hotspot)), "SSID service fingerprint changed");
        check(!service.equals(NearbyProtocol.bluetoothService("DIRECT-rb-REBARIT-b12b34")), "Different hotspots share a fingerprint");
        check(NearbyProtocol.isBluetoothService(service), "App Bluetooth service not recognized");
        check(!NearbyProtocol.isBluetoothService(null), "Null Bluetooth service recognized");
        check(!NearbyProtocol.isBluetoothService(UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")), "Generic serial service mistaken for this app");
        check(NearbyProtocol.validBluetoothOffer(service, hotspot, "SecurePass123456"), "Valid approved Bluetooth offer rejected");
        check(!NearbyProtocol.validBluetoothOffer(service, "DIRECT-rb-REBARIT-b12b34", "SecurePass123456"), "Wrong receiver's SSID accepted");
        check(!NearbyProtocol.validBluetoothOffer(service, hotspot, "short"), "Invalid Bluetooth password accepted");
        check(!NearbyProtocol.validBluetoothOffer(service, "", "SecurePass123456"), "Empty Bluetooth SSID accepted");
        check(!NearbyProtocol.validBluetoothOffer(null, hotspot, "SecurePass123456"), "Offer without discovered service accepted");
        check(NearbyProtocol.isBluetoothService(NearbyProtocol.bluetoothService("AndroidShare_2134")), "System-named hotspot not supported by automatic bootstrap");
        try {
            NearbyProtocol.bluetoothService("");
            throw new AssertionError("Invalid SSID hashed as a service");
        } catch (IllegalArgumentException expected) { checks++; }
        System.out.println("Passed " + checks + " protocol, approval, cancellation, and hotspot validation checks.");
    }
}
