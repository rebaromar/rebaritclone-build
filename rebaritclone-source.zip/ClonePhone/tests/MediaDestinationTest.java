package com.abdulla.clonephone;

public final class MediaDestinationTest {
    static void equal(String actual,String expected,String reason){if(!actual.equals(expected))throw new AssertionError(reason+": "+actual+" != "+expected);}
    public static void main(String[] args){
        equal(MediaDestination.relativePath("image/jpeg","Xom/Album/",34),"Pictures/Xom/Album/","arbitrary selected photo folder is a valid image destination");
        equal(MediaDestination.relativePath("application/pdf","Work/Invoices/",34),"Download/Work/Invoices/","arbitrary selected document folder is a valid download destination");
        equal(MediaDestination.relativePath("image/jpeg","Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/",34),"Pictures/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/","WhatsApp image hierarchy retained under Pictures");
        equal(MediaDestination.relativePath("video/mp4","Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video/",34),"Movies/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video/","WhatsApp video hierarchy retained under Movies");
        equal(MediaDestination.relativePath("audio/ogg","WhatsApp/Media/Voice Notes/",34),"Music/WhatsApp/Media/Voice Notes/","voice note hierarchy retained under Music");
        equal(MediaDestination.relativePath("image/jpeg","DCIM/Camera/",34),"DCIM/Camera/","valid photo DCIM path preserved");
        equal(MediaDestination.relativePath("video/mp4","DCIM/Camera/",34),"DCIM/Camera/","valid video DCIM path preserved");
        equal(MediaDestination.relativePath("video/mp4","Movies/Trips/",34),"Movies/Trips/","valid movie path preserved");
        equal(MediaDestination.relativePath("application/vnd.openxmlformats-officedocument.wordprocessingml.document","Documents/Reports/",34),"Documents/Reports/","valid Word document path preserved");
        equal(MediaDestination.relativePath("application/zip","Download/",34),"Download/","valid archive download path preserved");
        equal(MediaDestination.relativePath("image/png","pictures/Mixed Case/",34),"Pictures/Mixed Case/","accepted primary casing normalized without altering nested folders");
        equal(MediaDestination.relativePath("VIDEO/MP4","dcim/Camera/",34),"DCIM/Camera/","MIME matching and primary casing are case insensitive");
        equal(MediaDestination.relativePath("image/jpeg","Music/Artwork/",34),"Pictures/Music/Artwork/","incompatible media root prefixed with image directory");
        equal(MediaDestination.relativePath("video/mp4","Pictures/Video/",34),"Movies/Pictures/Video/","conservative video roots avoid incompatible Pictures destination");
        equal(MediaDestination.relativePath("application/pdf","DCIM/Notes/",34),"Download/DCIM/Notes/","documents cannot be inserted into an image-only root");
        equal(MediaDestination.relativePath("audio/mp4","Podcasts/Series/",23),"Podcasts/Series/","baseline audio collection directories are retained");
        equal(MediaDestination.relativePath("audio/mp4","Audiobooks/Book/",28),"Music/Audiobooks/Book/","Audiobooks root not used before Android 10");
        equal(MediaDestination.relativePath("audio/mp4","audiobooks/Book/",29),"Audiobooks/Book/","Audiobooks accepted starting Android 10");
        equal(MediaDestination.relativePath("audio/wav","Recordings/Meetings/",30),"Music/Recordings/Meetings/","Recordings root not used before Android 12");
        equal(MediaDestination.relativePath("audio/wav","recordings/Meetings/",31),"Recordings/Meetings/","Recordings accepted starting Android 12");
        equal(MediaDestination.relativePath("image/jpeg","",34),"Pictures/","root-level image uses Pictures");
        equal(MediaDestination.relativePath("video/mp4",null,34),"Movies/","root-level video uses Movies");
        equal(MediaDestination.relativePath("audio/ogg","/",34),"Music/","root-level audio uses Music");
        equal(MediaDestination.relativePath(null,"",34),"Download/","unknown file type uses Download");
        equal(MediaDestination.relativePath("application/pdf","Documents",34),"Documents/","accepted root has one trailing slash");
        equal(MediaDestination.relativePath("image/jpeg","/Pictures//Album///",34),"Pictures/Album/","empty path components normalized");
        equal(MediaDestination.relativePath("image/jpeg","Pictures\\Album\\",34),"Pictures/Album/","normalized separators preserve hierarchy");
        equal(MediaDestination.relativePath("application/pdf","فایلەکان/ڕاپۆرت/",34),"Download/فایلەکان/ڕاپۆرت/","Unicode directory names retained");
        String first=MediaDestination.relativePath("image/jpeg","Xom/Album/",34);
        equal(MediaDestination.relativePath("image/jpeg",first,34),first,"choosing destination repeatedly does not add another prefix");
        System.out.println("PASS: compatible MediaStore roots, arbitrary storage and WhatsApp hierarchy, canonical root casing, defaults, API-specific audio directories and stable destination paths");
    }
}
