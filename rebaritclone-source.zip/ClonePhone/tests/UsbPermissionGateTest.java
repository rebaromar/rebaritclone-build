package com.abdulla.clonephone;

public final class UsbPermissionGateTest {
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        UsbPermissionGate gate = new UsbPermissionGate();
        check(gate.begin("normal-device") == UsbPermissionGate.REQUEST, "first request");
        int first = gate.requestId();
        for (int i = 0; i < 20; i++) {
            check(gate.begin("normal-device") == UsbPermissionGate.WAIT, "poll must not duplicate dialog");
            check(gate.begin("aoa-device") == UsbPermissionGate.WAIT, "attach must not overlap dialog");
        }
        check(!gate.complete("aoa-device", first), "wrong endpoint callback ignored");
        check(!gate.complete("normal-device", first - 1), "stale request callback ignored");
        check(gate.isPending(), "stale result preserves pending request");
        check(gate.complete("normal-device", first), "Allow completes matching request");
        check(!gate.complete("normal-device", first), "duplicate callback ignored");
        check(gate.begin("normal-device") == UsbPermissionGate.ALREADY_ASKED, "permission visibility delay must not reprompt");
        check(gate.begin("aoa-device") == UsbPermissionGate.REQUEST, "Android can authorize new AOA identity separately");
        int aoa = gate.requestId();
        gate.reset();
        check(!gate.complete("aoa-device", aoa), "old session result ignored after reset");
        check(gate.begin("aoa-device") == UsbPermissionGate.REQUEST, "explicit user retry starts a fresh attempt");
        check(gate.requestId() != aoa, "retry gets a distinct pending intent identity");
        System.out.println("PASS: USB permission serialization, duplicate suppression, stale results and explicit retry");
    }
}
