package com.abdulla.clonephone;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class StorageFilesTest {
    static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);}
    static void file(Path root,String relative)throws IOException{Path file=root.resolve(relative);Files.createDirectories(file.getParent());Files.write(file,new byte[]{1});}
    interface Operation{void run()throws IOException;}
    static void rejected(Operation op,String reason)throws Exception{try{op.run();throw new AssertionError(reason+" accepted");}catch(IOException expected){check(!expected.getMessage().isEmpty(),reason+" has actionable error");}}
    static final class DeniedDirectory extends File {
        final boolean permission,throwsSecurity;
        DeniedDirectory(String path,boolean permission,boolean throwsSecurity){super(path);this.permission=permission;this.throwsSecurity=throwsSecurity;}
        @Override public String getCanonicalPath(){return getPath();}
        @Override public boolean isDirectory(){return true;}
        @Override public boolean canRead(){return permission;}
        @Override public File[] listFiles(){if(throwsSecurity)throw new SecurityException("denied");return null;}
    }
    static final class ListedDirectory extends File {
        final File[] children;
        ListedDirectory(String path,File... children){super(path);this.children=children;}
        @Override public String getCanonicalPath(){return getPath();}
        @Override public boolean isDirectory(){return true;}
        @Override public boolean canRead(){return true;}
        @Override public File[] listFiles(){return children;}
    }
    public static void main(String[] args)throws Exception{
        Path root=Files.createTempDirectory("storage-selection-");Path outside=Files.createTempDirectory("storage-outside-");
        try{
            file(root,"Album/one.jpg");file(root,"Album/Nested/two.mp4");file(root,"Album/Nested/.nomedia");
            file(root,"Documents/report.DOCX");file(root,"Android/media/Shared/audio.mp3");
            file(root,"Android/data/Private/hidden.pdf");file(root,"Android/obb/Private/hidden.obb");file(outside,"outside.pdf");
            Files.createSymbolicLink(root.resolve("escape"),outside);
            Files.createSymbolicLink(root.resolve("Album/Nested/loop"),root.resolve("Album"));
            Files.createSymbolicLink(root.resolve("private-alias"),root.resolve("Android/data"));
            Files.createSymbolicLink(root.resolve("Album/duplicate.jpg"),root.resolve("Album/one.jpg"));
            List<File> top=StorageFiles.list(root.toFile(),root.toFile(),()->{});
            Set<String> names=new HashSet<>();for(File file:top)names.add(file.getName());
            check(names.equals(new HashSet<>(Arrays.asList("Album","Android","Documents"))),"direct listing excludes escaped and restricted aliases");
            List<File> nested=StorageFiles.list(root.toFile(),root.resolve("Album/Nested").toFile(),()->{});
            check(nested.size()==2&&nested.get(0).isDirectory()&&nested.get(1).getName().equals("two.mp4"),"folder-first direct listing excludes .nomedia marker");
            List<File> streamed=new ArrayList<>();
            List<File> album=StorageFiles.collect(root.toFile(),Arrays.asList(root.resolve("Album").toFile(),root.resolve("Album/Nested").toFile(),root.resolve("Album/one.jpg").toFile()),()->{},batch->{
                streamed.addAll(batch);try{batch.clear();throw new AssertionError("batch can be mutated");}catch(UnsupportedOperationException expected){}
            });
            check(album.size()==2&&album.get(0).getName().equals("two.mp4")&&album.get(1).getName().equals("one.jpg"),"nested folders, files and aliases deduplicate canonical URIs");
            check(new HashSet<>(streamed).equals(new HashSet<>(album))&&streamed.size()==album.size(),"streamed selections cover exact result");
            check(StorageFiles.relativeDirectory(root.toFile(),root.resolve("Album/Nested/two.mp4").toFile()).equals("Album/Nested/"),"transfer metadata preserves nested original directory");
            check(StorageFiles.relativeDirectory(root.toFile(),root.resolve("Album/duplicate.jpg").toFile()).equals("Album/"),"transfer metadata uses canonical alias parent");
            file(root,"root-file.txt");check(StorageFiles.relativeDirectory(root.toFile(),root.resolve("root-file.txt").toFile()).isEmpty(),"root-level file keeps default receiver directory");
            Files.delete(root.resolve("root-file.txt"));
            rejected(()->StorageFiles.relativeDirectory(root.toFile(),outside.resolve("outside.pdf").toFile()),"outside transfer metadata");
            rejected(()->StorageFiles.relativeDirectory(root.toFile(),root.resolve("Android/data/Private/hidden.pdf").toFile()),"restricted transfer metadata");
            List<File> all=StorageFiles.collect(root.toFile(),Collections.singletonList(root.toFile()),()->{});
            check(all.size()==4,"select all retains shared Android/media and excludes restricted storage, escape, loops and markers");
            rejected(()->StorageFiles.list(root.toFile(),outside.toFile(),()->{}),"outside storage browsing");
            rejected(()->StorageFiles.collect(root.toFile(),Collections.singletonList(root.resolve("escape").toFile()),()->{}),"outside folder selection");
            rejected(()->StorageFiles.collect(root.toFile(),Collections.singletonList(root.resolve("Android/data").toFile()),()->{}),"explicit restricted selection");
            rejected(()->StorageFiles.collect(root.toFile(),Collections.singletonList(root.resolve("missing").toFile()),()->{}),"vanished selected file");
            File noPermission=new DeniedDirectory(root.resolve("denied").toString(),false,false);
            File nullListing=new DeniedDirectory(root.resolve("null-listing").toString(),true,false);
            File securityListing=new DeniedDirectory(root.resolve("security-listing").toString(),true,true);
            rejected(()->StorageFiles.list(root.toFile(),noPermission,()->{}),"folder read permission");
            rejected(()->StorageFiles.collect(root.toFile(),Collections.singletonList(nullListing),()->{}),"unreadable recursive selection");
            rejected(()->StorageFiles.list(root.toFile(),securityListing,()->{}),"provider listing denied");
            File interruptedFolder=new ListedDirectory(root.resolve("virtual").toString(),root.resolve("Album/one.jpg").toFile(),nullListing);
            List<File> partialProgress=new ArrayList<>();
            rejected(()->StorageFiles.collect(root.toFile(),Collections.singletonList(interruptedFolder),()->{},batch->partialProgress.addAll(batch)),"transaction with a nested denied folder");
            check(partialProgress.size()==1,"progress may precede nested failure; folder commit requires successful return");
            Path empty=Files.createDirectories(root.resolve("Empty"));check(StorageFiles.collect(root.toFile(),Collections.singletonList(empty.toFile()),()->{}).isEmpty(),"empty folder selection succeeds without invented files");
            final boolean[] stop={false};final int[] checks={0};
            try{StorageFiles.collect(root.toFile(),Collections.singletonList(root.toFile()),()->{checks[0]++;if(stop[0])throw new IOException("cancelled");},batch->{stop[0]=true;});throw new AssertionError("folder cancellation ignored");}
            catch(IOException expected){check(expected.getMessage().equals("cancelled")&&checks[0]<100,"cancel after first result interrupts traversal");}
        }finally{
            for(Path directory:Arrays.asList(root,outside))try(java.util.stream.Stream<Path> walk=Files.walk(directory)){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException ignored){}});}
        }
        System.out.println("PASS: immediate storage listing, recursive folder selection, canonical deduplication and transfer paths, shared-storage confinement, nested failure transactions, empty folders, access/read errors and cancellation");
    }
}
