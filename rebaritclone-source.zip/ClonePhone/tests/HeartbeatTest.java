import com.abdulla.clonephone.SecureChannel;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/** Exercise real socket read deadlines while authenticated heartbeats share the data stream. */
public class HeartbeatTest {
 static final byte[] key=SecureChannel.parseCode(SecureChannel.newCode());
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static void waitsAndConcurrentData()throws Exception{
  ExecutorService pool=Executors.newSingleThreadExecutor();
  byte[] payload=new byte[262144];new Random(17).nextBytes(payload);
  try(ServerSocket listener=new ServerSocket(0)){
   Future<Boolean> receiver=pool.submit(()->{try(Socket socket=listener.accept()){
    socket.setSoTimeout(180);SecureChannel channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,true);
    try(SecureChannel.Keepalive pulse=channel.startKeepalive(20)){
     check(Arrays.equals(channel.read(),new byte[]{0}),"zero byte changed");
     check(Arrays.equals(channel.read(),new byte[]{1}),"one byte confused with heartbeat");
     check(channel.read().length==0,"empty payload confused with heartbeat");
     for(int i=0;i<48;i++)check(Arrays.equals(channel.read(),payload),"concurrent ciphertext/data corrupted");
     // Represents local prefix verification or destination publication longer than the peer deadline.
     Thread.sleep(600);channel.write(new byte[]{2});
    }
    return true;
   }});
   try(Socket socket=new Socket("127.0.0.1",listener.getLocalPort())){
    socket.setSoTimeout(180);SecureChannel channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,false);
    try(SecureChannel.Keepalive pulse=channel.startKeepalive(20)){
     Thread.sleep(600);channel.write(new byte[]{0});channel.write(new byte[]{1});channel.write(new byte[0]);
     for(int i=0;i<48;i++){if(i==47)channel.write(payload);else channel.writeBuffered(payload,payload.length);if(i%8==0)Thread.sleep(25);}
     // Reads absorb heartbeats while the peer is publishing.
     check(Arrays.equals(channel.read(),new byte[]{2}),"late ACK");
    }
   }
   check(receiver.get(5,TimeUnit.SECONDS),"receiver failed");
  }finally{pool.shutdownNow();}
 }
 static void oldVersionRejected()throws Exception{
  try(ServerSocket listener=new ServerSocket(0)){
   ExecutorService pool=Executors.newSingleThreadExecutor();
   try{
    Future<?> old=pool.submit(()->{try(Socket socket=listener.accept()){
     DataOutputStream out=new DataOutputStream(socket.getOutputStream());out.writeInt(0x43503034);out.write(new byte[32]);out.flush();
    }catch(IOException e){throw new UncheckedIOException(e);}});
    try(Socket socket=new Socket("127.0.0.1",listener.getLocalPort())){
     try{new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,false);throw new AssertionError("old peer accepted");}
     catch(IOException expected){check(expected.getMessage().contains("update both phones"),"missing version guidance");}
    }
    old.get(3,TimeUnit.SECONDS);
   }finally{pool.shutdownNow();}
  }
 }
 public static void main(String[] args)throws Exception{
  waitsAndConcurrentData();oldVersionRejected();
  System.out.println("PASS: authenticated heartbeat survives 180ms peer deadline during 600ms local waits, concurrent encrypted data retains exact bytes, empty/control-like file payloads stay distinct, old peer rejected");
 }
}
