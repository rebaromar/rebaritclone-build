import com.abdulla.clonephone.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class ResumeTest {
 static byte[] source=new byte[3*1048576+37];
 static byte[] key;
 static AtomicInteger published=new AtomicInteger();
 static class DirectStore implements ResumableFile.Storage {
  final File file;
  boolean failWrite;
  DirectStore(File file){this.file=file;}
  public long length(){return file.length();}
  public InputStream openRead()throws IOException{return new FileInputStream(file);}
  public String identity(){return "pending:"+file.getAbsolutePath();}
  public void discard()throws IOException{if(file.exists()&&!file.delete())throw new IOException("delete");}
  public ResumableFile.RandomAccess openWrite()throws IOException{
   RandomAccessFile out=new RandomAccessFile(file,"rw");
   return new ResumableFile.RandomAccess(){
    public void seek(long offset)throws IOException{out.seek(offset);}
    public void write(byte[] bytes,int offset,int length)throws IOException{
     if(failWrite){failWrite=false;out.write(bytes,offset,Math.min(8192,length));throw new IOException("provider partial write");}
     out.write(bytes,offset,length);
    }
    public void truncate(long length)throws IOException{out.setLength(length);}
    public void sync()throws IOException{out.getFD().sync();}
    public void close()throws IOException{out.close();}
   };
  }
 }
 static void transfer(ResumableFile.Entry entry,boolean interrupt,boolean lostAck,byte[] data)throws Exception{
  transfer(entry,interrupt,lostAck,false,data);
 }
 static void transfer(ResumableFile.Entry entry,boolean interrupt,boolean lostAck,boolean prefixInterrupt,byte[] data)throws Exception{
  ExecutorService pool=Executors.newSingleThreadExecutor();
  try(ServerSocket listener=new ServerSocket(0)){
   Future<Long> server=pool.submit(()->{try(Socket s=listener.accept()){
    s.setSoTimeout(3000);SecureChannel c=new SecureChannel(s.getInputStream(),s.getOutputStream(),key,true);
    return ResumableFile.receiveDirect(c,entry,data.length,n->{if(interrupt&&n>=1048576){s.close();throw new EOFException("intentional disconnect");}},state->{
     try(InputStream in=new BufferedInputStream(state.storage.openRead())){for(byte expected:data)if(in.read()!=(expected&255))throw new AssertionError("wrong published bytes");if(in.read()!=-1)throw new AssertionError("extra bytes");}
     published.incrementAndGet();if(lostAck)s.close();
    });
   }});
   Exception clientError=null;
   try(Socket s=new Socket("127.0.0.1",listener.getLocalPort())){
    s.setSoTimeout(3000);SecureChannel c=new SecureChannel(s.getInputStream(),s.getOutputStream(),key,false);
    ResumableFile.send(c,new ByteArrayInputStream(data),data.length,262144,n->{if(prefixInterrupt&&n<0)throw new TransferFailure.TransportException("Connection lost",new SocketException("intentional prefix-check transport loss"));});
   }catch(Exception e){clientError=e;}
   Exception serverError=null;try{server.get(8,TimeUnit.SECONDS);}catch(ExecutionException e){serverError=(Exception)e.getCause();}
   if(interrupt||lostAck||prefixInterrupt){if(clientError==null||serverError==null)throw new AssertionError("expected disconnect");}
   else if(clientError!=null||serverError!=null)throw new AssertionError("unexpected failure",clientError!=null?clientError:serverError);
  }finally{pool.shutdownNow();}
 }
 public static void main(String[] args)throws Exception{
  new Random(123).nextBytes(source);key=SecureChannel.parseCode(SecureChannel.newCode());
  File f=File.createTempFile("resume-test-",".part");ResumableFile.Entry e=new ResumableFile.Entry(f);
  transfer(e,true,false,source);if(e.done||f.length()!=1048576)throw new AssertionError("checkpoint not preserved");
  transfer(e,false,false,true,source);if(e.done||f.length()!=1048576)throw new AssertionError("wire loss during prefix check erased valid bytes");
  transfer(e,false,true,source);if(!e.done||published.get()!=1)throw new AssertionError("commit before ACK");
  transfer(e,false,false,source);if(published.get()!=1)throw new AssertionError("duplicate publish");
  // Corrupt retained prefix: neither side may append or publish it.
  ResumableFile.Entry bad=new ResumableFile.Entry(File.createTempFile("resume-bad-",".part"));Files.write(bad.partial.toPath(),new byte[1048576]);
  try{transfer(bad,false,false,source);throw new AssertionError("corrupt prefix accepted");}catch(AssertionError expected){if(!"unexpected failure".equals(expected.getMessage()))throw expected;}
  if(bad.partial.length()!=0||bad.done||published.get()!=1)throw new AssertionError("bad prefix retained");
  transfer(bad,false,false,source);if(published.get()!=2)throw new AssertionError();
  ResumableFile.Entry empty=new ResumableFile.Entry(File.createTempFile("resume-empty-",".part"));transfer(empty,false,false,new byte[0]);transfer(empty,false,false,new byte[0]);if(published.get()!=3)throw new AssertionError("empty file duplicated");
  // Direct pending destinations resume without another full-size temporary file and remain after publication.
  DirectStore store=new DirectStore(File.createTempFile("resume-direct-",".part"));ResumableFile.Entry direct=new ResumableFile.Entry(store);
  ResumableFile.Entry[] persisted={null};
  direct.checkpoint=state->{if(!state.done)throw new AssertionError("commit saved before completion");ResumableFile.Entry saved=new ResumableFile.Entry(store);saved.done=state.done;saved.length=state.length;saved.digest=state.digest.clone();persisted[0]=saved;};
  transfer(direct,true,false,source);if(direct.partial!=null||store.length()!=1048576)throw new AssertionError("direct prefix lost");
  transfer(direct,false,true,source);if(!direct.done||store.length()!=source.length||persisted[0]==null)throw new AssertionError("direct commit not saved before ACK");
  transfer(persisted[0],false,false,source);if(published.get()!=4||!store.file.exists())throw new AssertionError("persisted completed destination republished/deleted");
  // A provider can partially write then throw: the incomplete record must not become a checkpoint.
  DirectStore failed=new DirectStore(File.createTempFile("resume-write-failure-",".part"));failed.failWrite=true;ResumableFile.Entry rollback=new ResumableFile.Entry(failed);
  try{transfer(rollback,false,false,source);throw new AssertionError("partial provider write accepted");}catch(AssertionError expected){if(!"unexpected failure".equals(expected.getMessage()))throw expected;}
  if(failed.length()!=0||rollback.done)throw new AssertionError("unauthenticated partial write retained");
  transfer(rollback,false,false,source);if(published.get()!=5)throw new AssertionError("provider retry failed");
  System.out.println("PASS: mid-file/prefix-check disconnect retains exact bytes, SHA-256, lost ACK deduplication after checkpoint restore, corrupt prefix reset, direct pending storage remains, partial provider write rollback, empty file and short tail");
 }
}
