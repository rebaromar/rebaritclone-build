import com.abdulla.clonephone.WifiBandPolicy;
import java.util.Arrays;

public class WifiBandPolicyTest {
    private static void expect(boolean value,String reason){if(!value)throw new AssertionError(reason);}
    public static void main(String[] args){
        for(int sdk:new int[]{23,25,26,28}){
            expect(WifiBandPolicy.canSelect(sdk,true,true,true,true,true,5975,0),"legacy Auto available");
            for(int band:new int[]{24,5,6})expect(!WifiBandPolicy.canSelect(sdk,true,true,true,true,true,5975,band),"legacy explicit band forbidden");
        }
        expect(WifiBandPolicy.canSelect(29,true,true,true,true,false,0,5),"API29 5 GHz");
        expect(!WifiBandPolicy.canSelect(35,true,false,true,true,true,5975,5),"P2P absent");
        expect(!WifiBandPolicy.canSelect(35,true,true,true,false,false,0,5),"5 GHz radio absent");
        expect(!WifiBandPolicy.canSelect(33,true,true,true,true,true,5975,6),"6 GHz needs channel API");
        expect(!WifiBandPolicy.canSelect(35,true,true,true,true,true,0,6),"6 GHz needs allowed channel");
        expect(WifiBandPolicy.canSelect(34,true,true,true,true,true,5975,6),"permitted 6 GHz");
        for(int band:new int[]{24,5,6})expect(!WifiBandPolicy.matches(band,0),"unknown frequency never confirms explicit band");
        expect(WifiBandPolicy.matches(24,2412)&&!WifiBandPolicy.matches(24,5180),"2.4 GHz matching");
        expect(WifiBandPolicy.matches(5,5180)&&!WifiBandPolicy.matches(5,5975),"5 GHz matching");
        expect(WifiBandPolicy.matches(6,5935)&&WifiBandPolicy.matches(6,7115),"6 GHz valid edges");
        for(int f:new int[]{0,5925,5945,5960,7135})expect(!WifiBandPolicy.matches(6,f),"invalid 6 GHz channel "+f);
        expect(WifiBandPolicy.choose6GHzFrequency(new int[]{5955,6135,5975,5180},new int[]{8,8,8,8},8)==5975,"lowest permitted PSC preferred");
        expect(WifiBandPolicy.choose6GHzFrequency(new int[]{5975,5955},new int[]{1,8},8)==5955,"station-only channel ignored");
        expect(WifiBandPolicy.choose6GHzFrequency(new int[]{5975},new int[]{0},8)==0,"unknown operational mode rejected");
        expect(Arrays.equals(WifiBandPolicy.automaticBands(true,true,true),new int[]{6,5,24}),"Auto descending band fallback");
        expect(Arrays.equals(WifiBandPolicy.automaticBands(false,true,false),new int[]{5}),"Auto excludes unavailable bands");
        expect(WifiBandPolicy.automaticBands(false,false,false).length==0,"Auto can use local hotspot only");
        System.out.println("PASS: band availability, allowed 6 GHz channel selection, verified frequencies, and Auto fallback order");
    }
}
