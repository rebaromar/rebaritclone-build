import com.abdulla.clonephone.TransferStats;
public class TransferStatsTest {
 public static void main(String[] args){
  TransferStats s=new TransferStats(new String[]{"one.jpg","two.mp4","three.heic","app.rbapp","notes.txt"},new String[]{"image/jpeg","video/mp4","application/octet-stream","application/x-rebaritclone-app","text/plain"},new long[]{1000000000L,2000000000L,500000000L,0,0});
  if(s.totalBytes!=3500000000L||!s.totalKnown||s.total(0)!=2||s.total(1)!=1||s.total(2)!=1||s.total(3)!=1)throw new AssertionError("totals");
  if(s.remaining(0,0)!=2||s.remaining(0,1)!=1||s.remaining(1,1)!=1||s.remaining(1,2)!=0)throw new AssertionError("completion boundary");
  if(s.remainingBytes(1250000000L)!=2250000000L||s.remainingBytes(4000000000L)!=0)throw new AssertionError("partial/resumed bytes");
  if(s.remaining(0,5)!=0||s.remaining(3,5)!=0)throw new AssertionError("end");
  TransferStats u=new TransferStats(new String[]{"clip"},new String[]{"video/mp4"},new long[]{-1});if(u.totalKnown||u.remainingBytes(1)!=-1)throw new AssertionError("unknown size fabricated");
  TransferStats z=new TransferStats(new String[]{},new String[]{},new long[]{});if(z.count!=0||z.totalBytes!=0||z.remaining(0,0)!=0)throw new AssertionError("empty");
  if(!"954 MB".equals(TransferStats.gb(1000000000L))||!"100 B".equals(TransferStats.gb(100))||!"1.00 KB".equals(TransferStats.size(1024))||!"1.00 GB".equals(TransferStats.size(1073741824L)))throw new AssertionError("binary units");
  long largeSize=220000000000L,resumed=173456789123L;
  TransferStats large=new TransferStats(new String[]{"large.zip","next.pdf"},new String[]{"application/zip","application/pdf"},new long[]{largeSize,10000000000L});
  if(!large.totalKnown||large.totalBytes!=230000000000L||large.remainingBytes(resumed)!=56543210877L)throw new AssertionError("220 GB resumed byte accounting narrowed");
  if(large.remaining(3,0)!=2||large.remaining(3,1)!=1||large.remainingBytes(largeSize)!=10000000000L||large.remainingBytes(230000000000L)!=0)throw new AssertionError("large acknowledgement and completion boundaries");
  if(!"205 GB".equals(TransferStats.size(largeSize))||!"1.00 TB".equals(TransferStats.size(1099511627776L)))throw new AssertionError("large binary units");
  System.out.println("PASS: mixed media counts, acknowledged boundaries, exact 220 GB resumed/remaining byte accounting, unknown size, empty selection and suitable binary units");
 }
}
