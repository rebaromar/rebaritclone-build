package com.abdulla.clonephone;

import java.util.*;

public final class PermissionPlanTest {
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static boolean includes(List<String[]> steps, String name) {
        for (String[] group : steps) for (String permission : group)
            if (permission.equals("android.permission." + name)) return true;
        return false;
    }

    private static void verify(int sdk) {
        List<String[]> steps = PermissionPlan.forStartup(sdk);
        Set<String> seen = new HashSet<>();
        for (String[] group : steps) for (String permission : group)
            check(seen.add(permission), "duplicated startup permission " + permission);
        check(includes(steps, "READ_CONTACTS"), "contacts missing");
        check(includes(steps, "CAMERA"), "camera missing");
        check(includes(steps, "BLUETOOTH_CONNECT") == (sdk >= 31), "Bluetooth SDK boundary");
        check(includes(steps, "READ_MEDIA_VISUAL_USER_SELECTED") == (sdk >= 34), "photo SDK boundary");
        check(includes(steps, "NEARBY_WIFI_DEVICES") == (sdk >= 33), "Wi-Fi SDK boundary");
        check(includes(steps, "READ_EXTERNAL_STORAGE") == (sdk < 33), "storage SDK boundary");
        if (sdk < 33) {
            boolean grouped = false;
            for (String[] group : steps) if (Arrays.asList(group).contains("android.permission.ACCESS_FINE_LOCATION"))
                grouped = Arrays.asList(group).contains("android.permission.ACCESS_COARSE_LOCATION");
            check(grouped, "location permission grouping");
        }
    }

    public static void main(String[] args) {
        for (int sdk : new int[]{23, 29, 31, 32, 33, 34, 35}) verify(sdk);
    }
}
