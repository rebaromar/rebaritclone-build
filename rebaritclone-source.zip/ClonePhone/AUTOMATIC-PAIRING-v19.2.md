# REBARIT CLONE 19.2 (versionCode 192)

Phone Clone keeps both Scan QR and Automatic connection. Automatic Wi-Fi Direct hosting now delegates band choice to the existing automatic policy, which prefers supported higher bands and falls back when Android cannot create the group. The receiver does not pin automatic mode to 2.4 GHz.

Large selections avoid date sorting in transfer-only MediaStore queries. Application export resolves the user's selected package names directly. The encrypted transport, resume checkpoints, SHA-256 checks, and durable file commits are unchanged.

Validate with two real phones: note the negotiated Wi-Fi frequency, transfer the same large selection three times on both Auto and explicit 5 GHz, and compare preparation time and sustained MB/s. Then interrupt a 5–10 GB transfer and verify resume and final SHA-256. These physical tests have not been performed in this workspace.
