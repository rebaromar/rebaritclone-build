# REBARIT CLONE Full VIP — v11.9
Implemented on top of v11.8 without removing USB/Turbo Wi‑Fi/path/date preservation.

1. Smart Clone VIP entry: one prominent entry into the existing connection/selection journey; existing engine still chooses the available transport path.
2. Transfer preflight foundation: storage + battery + privacy summary helpers; receiver refuses transfers that cannot fit.
3. Smart Resume: existing resumable-file engine retained; manifest identity now includes original path/date metadata where applicable.
4. Duplicate Protection: receiver checks same relative folder + filename + byte size and reuses/skips an existing item instead of overwriting it.
5. Clone summary: existing selection stats retained; VIP preflight/transfer records add file counts and transferred bytes.
6. Auto Install Queue: existing AppInstallActivity sequential install queue retained.
7. Transfer Health: existing live MB/s/ETA/progress retained; battery/storage health helpers added while Wi-Fi high-performance lock remains from v11.7.
8. Privacy Mode: enabled by default; ordinary selection excludes protected/private Android roots and transfer remains direct device-to-device.
9. Migration Checklist / history: persistent transfer history records Sent/Received counts and bytes.
10. Smart Clone: prominent VIP button integrated into Home.

Android restrictions remain: install/uninstall confirmations, private app data, protected Android folders and OEM Wi-Fi behavior cannot be bypassed by a normal app.
