# REBARIT High-Speed USB Engine — v11.5
- Android 9+ USB bulk I/O: 256 KiB per native transfer.
- Android 8.x compatibility fallback: 16 KiB.
- Accessory-side stream buffering: 512 KiB.
- USB payload frame: up to 1 MiB authenticated frame.
- Existing AES-GCM authentication, SHA-256 verification, resume, cancel and live speed/progress remain active.
- No unnecessary compression for already-compressed media/APK/ZIP.
- Real throughput is automatically bounded by the slower device, cable, storage and Android USB stack.
