package com.abdulla.clonephone;

import java.util.Locale;

/** Compatible MediaStore destination, preserving the source's safe folder hierarchy. */
final class MediaDestination {
    private MediaDestination(){}

    static String relativePath(String mime,String safeOriginal,int sdk){
        String type=mime==null?"":mime.toLowerCase(Locale.ROOT);
        String fallback=type.startsWith("image/")?"Pictures":type.startsWith("video/")?"Movies":type.startsWith("audio/")?"Music":"Download";
        String path=normalize(safeOriginal);
        if(path.isEmpty())return fallback+"/";
        int slash=path.indexOf('/');String primary=slash<0?path:path.substring(0,slash);
        String canonical=acceptedPrimary(type,primary,sdk);
        if(canonical!=null)return canonical+(slash<0?"/":path.substring(slash)+"/");
        return fallback+"/"+path+"/";
    }

    private static String acceptedPrimary(String mime,String primary,int sdk){
        if(mime.startsWith("image/"))return first(primary,"DCIM","Pictures");
        if(mime.startsWith("video/"))return first(primary,"DCIM","Movies");
        if(mime.startsWith("audio/")){
            String common=first(primary,"Music","Podcasts","Ringtones","Alarms","Notifications");
            if(common!=null)return common;
            if(sdk>=29&&primary.equalsIgnoreCase("Audiobooks"))return "Audiobooks";
            if(sdk>=31&&primary.equalsIgnoreCase("Recordings"))return "Recordings";
            return null;
        }
        return first(primary,"Download","Documents");
    }
    private static String first(String primary,String... allowed){for(String name:allowed)if(primary.equalsIgnoreCase(name))return name;return null;}
    // Callers sanitize individual directory names before choosing the destination.
    private static String normalize(String path){
        if(path==null||path.isEmpty())return "";
        StringBuilder result=new StringBuilder();
        for(String part:path.replace('\\','/').split("/")){if(part.isEmpty())continue;if(result.length()>0)result.append('/');result.append(part);}
        return result.toString();
    }
}
