package com.abdulla.clonephone;

import java.io.IOException;

/** Final batch receipts after every file has already been durably acknowledged. */
public final class TransferCompletion {
    private TransferCompletion() { }

    private static void expect(SecureChannel channel, int value) throws Exception {
        byte[] frame = channel.read();
        if (frame.length != 1 || frame[0] != value) throw new IOException("Invalid completion receipt");
    }

    private static boolean transport(Exception error, boolean usb) {
        return usb ? TransferFailure.usb(error) : TransferFailure.network(error);
    }

    /** Call only after every ResumableFile.send returned: all per-file ACKs were received. */
    public static void sender(SecureChannel channel, boolean usb) throws Exception {
        try {
            expect(channel, 3);
            channel.write(new byte[]{4});
        } catch (Exception error) {
            // A lost final receipt cannot undo outputs whose durable file ACKs reached us.
            if (!transport(error, usb)) throw error;
        }
    }

    /** Call only after every receiveDirect returned, including its durable commit and file ACK. */
    public static void receiver(SecureChannel channel, boolean usb) throws Exception {
        try {
            channel.write(new byte[]{3});
            expect(channel, 4);
        } catch (Exception error) {
            // File ACK write failures occur before this method and still take the resume path.
            if (!transport(error, usb)) throw error;
        }
    }
}
