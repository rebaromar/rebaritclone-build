package com.abdulla.clonephone

import android.graphics.Color

/** Modern design tokens shared by the Java screens while the app migrates incrementally to Kotlin. */
object VipDesign {
    @JvmField val BG = Color.rgb(5, 11, 18)
    @JvmField val SURFACE = Color.rgb(13, 24, 34)
    @JvmField val SURFACE_2 = Color.rgb(18, 34, 46)
    @JvmField val TEXT = Color.rgb(244, 250, 255)
    @JvmField val MUTED = Color.rgb(142, 166, 184)
    @JvmField val CYAN = Color.rgb(0, 218, 255)
    @JvmField val VIOLET = Color.rgb(124, 77, 255)
    @JvmField val GREEN = Color.rgb(0, 229, 155)
    @JvmField val RED = Color.rgb(255, 78, 103)
    @JvmField val LINE = Color.rgb(34, 56, 72)
}
