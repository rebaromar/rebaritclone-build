package com.abdulla.clonephone;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Received-app inbox. Installation is always controlled by the receiving phone.
 * Nothing is silently installed: the user taps Install and Android shows its own
 * trusted confirmation UI. After a successful install the row changes to Open.
 */
@SuppressWarnings("deprecation")
public class AppInstallActivity extends Activity {
    private static final int UNKNOWN_SOURCE_REQUEST=42;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayList<Entry> entries=new ArrayList<>();
    private final ArrayList<File> inspectTemps=new ArrayList<>();
    private LinearLayout list;
    private TextView counter;
    private volatile int sessionId=-1;
    private int activeIndex=-1,pendingPermissionIndex=-1;
    private PendingIntent callback;
    private Intent approvalIntent;
    private boolean destroyed,resumed;
    private String action;

    private static final class Entry {
        String uri,name,pkg="";
        Drawable icon;
        boolean working;
        LinearLayout row;
        ImageView iconView;
        TextView status;
        Button button;
        Entry(String u,String n){uri=u;name=n;}
    }

    private final BroadcastReceiver receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent intent){
        if(!action.equals(intent.getAction()))return;
        int id=intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID,-2);
        if(id<0||id!=sessionId||activeIndex<0||activeIndex>=entries.size())return;
        int status=intent.getIntExtra(PackageInstaller.EXTRA_STATUS,PackageInstaller.STATUS_FAILURE);
        String pkg=intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME);
        if(pkg!=null&&!pkg.isEmpty())entries.get(activeIndex).pkg=pkg;
        if(status==PackageInstaller.STATUS_PENDING_USER_ACTION){
            approvalIntent=intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if(approvalIntent==null){finishInstall(false,"پەنجەرەی دامەزراندن نەکرایەوە");return;}
            launchApproval();return;
        }
        finishInstall(status==PackageInstaller.STATUS_SUCCESS,status==PackageInstaller.STATUS_SUCCESS?"دامەزرا":"دامەزراندن تەواو نەبوو");
    }};

    @Override public void onCreate(Bundle saved){super.onCreate(saved);UiText.init(this);
        ArrayList<String> uris=getIntent().getStringArrayListExtra("uris");
        ArrayList<String> names=getIntent().getStringArrayListExtra("names");
        if(uris==null||names==null||uris.size()!=names.size()||uris.isEmpty()){finish();return;}
        for(int i=0;i<uris.size();i++)entries.add(new Entry(uris.get(i),names.get(i)));
        action=getPackageName()+".INSTALL."+UUID.randomUUID();
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,new IntentFilter(action),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,new IntentFilter(action));
        buildUi();
        resolveEntries();
        new Handler(Looper.getMainLooper()).postDelayed(()->{
            if(isFinishing()||isDestroyed())return;
            new AlertDialog.Builder(this)
                    .setTitle("ئەپە وەرگیراوەکان ئامادەن")
                    .setMessage("دەتەوێت ئێستا لەم مۆبایلە تازەیە بە دەستی خۆت دایانبمەزرێنیت؟")
                    .setPositiveButton("بەڵێ",null)
                    .setNegativeButton("دواتر",(d,w)->finish())
                    .show();
        },220);
    }

    private void buildUi(){
        getWindow().setStatusBarColor(0xff050b12);getWindow().setNavigationBarColor(0xff050b12);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(22),dp(18),dp(22));root.setBackgroundColor(0xff050b12);root.setLayoutDirection(UiText.direction());
        TextView brand=label("REBARIT CLONE",12,0xff6f8299,true);brand.setLetterSpacing(.14f);root.addView(brand);
        TextView title=label("ئەپە وەرگیراوەکان",28,Color.WHITE,true);title.setPadding(0,dp(7),0,dp(4));root.addView(title);
        TextView sub=label("دامەزراندن تەنها لەم مۆبایلە تازەیە کۆنترۆڵ دەکرێت. بۆ هەر ئەپێک Install دابگرە؛ Android خۆی ڕەزامەندی لێ دەپرسی.",13,0xff94a7bc,false);sub.setLineSpacing(0,1.12f);root.addView(sub);
        counter=label("",13,0xff63dbc6,true);counter.setPadding(0,dp(12),0,dp(14));root.addView(counter);

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        for(int i=0;i<entries.size();i++)addRow(i);

        TextView note=label("Install = دامەزراندن   •   Open = کردنەوەی ئەپی دامەزراو",12,0xff718398,false);note.setGravity(Gravity.CENTER);note.setPadding(0,dp(12),0,dp(8));root.addView(note);
        Button done=button("تەواو",0xff182432);done.setOnClickListener(v->finish());root.addView(done,new LinearLayout.LayoutParams(-1,dp(50)));
        setContentView(root);refreshAll();
    }

    private void addRow(int index){
        Entry e=entries.get(index);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(13),dp(12),dp(13));row.setBackground(card());
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,0,0,dp(10));list.addView(row,rp);e.row=row;
        ImageView icon=new ImageView(this);icon.setImageDrawable(getPackageManager().getDefaultActivityIcon());icon.setScaleType(ImageView.ScaleType.FIT_CENTER);row.addView(icon,new LinearLayout.LayoutParams(dp(50),dp(50)));e.iconView=icon;
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(12),0,dp(8),0);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView name=label(cleanName(e.name),15,Color.WHITE,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);words.addView(name);
        TextView status=label("پشکنین…",11,0xff899bb0,false);status.setPadding(0,dp(4),0,0);words.addView(status);e.status=status;
        Button actionButton=button("Install",0xff2563eb);actionButton.setTextSize(12);actionButton.setMinWidth(0);row.addView(actionButton,new LinearLayout.LayoutParams(dp(94),dp(44)));e.button=actionButton;
        actionButton.setOnClickListener(v->onAction(index));
    }

    private void onAction(int index){
        if(index<0||index>=entries.size())return;Entry e=entries.get(index);
        if(e.working)return;
        if(isInstalled(e.pkg)){
            Intent launch=getPackageManager().getLaunchIntentForPackage(e.pkg);
            if(launch!=null){try{startActivity(launch);}catch(Exception ignored){}}return;
        }
        beginInstall(index);
    }

    private void beginInstall(int index){
        if(activeIndex>=0||index<0||index>=entries.size())return;
        if(!getPackageManager().canRequestPackageInstalls()){
            pendingPermissionIndex=index;
            try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())),UNKNOWN_SOURCE_REQUEST);}catch(Exception ignored){}
            return;
        }
        Entry e=entries.get(index);activeIndex=index;e.working=true;refreshRow(index);
        worker.execute(()->{int created=-1;boolean committed=false;
            try{
                PackageInstaller installer=getPackageManager().getPackageInstaller();
                PackageInstaller.SessionParams params=new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
                if(!e.pkg.isEmpty())params.setAppPackageName(e.pkg);
                if(Build.VERSION.SDK_INT>=31)params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_REQUIRED);
                created=installer.createSession(params);sessionId=created;
                try(PackageInstaller.Session session=installer.openSession(created);InputStream source=getContentResolver().openInputStream(Uri.parse(e.uri))){
                    if(source==null)throw new IOException("File unavailable");
                    if(e.name.toLowerCase(Locale.ROOT).endsWith(".rbapp"))AppBundle.read(source,(part,in)->stage(session,part,in));else stage(session,"base.apk",source);
                    Intent result=new Intent(action).setPackage(getPackageName());int flags=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=31)flags|=PendingIntent.FLAG_MUTABLE;
                    callback=PendingIntent.getBroadcast(this,created,result,flags);session.commit(callback.getIntentSender());committed=true;
                }
            }catch(Exception ex){if(created>=0)try{getPackageManager().getPackageInstaller().abandonSession(created);}catch(Exception ignored){}runOnUiThread(()->finishInstall(false,"هەڵە لە ئامادەکردنی ئەپ"));}
            finally{if(!committed&&callback!=null){callback.cancel();callback=null;}}
        });
    }

    private void stage(PackageInstaller.Session session,String name,InputStream in)throws Exception{
        try(OutputStream out=session.openWrite(name,0,-1)){byte[] data=new byte[1048576];int n;long total=0;while((n=in.read(data))!=-1){if(destroyed||Thread.currentThread().isInterrupted())throw new InterruptedIOException();total+=n;if(total>AppBundle.MAX_BYTES)throw new IOException("App too large");out.write(data,0,n);}session.fsync(out);}
    }

    private void finishInstall(boolean success,String message){
        int index=activeIndex;activeIndex=-1;sessionId=-1;approvalIntent=null;
        if(callback!=null){callback.cancel();callback=null;}
        if(index>=0&&index<entries.size()){Entry e=entries.get(index);e.working=false;e.status.setText(message);refreshRow(index);}
        refreshCounter();
    }

    private void launchApproval(){if(resumed&&approvalIntent!=null){Intent i=approvalIntent;approvalIntent=null;try{startActivity(i);}catch(Exception e){finishInstall(false,"پەنجەرەی Android Install نەکرایەوە");}}}

    private void resolveEntries(){
        worker.execute(()->{for(int i=0;i<entries.size()&&!destroyed;i++){final int index=i;Entry e=entries.get(i);try{Resolved r=inspect(e);e.pkg=r.pkg;e.icon=r.icon;}catch(Exception ignored){}runOnUiThread(()->{if(!destroyed)refreshRow(index);});}});
    }

    private static final class Resolved {String pkg="";Drawable icon;}
    private Resolved inspect(Entry e)throws Exception{
        File base=File.createTempFile("received-app-",".apk",getCacheDir());inspectTemps.add(base);
        try(InputStream source=getContentResolver().openInputStream(Uri.parse(e.uri))){if(source==null)throw new IOException();
            if(e.name.toLowerCase(Locale.ROOT).endsWith(".rbapp")){
                final boolean[] got={false};AppBundle.read(source,(part,in)->{if("base.apk".equals(part)){copy(in,base);got[0]=true;}else drain(in);});if(!got[0])throw new IOException();
            }else copy(source,base);
        }
        PackageInfo pi=getPackageManager().getPackageArchiveInfo(base.getAbsolutePath(),0);Resolved r=new Resolved();if(pi!=null){r.pkg=pi.packageName==null?"":pi.packageName;if(pi.applicationInfo!=null){pi.applicationInfo.sourceDir=base.getAbsolutePath();pi.applicationInfo.publicSourceDir=base.getAbsolutePath();try{r.icon=pi.applicationInfo.loadIcon(getPackageManager());}catch(Exception ignored){}}}return r;
    }
    private static void copy(InputStream in,File file)throws Exception{try(OutputStream out=new BufferedOutputStream(new FileOutputStream(file),262144)){byte[] b=new byte[262144];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}}
    private static void drain(InputStream in)throws Exception{byte[] b=new byte[262144];while(in.read(b)!=-1){} }

    private boolean isInstalled(String pkg){if(pkg==null||pkg.isEmpty())return false;try{getPackageManager().getApplicationInfo(pkg,0);return true;}catch(Exception e){return false;}}
    private void refreshAll(){for(int i=0;i<entries.size();i++)refreshRow(i);refreshCounter();}
    private void refreshRow(int index){if(index<0||index>=entries.size())return;Entry e=entries.get(index);if(e.icon!=null)e.iconView.setImageDrawable(e.icon);
        if(e.working){e.status.setText("ئامادەکردنی دامەزراندن…");e.button.setText("…");e.button.setEnabled(false);return;}
        boolean installed=isInstalled(e.pkg);Intent launch=installed&&!e.pkg.isEmpty()?getPackageManager().getLaunchIntentForPackage(e.pkg):null;
        if(installed){e.status.setText("دامەزرا");e.button.setText(launch!=null?"Open":"Installed");e.button.setEnabled(launch!=null);e.button.setBackground(tint(launch!=null?0xff16a085:0xff263647));}
        else{e.status.setText(e.pkg.isEmpty()?"ئامادەی دامەزراندن":"دانەمەزراو");e.button.setText("Install");e.button.setEnabled(true);e.button.setBackground(tint(0xff2563eb));}
    }
    private void refreshCounter(){int installed=0;for(Entry e:entries)if(isInstalled(e.pkg))installed++;counter.setText(installed+" دامەزراو  •  "+(entries.size()-installed)+" چاوەڕێی Install");}

    @Override protected void onResume(){super.onResume();resumed=true;if(pendingPermissionIndex>=0&&getPackageManager().canRequestPackageInstalls()){int x=pendingPermissionIndex;pendingPermissionIndex=-1;beginInstall(x);}launchApproval();refreshAll();}
    @Override protected void onPause(){resumed=false;super.onPause();}
    @Override protected void onDestroy(){destroyed=true;try{unregisterReceiver(receiver);}catch(Exception ignored){}if(sessionId>=0)try{getPackageManager().getPackageInstaller().abandonSession(sessionId);}catch(Exception ignored){}if(callback!=null)callback.cancel();worker.shutdownNow();for(File f:inspectTemps)try{f.delete();}catch(Exception ignored){}super.onDestroy();}

    private String cleanName(String n){if(n==null)return "App";return n.replaceAll("(?i)\\.(rbapp|apk)$","");}
    private TextView label(String value,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String value,int color){Button b=new Button(this);b.setAllCaps(false);b.setText(value);b.setTextColor(Color.WHITE);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(tint(color));return b;}
    private GradientDrawable tint(int color){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(14));return g;}
    private GradientDrawable card(){GradientDrawable g=new GradientDrawable();g.setColor(0xff0d1722);g.setCornerRadius(dp(18));g.setStroke(dp(1),0xff223142);return g;}
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
}
