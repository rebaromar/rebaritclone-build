package com.abdulla.clonephone;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;

/** Shared native UI system. Illustrations are vectors drawn at the device resolution. */
final class CloneDesign {
    static final int BLUE=0xff4559ed, INK=0xff142440, MUTED=0xff66758d;
    static final int BG=0xfff4f6fc, LINE=0xffe2e8f3, PALE=0xffedf1ff;
    static final int NAVY=0xff101f40, TEAL=0xff47d6bd;
    static String words(String ckb,String en,String ar){return "en".equals(UiText.language())?en:"ar".equals(UiText.language())?ar:ckb;}
    static String ltr(String value){return android.text.BidiFormatter.getInstance(UiText.direction()==View.LAYOUT_DIRECTION_RTL).unicodeWrap(value,android.text.TextDirectionHeuristics.LTR);}
    static int dp(Context c,int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
    static GradientDrawable surface(Context c,int color,int border,int radius){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,radius));
        if(border!=0)d.setStroke(dp(c,1),border);return d;
    }
    static GradientDrawable gradient(Context c,int first,int second,int radius){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{first,second});d.setCornerRadius(dp(c,radius));return d;
    }
    static Drawable press(Context c,Drawable d){return new RippleDrawable(ColorStateList.valueOf(0x164559ed),d,null);}
    static TextView text(Context c,String value,int size,int color,boolean bold){
        TextView t=new TextView(c);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setGravity(Gravity.START);t.setLineSpacing(dp(c,2),1);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;
    }
    static void button(Button b,boolean primary){
        Context c=b.getContext();b.setAllCaps(false);b.setTextSize(15);b.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        b.setTextColor(primary?Color.WHITE:BLUE);b.setMinHeight(dp(c,56));b.setMinimumHeight(dp(c,56));
        b.setPadding(dp(c,18),dp(c,12),dp(c,18),dp(c,12));b.setStateListAnimator(null);
        b.setBackground(press(c,primary?gradient(c,BLUE,0xff6272f3,18):surface(c,Color.WHITE,LINE,18)));
        b.setElevation(primary?dp(c,2):0);
    }
    static void enter(View v){v.setAlpha(0);v.setTranslationY(dp(v.getContext(),8));v.animate().alpha(1).translationY(0).setDuration(220).start();}
    static LinearLayout steps(Context c,int active){
        LinearLayout line=new LinearLayout(c);line.setGravity(Gravity.CENTER_VERTICAL);line.setLayoutDirection(UiText.direction());
        for(int n=1;n<=3;n++){
            LinearLayout cell=new LinearLayout(c);cell.setGravity(Gravity.CENTER_VERTICAL);cell.setPadding(dp(c,9),dp(c,10),dp(c,7),dp(c,10));
            cell.setBackground(surface(c,n==active?PALE:Color.TRANSPARENT,n==active?0xffccd4ff:0,16));
            TextView number=text(c,n<active?"✓":String.valueOf(n),11,n<=active?Color.WHITE:MUTED,true);number.setGravity(Gravity.CENTER);
            number.setBackground(surface(c,n<active?0xff1d9a83:n==active?BLUE:0xffe5eaf3,0,20));cell.addView(number,new LinearLayout.LayoutParams(dp(c,25),dp(c,25)));
            TextView label=text(c,UiText.t(n==1?270:n==2?269:271),11,n==active?BLUE:MUTED,n==active);label.setPadding(dp(c,5),0,dp(c,2),0);cell.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(c,1),0,dp(c,1),0);line.addView(cell,lp);
        }return line;
    }
    static LinearLayout appBar(Context c,String version,Runnable back,View.OnClickListener menu){
        LinearLayout bar=new LinearLayout(c);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(0,dp(c,6),0,dp(c,10));
        if(back!=null){TextView arrow=text(c,UiText.direction()==View.LAYOUT_DIRECTION_RTL?"›":"‹",30,INK,false);arrow.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP,30);arrow.setGravity(Gravity.CENTER);arrow.setBackground(press(c,surface(c,Color.WHITE,LINE,15)));arrow.setContentDescription(words("گەڕانەوە","Back","رجوع"));bar.addView(arrow,new LinearLayout.LayoutParams(dp(c,44),dp(c,44)));arrow.setOnClickListener(v->back.run());}
        LinearLayout words=new LinearLayout(c);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(c,12),0,dp(c,8),0);bar.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView brand=text(c,"REBARIT CLONE",16,INK,true);brand.setTextDirection(View.TEXT_DIRECTION_LTR);words.addView(brand);
        TextView build=text(c,"v"+version,11,MUTED,false);build.setTextDirection(View.TEXT_DIRECTION_LTR);words.addView(build);
        if(menu!=null){TextView dots=text(c,"⋮",26,INK,true);dots.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP,26);dots.setGravity(Gravity.CENTER);dots.setContentDescription(UiText.t(262));dots.setBackground(press(c,surface(c,Color.WHITE,LINE,15)));bar.addView(dots,new LinearLayout.LayoutParams(dp(c,44),dp(c,44)));dots.setOnClickListener(menu);}
        return bar;
    }

    static final class Devices extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final boolean dark;
        Devices(Context c,boolean dark){super(c);this.dark=dark;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas c){
            float s=Math.min(getWidth()/340f,getHeight()/190f);c.save();c.translate((getWidth()-340*s)/2,(getHeight()-190*s)/2);c.scale(s,s);
            p.setColor(dark?0x1247d6bd:0xffe8edff);c.drawCircle(173,96,86,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(dark?0x2647d6bd:0xffd7def9);c.drawCircle(173,96,73,p);p.setStyle(Paint.Style.FILL);
            c.save();c.rotate(-9,108,94);phone(c,61,22,0xff7d90c7,false);c.restore();
            c.save();c.rotate(9,230,96);phone(c,194,12,0xff77e8d1,true);c.restore();
            p.setColor(dark?0xff203d6f:Color.WHITE);c.drawCircle(174,97,27,p);p.setColor(dark?TEAL:BLUE);p.setStrokeWidth(3);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(159,91,185,91,p);c.drawLine(179,85,185,91,p);c.drawLine(179,97,185,91,p);c.drawLine(185,104,159,104,p);c.drawLine(165,98,159,104,p);c.drawLine(165,110,159,104,p);
            p.setColor(TEAL);c.drawCircle(282,37,5,p);p.setColor(dark?0xff7387c1:0xffb7c6f2);c.drawCircle(49,143,4,p);c.restore();
        }
        private void phone(Canvas c,float x,float y,int edge,boolean fresh){
            p.setColor(0x14000000);c.drawRoundRect(x+2,y+5,x+80,y+159,16,16,p);
            p.setColor(edge);c.drawRoundRect(x,y,x+78,y+154,16,16,p);p.setColor(0xfff5f8ff);c.drawRoundRect(x+4,y+4,x+74,y+150,13,13,p);
            p.setColor(NAVY);c.drawRoundRect(x+26,y+8,x+52,y+13,3,3,p);
            p.setColor(fresh?0xffdbf7ef:0xffe4eaff);c.drawRoundRect(x+11,y+27,x+67,y+79,9,9,p);
            for(int n=0;n<3;n++){p.setColor(n==0?(fresh?0xff1aa991:BLUE):0xffd3dded);c.drawRoundRect(x+11,y+90+n*15,x+(n==2?49:67),y+96+n*15,3,3,p);}
            p.setColor(fresh?0xff1aa991:BLUE);c.drawCircle(x+39,y+53,13,p);p.setColor(Color.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawLine(x+33,y+53,x+38,y+58,p);c.drawLine(x+38,y+58,x+46,y+48,p);p.setStyle(Paint.Style.FILL);
        }
    }
}
