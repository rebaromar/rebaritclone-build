package com.abdulla.clonephone;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Arrays;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Versioned, bounded encrypted records. Independent keys and counters per direction. */
public final class SecureChannel {
    public static final int MAX_FRAME = 1048576;
    private final DataInputStream input;
    private final DataOutputStream output;
    private final byte[] sendKey, receiveKey;
    private final Object writeLock = new Object();
    private long sent, received;
    private final Cipher encrypt = Cipher.getInstance("AES/GCM/NoPadding");
    private final Cipher decrypt = Cipher.getInstance("AES/GCM/NoPadding");

    public SecureChannel(InputStream in, OutputStream out, byte[] master, boolean server) throws Exception {
        input = new DataInputStream(new BufferedInputStream(TransferFailure.wireInput(in), 524288));
        output = new DataOutputStream(new BufferedOutputStream(TransferFailure.wireOutput(out), 524288));
        byte[] session = new byte[32];
        if (server) {
            new SecureRandom().nextBytes(session);
            output.writeInt(0x43503035); output.write(session); output.flush();
        } else {
            if (input.readInt() != 0x43503035) throw new IOException("Protocol mismatch: update both phones");
            input.readFully(session);
        }
        sendKey = derive(master, session, server ? "server" : "client");
        receiveKey = derive(master, session, server ? "client" : "server");
        if (server) {
            if (!MessageDigest.isEqual(read(), "HELLO".getBytes(StandardCharsets.UTF_8))) throw new IOException("Pairing failed");
            write("READY".getBytes(StandardCharsets.UTF_8));
        } else {
            write("HELLO".getBytes(StandardCharsets.UTF_8));
            if (!MessageDigest.isEqual(read(), "READY".getBytes(StandardCharsets.UTF_8))) throw new IOException("Pairing failed");
        }
    }
    private static byte[] derive(byte[] master, byte[] session, String direction) throws Exception {
        javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(master, "HmacSHA256"));
        mac.update(session);
        return mac.doFinal(("rebaritclone-v5-" + direction).getBytes(StandardCharsets.UTF_8));
    }
    private byte[] nonce(long counter) { return ByteBuffer.allocate(12).putInt(0).putLong(counter).array(); }
    public void write(byte[] plain) throws Exception {
        synchronized (writeLock) { writeRecord(plain, plain.length, false); output.flush(); }
    }
    public void writeBuffered(byte[] plain, int length) throws Exception {
        synchronized (writeLock) { writeRecord(plain, length, false); }
    }
    private void writeRecord(byte[] plain, int length, boolean heartbeat) throws Exception {
        if (length < 0 || length > plain.length || length > MAX_FRAME || sent == Long.MAX_VALUE) throw new IOException("Frame limit");
        // The encrypted type byte keeps a heartbeat distinct from every possible file byte.
        byte[] record = new byte[length + 1];
        record[0] = (byte)(heartbeat ? 1 : 0);
        System.arraycopy(plain, 0, record, 1, length);
        encrypt.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(sendKey, "AES"), new GCMParameterSpec(128, nonce(sent++)));
        byte[] encrypted = encrypt.doFinal(record);
        output.writeInt(encrypted.length); output.write(encrypted);
    }
    private void writeKeepalive() throws Exception {
        synchronized (writeLock) { writeRecord(new byte[0], 0, true); output.flush(); }
    }
    public byte[] read() throws Exception {
        for (;;) {
            int size = input.readInt();
            if (size < 17 || size > MAX_FRAME + 17 || received == Long.MAX_VALUE) throw new IOException("Frame limit");
            byte[] encrypted = new byte[size]; input.readFully(encrypted);
            decrypt.init(Cipher.DECRYPT_MODE, new SecretKeySpec(receiveKey, "AES"), new GCMParameterSpec(128, nonce(received++)));
            byte[] record = decrypt.doFinal(encrypted);
            if (record[0] == 1 && record.length == 1) continue;
            if (record[0] != 0) throw new IOException("Invalid record type");
            return Arrays.copyOfRange(record, 1, record.length);
        }
    }
    /** Keeps the peer's read timeout alive during local hashing, consent, sync or publishing. */
    public final class Keepalive implements Closeable {
        private final ScheduledExecutorService timer;
        private final AtomicReference<Exception> failure = new AtomicReference<>();
        private volatile boolean closed;
        private Keepalive(long intervalMillis) {
            if (intervalMillis < 1) throw new IllegalArgumentException("Keepalive interval");
            timer = Executors.newSingleThreadScheduledExecutor(task -> {
                Thread thread = new Thread(task, "clone-keepalive"); thread.setDaemon(true); return thread;
            });
            timer.scheduleWithFixedDelay(() -> {
                if (closed || failure.get() != null) return;
                try { writeKeepalive(); } catch (Exception e) { failure.compareAndSet(null, e); }
            }, intervalMillis, intervalMillis, TimeUnit.MILLISECONDS);
        }
        public void check() throws IOException {
            Exception error = failure.get();
            if (error instanceof TransferFailure.TransportException) throw (TransferFailure.TransportException)error;
            if (error != null) throw new IOException("Keepalive failed", error);
        }
        @Override public void close() throws IOException {
            closed = true; timer.shutdownNow();
            try {
                timer.awaitTermination(1000, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            // A peer may close immediately after its final ACK. Timer cleanup cannot
            // turn an already successful application operation into a failed transfer.
        }
    }
    public Keepalive startKeepalive() { return startKeepalive(10000); }
    public Keepalive startKeepalive(long intervalMillis) { return new Keepalive(intervalMillis); }
    public <T> T withKeepalive(Callable<T> job) throws Exception {
        return withKeepalive(10000, job);
    }
    public <T> T withKeepalive(long intervalMillis, Callable<T> job) throws Exception {
        try (Keepalive keepalive = startKeepalive(intervalMillis)) { return job.call(); }
    }
    public static String newCode() {
        byte[] key = new byte[16]; new SecureRandom().nextBytes(key);
        StringBuilder s = new StringBuilder(); for (byte b : key) s.append(String.format("%02X", b)); return s.toString();
    }
    public static byte[] parseCode(String text) {
        text = text.replaceAll("[\\s-]", "");
        if (!text.matches("[0-9a-fA-F]{32}")) throw new IllegalArgumentException("Pairing code must be 32 hex characters");
        byte[] key = new byte[16]; for (int i=0; i<16; i++) key[i]=(byte)Integer.parseInt(text.substring(i*2,i*2+2),16); return key;
    }
}
