package com.abdulla.clonephone;

import java.io.*;
import java.util.*;

/** Controller/source command layer used before the normal file-transfer manifest. */
final class UsbCloneProtocol {
    static final int INVENTORY_REQUEST = 41;
    static final int INVENTORY = 42;
    static final int SELECTION = 43;
    static final int PREPARING = 44;
    static final int ACCEPTED = 45;
    static final int DECLINED = 46;
    static final int ERROR = 47;
    private static final int VERSION = 1;

    static final class Category {
        final String id;
        final int count;
        final long bytes;
        Category(String id,int count,long bytes){this.id=id;this.count=count;this.bytes=bytes;}
    }

    static byte[] command(int command){return new byte[]{(byte)command};}
    static boolean is(byte[] packet,int command){return packet!=null&&packet.length==1&&(packet[0]&255)==command;}

    static byte[] encodeInventory(List<Category> categories)throws IOException{
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        DataOutputStream out=new DataOutputStream(buffer);
        out.writeByte(INVENTORY);out.writeByte(VERSION);out.writeInt(categories.size());
        for(Category c:categories){out.writeUTF(c.id);out.writeInt(c.count);out.writeLong(c.bytes);}
        out.flush();return buffer.toByteArray();
    }

    static List<Category> decodeInventory(byte[] packet)throws IOException{
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(packet));
        if(in.readUnsignedByte()!=INVENTORY||in.readUnsignedByte()!=VERSION)throw new IOException("USB_PROTOCOL");
        int count=in.readInt();if(count<0||count>32)throw new IOException("USB_PROTOCOL");
        List<Category> result=new ArrayList<>();
        for(int n=0;n<count;n++){String id=in.readUTF();int files=in.readInt();long bytes=in.readLong();if(id.length()>32||files<0||bytes< -1)throw new IOException("USB_PROTOCOL");result.add(new Category(id,files,bytes));}
        if(in.available()!=0)throw new IOException("USB_PROTOCOL");return result;
    }

    static byte[] encodeSelection(Collection<String> ids)throws IOException{
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        DataOutputStream out=new DataOutputStream(buffer);
        out.writeByte(SELECTION);out.writeByte(VERSION);out.writeInt(ids.size());
        for(String id:ids)out.writeUTF(id);out.flush();return buffer.toByteArray();
    }

    static LinkedHashSet<String> decodeSelection(byte[] packet)throws IOException{
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(packet));
        if(in.readUnsignedByte()!=SELECTION||in.readUnsignedByte()!=VERSION)throw new IOException("USB_PROTOCOL");
        int count=in.readInt();if(count<0||count>32)throw new IOException("USB_PROTOCOL");
        LinkedHashSet<String> result=new LinkedHashSet<>();
        for(int n=0;n<count;n++){String id=in.readUTF();if(id.length()>32)throw new IOException("USB_PROTOCOL");result.add(id);}
        if(in.available()!=0)throw new IOException("USB_PROTOCOL");return result;
    }
}
