package com.abdulla.clonephone;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.widget.*;

/** Displays measured transfer progress only; estimates are supplied by the transport. */
final class TransferDashboard extends LinearLayout {
    private final Ring ring;private final TextView percent,speed,remaining,moved,total,file;
    TransferDashboard(Context c){
        super(c);setOrientation(VERTICAL);setLayoutDirection(UiText.direction());
        LinearLayout hero=new LinearLayout(c);hero.setOrientation(VERTICAL);hero.setGravity(Gravity.CENTER);hero.setPadding(dp(20),dp(18),dp(20),dp(20));hero.setBackground(CloneDesign.gradient(c,CloneDesign.NAVY,0xff243d79,28));addView(hero,new LayoutParams(-1,-2));
        FrameLayout gauge=new FrameLayout(c);hero.addView(gauge,new LayoutParams(dp(204),dp(204)));ring=new Ring(c);gauge.addView(ring,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout center=new LinearLayout(c);center.setOrientation(VERTICAL);center.setGravity(Gravity.CENTER);gauge.addView(center,new FrameLayout.LayoutParams(-1,-1));percent=CloneDesign.text(c,"0.0%",40,Color.WHITE,true);percent.setTextDirection(View.TEXT_DIRECTION_LTR);percent.setGravity(Gravity.CENTER);center.addView(percent);
        TextView caption=CloneDesign.text(c,CloneDesign.words("گواستراوەتەوە","Transferred","تم النقل"),12,0xffb7c6e6,false);caption.setGravity(Gravity.CENTER);center.addView(caption);
        file=CloneDesign.text(c,UiText.t(119),13,0xffd3def4,false);file.setGravity(Gravity.CENTER);file.setMaxLines(2);file.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);file.setPadding(0,dp(6),0,0);hero.addView(file,new LayoutParams(-1,-2));
        LinearLayout first=row(c),second=row(c);speed=metric(c,first,CloneDesign.words("خێرایی","Speed","السرعة"));remaining=metric(c,first,CloneDesign.words("کاتی ماوە","Time remaining","الوقت المتبقي"));moved=metric(c,second,CloneDesign.words("گواستراوە","Transferred","المنقول"));total=metric(c,second,CloneDesign.words("کۆی داتا","Total data","إجمالي البيانات"));
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
    }
    private int dp(int n){return CloneDesign.dp(getContext(),n);}
    private LinearLayout row(Context c){LinearLayout r=new LinearLayout(c);LayoutParams lp=new LayoutParams(-1,-2);lp.topMargin=dp(10);addView(r,lp);return r;}
    private TextView metric(Context c,LinearLayout row,String title){
        LinearLayout card=new LinearLayout(c);card.setOrientation(VERTICAL);card.setPadding(dp(15),dp(15),dp(15),dp(15));card.setBackground(CloneDesign.surface(c,Color.WHITE,CloneDesign.LINE,20));LayoutParams lp=new LayoutParams(0,-2,1);lp.setMargins(dp(3),0,dp(3),0);row.addView(card,lp);
        card.addView(CloneDesign.text(c,title,12,CloneDesign.MUTED,false));TextView value=CloneDesign.text(c,"—",20,CloneDesign.INK,true);value.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);value.setPadding(0,dp(5),0,0);value.setMaxLines(2);card.addView(value,new LayoutParams(-1,-2));return value;
    }
    void update(int tenths,String shown,String filename,String speedText,String etaText,String movedText,String totalText){
        ring.progress=Math.max(0,Math.min(1000,tenths));ring.invalidate();percent.setText(shown);file.setText(filename);speed.setText(speedText);remaining.setText(etaText);moved.setText(movedText);total.setText(totalText);
    }
    private static final class Ring extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int progress;
        Ring(Context c){super(c);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas c){float inset=CloneDesign.dp(getContext(),13);RectF r=new RectF(inset,inset,getWidth()-inset,getHeight()-inset);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(CloneDesign.dp(getContext(),9));p.setStrokeCap(Paint.Cap.ROUND);p.setShader(null);p.setColor(0xff3a507e);c.drawArc(r,0,360,false,p);if(progress>0){p.setShader(new SweepGradient(getWidth()/2f,getHeight()/2f,new int[]{CloneDesign.BLUE,CloneDesign.TEAL,CloneDesign.TEAL},null));c.save();c.rotate(-90,getWidth()/2f,getHeight()/2f);c.drawArc(r,0,progress*.36f,false,p);c.restore();p.setShader(null);}}
    }
}
