package com.abdulla.clonephone;

import android.app.*;
import android.content.*;
import android.os.*;

/** Keeps an active phone-to-phone transfer alive when the UI is backgrounded. */
public final class TransferService extends Service {
    public static final String CHANNEL="rebarit_transfer";
    public static final int ID=74;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate(){
        super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(nm!=null&&Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"REBARIT transfer",NotificationManager.IMPORTANCE_LOW));
        try{
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(pm!=null){wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"REBARITCLONE:transfer");wakeLock.setReferenceCounted(false);wakeLock.acquire();}
        }catch(Exception ignored){}
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Notification n=builder.setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("REBARIT CLONE").setContentText("گواستنەوە بەردەوامە…").setContentIntent(tap)
            .setOnlyAlertOnce(true).setOngoing(true).build();
        startForeground(ID,n);return START_NOT_STICKY;
    }
    @Override public void onDestroy(){try{if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();}catch(Exception ignored){}wakeLock=null;super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
