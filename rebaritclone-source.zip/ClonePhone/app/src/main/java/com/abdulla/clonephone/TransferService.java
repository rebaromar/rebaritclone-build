package com.abdulla.clonephone;

import android.app.*;
import android.content.*;
import android.os.Build;

/** Keeps an active phone-to-phone transfer alive when the UI is backgrounded. */
public final class TransferService extends Service {
    public static final String CHANNEL="rebarit_transfer";
    public static final int ID=74;
    @Override public void onCreate(){super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(nm!=null&&Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"REBARIT transfer",NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("REBARIT CLONE").setContentText("گواستنەوە بەردەوامە…").setContentIntent(tap)
            .setOnlyAlertOnce(true).setOngoing(true).build();
        startForeground(ID,n);return START_STICKY;
    }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
