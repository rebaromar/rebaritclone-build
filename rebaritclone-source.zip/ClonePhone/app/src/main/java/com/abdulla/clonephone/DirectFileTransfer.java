package com.abdulla.clonephone;

import java.io.*;
import java.security.MessageDigest;

/** Fresh, non-resumable transfer used by USB. Streams directly to destination storage. */
public final class DirectFileTransfer {
    public interface Progress { void update(long bytes) throws Exception; }
    private static final byte READY = 1;
    private static final byte SKIP = 2;
    private static final byte VERIFIED = 3;

    private static MessageDigest sha256() throws Exception { return MessageDigest.getInstance("SHA-256"); }

    public static long send(SecureChannel channel, InputStream in, long size, int chunk, Progress progress) throws Exception {
        byte[] state = channel.read();
        if (state.length != 1) throw new IOException("USB_FILE_STATE");
        if (state[0] == SKIP) {
            long done = Math.max(0, size);
            progress.update(done);
            return done;
        }
        if (state[0] != READY) throw new IOException("USB_FILE_STATE");

        MessageDigest hash = sha256();
        long bytes = 0;
        byte[] data = new byte[Math.min(chunk, SecureChannel.MAX_FRAME)];
        for (;;) {
            int n = in.read(data);
            if (n < 0) break;
            if (n == 0) continue;
            hash.update(data, 0, n);
            channel.writeBuffered(data, n);
            bytes += n;
            progress.update(bytes);
        }
        if (size >= 0 && bytes != size) throw new IOException("SOURCE_CHANGED");
        channel.write(new byte[0]);
        channel.write(hash.digest());
        byte[] ack = channel.read();
        if (ack.length != 1 || ack[0] != VERIFIED) throw new IOException("USB_VERIFY");
        return bytes;
    }

    public static long receive(SecureChannel channel, OutputStream out, long size, Progress progress) throws Exception {
        channel.write(new byte[]{READY});
        MessageDigest hash = sha256();
        long bytes = 0;
        for (;;) {
            byte[] data = channel.read();
            if (data.length == 0) break;
            if (size >= 0 && data.length > size - bytes) throw new IOException("USB_SIZE");
            out.write(data);
            hash.update(data);
            bytes += data.length;
            progress.update(bytes);
        }
        byte[] remoteHash = channel.read();
        if (remoteHash.length != 32 || !MessageDigest.isEqual(hash.digest(), remoteHash) || (size >= 0 && bytes != size)) {
            throw new IOException("USB_VERIFY");
        }
        out.flush();
        channel.write(new byte[]{VERIFIED});
        return bytes;
    }

    public static void skip(SecureChannel channel) throws Exception {
        channel.write(new byte[]{SKIP});
    }
}
