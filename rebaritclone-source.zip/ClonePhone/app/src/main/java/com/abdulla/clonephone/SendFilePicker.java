package com.abdulla.clonephone;

import android.app.Activity;
import android.content.ContentUris;
import android.content.pm.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.Manifest;
import java.io.IOException;
import java.text.SimpleDateFormat;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.concurrent.*;

/** Full-screen sender picker. Selection survives tab changes and search filters. */
final class SendFilePicker extends LinearLayout {
    static final class Entry {
        Uri uri; String name,mime,folder="",path="",title="",artist=""; long size,date,duration,albumId; ApplicationInfo app; boolean recent; PersonalRecords.Row contact;
        String key(){if(contact!=null)return "contact:"+contact.id;if(app!=null)return "app:"+app.packageName;if(!path.isEmpty())return "file:"+path;return "file".equals(uri.getScheme())?"file:"+uri.getPath():uri.toString();}
    }
    interface Actions {
        void back(); void browse(); void permission(String tab); void uninstall(List<Entry> entries); void next(List<Entry> entries);
    }
    private enum Notice { APP_BUNDLE, BROWSE, HUB, ACCESS, LOADING, EMPTY, RETRY, FOLDERS, STORAGE }
    private static final class FolderRow {final String folder;final List<Entry> entries;FolderRow(String f,List<Entry> e){folder=f;entries=e;}}
    private static final class StorageFolder {final File file;StorageFolder(File f){file=f;}}
    private static final class ContactHeading {final String letter;ContactHeading(String s){letter=s;}}
    private static final int INK=0xff25262b,DIM=0xff898b91,BLUE=0xff3266df,BG=0xfffafafa;
    private final Activity activity;
    private final Actions actions;
    private final ExecutorService loader=Executors.newSingleThreadExecutor();
    private final ExecutorService folderLoader=Executors.newSingleThreadExecutor();
    private final ThreadPoolExecutor thumbnails=new ThreadPoolExecutor(2,2,10,TimeUnit.SECONDS,new ArrayBlockingQueue<>(64),new ThreadPoolExecutor.DiscardOldestPolicy());
    private final ThreadPoolExecutor packageIcons=new ThreadPoolExecutor(2,2,10,TimeUnit.SECONDS,new ArrayBlockingQueue<>(48),new ThreadPoolExecutor.AbortPolicy());
    private final Map<String,List<WeakReference<ImageView>>> iconTargets=new HashMap<>();
    private final android.util.LruCache<String,android.graphics.Bitmap> images=new android.util.LruCache<String,android.graphics.Bitmap>(8*1024*1024){protected int sizeOf(String key,android.graphics.Bitmap image){return image.getByteCount();}};
    private final LinkedHashMap<String,Entry> selected=new LinkedHashMap<>();
    private final List<Entry> entries=new ArrayList<>();
    private final List<Object> rows=new ArrayList<>();
    private final Set<String> collapsed=new HashSet<>();
    private final Map<String,TextView> tabs=new LinkedHashMap<>();
    private final LinearLayout segments;
    private final HorizontalScrollView tabStrip;
    private final ListView list;
    private final TextView count,empty,next;
    private final ImageButton uninstall;
    private final EditText search;
    private final BaseAdapter adapter;
    private String tab="apps",query="",folderFilter=null,fileFilter="";
    private final File storageRoot=Environment.getExternalStorageDirectory();
    private File storageDirectory=storageRoot;
    private final List<File> storageFolders=new ArrayList<>();
    private final Map<String,List<Entry>> folderContents=new HashMap<>();
    private final Map<String,List<Entry>> documentCache=new HashMap<>();
    private boolean documentCacheAccess,selectingFolders;
    private Future<?> folderTask;
    private volatile int folderGeneration;
    private List<Entry> packageCache;
    private boolean packageCacheAccess;
    private Future<?> loadTask;
    private android.os.CancellationSignal queryCancellation;
    // Accessed by the single loader thread; progress is coalesced before copying results.
    private int packageProgressGeneration=-1;
    private long packageProgressTime;
    private boolean loading;
    private boolean loadFailed;
    private boolean restrictedAccess;
    private String loadMessage="";
    private boolean packages;
    private volatile boolean closed;
    private volatile int generation;

    SendFilePicker(Activity a,List<Entry> initial,Actions callback){
        super(a);activity=a;actions=callback;
        for(Entry e:initial)selected.put(e.key(),e);
        setOrientation(VERTICAL);setLayoutDirection(LAYOUT_DIRECTION_LTR);setBackgroundColor(BG);
        setPadding(dp(14),0,dp(14),0);
        LinearLayout header=new LinearLayout(a);header.setGravity(Gravity.CENTER_VERTICAL);
        addView(header,new LayoutParams(-1,dp(60)));
        TextView back=text("←",28,INK,false);back.setGravity(Gravity.CENTER);back.setContentDescription("Back");
        header.addView(back,new LayoutParams(dp(44),-1));back.setOnClickListener(v->{if(!back())actions.back();});
        TextView title=text("Select Files",21,INK,true);header.addView(title,new LayoutParams(0,-2,1));
        uninstall=new ImageButton(a);uninstall.setImageResource(android.R.drawable.ic_menu_delete);uninstall.setBackgroundColor(Color.TRANSPARENT);uninstall.setColorFilter(0xffc44747);uninstall.setContentDescription("Uninstall selected apps");uninstall.setVisibility(GONE);header.addView(uninstall,new LayoutParams(dp(48),dp(48)));uninstall.setOnClickListener(v->{List<Entry> apps=uninstallSelection();if(!apps.isEmpty())actions.uninstall(apps);});
        ImageButton find=new ImageButton(a);find.setImageResource(android.R.drawable.ic_menu_search);
        find.setBackgroundColor(Color.TRANSPARENT);find.setContentDescription("Search files");
        header.addView(find,new LayoutParams(dp(48),dp(48)));
        search=new EditText(a);search.setSingleLine(true);search.setTextSize(16);search.setHint("Search files");
        search.setTextColor(INK);search.setHintTextColor(DIM);search.setBackground(shape(0xfff0f0f2,12));
        search.setPadding(dp(12),0,dp(12),0);search.setVisibility(GONE);addView(search,new LayoutParams(-1,dp(44)));
        find.setOnClickListener(v->{search.setVisibility(search.getVisibility()==VISIBLE?GONE:VISIBLE);if(search.getVisibility()==VISIBLE){search.requestFocus();((android.view.inputmethod.InputMethodManager)a.getSystemService(android.content.Context.INPUT_METHOD_SERVICE)).showSoftInput(search,0);}else search.setText("");});
        HorizontalScrollView strip=new HorizontalScrollView(a);tabStrip=strip;strip.setHorizontalScrollBarEnabled(false);
        LinearLayout tabRow=new LinearLayout(a);strip.addView(tabRow);addView(strip,new LayoutParams(-1,dp(56)));
        String[] ids={"contacts","files","videos","apps","photos","audio"},labels={"CONTACTS","FILES","VIDEOS","APPS","PHOTOS","MUSIC"};
        for(int i=0;i<ids.length;i++){
            final String id=ids[i];TextView t=text(labels[i],15,DIM,true);t.setGravity(Gravity.CENTER);
            tabRow.addView(t,new LayoutParams(dp(86),-1));tabs.put(id,t);
            t.setOnClickListener(v->{if(tab.equals(id))return;tab=id;packages=false;folderFilter=null;fileFilter="";collapsed.clear();load();});
        }
        segments=new LinearLayout(a);segments.setPadding(dp(4),dp(4),dp(4),dp(4));segments.setBackground(shape(0xfff0f0f2,15));
        LayoutParams segmentParams=new LayoutParams(-1,dp(48));segmentParams.setMargins(0,dp(8),0,dp(14));addView(segments,segmentParams);
        TextView installed=text("Installed",16,INK,true),notInstalled=text("Not Installed",16,INK,true);
        for(TextView t:Arrays.asList(installed,notInstalled)){t.setGravity(Gravity.CENTER);segments.addView(t,new LayoutParams(0,-1,1));}
        installed.setOnClickListener(v->setFolderMode(false));notInstalled.setOnClickListener(v->setFolderMode(true));
        FrameLayout content=new FrameLayout(a);addView(content,new LayoutParams(-1,0,1));
        list=new ListView(a);list.setDivider(null);list.setVerticalScrollBarEnabled(false);content.addView(list,new FrameLayout.LayoutParams(-1,-1));
        empty=text("Loading…",15,DIM,false);empty.setGravity(Gravity.CENTER);content.addView(empty,new FrameLayout.LayoutParams(-1,-1));list.setEmptyView(empty);
        adapter=new BaseAdapter(){
            public int getCount(){return rows.size();}public Object getItem(int p){return rows.get(p);}public long getItemId(int p){return p;}
            public boolean isEnabled(int p){return false;}
            public View getView(int p,View old,ViewGroup parent){
                Object row=rows.get(p);
                if(row instanceof String)return section((String)row);
                if(row==Notice.HUB)return fileHub();
                if(row==Notice.FOLDERS)return folderHeading();
                if(row==Notice.STORAGE)return storageHeading();
                if(row==Notice.EMPTY){TextView label=text(loadMessage.isEmpty()?"No matching files":loadMessage,14,DIM,false);label.setPadding(dp(12),dp(24),dp(12),dp(24));return label;}
                if(row==Notice.LOADING){TextView label=text("Finding files…",14,DIM,false);label.setPadding(dp(12),dp(16),dp(12),dp(16));return label;}
                if(row==Notice.RETRY){TextView retry=text(loadMessage,14,BLUE,true);retry.setPadding(dp(12),dp(16),dp(12),dp(16));retry.setOnClickListener(v->reload());return retry;}
                if(row==Notice.ACCESS){TextView allow=text(tab.equals("files")||tab.equals("apps")?"Allow file access to find APKs and documents  ›":"Allow access to "+(tab.equals("audio")?"music":tab)+"  ›",14,BLUE,true);allow.setPadding(dp(12),dp(16),dp(12),dp(16));allow.setBackground(shape(0xffeaf0ff,10));allow.setOnClickListener(v->actions.permission(tab));return allow;}
                if(row instanceof FolderRow)return folderCell((FolderRow)row);
                if(row instanceof StorageFolder)return storageFolderCell(((StorageFolder)row).file);
                if(row instanceof ContactHeading){TextView letter=text(((ContactHeading)row).letter,13,DIM,true);letter.setPadding(dp(12),dp(10),0,dp(4));return letter;}
                if(row instanceof Entry){Entry e=(Entry)row;return e.contact!=null?contactCell(e):fileRow(e);}
                if(row==Notice.BROWSE){TextView browse=text("Browse other files…",14,BLUE,true);browse.setPadding(dp(10),dp(14),dp(10),dp(14));browse.setOnClickListener(v->actions.browse());if(!tab.equals("apps")||!packages)return browse;LinearLayout line=new LinearLayout(a);line.setGravity(Gravity.CENTER_VERTICAL);line.addView(browse,new LayoutParams(0,-2,1));TextView refresh=text("↻",25,BLUE,true);refresh.setGravity(Gravity.CENTER);refresh.setContentDescription("Refresh app packages");line.addView(refresh,new LayoutParams(dp(48),dp(48)));refresh.setOnClickListener(v->reload());return line;}
                if(row==Notice.APP_BUNDLE){TextView note=text("▣  App packages and split APKs are transferred together.",13,0xffc87525,true);note.setPadding(dp(14),dp(14),dp(14),dp(14));note.setBackground(shape(0xffffefdf,10));return note;}
                @SuppressWarnings("unchecked") List<Entry> cells=(List<Entry>)row;
                LinearLayout line=new LinearLayout(a);line.setPadding(dp(2),dp(5),dp(2),dp(10));
                int columns=media()?3:4;int height=media()?Math.max(dp(96),(getResources().getDisplayMetrics().widthPixels-dp(36))/3):dp(122);
                for(Entry e:cells)line.addView(media()?mediaCell(e):cell(e),new LayoutParams(0,height,1));
                for(int n=cells.size();n<columns;n++)line.addView(new View(a),new LayoutParams(0,1,1));
                return line;
            }
        };list.setAdapter(adapter);
        LinearLayout footer=new LinearLayout(a);footer.setGravity(Gravity.CENTER_VERTICAL);footer.setPadding(0,dp(10),0,dp(14));footer.setBackgroundColor(BG);
        addView(footer,new LayoutParams(-1,dp(78)));count=text("",15,INK,true);footer.addView(count,new LayoutParams(0,-2,1));
        next=text("NEXT",16,Color.WHITE,true);next.setGravity(Gravity.CENTER);next.setBackground(shape(BLUE,8));
        footer.addView(next,new LayoutParams(0,dp(48),1));next.setOnClickListener(v->{if(!selected.isEmpty()&&!selectingFolders)actions.next(new ArrayList<>(selected.values()));});
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int af){}public void afterTextChanged(android.text.Editable e){}public void onTextChanged(CharSequence s,int st,int b,int c){query=s.toString().toLowerCase(Locale.ROOT);rebuild();}});
        load();
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(activity);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private boolean media(){return tab.equals("photos")||tab.equals("videos");}
    private boolean storage(){return tab.equals("files")&&fileFilter.equals("Storage");}
    private boolean folderCapable(){return media()||tab.equals("audio")||(tab.equals("files")&&!fileFilter.isEmpty()&&!storage());}
    private void setFolderMode(boolean folders){if(packages==folders)return;packages=folders;folderFilter=null;collapsed.clear();if(tab.equals("apps"))load();else rebuild();}
    private void updateSegments(){
        segments.setVisibility(tab.equals("apps")||folderCapable()?VISIBLE:GONE);
        ((TextView)segments.getChildAt(0)).setText(tab.equals("apps")?"Installed":tab.equals("files")?"Files":"Recent");
        ((TextView)segments.getChildAt(1)).setText(tab.equals("apps")?"Not Installed":"Folders");
        for(int i=0;i<2;i++)segments.getChildAt(i).setBackground(shape((i==1)==packages?Color.WHITE:Color.TRANSPARENT,12));
    }
    private String group(Entry e){
        if(tab.equals("contacts"))return "Contacts";
        if(tab.equals("apps"))return packages?"Not Installed":e.recent?"New":"Apps";
        if(folderCapable()&&packages)return folderLabel(e.folder);
        if(media()){
            Calendar today=Calendar.getInstance();today.set(Calendar.HOUR_OF_DAY,0);today.set(Calendar.MINUTE,0);today.set(Calendar.SECOND,0);today.set(Calendar.MILLISECOND,0);
            long midnight=today.getTimeInMillis();today.add(Calendar.DAY_OF_YEAR,-1);
            return e.date>=midnight?"Today":e.date>=today.getTimeInMillis()?"Yesterday":new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date(e.date));
        }
        return tab.equals("files")?(fileFilter.isEmpty()?"Files":fileFilter):"Music";
    }
    private String folderLabel(String folder){String path=folder.endsWith("/")?folder.substring(0,folder.length()-1):folder;int slash=path.lastIndexOf('/');return path.isEmpty()?"Other":path.substring(slash+1);}
    private List<Entry> visible(){List<Entry> out=new ArrayList<>();for(Entry e:entries){
        if(!(e.contact!=null?e.contact.label:e.name+" "+e.title+" "+e.artist+" "+folderLabel(e.folder)).toLowerCase(Locale.ROOT).contains(query))continue;
        if(folderCapable()&&folderFilter!=null&&!e.folder.equals(folderFilter))continue;
        if(tab.equals("files")&&!fileFilter.isEmpty()&&!storage()&&!PickerFiles.matches(e.name,e.mime,e.size,e.path,fileFilter))continue;
        out.add(e);
    }return out;}
    private List<Entry> members(String title){List<Entry> out=new ArrayList<>();for(Entry e:visible())if(group(e).equals(title))out.add(e);return out;}
    private View section(String title){
        List<Entry> items=members(title);LinearLayout header=new LinearLayout(activity);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(8),dp(16),dp(4),dp(10));
        TextView name=text((collapsed.contains(title)?"⌄":"⌃")+"  "+title+" ("+items.size()+")",17,INK,true);header.addView(name,new LayoutParams(0,dp(40),1));name.setOnClickListener(v->{if(!collapsed.add(title))collapsed.remove(title);rebuild();});
        boolean all=!items.isEmpty();for(Entry e:items)all&=selected.containsKey(e.key());final boolean checked=all;
        TextView check=text(all?"●":"○",27,all?BLUE:0xffc5c7cc,false);check.setGravity(Gravity.CENTER);check.setContentDescription("Select all "+title);header.addView(check,new LayoutParams(dp(48),dp(48)));
        check.setEnabled(!loading);check.setAlpha(loading?.4f:1f);check.setOnClickListener(v->{for(Entry e:items)if(checked)selected.remove(e.key());else selected.put(e.key(),e);rebuild();});return header;
    }
    private View cell(Entry e){
        boolean checked=selected.containsKey(e.key());LinearLayout cell=new LinearLayout(activity);cell.setOrientation(VERTICAL);cell.setGravity(Gravity.CENTER_HORIZONTAL);cell.setPadding(dp(4),dp(6),dp(4),0);cell.setBackground(shape(checked?0xffeaf0ff:Color.TRANSPARENT,12));
        FrameLayout iconBox=new FrameLayout(activity);cell.addView(iconBox,new LayoutParams(dp(58),dp(58)));
        ImageView icon=new ImageView(activity);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);iconBox.addView(icon,new FrameLayout.LayoutParams(-1,-1));
        if(e.app==null&&PickerFiles.packageFile(e.name)){icon.setImageResource(android.R.drawable.sym_def_app_icon);if(PickerFiles.extension(e.name).equals("apk")&&"file".equals(e.uri.getScheme()))packageIcon(e,icon);}
        else if(e.app!=null)try{icon.setImageDrawable(activity.getPackageManager().getApplicationIcon(e.app));}catch(Exception ignored){icon.setImageResource(android.R.drawable.sym_def_app_icon);}
        else icon.setImageResource(e.mime.startsWith("video/")?android.R.drawable.ic_media_play:e.mime.startsWith("image/")?android.R.drawable.ic_menu_gallery:e.mime.startsWith("audio/")?android.R.drawable.ic_media_ff:android.R.drawable.ic_menu_save);
        if(e.app==null&&(e.mime.startsWith("image/")||e.mime.startsWith("video/")))thumbnail(e,icon);
        if(checked){TextView tick=text("✓",13,Color.WHITE,true);tick.setGravity(Gravity.CENTER);tick.setBackground(shape(BLUE,20));iconBox.addView(tick,new FrameLayout.LayoutParams(dp(22),dp(22),Gravity.TOP|Gravity.RIGHT));}
        TextView name=text(e.name,12,INK,true);name.setMaxLines(1);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setGravity(Gravity.CENTER);name.setPadding(0,dp(9),0,dp(3));cell.addView(name,new LayoutParams(-1,-2));
        TextView size=text(TransferStats.size(e.size),11,DIM,false);size.setGravity(Gravity.CENTER);cell.addView(size);
        cell.setContentDescription(e.name+", "+size.getText()+", "+(checked?"selected":"not selected"));cell.setFocusable(true);cell.setOnClickListener(v->{if(selected.containsKey(e.key()))selected.remove(e.key());else selected.put(e.key(),e);rebuild();});return cell;
    }
    private void toggle(Entry e){if(selected.containsKey(e.key()))selected.remove(e.key());else selected.put(e.key(),e);rebuild();}
    private View mediaCell(Entry e){
        FrameLayout frame=new FrameLayout(activity);frame.setPadding(dp(2),dp(2),dp(2),dp(2));
        ImageView image=new ImageView(activity);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackground(shape(0xffeeeeee,8));image.setClipToOutline(true);frame.addView(image,new FrameLayout.LayoutParams(-1,-1));thumbnail(e,image);
        boolean checked=selected.containsKey(e.key());TextView tick=text(checked?"✓":"○",checked?16:26,checked?Color.WHITE:Color.WHITE,true);tick.setGravity(Gravity.CENTER);if(checked)tick.setBackground(shape(BLUE,20));FrameLayout.LayoutParams mark=new FrameLayout.LayoutParams(dp(28),dp(28),Gravity.TOP|Gravity.RIGHT);mark.setMargins(0,dp(4),dp(4),0);frame.addView(tick,mark);
        frame.setContentDescription(e.name+(checked?", selected":""));frame.setOnClickListener(v->toggle(e));return frame;
    }
    private View folderCell(FolderRow folder){
        LinearLayout row=new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(10),dp(8),dp(10));
        if(media()){ImageView cover=new ImageView(activity);cover.setScaleType(ImageView.ScaleType.CENTER_CROP);row.addView(cover,new LayoutParams(dp(64),dp(64)));thumbnail(folder.entries.get(0),cover);}else row.addView(hubIcon("▰",0xffdca431,52),new LayoutParams(dp(52),dp(52)));
        LinearLayout words=new LinearLayout(activity);words.setOrientation(VERTICAL);words.setPadding(dp(14),0,0,0);row.addView(words,new LayoutParams(0,-2,1));words.addView(text(folderLabel(folder.folder),16,INK,true));words.addView(text(folder.entries.size()+" items",13,DIM,false));
        addSelection(row,folder.entries,"Select folder "+folderLabel(folder.folder),!loading);TextView arrow=text("›",26,DIM,false);arrow.setGravity(Gravity.CENTER);row.addView(arrow,new LayoutParams(dp(28),dp(48)));row.setOnClickListener(v->{folderFilter=folder.folder;collapsed.clear();rebuild();});return row;
    }
    private boolean allSelected(Collection<Entry> items){if(items.isEmpty())return false;for(Entry e:items)if(!selected.containsKey(e.key()))return false;return true;}
    private boolean someSelected(Collection<Entry> items){for(Entry e:items)if(selected.containsKey(e.key()))return true;return false;}
    private void addSelection(LinearLayout row,List<Entry> items,String label,boolean enabled){
        boolean all=allSelected(items),some=someSelected(items);TextView check=text(all?"●":some?"−":"○",27,some?BLUE:0xffbfc3cd,false);check.setGravity(Gravity.CENTER);check.setContentDescription(label+(all?", selected":some?", partly selected":""));row.addView(check,new LayoutParams(dp(48),dp(48)));check.setEnabled(enabled);check.setAlpha(enabled?1f:.4f);check.setOnClickListener(v->{for(Entry e:items)if(all)selected.remove(e.key());else selected.put(e.key(),e);rebuild();});
    }
    private View folderHeading(){LinearLayout header=new LinearLayout(activity);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(8),dp(8),0,dp(6));header.addView(text("Folders",17,INK,true),new LayoutParams(0,-2,1));TextView label=text("Select all",13,BLUE,true);header.addView(label);addSelection(header,visible(),"Select all folders",!loading);return header;}
    private View fileRow(Entry e){
        boolean music=tab.equals("audio"),checked=selected.containsKey(e.key());LinearLayout row=new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(12),dp(2),dp(12));row.setBackground(shape(checked?0xffeaf0ff:Color.TRANSPARENT,12));
        String ext=PickerFiles.extension(e.name).toUpperCase(Locale.ROOT);if(ext.length()>5||ext.isEmpty())ext="FILE";int color=music?0xff6479aa:ext.equals("PDF")?0xffd96865:ext.startsWith("XL")?0xff4c9d78:0xff607fae;
        FrameLayout cover=new FrameLayout(activity);row.addView(cover,new LayoutParams(dp(52),dp(52)));TextView badge=hubIcon(music?"♪":ext,color,52);badge.setTextSize(music?27:12);cover.addView(badge,new FrameLayout.LayoutParams(-1,-1));
        if(music&&e.albumId>0){ImageView art=new ImageView(activity);art.setScaleType(ImageView.ScaleType.CENTER_CROP);art.setBackground(shape(Color.TRANSPARENT,8));art.setClipToOutline(true);cover.addView(art,new FrameLayout.LayoutParams(-1,-1));albumArt(e,art);}
        LinearLayout words=new LinearLayout(activity);words.setOrientation(VERTICAL);words.setPadding(dp(12),0,dp(6),0);row.addView(words,new LayoutParams(0,-2,1));TextView name=text(music&&!e.title.isEmpty()?e.title:e.name,15,INK,true);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);words.addView(name);
        String details=TransferStats.size(e.size);if(music){if(e.duration>0)details=(e.duration/60000)+":"+String.format(Locale.US,"%02d",(e.duration/1000)%60)+"  ·  "+details;if(!e.artist.isEmpty()&&!e.artist.equals("<unknown>"))details=e.artist+"  ·  "+details;}else if(!e.folder.isEmpty())details=folderLabel(e.folder)+"  ·  "+details;
        TextView info=text(details,12,DIM,false);info.setMaxLines(2);info.setEllipsize(android.text.TextUtils.TruncateAt.END);info.setPadding(0,dp(5),0,0);words.addView(info);TextView tick=text(checked?"●":"○",26,checked?BLUE:0xffc5c7cc,false);tick.setGravity(Gravity.CENTER);row.addView(tick,new LayoutParams(dp(40),dp(48)));row.setContentDescription(e.name+", "+details+(checked?", selected":""));row.setOnClickListener(v->toggle(e));return row;
    }
    private void albumArt(Entry e,ImageView target){String key="album:"+e.albumId;target.setTag(key);android.graphics.Bitmap cached=images.get(key);if(cached!=null){target.setImageBitmap(cached);return;}if(closed)return;thumbnails.execute(()->{android.graphics.Bitmap art=null;Uri uri=ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"),e.albumId);try(java.io.InputStream stream=activity.getContentResolver().openInputStream(uri)){android.graphics.BitmapFactory.Options options=new android.graphics.BitmapFactory.Options();options.inSampleSize=4;art=android.graphics.BitmapFactory.decodeStream(stream,null,options);}catch(Exception ignored){}if(art!=null&&!closed){images.put(key,art);final android.graphics.Bitmap result=art;activity.runOnUiThread(()->{if(!closed&&key.equals(target.getTag()))target.setImageBitmap(result);});}});}
    private View contactCell(Entry e){
        boolean checked=selected.containsKey(e.key());LinearLayout row=new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(12),dp(10),dp(12));
        String first=e.name.isEmpty()?"&":e.name.substring(0,e.name.offsetByCodePoints(0,1));TextView avatar=text(first,20,Color.WHITE,true);avatar.setGravity(Gravity.CENTER);avatar.setBackground(shape(0xff55c52d,40));row.addView(avatar,new LayoutParams(dp(48),dp(48)));
        LinearLayout words=new LinearLayout(activity);words.setOrientation(VERTICAL);words.setPadding(dp(14),0,dp(8),0);row.addView(words,new LayoutParams(0,-2,1));TextView name=text(e.name,15,INK,false);name.setMaxLines(1);name.setEllipsize(android.text.TextUtils.TruncateAt.END);words.addView(name);
        int line=e.contact.label.indexOf('\n');String phone=line<0?"No number":e.contact.label.substring(line+1);TextView number=text(phone,13,DIM,false);number.setPadding(0,dp(5),0,0);words.addView(number);
        TextView tick=text(checked?"●":"○",26,checked?BLUE:0xffc5c7cc,false);row.addView(tick,new LayoutParams(dp(32),dp(40)));row.setContentDescription(e.name+", "+phone);row.setOnClickListener(v->toggle(e));return row;
    }
    private int fileCount(String filter){int result=0;for(Entry e:entries)if(PickerFiles.matches(e.name,e.mime,e.size,e.path,filter))result++;return result;}
    private void openFileCategory(String category){fileFilter=category;packages=false;folderFilter=null;if(category.equals("Storage"))storageDirectory=storageRoot;collapsed.clear();load();}
    private LinearLayout hubCard(LinearLayout parent){LinearLayout card=new LinearLayout(activity);card.setOrientation(VERTICAL);card.setPadding(dp(16),dp(16),dp(16),dp(16));card.setBackground(shape(0xfff2f2f2,16));LayoutParams params=new LayoutParams(-1,-2);params.setMargins(0,0,0,dp(12));parent.addView(card,params);return card;}
    private TextView hubIcon(String glyph,int color,int size){TextView icon=text(glyph,22,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(color,8));icon.setMinWidth(dp(size));icon.setMinHeight(dp(size));return icon;}
    private View fileHub(){
        LinearLayout hub=new LinearLayout(activity);hub.setOrientation(VERTICAL);hub.setPadding(dp(2),dp(10),dp(2),dp(4));
        LinearLayout whatsapp=hubCard(hub);whatsapp.addView(text("WhatsApp Transfer",15,INK,true));LinearLayout waRow=new LinearLayout(activity);LayoutParams waParams=new LayoutParams(-1,dp(72));waParams.setMargins(0,dp(12),0,0);whatsapp.addView(waRow,waParams);
        String[] waNames={"Status","Media"};int[] waColors={0xff00b894,0xfffa7553};
        for(int i=0;i<2;i++){final String category=waNames[i];LinearLayout tile=new LinearLayout(activity);tile.setGravity(Gravity.CENTER_VERTICAL);tile.setPadding(dp(6),0,dp(6),0);waRow.addView(tile,new LayoutParams(0,-1,1));tile.addView(hubIcon(i==0?"◌":"▣",waColors[i],36),new LayoutParams(dp(36),dp(36)));LinearLayout words=new LinearLayout(activity);words.setOrientation(VERTICAL);words.setPadding(dp(8),0,0,0);tile.addView(words,new LayoutParams(0,-2,1));words.addView(text(category,13,INK,false));words.addView(text(String.valueOf(fileCount(category)),12,DIM,false));tile.setOnClickListener(v->openFileCategory(category));}
        LinearLayout docs=hubCard(hub);docs.addView(text("Documents",15,INK,true));
        String[] names={"ALL","PDF","EXCEL","PPT","TXT","DOC","WPS"},glyphs={"≡","PDF","X","P","T","W","W"};int[] colors={0xffedb527,0xffed7050,0xff67bc68,0xffef914e,0xff8c80df,0xff60b8d5,0xff76a5eb};
        for(int start=0;start<names.length;start+=4){LinearLayout line=new LinearLayout(activity);LayoutParams lp=new LayoutParams(-1,dp(92));lp.setMargins(0,dp(10),0,0);docs.addView(line,lp);for(int i=start;i<Math.min(start+4,names.length);i++){final String category=names[i];LinearLayout tile=new LinearLayout(activity);tile.setOrientation(VERTICAL);tile.setGravity(Gravity.CENTER_HORIZONTAL);line.addView(tile,new LayoutParams(0,-1,1));TextView icon=hubIcon(glyphs[i],colors[i],42);if(glyphs[i].equals("PDF"))icon.setTextSize(13);tile.addView(icon,new LayoutParams(dp(42),dp(42)));TextView label=text(category,12,DIM,true);label.setPadding(0,dp(8),0,0);tile.addView(label);tile.setOnClickListener(v->openFileCategory(category));}for(int i=Math.min(start+4,names.length);i<start+4;i++)line.addView(new View(activity),new LayoutParams(0,-1,1));}
        fileHubLink(hub,"Zip","zip, rar, iso, 7z","▤",0xff438de9);fileHubLink(hub,"Large Files","Larger than 50MB","▰",0xffeaaa2c);fileHubLink(hub,"Storage","Browse phone folders and files","▰",0xff6479aa);return hub;
    }
    private void fileHubLink(LinearLayout hub,String category,String subtitle,String glyph,int color){LinearLayout card=hubCard(hub);card.setOrientation(HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.addView(hubIcon(glyph,color,40),new LayoutParams(dp(40),dp(40)));LinearLayout words=new LinearLayout(activity);words.setOrientation(VERTICAL);words.setPadding(dp(12),0,0,0);card.addView(words,new LayoutParams(0,-2,1));words.addView(text(category,14,INK,false));words.addView(text(subtitle,12,DIM,false));card.addView(text("›",24,DIM,false));card.setOnClickListener(v->openFileCategory(category));}
    private List<Entry> uninstallSelection(){List<Entry> result=new ArrayList<>();for(Entry e:selected.values())if(e.app!=null&&!e.app.packageName.equals(activity.getPackageName())&&(e.app.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))==0)result.add(e);return result;}
    void uninstallFinished(String packageName,boolean success){if(closed||!success)return;selected.remove("app:"+packageName);entries.removeIf(e->e.app!=null&&e.app.packageName.equals(packageName));rebuild();}
    private String storageKey(File file){try{return file.getCanonicalPath();}catch(IOException e){return file.getAbsolutePath();}}
    private List<File> visibleStorageFolders(){List<File> result=new ArrayList<>();for(File file:storageFolders)if(file.getName().toLowerCase(Locale.ROOT).contains(query))result.add(file);return result;}
    private List<Entry> selectedBelow(File folder){String prefix=storageKey(folder)+File.separator;List<Entry> result=new ArrayList<>();for(Entry e:selected.values())if(!e.path.isEmpty()&&e.path.startsWith(prefix))result.add(e);return result;}
    private List<Entry> storageMembers(File folder){String key=storageKey(folder),prefix=key+File.separator;List<Entry> known=folderContents.get(key);if(known!=null)return known;for(Map.Entry<String,List<Entry>> parent:folderContents.entrySet())if(key.startsWith(parent.getKey()+File.separator)){List<Entry> children=new ArrayList<>();for(Entry e:parent.getValue())if(e.path.startsWith(prefix))children.add(e);return children;}return null;}
    private View storageHeading(){
        LinearLayout panel=new LinearLayout(activity);panel.setOrientation(VERTICAL);panel.setPadding(dp(8),dp(6),0,dp(10));TextView path=text(storageDirectory.equals(storageRoot)?"Phone storage":storageDirectory.getAbsolutePath().replace(storageRoot.getAbsolutePath()+"/",""),14,INK,true);path.setMaxLines(2);panel.addView(path);LinearLayout line=new LinearLayout(activity);line.setGravity(Gravity.CENTER_VERTICAL);panel.addView(line,new LayoutParams(-1,dp(48)));
        TextView parent=text(storageDirectory.equals(storageRoot)?"← Files":"↑ Parent folder",14,BLUE,true);line.addView(parent,new LayoutParams(0,-1,1));parent.setGravity(Gravity.CENTER_VERTICAL);parent.setOnClickListener(v->{if(storageDirectory.equals(storageRoot)){fileFilter="";load();}else{storageDirectory=storageDirectory.getParentFile();load();}});
        TextView refresh=text("↻",23,BLUE,true);refresh.setGravity(Gravity.CENTER);refresh.setContentDescription("Refresh storage");line.addView(refresh,new LayoutParams(dp(42),-1));refresh.setOnClickListener(v->reload());
        TextView all=text("Select all",13,BLUE,true);all.setGravity(Gravity.CENTER);line.addView(all,new LayoutParams(dp(86),-1));all.setEnabled(!loading&&!selectingFolders&&fileAccess());all.setAlpha(all.isEnabled()?1f:.4f);all.setOnClickListener(v->{List<File> roots=visibleStorageFolders();for(Entry e:visible())if("file".equals(e.uri.getScheme()))roots.add(new File(e.uri.getPath()));selectStorage(roots);});return panel;
    }
    private View storageFolderCell(File folder){
        LinearLayout row=new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(12),0,dp(12));row.addView(hubIcon("▰",0xffdca431,52),new LayoutParams(dp(52),dp(52)));LinearLayout words=new LinearLayout(activity);words.setOrientation(VERTICAL);words.setPadding(dp(12),0,dp(4),0);row.addView(words,new LayoutParams(0,-2,1));TextView name=text(folder.getName(),15,INK,true);name.setMaxLines(2);words.addView(name);words.addView(text("Folder",12,DIM,false));
        List<Entry> contents=storageMembers(folder);boolean checked=contents!=null&&allSelected(contents),some=!selectedBelow(folder).isEmpty();TextView check=text(checked?"●":some?"−":"○",27,some?BLUE:0xffbfc3cd,false);check.setGravity(Gravity.CENTER);check.setContentDescription("Select folder "+folder.getName()+(checked?", selected":some?", partly selected":""));row.addView(check,new LayoutParams(dp(48),dp(48)));check.setEnabled(!selectingFolders);check.setOnClickListener(v->{if(checked){for(Entry e:contents)selected.remove(e.key());rebuild();}else selectStorage(Collections.singletonList(folder));});TextView arrow=text("›",26,DIM,false);arrow.setGravity(Gravity.CENTER);row.addView(arrow,new LayoutParams(dp(28),dp(48)));row.setOnClickListener(v->{storageDirectory=folder;collapsed.clear();load();});return row;
    }
    private void selectStorage(Collection<File> roots){
        if(selectingFolders||roots.isEmpty())return;if(!fileAccess()){actions.permission("files");return;}
        List<Entry> known=new ArrayList<>();boolean complete=true;for(File root:roots){if(root.isDirectory()){List<Entry> contents=storageMembers(root);if(contents==null){complete=false;break;}known.addAll(contents);}else known.add(fileEntry(root));}if(complete&&allSelected(known)){for(Entry e:known)selected.remove(e.key());rebuild();return;}
        final List<File> requested=new ArrayList<>(roots);final int token=++folderGeneration;selectingFolders=true;rebuild();folderTask=folderLoader.submit(()->{
            try{int[] total={0};List<File> files=StorageFiles.collect(storageRoot,requested,()->checkFolderSelection(token),batch->{total[0]+=batch.size();if(total[0]>10000)throw new IOException("Too many files. Select fewer than 10,000 files.");});List<Entry> collected=new ArrayList<>();for(File file:files){checkFolderSelection(token);collected.add(fileEntry(file));}activity.runOnUiThread(()->{if(closed||token!=folderGeneration)return;selectingFolders=false;Set<String> merged=new HashSet<>(selected.keySet());for(Entry e:collected)merged.add(e.key());if(merged.size()>10000){Toast.makeText(activity,"Too many items. Select fewer than 10,000 items.",Toast.LENGTH_LONG).show();rebuild();return;}for(Entry e:collected)selected.put(e.key(),e);for(File root:requested)if(root.isDirectory()){String prefix=storageKey(root)+File.separator;List<Entry> children=new ArrayList<>();for(Entry e:collected)if(e.path.startsWith(prefix))children.add(e);folderContents.put(storageKey(root),children);}if(collected.isEmpty())Toast.makeText(activity,"No readable files in these folders",Toast.LENGTH_SHORT).show();rebuild();});}
            catch(Exception e){activity.runOnUiThread(()->{if(closed||token!=folderGeneration)return;selectingFolders=false;Toast.makeText(activity,e.getMessage()!=null&&e.getMessage().startsWith("Too many")?e.getMessage():"Unable to select folder. Check file access and retry.",Toast.LENGTH_LONG).show();rebuild();});}
        });
    }
    private void checkFolderSelection(int token)throws IOException{if(closed||token!=folderGeneration||Thread.currentThread().isInterrupted())throw new IOException("Cancelled");}
    private void rebuild(){
        if(closed)return;updateSegments();uninstall.setVisibility(tab.equals("apps")&&!packages&&!uninstallSelection().isEmpty()?VISIBLE:GONE);rows.clear();List<Entry> shown=visible();
        boolean fileBased=tab.equals("files")||(tab.equals("apps")&&packages);
        if(restrictedAccess||(fileBased&&!fileAccess()))rows.add(Notice.ACCESS);
        if(loading&&(fileBased||(folderCapable()&&packages)))rows.add(Notice.LOADING);
        if(tab.equals("files")&&fileFilter.isEmpty())rows.add(Notice.HUB);
        else if(storage()){
            rows.add(Notice.STORAGE);for(File folder:visibleStorageFolders())rows.add(new StorageFolder(folder));rows.addAll(shown);
        }else if(folderCapable()&&packages&&folderFilter==null){
            rows.add(Notice.FOLDERS);
            LinkedHashMap<String,List<Entry>> folders=new LinkedHashMap<>();for(Entry e:shown)folders.computeIfAbsent(e.folder,k->new ArrayList<>()).add(e);
            for(Map.Entry<String,List<Entry>> f:folders.entrySet())rows.add(new FolderRow(f.getKey(),f.getValue()));
        }else{
            LinkedHashSet<String> groups=new LinkedHashSet<>();for(Entry e:shown)groups.add(group(e));
            for(String title:groups){
                rows.add(title);if(collapsed.contains(title))continue;
                if(title.equals("Apps"))rows.add(Notice.APP_BUNDLE);
                List<Entry> cells=null;String previous="";
                for(Entry e:members(title)){
                    if(e.contact!=null){String letter=e.name.isEmpty()?"#":e.name.substring(0,e.name.offsetByCodePoints(0,1)).toUpperCase(Locale.ROOT);if(!letter.equals(previous)){rows.add(new ContactHeading(letter));previous=letter;}rows.add(e);}
                    else if(tab.equals("audio")||tab.equals("files"))rows.add(e);
                    else{int columns=media()?3:4;if(cells==null||cells.size()==columns){cells=new ArrayList<>();rows.add(cells);}cells.add(e);}
                }
            }
        }
        if(!loading&&loadFailed)rows.add(Notice.RETRY);
        if(fileBased&&!loading&&!loadFailed&&shown.isEmpty()&&(!storage()||visibleStorageFolders().isEmpty())&&(!fileFilter.isEmpty()||tab.equals("apps")))rows.add(Notice.EMPTY);
        if(!fileBased&&folderCapable()&&packages&&!loading&&!loadFailed&&!restrictedAccess&&shown.isEmpty())rows.add(Notice.EMPTY);
        if(fileBased)rows.add(Notice.BROWSE);
        count.setText(selectingFolders?"Selecting files… Cancel":selected.size()+" item(s) selected");count.setTextColor(selectingFolders?BLUE:INK);count.setOnClickListener(selectingFolders?v->{++folderGeneration;if(folderTask!=null)folderTask.cancel(true);selectingFolders=false;rebuild();}:null);next.setEnabled(!selected.isEmpty()&&!selectingFolders);next.setAlpha(next.isEnabled()?1f:.55f);
        empty.setText(loading?"Loading…":loadMessage.isEmpty()?"No matching items":loadMessage);adapter.notifyDataSetChanged();
    }
    boolean back(){if(storage()&&!storageDirectory.equals(storageRoot)){storageDirectory=storageDirectory.getParentFile();load();return true;}if(folderFilter!=null){folderFilter=null;rebuild();return true;}if(!fileFilter.isEmpty()){fileFilter="";packages=false;load();return true;}return false;}
    List<Entry> selection(){return new ArrayList<>(selected.values());}
    void reload(){if(tab.equals("files")){documentCache.clear();folderContents.clear();}if(tab.equals("apps")&&packages)packageCache=null;load();}
    private boolean fileAccess(){return Build.VERSION.SDK_INT>=30?Environment.isExternalStorageManager():activity.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;}
    private void checkLoad(int version)throws IOException{if(closed||generation!=version||Thread.currentThread().isInterrupted())throw new IOException("Cancelled");}
    private Entry fileEntry(File file){Entry e=new Entry();e.uri=Uri.fromFile(file);e.name=file.getName();e.path=storageKey(file);e.folder=file.getParent();e.size=file.length();e.date=file.lastModified();String mime=android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(PickerFiles.extension(e.name));e.mime=mime==null?"application/octet-stream":mime;return e;}
    private void publishPackages(int version,Collection<Entry> found){
        long now=android.os.SystemClock.elapsedRealtime();if(packageProgressGeneration==version&&now-packageProgressTime<150)return;
        packageProgressGeneration=version;packageProgressTime=now;
        List<Entry> snapshot=new ArrayList<>(found);
        activity.runOnUiThread(()->{if(closed||generation!=version)return;entries.clear();entries.addAll(snapshot);rebuild();});
    }
    private void indexedPackages(int version,android.os.CancellationSignal cancellation,Map<String,Entry> found)throws Exception{
        Uri uri=MediaStore.Files.getContentUri("external");
        String selection="(_display_name LIKE ? OR _display_name LIKE ? OR _display_name LIKE ? OR _display_name LIKE ? OR _display_name LIKE ?)";
        String[] suffixes={"%.apk","%.apks","%.xapk","%.apkm","%.rbapp"};
        boolean access=fileAccess();long lastPublish=System.currentTimeMillis();
        try(Cursor c=activity.getContentResolver().query(uri,new String[]{"_id","_display_name","mime_type","_size","date_modified",MediaStore.MediaColumns.DATA},selection,suffixes,"date_added DESC",cancellation)){
            while(c!=null&&c.moveToNext()){
                checkLoad(version);String name=c.isNull(1)?"":c.getString(1);if(!PickerFiles.packageFile(name))continue;
                String path=c.isNull(5)?"":c.getString(5);Entry e;
                if(access&&path.isEmpty())continue;
                if(access&&!path.isEmpty()){
                    File file=new File(path);if(!file.isFile()||!file.canRead()||!PickerFiles.packageFile(file.getName()))continue;e=fileEntry(file);
                }else{
                    e=new Entry();e.uri=ContentUris.withAppendedId(uri,c.getLong(0));e.path=path;e.name=name;e.mime=c.isNull(2)?"application/octet-stream":c.getString(2);e.size=c.isNull(3)?-1:c.getLong(3);e.date=c.isNull(4)?0:c.getLong(4)*1000L;
                }
                found.put(e.key(),e);
                long now=System.currentTimeMillis();if(found.size()==1||now-lastPublish>=150){publishPackages(version,found.values());lastPublish=now;}
            }
        }
    }
    private void loadPackages(int version,android.os.CancellationSignal cancellation,List<Entry> found)throws Exception{
        LinkedHashMap<String,Entry> discovered=new LinkedHashMap<>();
        try{indexedPackages(version,cancellation,discovered);}catch(Exception e){checkLoad(version);if(!fileAccess())throw e;}
        checkLoad(version);if(!discovered.isEmpty())publishPackages(version,discovered.values());
        if(fileAccess()){
            PickerFiles.scanPackages(Environment.getExternalStorageDirectory(),()->checkLoad(version),batch->{
                checkLoad(version);for(File file:batch){Entry e=fileEntry(file);discovered.put(e.key(),e);}publishPackages(version,discovered.values());
            });
        }
        checkLoad(version);found.addAll(discovered.values());found.sort((a,b)->Long.compare(b.date,a.date));
    }
    private void loadDocuments(int version,String category,android.os.CancellationSignal cancellation,List<Entry> found)throws Exception{
        LinkedHashMap<String,Entry> discovered=new LinkedHashMap<>();Uri uri=MediaStore.Files.getContentUri("external");boolean access=fileAccess();String selection;String[] args=null;
        if(category.isEmpty()||category.equals("Status")||category.equals("Media")){selection=MediaStore.MediaColumns.DATA+" LIKE ?";args=new String[]{"%WhatsApp%"};}
        else if(category.equals("Large Files")){selection="_size > ?";args=new String[]{String.valueOf(50L*1024*1024)};}
        else selection="media_type IN (0,6)";
        try(Cursor c=activity.getContentResolver().query(uri,new String[]{"_id","_display_name","mime_type","_size","date_modified",MediaStore.MediaColumns.DATA},selection,args,"date_modified DESC",cancellation)){
            while(c!=null&&c.moveToNext()){
                checkLoad(version);String name=c.isNull(1)?"File":c.getString(1),mime=c.isNull(2)?"application/octet-stream":c.getString(2),path=c.isNull(5)?"":c.getString(5);long size=c.isNull(3)?-1:c.getLong(3);if(!category.isEmpty()&&!PickerFiles.matches(name,mime,size,path,category))continue;
                Entry e;if(access){if(path.isEmpty())continue;File file=new File(path);if(!file.isFile()||!file.canRead())continue;e=fileEntry(file);e.mime=mime;}else{e=new Entry();e.uri=ContentUris.withAppendedId(uri,c.getLong(0));e.name=name;e.mime=mime;e.path=path;e.folder=path.isEmpty()?"":new File(path).getParent();e.size=size;e.date=c.isNull(4)?0:c.getLong(4)*1000L;}discovered.put(e.key(),e);if(!category.isEmpty())publishPackages(version,discovered.values());
            }
        }catch(Exception e){checkLoad(version);if(!access)throw e;}
        if(access&&!category.isEmpty())PickerFiles.scanDocuments(storageRoot,category,()->checkLoad(version),batch->{checkLoad(version);for(File file:batch){Entry e=fileEntry(file);discovered.put(e.key(),e);}publishPackages(version,discovered.values());});
        checkLoad(version);found.addAll(discovered.values());found.sort((a,b)->Long.compare(b.date,a.date));
    }
    private void load(){
        final int version=++generation;final String type=tab,category=fileFilter;final boolean apk=packages;final File directory=storageDirectory;
        if(loadTask!=null)loadTask.cancel(true);if(queryCancellation!=null)queryCancellation.cancel();
        final android.os.CancellationSignal cancellation=new android.os.CancellationSignal();queryCancellation=cancellation;
        for(Map.Entry<String,TextView> t:tabs.entrySet()){boolean active=t.getKey().equals(tab);t.getValue().setTextColor(active?BLUE:DIM);t.getValue().setBackground(active?underline():null);}
        tabStrip.post(()->{if(!closed&&generation==version)tabStrip.smoothScrollTo(Math.max(0,tabs.get(type).getLeft()-dp(86)),0);});
        updateSegments();entries.clear();storageFolders.clear();loadMessage="";loadFailed=false;restrictedAccess=false;empty.setOnClickListener(null);
        if(documentCacheAccess!=fileAccess()){documentCache.clear();documentCacheAccess=fileAccess();}
        if(type.equals("apps")&&apk&&packageCache!=null&&packageCacheAccess==fileAccess()){entries.addAll(packageCache);loading=false;rebuild();return;}
        if(type.equals("files")&&!category.equals("Storage")&&documentCache.containsKey(category)){entries.addAll(documentCache.get(category));loading=false;rebuild();return;}
        loading=true;rebuild();
        loadTask=loader.submit(()->{
            List<Entry> found=new ArrayList<>();List<File> directories=new ArrayList<>();boolean denied=false;String error="";
            try{
                checkLoad(version);
                if(type.equals("contacts")){
                    if(activity.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)throw new SecurityException();
                    PersonalRecords.Result contacts=PersonalRecords.load(activity,"contacts",()->checkLoad(version));
                    for(PersonalRecords.Row row:contacts.rows){Entry e=new Entry();e.contact=row;int line=row.label.indexOf('\n');e.name=line<0?row.label:row.label.substring(0,line);e.mime="text/x-vcard";found.add(e);}
                }else if(type.equals("apps")&&!apk){
                    PackageManager pm=activity.getPackageManager();long since=System.currentTimeMillis()-7L*24*60*60*1000;
                    for(ApplicationInfo app:pm.getInstalledApplications(0)){
                        checkLoad(version);if((app.flags&ApplicationInfo.FLAG_SYSTEM)!=0||app.sourceDir==null)continue;
                        Entry e=new Entry();e.app=app;e.name=pm.getApplicationLabel(app).toString();e.mime=AppBundle.MIME;e.size=new File(app.sourceDir).length();if(app.splitSourceDirs!=null)for(String path:app.splitSourceDirs)e.size+=new File(path).length();
                        try{e.recent=pm.getPackageInfo(app.packageName,0).firstInstallTime>=since;}catch(Exception ignored){}found.add(e);
                    }
                    found.sort((x,y)->x.recent==y.recent?x.name.compareToIgnoreCase(y.name):x.recent?-1:1);
                }else if(type.equals("apps")&&apk){
                    loadPackages(version,cancellation,found);
                }else if(type.equals("files")){
                    if(category.equals("Storage")){if(!fileAccess())throw new SecurityException();for(File file:StorageFiles.list(storageRoot,directory,()->checkLoad(version))){if(file.isDirectory())directories.add(file);else found.add(fileEntry(file));}}
                    else loadDocuments(version,category,cancellation,found);
                }else{
                    boolean photos=type.equals("photos"),videos=type.equals("videos");
                    String permission=Build.VERSION.SDK_INT>=33?photos?Manifest.permission.READ_MEDIA_IMAGES:videos?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;
                    boolean partial=Build.VERSION.SDK_INT>=34&&(photos||videos)&&activity.checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)==PackageManager.PERMISSION_GRANTED;
                    if(activity.checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED&&!partial)throw new SecurityException();
                    Uri uri=photos?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:videos?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    String folderColumn=Build.VERSION.SDK_INT>=29?MediaStore.MediaColumns.RELATIVE_PATH:MediaStore.MediaColumns.DATA;
                    String[] fields=photos||videos?new String[]{"_id","_display_name","mime_type","_size","date_added",folderColumn,MediaStore.MediaColumns.DATA}:new String[]{"_id","_display_name","mime_type","_size","date_added",folderColumn,MediaStore.MediaColumns.DATA,"title","artist","duration","album_id"};
                    try(Cursor c=activity.getContentResolver().query(uri,fields,null,null,"date_added DESC",cancellation)){
                        while(c!=null&&c.moveToNext()){checkLoad(version);Entry e=new Entry();e.uri=ContentUris.withAppendedId(uri,c.getLong(0));e.name=c.isNull(1)?"File":c.getString(1);e.mime=c.isNull(2)?photos?"image/jpeg":videos?"video/mp4":"audio/mpeg":c.getString(2);e.size=c.isNull(3)?-1:c.getLong(3);e.date=c.getLong(4)*1000L;e.path=c.isNull(6)?"":c.getString(6);e.folder=c.isNull(5)?"":c.getString(5);if(Build.VERSION.SDK_INT<29){e.path=e.folder;int slash=e.folder.lastIndexOf('/');e.folder=slash<0?"":e.folder.substring(0,slash);}if(!photos&&!videos){e.title=c.isNull(7)?"":c.getString(7);e.artist=c.isNull(8)?"":c.getString(8);e.duration=c.isNull(9)?0:c.getLong(9);e.albumId=c.isNull(10)?0:c.getLong(10);}found.add(e);}
                    }
                }
            }catch(SecurityException e){denied=true;}catch(IOException e){if(generation!=version||closed)return;error="Unable to read files. Tap to retry.";}catch(Exception e){error="Unable to load items. Tap to retry.";}
            final boolean restricted=denied;final String message=error;
            activity.runOnUiThread(()->{if(closed||generation!=version)return;loading=false;
                loadFailed=!message.isEmpty();restrictedAccess=restricted;
                if(type.equals("apps")&&apk&&!restricted&&message.isEmpty()){packageCache=new ArrayList<>(found);packageCacheAccess=fileAccess();}
                if(type.equals("files")&&!category.equals("Storage")&&!restricted&&message.isEmpty())documentCache.put(category,new ArrayList<>(found));
                storageFolders.clear();storageFolders.addAll(directories);
                Map<String,Entry> previous=new HashMap<>();for(Entry old:selected.values())if(old.uri!=null)previous.put(old.uri.toString(),old);
                for(Entry e:found)if(e.uri!=null){Entry old=previous.get(e.uri.toString());if(old!=null){selected.remove(old.key());selected.put(e.key(),e);}}
                if(restricted||message.isEmpty()||!found.isEmpty()){entries.clear();entries.addAll(found);}loadMessage=restricted?"Tap to allow access":!message.isEmpty()?message:type.equals("contacts")?"No contacts found":type.equals("apps")&&apk?"No APK or app bundle files found":"No files found";empty.setOnClickListener(v->{if(restricted)actions.permission(type);else reload();});rebuild();});
        });
    }
    private android.graphics.drawable.Drawable underline(){android.graphics.drawable.LayerDrawable line=new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{shape(BLUE,2)});line.setLayerInset(0,dp(32),dp(51),dp(32),dp(2));return line;}
    private void packageIcon(Entry entry,ImageView target){
        String key="package-icon:"+entry.key()+":"+entry.size+":"+entry.date;target.setTag(key);
        android.graphics.Bitmap cached=images.get(key);if(cached!=null){target.setImageBitmap(cached);return;}
        if(closed)return;
        List<WeakReference<ImageView>> waiting=iconTargets.get(key);
        if(waiting!=null){waiting.add(new WeakReference<>(target));return;}
        waiting=new ArrayList<>();waiting.add(new WeakReference<>(target));iconTargets.put(key,waiting);
        try{packageIcons.execute(()->{
            android.graphics.Bitmap image=null;
            try{
                PackageManager pm=activity.getPackageManager();PackageInfo info=pm.getPackageArchiveInfo(entry.uri.getPath(),0);
                if(info!=null&&info.applicationInfo!=null){
                    info.applicationInfo.sourceDir=entry.uri.getPath();info.applicationInfo.publicSourceDir=entry.uri.getPath();
                    android.graphics.drawable.Drawable drawable=info.applicationInfo.loadIcon(pm);
                    if(drawable!=null){int side=Math.min(160,dp(58));image=android.graphics.Bitmap.createBitmap(side,side,android.graphics.Bitmap.Config.ARGB_8888);drawable.setBounds(0,0,side,side);drawable.draw(new android.graphics.Canvas(image));}
                }
            }catch(Exception ignored){}
            if(image==null&&!closed){int side=Math.min(160,dp(58));image=android.graphics.Bitmap.createBitmap(side,side,android.graphics.Bitmap.Config.ARGB_8888);android.graphics.drawable.Drawable generic=activity.getDrawable(android.R.drawable.sym_def_app_icon);if(generic!=null){generic.setBounds(0,0,side,side);generic.draw(new android.graphics.Canvas(image));}}
            final android.graphics.Bitmap result=image;if(closed)return;
            activity.runOnUiThread(()->{List<WeakReference<ImageView>> targets=iconTargets.remove(key);if(closed||result==null)return;images.put(key,result);if(targets!=null)for(WeakReference<ImageView> reference:targets){ImageView view=reference.get();if(view!=null&&key.equals(view.getTag()))view.setImageBitmap(result);}});
        });}catch(RejectedExecutionException ignored){iconTargets.remove(key);}
    }
    private void thumbnail(Entry entry,ImageView target){
        String key=entry.uri.toString();target.setTag(key);android.graphics.Bitmap cached=images.get(key);if(cached!=null){target.setImageBitmap(cached);return;}
        if(closed)return;thumbnails.execute(()->{android.graphics.Bitmap image=null;
            try{if(Build.VERSION.SDK_INT>=29)image=activity.getContentResolver().loadThumbnail(entry.uri,new android.util.Size(160,160),null);
                else if(entry.mime.startsWith("video/"))image=MediaStore.Video.Thumbnails.getThumbnail(activity.getContentResolver(),ContentUris.parseId(entry.uri),MediaStore.Video.Thumbnails.MINI_KIND,null);
                else image=MediaStore.Images.Thumbnails.getThumbnail(activity.getContentResolver(),ContentUris.parseId(entry.uri),MediaStore.Images.Thumbnails.MINI_KIND,null);
            }catch(Exception ignored){}
            if(image!=null&&!closed){images.put(key,image);final android.graphics.Bitmap result=image;activity.runOnUiThread(()->{if(!closed&&key.equals(target.getTag()))target.setImageBitmap(result);});}
        });
    }
    void close(){closed=true;++folderGeneration;if(folderTask!=null)folderTask.cancel(true);if(queryCancellation!=null)queryCancellation.cancel();loader.shutdownNow();folderLoader.shutdownNow();thumbnails.shutdownNow();packageIcons.shutdownNow();iconTargets.clear();images.evictAll();}
}
