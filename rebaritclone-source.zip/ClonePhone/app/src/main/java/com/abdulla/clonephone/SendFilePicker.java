package com.abdulla.clonephone;

import android.app.Activity;
import android.content.ContentUris;
import android.content.pm.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;
import java.util.concurrent.*;

/** Full-screen sender picker. Selection survives tab changes and search filters. */
final class SendFilePicker extends LinearLayout {
    static final class Entry {
        Uri uri; String name,mime; long size; ApplicationInfo app; boolean recent;
        String key(){return app==null?uri.toString():"app:"+app.packageName;}
    }
    interface Actions {
        void back(); void browse(); void permission(String tab); void next(List<Entry> entries);
    }
    private enum Notice { APP_BUNDLE, BROWSE }
    private static final int INK=0xff25262b,DIM=0xff898b91,BLUE=0xff3266df,BG=0xfffafafa;
    private final Activity activity;
    private final Actions actions;
    private final ExecutorService loader=Executors.newSingleThreadExecutor();
    private final ThreadPoolExecutor thumbnails=new ThreadPoolExecutor(2,2,10,TimeUnit.SECONDS,new ArrayBlockingQueue<>(64),new ThreadPoolExecutor.DiscardOldestPolicy());
    private final android.util.LruCache<String,android.graphics.Bitmap> images=new android.util.LruCache<String,android.graphics.Bitmap>(8*1024*1024){protected int sizeOf(String key,android.graphics.Bitmap image){return image.getByteCount();}};
    private final LinkedHashMap<String,Entry> selected=new LinkedHashMap<>();
    private final List<Entry> entries=new ArrayList<>();
    private final List<Object> rows=new ArrayList<>();
    private final Set<String> collapsed=new HashSet<>();
    private final Map<String,TextView> tabs=new LinkedHashMap<>();
    private final LinearLayout segments;
    private final ListView list;
    private final TextView count,empty,next;
    private final EditText search;
    private final BaseAdapter adapter;
    private String tab="apps",query="";
    private boolean packages;
    private volatile boolean closed;
    private int generation;

    SendFilePicker(Activity a,List<Entry> initial,Actions callback){
        super(a);activity=a;actions=callback;
        for(Entry e:initial)selected.put(e.key(),e);
        setOrientation(VERTICAL);setLayoutDirection(LAYOUT_DIRECTION_LTR);setBackgroundColor(BG);
        setPadding(dp(14),0,dp(14),0);
        LinearLayout header=new LinearLayout(a);header.setGravity(Gravity.CENTER_VERTICAL);
        addView(header,new LayoutParams(-1,dp(60)));
        TextView back=text("←",28,INK,false);back.setGravity(Gravity.CENTER);back.setContentDescription("Back");
        header.addView(back,new LayoutParams(dp(44),-1));back.setOnClickListener(v->actions.back());
        TextView title=text("Select Files",21,INK,true);header.addView(title,new LayoutParams(0,-2,1));
        ImageButton find=new ImageButton(a);find.setImageResource(android.R.drawable.ic_menu_search);
        find.setBackgroundColor(Color.TRANSPARENT);find.setContentDescription("Search files");
        header.addView(find,new LayoutParams(dp(48),dp(48)));
        search=new EditText(a);search.setSingleLine(true);search.setTextSize(16);search.setHint("Search files");
        search.setTextColor(INK);search.setHintTextColor(DIM);search.setBackground(shape(0xfff0f0f2,12));
        search.setPadding(dp(12),0,dp(12),0);search.setVisibility(GONE);addView(search,new LayoutParams(-1,dp(44)));
        find.setOnClickListener(v->{search.setVisibility(search.getVisibility()==VISIBLE?GONE:VISIBLE);if(search.getVisibility()==VISIBLE){search.requestFocus();((android.view.inputmethod.InputMethodManager)a.getSystemService(android.content.Context.INPUT_METHOD_SERVICE)).showSoftInput(search,0);}else search.setText("");});
        HorizontalScrollView strip=new HorizontalScrollView(a);strip.setHorizontalScrollBarEnabled(false);
        LinearLayout tabRow=new LinearLayout(a);strip.addView(tabRow);addView(strip,new LayoutParams(-1,dp(56)));
        String[] ids={"files","videos","apps","photos","audio"},labels={"FILES","VIDEOS","APPS","PHOTOS","MUSIC"};
        for(int i=0;i<ids.length;i++){
            final String id=ids[i];TextView t=text(labels[i],15,DIM,true);t.setGravity(Gravity.CENTER);
            tabRow.addView(t,new LayoutParams(dp(86),-1));tabs.put(id,t);
            t.setOnClickListener(v->{tab=id;packages=false;collapsed.clear();load();});
        }
        segments=new LinearLayout(a);segments.setPadding(dp(4),dp(4),dp(4),dp(4));segments.setBackground(shape(0xfff0f0f2,15));
        LayoutParams segmentParams=new LayoutParams(-1,dp(48));segmentParams.setMargins(0,dp(8),0,dp(14));addView(segments,segmentParams);
        TextView installed=text("Installed",16,INK,true),notInstalled=text("Not Installed",16,INK,true);
        for(TextView t:Arrays.asList(installed,notInstalled)){t.setGravity(Gravity.CENTER);segments.addView(t,new LayoutParams(0,-1,1));}
        installed.setOnClickListener(v->{packages=false;load();});notInstalled.setOnClickListener(v->{packages=true;load();});
        FrameLayout content=new FrameLayout(a);addView(content,new LayoutParams(-1,0,1));
        list=new ListView(a);list.setDivider(null);list.setVerticalScrollBarEnabled(false);content.addView(list,new FrameLayout.LayoutParams(-1,-1));
        empty=text("Loading…",15,DIM,false);empty.setGravity(Gravity.CENTER);content.addView(empty,new FrameLayout.LayoutParams(-1,-1));list.setEmptyView(empty);
        adapter=new BaseAdapter(){
            public int getCount(){return rows.size();}public Object getItem(int p){return rows.get(p);}public long getItemId(int p){return p;}
            public boolean isEnabled(int p){return false;}
            public View getView(int p,View old,ViewGroup parent){
                Object row=rows.get(p);
                if(row instanceof String)return section((String)row);
                if(row==Notice.BROWSE){TextView browse=text("Browse other files…",14,BLUE,true);browse.setPadding(dp(10),dp(14),dp(10),dp(14));browse.setOnClickListener(v->actions.browse());return browse;}
                if(row==Notice.APP_BUNDLE){TextView note=text("▣  App packages and split APKs are transferred together.",13,0xffc87525,true);note.setPadding(dp(14),dp(14),dp(14),dp(14));note.setBackground(shape(0xffffefdf,10));return note;}
                @SuppressWarnings("unchecked") List<Entry> cells=(List<Entry>)row;
                LinearLayout line=new LinearLayout(a);line.setPadding(dp(2),dp(5),dp(2),dp(10));
                for(Entry e:cells)line.addView(cell(e),new LayoutParams(0,dp(122),1));
                for(int n=cells.size();n<4;n++)line.addView(new View(a),new LayoutParams(0,1,1));
                return line;
            }
        };list.setAdapter(adapter);
        LinearLayout footer=new LinearLayout(a);footer.setGravity(Gravity.CENTER_VERTICAL);footer.setPadding(0,dp(10),0,dp(14));footer.setBackgroundColor(BG);
        addView(footer,new LayoutParams(-1,dp(78)));count=text("",15,INK,true);footer.addView(count,new LayoutParams(0,-2,1));
        next=text("NEXT",16,Color.WHITE,true);next.setGravity(Gravity.CENTER);next.setBackground(shape(BLUE,8));
        footer.addView(next,new LayoutParams(0,dp(48),1));next.setOnClickListener(v->{if(!selected.isEmpty())actions.next(new ArrayList<>(selected.values()));});
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int af){}public void afterTextChanged(android.text.Editable e){}public void onTextChanged(CharSequence s,int st,int b,int c){query=s.toString().toLowerCase(Locale.ROOT);rebuild();}});
        load();
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(activity);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private String group(Entry e){return "apps".equals(tab)?packages?"Not Installed":e.recent?"New":"Apps":"files".equals(tab)?"Files":"videos".equals(tab)?"Videos":"photos".equals(tab)?"Photos":"Music";}
    private List<Entry> members(String title){List<Entry> out=new ArrayList<>();for(Entry e:entries)if(group(e).equals(title)&&e.name.toLowerCase(Locale.ROOT).contains(query))out.add(e);return out;}
    private View section(String title){
        List<Entry> items=members(title);LinearLayout header=new LinearLayout(activity);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(8),dp(16),dp(4),dp(10));
        TextView name=text((collapsed.contains(title)?"⌄":"⌃")+"  "+title+" ("+items.size()+")",17,INK,true);header.addView(name,new LayoutParams(0,dp(40),1));name.setOnClickListener(v->{if(!collapsed.add(title))collapsed.remove(title);rebuild();});
        boolean all=!items.isEmpty();for(Entry e:items)all&=selected.containsKey(e.key());final boolean checked=all;
        TextView check=text(all?"●":"○",27,all?BLUE:0xffc5c7cc,false);check.setGravity(Gravity.CENTER);check.setContentDescription("Select all "+title);header.addView(check,new LayoutParams(dp(48),dp(48)));
        check.setOnClickListener(v->{for(Entry e:items)if(checked)selected.remove(e.key());else selected.put(e.key(),e);rebuild();});return header;
    }
    private View cell(Entry e){
        boolean checked=selected.containsKey(e.key());LinearLayout cell=new LinearLayout(activity);cell.setOrientation(VERTICAL);cell.setGravity(Gravity.CENTER_HORIZONTAL);cell.setPadding(dp(4),dp(6),dp(4),0);cell.setBackground(shape(checked?0xffeaf0ff:Color.TRANSPARENT,12));
        FrameLayout iconBox=new FrameLayout(activity);cell.addView(iconBox,new LayoutParams(dp(58),dp(58)));
        ImageView icon=new ImageView(activity);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);iconBox.addView(icon,new FrameLayout.LayoutParams(-1,-1));
        if(e.app!=null)try{icon.setImageDrawable(activity.getPackageManager().getApplicationIcon(e.app));}catch(Exception ignored){icon.setImageResource(android.R.drawable.sym_def_app_icon);}
        else icon.setImageResource(e.mime.startsWith("video/")?android.R.drawable.ic_media_play:e.mime.startsWith("image/")?android.R.drawable.ic_menu_gallery:e.mime.startsWith("audio/")?android.R.drawable.ic_media_ff:android.R.drawable.ic_menu_save);
        if(e.app==null&&(e.mime.startsWith("image/")||e.mime.startsWith("video/")))thumbnail(e,icon);
        if(checked){TextView tick=text("✓",13,Color.WHITE,true);tick.setGravity(Gravity.CENTER);tick.setBackground(shape(BLUE,20));iconBox.addView(tick,new FrameLayout.LayoutParams(dp(22),dp(22),Gravity.TOP|Gravity.RIGHT));}
        TextView name=text(e.name,12,INK,true);name.setMaxLines(1);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setGravity(Gravity.CENTER);name.setPadding(0,dp(9),0,dp(3));cell.addView(name,new LayoutParams(-1,-2));
        TextView size=text(TransferStats.size(e.size),11,DIM,false);size.setGravity(Gravity.CENTER);cell.addView(size);
        cell.setContentDescription(e.name+", "+size.getText()+", "+(checked?"selected":"not selected"));cell.setFocusable(true);cell.setOnClickListener(v->{if(selected.containsKey(e.key()))selected.remove(e.key());else selected.put(e.key(),e);rebuild();});return cell;
    }
    private void rebuild(){
        if(closed)return;rows.clear();LinkedHashSet<String> groups=new LinkedHashSet<>();for(Entry e:entries)if(e.name.toLowerCase(Locale.ROOT).contains(query))groups.add(group(e));
        for(String title:groups){rows.add(title);if(collapsed.contains(title))continue;if(title.equals("Apps"))rows.add(Notice.APP_BUNDLE);List<Entry> cells=null;for(Entry e:members(title)){if(cells==null||cells.size()==4){cells=new ArrayList<>();rows.add(cells);}cells.add(e);}}
        if(!entries.isEmpty()&&(tab.equals("files")||(tab.equals("apps")&&packages)))rows.add(Notice.BROWSE);
        count.setText(selected.size()+" file(s) selected");next.setEnabled(!selected.isEmpty());next.setAlpha(selected.isEmpty()?.55f:1f);adapter.notifyDataSetChanged();
    }
    List<Entry> selection(){return new ArrayList<>(selected.values());}
    void reload(){load();}
    private void load(){
        final int version=++generation;final String type=tab;final boolean apk=packages;
        for(Map.Entry<String,TextView> t:tabs.entrySet()){boolean active=t.getKey().equals(tab);t.getValue().setTextColor(active?BLUE:DIM);t.getValue().setBackground(active?underline():null);}
        segments.setVisibility("apps".equals(tab)?VISIBLE:GONE);
        for(int i=0;i<2;i++)segments.getChildAt(i).setBackground(shape((i==1)==packages?Color.WHITE:Color.TRANSPARENT,12));
        entries.clear();empty.setText("Loading…");empty.setOnClickListener(null);rebuild();
        loader.execute(()->{
            List<Entry> found=new ArrayList<>();boolean denied=false;
            try{
                if(type.equals("apps")&&!apk){
                    PackageManager pm=activity.getPackageManager();long since=System.currentTimeMillis()-7L*24*60*60*1000;
                    for(ApplicationInfo app:pm.getInstalledApplications(0)){
                        if(closed)return;if((app.flags&ApplicationInfo.FLAG_SYSTEM)!=0||app.sourceDir==null)continue;
                        Entry e=new Entry();e.app=app;e.name=pm.getApplicationLabel(app).toString();e.mime=AppBundle.MIME;e.size=new File(app.sourceDir).length();if(app.splitSourceDirs!=null)for(String path:app.splitSourceDirs)e.size+=new File(path).length();
                        try{e.recent=pm.getPackageInfo(app.packageName,0).firstInstallTime>=since;}catch(Exception ignored){}found.add(e);
                    }
                    found.sort((x,y)->x.recent==y.recent?x.name.compareToIgnoreCase(y.name):x.recent?-1:1);
                }else{
                    Uri uri=type.equals("photos")?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:type.equals("videos")?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:type.equals("audio")?MediaStore.Audio.Media.EXTERNAL_CONTENT_URI:MediaStore.Files.getContentUri("external");
                    String condition=apk?"(_display_name LIKE ? OR mime_type=?)":type.equals("files")?"media_type=0":null;
                    String[] args=apk?new String[]{"%.apk","application/vnd.android.package-archive"}:null;
                    try(Cursor c=activity.getContentResolver().query(uri,new String[]{"_id","_display_name","mime_type","_size"},condition,args,"date_added DESC")){
                        while(c!=null&&c.moveToNext()&&!closed){Entry e=new Entry();e.uri=ContentUris.withAppendedId(uri,c.getLong(0));e.name=c.isNull(1)?"File":c.getString(1);e.mime=c.isNull(2)?"application/octet-stream":c.getString(2);e.size=c.isNull(3)?-1:c.getLong(3);found.add(e);}
                    }
                }
            }catch(SecurityException e){denied=true;}catch(Exception ignored){}
            final boolean restricted=denied;
            activity.runOnUiThread(()->{if(closed||generation!=version)return;entries.addAll(found);empty.setText(restricted?"Tap to allow access":apk?"No APK files found. Tap to browse.":"No files found. Tap to browse.");empty.setOnClickListener(v->{if(restricted)actions.permission(type);else actions.browse();});rebuild();});
        });
    }
    private android.graphics.drawable.Drawable underline(){android.graphics.drawable.LayerDrawable line=new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{shape(BLUE,2)});line.setLayerInset(0,dp(32),dp(51),dp(32),dp(2));return line;}
    private void thumbnail(Entry entry,ImageView target){
        String key=entry.uri.toString();target.setTag(key);android.graphics.Bitmap cached=images.get(key);if(cached!=null){target.setImageBitmap(cached);return;}
        if(closed)return;thumbnails.execute(()->{android.graphics.Bitmap image=null;
            try{if(Build.VERSION.SDK_INT>=29)image=activity.getContentResolver().loadThumbnail(entry.uri,new android.util.Size(160,160),null);
                else if(entry.mime.startsWith("video/"))image=MediaStore.Video.Thumbnails.getThumbnail(activity.getContentResolver(),ContentUris.parseId(entry.uri),MediaStore.Video.Thumbnails.MINI_KIND,null);
                else image=MediaStore.Images.Thumbnails.getThumbnail(activity.getContentResolver(),ContentUris.parseId(entry.uri),MediaStore.Images.Thumbnails.MINI_KIND,null);
            }catch(Exception ignored){}
            if(image!=null&&!closed){images.put(key,image);final android.graphics.Bitmap result=image;activity.runOnUiThread(()->{if(!closed&&key.equals(target.getTag()))target.setImageBitmap(result);});}
        });
    }
    void close(){closed=true;loader.shutdownNow();thumbnails.shutdownNow();images.evictAll();}
}
