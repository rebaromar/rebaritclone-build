package com.abdulla.clonephone;

import java.util.*;

/** Shared classification for inventory, selected payloads and transfer progress. */
final class DocumentTypes {
    private static final Set<String> EXTENSIONS=new HashSet<>(Arrays.asList(
        "pdf","doc","docx","docm","dot","dotx","dotm",
        "xls","xlsx","xlsm","xlsb","xlt","xltx","xltm",
        "ppt","pptx","pptm","pot","potx","potm","pps","ppsx","ppsm",
        "odt","ods","odp","odg","ott","ots","otp","rtf","txt","csv","tsv",
        "md","markdown","html","htm","epub","mobi","azw","azw3","fb2",
        "djvu","djv","xps","oxps","pages","numbers","key","wps","wpd","tex","ps"));
    private static final Set<String> EXCLUDED=new HashSet<>(Arrays.asList(
        "apk","rbapp","zip","rar","7z","tar","gz","bin","db","sqlite","sqlite3",
        "json","xml","log","tmp","bak","vcf","exe","dll","so"));
    static boolean matches(String name,String mime){
        String filename=name==null?"":name.toLowerCase(Locale.ROOT);
        String type=mime==null?"":mime.toLowerCase(Locale.ROOT).split(";",2)[0].trim();
        if(type.startsWith("image/")||type.startsWith("video/")||type.startsWith("audio/"))return false;
        int dot=filename.lastIndexOf('.');String extension=dot<0?"":filename.substring(dot+1);
        if(EXCLUDED.contains(extension))return false;
        if(EXTENSIONS.contains(extension))return true;
        if(type.equals("application/pdf")||type.equals("application/msword")||type.equals("application/rtf")||type.equals("application/postscript")||type.equals("application/epub+zip")||type.equals("application/vnd.ms-xpsdocument")||type.equals("application/oxps"))return true;
        if(type.startsWith("application/vnd.openxmlformats-officedocument.")||type.startsWith("application/vnd.oasis.opendocument.")||type.startsWith("application/vnd.ms-excel")||type.startsWith("application/vnd.ms-word")||type.startsWith("application/vnd.ms-powerpoint"))return true;
        return extension.isEmpty()&&(type.equals("text/plain")||type.equals("text/csv")||type.equals("text/tab-separated-values")||type.equals("text/rtf")||type.equals("text/html")||type.equals("text/markdown"));
    }
    private DocumentTypes(){}
}
