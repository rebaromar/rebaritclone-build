package com.abdulla.clonephone;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructStatVfs;

import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;

/** Receives into the final pending destination without a second full-size cache copy. */
final class UriResumeStorage implements ResumableFile.Storage {
    private final ContentResolver resolver;
    private final boolean document;
    private Uri uri;

    UriResumeStorage(ContentResolver resolver, Uri uri, boolean document) {
        if (resolver == null || uri == null) throw new IllegalArgumentException("Missing destination");
        this.resolver = resolver;
        this.uri = uri;
        this.document = document;
    }

    Uri uri() { return uri; }

    /** SAF providers may return a new document URI when the partial name is finalized. */
    void renamed(Uri updated) {
        if (updated == null) throw new IllegalArgumentException("Missing destination");
        uri = updated;
    }

    @Override public String identity() { return uri.toString(); }

    @Override public long length() throws IOException {
        try (ParcelFileDescriptor descriptor = open("r")) {
            try { return Os.fstat(descriptor.getFileDescriptor()).st_size; }
            catch (ErrnoException error) { throw io("Cannot inspect destination", error); }
        }
    }

    @Override public InputStream openRead() throws IOException {
        ParcelFileDescriptor descriptor = open("r");
        try {
            Os.lseek(descriptor.getFileDescriptor(), 0L, OsConstants.SEEK_SET);
            return new ParcelFileDescriptor.AutoCloseInputStream(descriptor);
        } catch (ErrnoException | RuntimeException error) {
            closeAfterFailure(descriptor, error);
            throw io("Cannot read destination", error);
        }
    }

    @Override public ResumableFile.RandomAccess openWrite() throws IOException {
        // "rw" preserves a retained prefix. "w" and "rwt" may erase it on reopen.
        return new DestinationWriter(open("rw"));
    }

    /** Reject pipe/cloud providers before transfer: safe resumption requires random access. */
    void validateWritable() throws IOException {
        try (ResumableFile.RandomAccess ignored = openWrite()) { }
    }

    /** Free space on this descriptor's actual volume, including removable SAF volumes. */
    long availableBytes() throws IOException {
        try (ParcelFileDescriptor descriptor = open("r")) {
            try {
                StructStatVfs stats = Os.fstatvfs(descriptor.getFileDescriptor());
                long blocks = stats.f_bavail, blockSize = stats.f_frsize;
                if (blocks < 0L || blockSize <= 0L) return -1L;
                return blocks > Long.MAX_VALUE / blockSize ? Long.MAX_VALUE : blocks * blockSize;
            } catch (ErrnoException error) {
                // Some document providers cannot report capacity; writes still report ENOSPC.
                return -1L;
            }
        }
    }

    @Override public void discard() throws IOException {
        try {
            if (document) {
                if (!DocumentsContract.deleteDocument(resolver, uri)) throw new IOException("Cannot remove partial destination");
            } else {
                resolver.delete(uri, null, null);
            }
        } catch (RuntimeException error) {
            throw io("Cannot remove partial destination", error);
        }
    }

    private ParcelFileDescriptor open(String mode) throws IOException {
        ParcelFileDescriptor descriptor = null;
        try {
            descriptor = resolver.openFileDescriptor(uri, mode);
            if (descriptor == null) throw new IOException("Storage unavailable");
            FileDescriptor fd = descriptor.getFileDescriptor();
            if (!OsConstants.S_ISREG(Os.fstat(fd).st_mode)) throw new IOException("Destination does not support resumable files; choose local device storage");
            Os.lseek(fd, 0L, OsConstants.SEEK_CUR);
            return descriptor;
        } catch (ErrnoException | RuntimeException | IOException error) {
            closeAfterFailure(descriptor, error);
            if (error instanceof IOException) throw (IOException) error;
            throw io("Destination does not support resumable files; choose local device storage", error);
        }
    }

    private static IOException io(String message, Exception cause) { return new IOException(message, cause); }

    private static void closeAfterFailure(ParcelFileDescriptor descriptor, Exception cause) {
        if (descriptor == null) return;
        try { descriptor.close(); } catch (IOException closeError) { cause.addSuppressed(closeError); }
    }

    private static final class DestinationWriter implements ResumableFile.RandomAccess {
        private final ParcelFileDescriptor descriptor;
        private final FileDescriptor fd;

        DestinationWriter(ParcelFileDescriptor descriptor) {
            this.descriptor = descriptor;
            fd = descriptor.getFileDescriptor();
        }

        @Override public void seek(long position) throws IOException {
            if (position < 0L) throw new IOException("Invalid destination offset");
            try { if (Os.lseek(fd, position, OsConstants.SEEK_SET) != position) throw new IOException("Invalid destination offset"); }
            catch (ErrnoException error) { throw io("Cannot seek destination", error); }
        }

        @Override public void write(byte[] data, int offset, int length) throws IOException {
            if (offset < 0 || length < 0 || offset > data.length - length) throw new IndexOutOfBoundsException();
            while (length > 0) {
                int written;
                try { written = Os.write(fd, data, offset, length); }
                catch (ErrnoException error) { throw io("Cannot write destination", error); }
                if (written <= 0) throw new IOException("Cannot write destination");
                offset += written;
                length -= written;
            }
        }

        @Override public void truncate(long length) throws IOException {
            if (length < 0L) throw new IOException("Invalid destination length");
            try { Os.ftruncate(fd, length); }
            catch (ErrnoException error) { throw io("Cannot truncate destination", error); }
        }

        @Override public void sync() throws IOException {
            try { Os.fsync(fd); }
            catch (ErrnoException error) { throw io("Cannot sync destination", error); }
        }

        @Override public void close() throws IOException { descriptor.close(); }
    }
}
