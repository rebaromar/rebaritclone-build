package com.abdulla.clonephone;

import android.app.PendingIntent;
import android.content.*;
import android.hardware.usb.*;
import android.os.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/**
 * Reliable Android-to-Android USB transport.
 *
 * Logical transfer direction is intentionally decoupled from the physical USB role:
 * either phone may become the Type-C USB host. The physical host switches its peer
 * into Android Open Accessory (AOA) mode; the other side opens UsbAccessory.
 */
final class UsbLink {
    interface Listener {
        void ready(InputStream in, OutputStream out);
        void failed(String reason);
        default void status(String message) {}
    }

    private static final int DISCOVERY_TIMEOUT_MS = 180_000;
    private static final int USB_IO_TIMEOUT_MS = 60_000;
    private static final int MAX_OPEN_FAILURES = 3;
    private static final int MODERN_BULK = 64 * 1024;
    private static final int LEGACY_BULK = 16 * 1024;

    private final Context context;
    private final UsbManager manager;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final String permissionAction;
    private final Set<String> requested = new HashSet<>();
    private final Map<String,Integer> failures = new HashMap<>();

    private boolean preferHost, running, opening, connected, registered;
    private int generation;
    private long deadline;
    private Listener listener;
    private UsbDeviceConnection connection;
    private ParcelFileDescriptor descriptor;
    private InputStream input;
    private OutputStream output;
    private String activeDeviceName;
    private UsbAccessory activeAccessory;

    UsbLink(Context context) {
        this.context = context;
        manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        permissionAction = context.getPackageName() + ".USB_PERMISSION";
    }

    private static int bulkSize() {
        return Build.VERSION.SDK_INT >= 28 ? MODERN_BULK : LEGACY_BULK;
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent intent) {
            if (!running) return;
            String action = intent.getAction();
            if (permissionAction.equals(action)) {
                opening = false;
                if (!intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                    notifyStatus("USB permission ڕەتکرایەوە");
                }
                pollSoon(40);
                return;
            }
            if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action) || UsbManager.ACTION_USB_ACCESSORY_ATTACHED.equals(action)) {
                if (!connected) {
                    opening = false;
                    requested.clear();
                    failures.clear();
                    pollSoon(80);
                }
                return;
            }
            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                UsbDevice device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (connected && (device == null || Objects.equals(activeDeviceName, device.getDeviceName()))) {
                    notifyStatus("USB پچڕا");
                    closeStreams();
                    connected = false;
                } else if (!connected) {
                    opening = false;
                    requested.clear();
                    pollSoon(120);
                }
                return;
            }
            if (UsbManager.ACTION_USB_ACCESSORY_DETACHED.equals(action)) {
                UsbAccessory accessory = (UsbAccessory) intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY);
                if (connected && (accessory == null || Objects.equals(activeAccessory, accessory))) {
                    notifyStatus("USB پچڕا");
                    closeStreams();
                    connected = false;
                } else if (!connected) {
                    opening = false;
                    requested.clear();
                    pollSoon(120);
                }
            }
        }
    };

    /** preferHost is only a preference. Physical USB role is auto-detected. */
    void start(boolean preferHost, Listener callback) {
        close();
        this.preferHost = preferHost;
        listener = callback;
        running = true;
        connected = false;
        deadline = SystemClock.elapsedRealtime() + DISCOVERY_TIMEOUT_MS;
        requested.clear();
        failures.clear();

        IntentFilter filter = new IntentFilter(permissionAction);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        filter.addAction(UsbManager.ACTION_USB_ACCESSORY_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else context.registerReceiver(receiver, filter);
        registered = true;
        notifyStatus("USB دەپشکنرێت…");
        poll();
    }

    private PendingIntent permissionIntent() {
        Intent intent = new Intent(permissionAction).setPackage(context.getPackageName());
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        return PendingIntent.getBroadcast(context, generation, intent, flags);
    }

    private void pollSoon(long delay) {
        main.removeCallbacks(pollTask);
        main.postDelayed(pollTask, delay);
    }
    private final Runnable pollTask = this::poll;

    private void poll() {
        if (!running || connected || opening) return;
        if (SystemClock.elapsedRealtime() > deadline) {
            fail("USB پەیوەندی نەکرا");
            return;
        }
        try {
            boolean started;
            if (preferHost) {
                started = tryHost();
                if (!started) started = tryAccessory();
            } else {
                started = tryAccessory();
                if (!started) started = tryHost();
            }
            if (!started) pollSoon(250);
        } catch (Exception e) {
            notifyStatus("USB: " + e.getClass().getSimpleName());
            pollSoon(350);
        }
    }

    private boolean tryAccessory() {
        UsbAccessory[] list = manager.getAccessoryList();
        if (list == null) return false;
        for (UsbAccessory accessory : list) {
            if (!matchesAccessory(accessory)) continue;
            if (!manager.hasPermission(accessory)) {
                String key = "A:" + accessory;
                if (requested.add(key)) {
                    notifyStatus("USB permission چاوەڕێ دەکات…");
                    manager.requestPermission(accessory, permissionIntent());
                }
                return true;
            }
            opening = true;
            int token = generation;
            executor.execute(() -> openAccessory(accessory, token));
            return true;
        }
        return false;
    }

    private boolean tryHost() {
        if (!context.getPackageManager().hasSystemFeature("android.hardware.usb.host")) return false;
        List<UsbDevice> devices = new ArrayList<>(manager.getDeviceList().values());
        devices.sort((a,b) -> Boolean.compare(isAoa(b), isAoa(a)));
        for (UsbDevice device : devices) {
            if (!isAoa(device) && !phoneCandidate(device)) continue;
            String key = deviceKey(device);
            if (failures.getOrDefault(key, 0) >= MAX_OPEN_FAILURES) continue;
            if (!manager.hasPermission(device)) {
                if (requested.add("D:" + device.getDeviceName())) {
                    notifyStatus("USB permission چاوەڕێ دەکات…");
                    manager.requestPermission(device, permissionIntent());
                }
                return true;
            }
            opening = true;
            int token = generation;
            executor.execute(() -> openHost(device, token));
            return true;
        }
        return false;
    }

    private static boolean matchesAccessory(UsbAccessory accessory) {
        String maker = accessory.getManufacturer();
        String model = accessory.getModel();
        String serial = accessory.getSerial();
        return "rebaritclone".equalsIgnoreCase(maker)
            || "Phone Transfer".equalsIgnoreCase(model)
            || "rebaritclone-usb".equalsIgnoreCase(serial);
    }

    private static boolean isAoa(UsbDevice d) {
        int p = d.getProductId();
        return d.getVendorId() == 0x18d1 && (p == 0x2d00 || p == 0x2d01 || p == 0x2d04 || p == 0x2d05);
    }

    private static boolean phoneCandidate(UsbDevice d) {
        int dc = d.getDeviceClass();
        if (dc == UsbConstants.USB_CLASS_HUB || dc == UsbConstants.USB_CLASS_MASS_STORAGE || dc == UsbConstants.USB_CLASS_HID) return false;
        if (dc == 0 || dc == 2 || dc == 6 || dc == 239 || dc == 255) return true;
        for (int i=0;i<d.getInterfaceCount();i++) {
            int cls = d.getInterface(i).getInterfaceClass();
            if (cls == 2 || cls == 6 || cls == 239 || cls == 255) return true;
        }
        return false;
    }

    private static String deviceKey(UsbDevice d) {
        return d.getVendorId() + ":" + d.getProductId() + ":" + d.getDeviceName();
    }

    private void openAccessory(UsbAccessory accessory, int token) {
        ParcelFileDescriptor pfd = null;
        try {
            if (token != generation) return;
            pfd = manager.openAccessory(accessory);
            if (pfd == null) throw new IOException("Accessory open failed");
            InputStream in = new BufferedInputStream(new FileInputStream(pfd.getFileDescriptor()), 256 * 1024);
            OutputStream out = new BufferedOutputStream(new FileOutputStream(pfd.getFileDescriptor()), 256 * 1024);
            ParcelFileDescriptor finalPfd = pfd;
            main.post(() -> completeAccessory(accessory, finalPfd, in, out, token));
        } catch (Exception e) {
            try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
            main.post(() -> retryAfterFailure(null, token, e));
        }
    }

    private void completeAccessory(UsbAccessory accessory, ParcelFileDescriptor pfd, InputStream in, OutputStream out, int token) {
        if (token != generation || !running) {
            try { pfd.close(); } catch (Exception ignored) {}
            return;
        }
        descriptor = pfd;
        input = in;
        output = out;
        activeAccessory = accessory;
        opening = false;
        connected = true;
        notifyStatus("USB پەیوەست بوو");
        listener.ready(in, out);
    }

    private void openHost(UsbDevice device, int token) {
        UsbDeviceConnection c = null;
        try {
            if (token != generation) return;
            c = manager.openDevice(device);
            if (c == null) throw new IOException("USB open failed");

            if (!isAoa(device)) {
                switchToAccessory(c, device, token);
                return;
            }

            UsbInterface chosen = null;
            UsbEndpoint read = null, write = null;
            for (int i=0;i<device.getInterfaceCount();i++) {
                UsbInterface face = device.getInterface(i);
                UsbEndpoint r = null, w = null;
                for (int j=0;j<face.getEndpointCount();j++) {
                    UsbEndpoint ep = face.getEndpoint(j);
                    if (ep.getType() != UsbConstants.USB_ENDPOINT_XFER_BULK) continue;
                    if (ep.getDirection() == UsbConstants.USB_DIR_IN) r = ep; else w = ep;
                }
                if (r != null && w != null) { chosen = face; read = r; write = w; break; }
            }
            if (chosen == null || !c.claimInterface(chosen, true)) throw new IOException("AOA bulk interface unavailable");

            UsbDeviceConnection link = c;
            UsbEndpoint readEp = read, writeEp = write;
            InputStream in = new BulkInputStream(link, readEp);
            OutputStream out = new BulkOutputStream(link, writeEp);
            main.post(() -> completeHost(device, link, in, out, token));
        } catch (Exception e) {
            try { if (c != null) c.close(); } catch (Exception ignored) {}
            main.post(() -> retryAfterFailure(device, token, e));
        }
    }

    private void switchToAccessory(UsbDeviceConnection c, UsbDevice device, int token) throws Exception {
        byte[] protocol = new byte[2];
        int n = c.controlTransfer(0xc0, 51, 0, 0, protocol, protocol.length, 5000);
        if (n != 2) throw new IOException("AOA unsupported");
        int version = (protocol[0] & 0xff) | ((protocol[1] & 0xff) << 8);
        if (version < 1) throw new IOException("AOA unsupported");

        String[] strings = {"rebaritclone", "Phone Transfer", "Offline phone transfer", "2.0", "", "rebaritclone-usb"};
        for (int i=0;i<strings.length;i++) {
            if (token != generation) { c.close(); return; }
            byte[] value = (strings[i] + "\0").getBytes(StandardCharsets.UTF_8);
            if (c.controlTransfer(0x40, 52, 0, i, value, value.length, 5000) < 0) throw new IOException("AOA setup failed");
        }
        if (c.controlTransfer(0x40, 53, 0, 0, null, 0, 5000) < 0) throw new IOException("AOA start failed");
        c.close();
        main.post(() -> {
            if (token != generation || !running) return;
            opening = false;
            requested.clear();
            notifyStatus("USB دەگوازرێتەوە بۆ Transfer mode…");
            pollSoon(650);
        });
    }

    private void completeHost(UsbDevice device, UsbDeviceConnection link, InputStream in, OutputStream out, int token) {
        if (token != generation || !running) {
            link.close();
            return;
        }
        connection = link;
        input = in;
        output = out;
        activeDeviceName = device.getDeviceName();
        opening = false;
        connected = true;
        notifyStatus("USB پەیوەست بوو");
        listener.ready(in, out);
    }

    private void retryAfterFailure(UsbDevice device, int token, Exception error) {
        if (token != generation || !running) return;
        opening = false;
        if (device != null) {
            String key = deviceKey(device);
            failures.put(key, failures.getOrDefault(key, 0) + 1);
            requested.remove("D:" + device.getDeviceName());
        }
        notifyStatus("USB دووبارە دەپشکنرێت…");
        pollSoon(500);
    }

    private void notifyStatus(String message) {
        Listener l = listener;
        if (l != null) main.post(() -> {
            if (l == listener) l.status(message);
        });
    }

    private void fail(String message) {
        Listener callback = listener;
        close();
        if (callback != null) callback.failed(message);
    }

    void closeStreams() {
        try { if (input != null) input.close(); } catch (Exception ignored) {}
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        try { if (connection != null) connection.close(); } catch (Exception ignored) {}
        try { if (descriptor != null) descriptor.close(); } catch (Exception ignored) {}
        input = null;
        output = null;
        connection = null;
        descriptor = null;
        activeDeviceName = null;
        activeAccessory = null;
    }

    void close() {
        generation++;
        running = false;
        opening = false;
        connected = false;
        main.removeCallbacksAndMessages(null);
        if (registered) {
            try { context.unregisterReceiver(receiver); } catch (Exception ignored) {}
            registered = false;
        }
        closeStreams();
    }

    void destroy() {
        close();
        executor.shutdownNow();
    }

    private static final class BulkInputStream extends InputStream {
        private final UsbDeviceConnection link;
        private final UsbEndpoint endpoint;
        private final byte[] buffer = new byte[bulkSize()];
        private int offset, count;
        BulkInputStream(UsbDeviceConnection link, UsbEndpoint endpoint) { this.link = link; this.endpoint = endpoint; }
        @Override public int read() throws IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n < 0 ? -1 : one[0] & 0xff;
        }
        @Override public int read(byte[] out, int start, int length) throws IOException {
            if (length == 0) return 0;
            if (offset == count) {
                int n = transferIn();
                if (n <= 0) throw new EOFException("USB disconnected");
                offset = 0;
                count = n;
            }
            int n = Math.min(length, count - offset);
            System.arraycopy(buffer, offset, out, start, n);
            offset += n;
            return n;
        }
        private int transferIn() {
            for (int attempt=0;attempt<3;attempt++) {
                int n = link.bulkTransfer(endpoint, buffer, buffer.length, USB_IO_TIMEOUT_MS);
                if (n > 0) return n;
                SystemClock.sleep(80L * (attempt + 1));
            }
            return -1;
        }
        @Override public void close() { link.close(); }
    }

    private static final class BulkOutputStream extends OutputStream {
        private final UsbDeviceConnection link;
        private final UsbEndpoint endpoint;
        BulkOutputStream(UsbDeviceConnection link, UsbEndpoint endpoint) { this.link = link; this.endpoint = endpoint; }
        @Override public void write(int b) throws IOException { write(new byte[]{(byte)b}); }
        @Override public void write(byte[] data, int offset, int length) throws IOException {
            while (length > 0) {
                int request = Math.min(length, bulkSize());
                int n = -1;
                for (int attempt=0;attempt<3 && n<=0;attempt++) {
                    n = link.bulkTransfer(endpoint, data, offset, request, USB_IO_TIMEOUT_MS);
                    if (n <= 0) SystemClock.sleep(80L * (attempt + 1));
                }
                if (n <= 0) throw new IOException("USB disconnected");
                offset += n;
                length -= n;
            }
        }
        @Override public void close() { link.close(); }
    }
}
