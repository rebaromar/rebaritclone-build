package com.abdulla.clonephone

/**
 * Step 1 of the Java -> Kotlin migration.
 *
 * This file intentionally has no Android/UI/transfer side effects. Its presence makes the
 * production app module compile Kotlin and Java together, so future classes can be migrated
 * one at a time without touching the working USB/Wi-Fi transfer engine first.
 */
object KotlinBridge {
    const val MIGRATION_STAGE: Int = 1
    const val JAVA_INTEROP_READY: Boolean = true

    @JvmStatic
    fun isReady(): Boolean = JAVA_INTEROP_READY
}
