package com.abdulla.clonephone

/** SDK/role-dependent sequence. No file access or consent is inferred here. */
object PermissionPlan {
    private fun p(name: String) = "android.permission.$name"

    @JvmStatic
    fun forUsbSource(sdk: Int): List<Array<String>> = buildList {
        if (sdk >= 33) {
            add(arrayOf(p("POST_NOTIFICATIONS")))
            add(
                if (sdk >= 34) arrayOf(p("READ_MEDIA_IMAGES"), p("READ_MEDIA_VIDEO"), p("READ_MEDIA_VISUAL_USER_SELECTED"))
                else arrayOf(p("READ_MEDIA_IMAGES"), p("READ_MEDIA_VIDEO"))
            )
            add(arrayOf(p("READ_MEDIA_AUDIO")))
        } else {
            add(arrayOf(p("READ_EXTERNAL_STORAGE")))
        }
        listOf("READ_CONTACTS", "READ_CALL_LOG", "READ_SMS").forEach { add(arrayOf(p(it))) }
    }

    @JvmStatic
    fun forRole(sdk: Int, receiving: Boolean): List<Array<String>> = buildList {
        if (sdk >= 33) add(arrayOf(p("POST_NOTIFICATIONS")))
        add(
            if (sdk >= 33) arrayOf(p("NEARBY_WIFI_DEVICES"))
            else arrayOf(p("ACCESS_COARSE_LOCATION"), p("ACCESS_FINE_LOCATION"))
        )
        if (!receiving) {
            if (sdk >= 33) {
                add(
                    if (sdk >= 34) arrayOf(p("READ_MEDIA_IMAGES"), p("READ_MEDIA_VIDEO"), p("READ_MEDIA_VISUAL_USER_SELECTED"))
                    else arrayOf(p("READ_MEDIA_IMAGES"), p("READ_MEDIA_VIDEO"))
                )
                add(arrayOf(p("READ_MEDIA_AUDIO")))
            } else {
                add(arrayOf(p("READ_EXTERNAL_STORAGE")))
            }
            listOf("CAMERA", "READ_CONTACTS", "READ_CALL_LOG", "READ_SMS").forEach { add(arrayOf(p(it))) }
        }
    }
}
