package com.abdulla.clonephone;

import java.util.HashSet;
import java.util.Set;

/** One system permission dialog at a time, and one request per endpoint per attempt. */
final class UsbPermissionGate {
    static final int WAIT = 0, REQUEST = 1, ALREADY_ASKED = -1;
    private final Set<String> attempted = new HashSet<>();
    private String pending;
    private int sequence;

    int begin(String key) {
        if (pending != null) return WAIT;
        if (!attempted.add(key)) return ALREADY_ASKED;
        pending = key;
        sequence++;
        return REQUEST;
    }

    int requestId() { return sequence; }
    boolean isPending() { return pending != null; }

    boolean complete(String key, int id) {
        if (pending == null || !pending.equals(key) || id != sequence) return false;
        pending = null;
        return true;
    }

    void reset() { pending = null; attempted.clear(); sequence++; }
}
