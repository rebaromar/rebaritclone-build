package com.abdulla.clonephone

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbAccessory
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.EOFException
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.UUID

/**
 * REBARIT CLONE USB transport rewritten from scratch in Kotlin.
 *
 * Logical role (new phone/controller vs old phone/source) is intentionally independent
 * from the physical USB-C host/accessory role negotiated by Android.  Whichever phone
 * becomes the physical host tries to switch the peer into Android Open Accessory (AOA)
 * mode, while the logical new phone still remains the controller at protocol level.
 *
 * The class never reads permission-protected serial numbers during discovery and it
 * catches OEM SecurityException/IllegalArgumentException failures so a bad USB event
 * cannot crash the Activity.
 */
class UsbLink(private val context: Context) {
    interface Listener {
        fun ready(input: InputStream, output: OutputStream)
        fun failed(reason: String)
        fun status(message: String)
    }

    private enum class State { IDLE, DISCOVERING, WAITING_PERMISSION, SWITCHING, OPENING, CONNECTED, CLOSED }

    private val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "rebar-usb").apply { isDaemon = true } }
    private val permissionAction = context.packageName + ".USB_PERMISSION"
    private val closed = AtomicBoolean(false)

    @Volatile private var state = State.IDLE
    @Volatile private var running = false
    @Volatile private var connected = false
    @Volatile private var preferHost = true
    @Volatile private var generation = 0
    @Volatile private var deadline = 0L
    @Volatile private var listener: Listener? = null

    private var registered = false
    private var requestedKey: String? = null
    private var permissionSession = UUID.randomUUID().toString()
    private var deviceConnection: UsbDeviceConnection? = null
    private var accessoryDescriptor: ParcelFileDescriptor? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var activeDeviceName: String? = null
    private var activeAccessory: UsbAccessory? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (!running || intent == null) return
            try {
                when (intent.action) {
                    permissionAction + "." + permissionSession -> onPermissionResult(intent)
                    UsbManager.ACTION_USB_DEVICE_ATTACHED,
                    UsbManager.ACTION_USB_ACCESSORY_ATTACHED -> {
                        requestedKey = null
                        if (!connected) {
                            state = State.DISCOVERING
                            pollSoon(60)
                        }
                    }
                    UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                        val d = usbDeviceExtra(intent)
                        if (connected && (d == null || d.deviceName == activeDeviceName)) {
                            status("USB پچڕا")
                            closeStreams()
                            connected = false
                            state = State.DISCOVERING
                        } else if (!connected) {
                            requestedKey = null
                            state = State.DISCOVERING
                            pollSoon(120)
                        }
                    }
                    UsbManager.ACTION_USB_ACCESSORY_DETACHED -> {
                        val a = usbAccessoryExtra(intent)
                        if (connected && (a == null || a == activeAccessory)) {
                            status("USB پچڕا")
                            closeStreams()
                            connected = false
                            state = State.DISCOVERING
                        } else if (!connected) {
                            requestedKey = null
                            state = State.DISCOVERING
                            pollSoon(120)
                        }
                    }
                }
            } catch (_: SecurityException) {
                status("USB permission پێویستە")
            } catch (_: Throwable) {
                // A malformed/OEM USB broadcast must never crash REBARIT CLONE.
                status("USB دووبارە دەپشکنرێت…")
                if (!connected) pollSoon(350)
            }
        }
    }

    /** `preferHost` is only a hint. Physical USB role is auto-detected. */
    fun start(preferHost: Boolean, callback: Listener) {
        closeInternal(shutdown = false)
        this.preferHost = preferHost
        this.listener = callback
        this.running = true
        this.connected = false
        this.closed.set(false)
        this.state = State.DISCOVERING
        this.deadline = SystemClock.elapsedRealtime() + DISCOVERY_TIMEOUT_MS
        this.requestedKey = null
        this.permissionSession = UUID.randomUUID().toString()
        val pm = context.packageManager
        val canHost = pm.hasSystemFeature("android.hardware.usb.host")
        val canAccessory = pm.hasSystemFeature("android.hardware.usb.accessory")
        if (!canHost && !canAccessory) {
            fail("ئەم مۆبایلە USB Host/Accessory پشتگیری ناکات")
            return
        }
        registerReceiverSafely()
        status("USB دەپشکنرێت…")
        pollSoon(0)
    }

    private fun registerReceiverSafely() {
        if (registered) return
        val filter = IntentFilter(permissionAction + "." + permissionSession).apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(UsbManager.ACTION_USB_ACCESSORY_ATTACHED)
            addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                // USB attach/detach broadcasts come from the Android system, not our UID.
                context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                @Suppress("DEPRECATION") context.registerReceiver(receiver, filter)
            }
            registered = true
        } catch (_: Throwable) {
            registered = false
        }
    }

    private fun permissionIntent(): PendingIntent {
        val intent = Intent(permissionAction + "." + permissionSession).setPackage(context.packageName)
            .putExtra(PERMISSION_GENERATION, generation)
        // UsbManager supplies the granted flag and device through fill-in extras.
        // Immutable PendingIntents discard those extras, making Allow look denied.
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        return PendingIntent.getBroadcast(context, generation, intent, flags)
    }

    private fun onPermissionResult(intent: Intent) {
        // A permission dialog from an earlier discovery must not stop a new session.
        if (intent.action != permissionAction + "." + permissionSession ||
            intent.getIntExtra(PERMISSION_GENERATION, -1) != generation ||
            requestedKey == null || connected || state == State.OPENING || state == State.SWITCHING) return
        val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
        requestedKey = null
        if (!granted) {
            state = State.DISCOVERING
            fail("USB permission ڕەتکرایەوە • Allow هەڵبژێرە")
            return
        }
        state = State.DISCOVERING
        pollSoon(40)
    }

    private fun pollSoon(delayMs: Long) {
        main.removeCallbacks(pollTask)
        main.postDelayed(pollTask, delayMs.coerceAtLeast(0))
    }

    private val pollTask = Runnable { poll() }

    private fun poll() {
        if (!running || connected || state == State.OPENING || state == State.SWITCHING) return
        if (SystemClock.elapsedRealtime() > deadline) {
            fail("USB پەیوەندی نەکرا • Data cable و Allow پشکنە")
            return
        }
        try {
            state = State.DISCOVERING
            val started = if (preferHost) {
                tryHost() || tryAccessory()
            } else {
                tryAccessory() || tryHost()
            }
            if (!started) pollSoon(POLL_MS)
        } catch (_: SecurityException) {
            state = State.DISCOVERING
            status("USB permission پێویستە • Allow هەڵبژێرە")
            pollSoon(700)
        } catch (_: Throwable) {
            state = State.DISCOVERING
            status("USB دووبارە دەپشکنرێت…")
            pollSoon(450)
        }
    }

    private fun tryAccessory(): Boolean {
        val list = try { manager.accessoryList } catch (_: SecurityException) { null } ?: return false
        for (accessory in list) {
            if (!matchesAccessory(accessory)) continue
            if (!manager.hasPermission(accessory)) {
                val key = "A:${safeAccessoryIdentity(accessory)}"
                if (requestedKey != key) {
                    requestedKey = key
                    state = State.WAITING_PERMISSION
                    status("USB permission چاوەڕێ دەکات…")
                    try {
                        manager.requestPermission(accessory, permissionIntent())
                    } catch (_: Throwable) {
                        requestedKey = null
                        state = State.DISCOVERING
                        fail("USB permission نەکرا • دووبارە هەوڵ بدە")
                    }
                }
                return true
            }
            state = State.OPENING
            val token = generation
            io.execute { openAccessory(accessory, token) }
            return true
        }
        return false
    }

    private fun tryHost(): Boolean {
        if (!context.packageManager.hasSystemFeature("android.hardware.usb.host")) return false
        val devices = try { manager.deviceList.values.toList() } catch (_: SecurityException) { emptyList() }
            .sortedWith(compareByDescending<UsbDevice> { isAoa(it) }.thenBy { it.deviceName })
        for (device in devices) {
            if (!isAoa(device) && !phoneCandidate(device)) continue
            if (!manager.hasPermission(device)) {
                val key = "D:${device.deviceName}:${device.vendorId}:${device.productId}"
                if (requestedKey != key) {
                    requestedKey = key
                    state = State.WAITING_PERMISSION
                    status("USB permission چاوەڕێ دەکات…")
                    try {
                        manager.requestPermission(device, permissionIntent())
                    } catch (_: Throwable) {
                        requestedKey = null
                        state = State.DISCOVERING
                        fail("USB permission نەکرا • Allow هەڵبژێرە")
                    }
                }
                return true
            }
            state = if (isAoa(device)) State.OPENING else State.SWITCHING
            val token = generation
            io.execute { openHost(device, token) }
            return true
        }
        return false
    }

    private fun openAccessory(accessory: UsbAccessory, token: Int) {
        var pfd: ParcelFileDescriptor? = null
        try {
            if (!valid(token)) return
            pfd = manager.openAccessory(accessory) ?: throw IOException("USB_ACCESSORY_OPEN")
            val input = BufferedInputStream(TransferFailure.usbInput(FileInputStream(pfd.fileDescriptor)), STREAM_BUFFER)
            val output = BufferedOutputStream(TransferFailure.usbOutput(FileOutputStream(pfd.fileDescriptor)), STREAM_BUFFER)
            val keep = pfd
            main.post { completeAccessory(accessory, keep, input, output, token) }
        } catch (t: Throwable) {
            try { pfd?.close() } catch (_: Throwable) {}
            retry(token, t)
        }
    }

    private fun openHost(device: UsbDevice, token: Int) {
        var connection: UsbDeviceConnection? = null
        try {
            if (!valid(token)) return
            connection = manager.openDevice(device) ?: throw IOException("USB_DEVICE_OPEN")
            if (!isAoa(device)) {
                switchPeerToAoa(connection, token)
                return
            }

            val pair = findBulkPair(device) ?: throw IOException("USB_BULK_INTERFACE")
            if (!connection.claimInterface(pair.face, true)) throw IOException("USB_CLAIM_INTERFACE")
            val input = BulkInputStream(connection, pair.input)
            val output = BulkOutputStream(connection, pair.output)
            val keep = connection
            main.post { completeHost(device, keep, input, output, token) }
        } catch (t: Throwable) {
            try { connection?.close() } catch (_: Throwable) {}
            retry(token, t)
        }
    }

    private fun switchPeerToAoa(connection: UsbDeviceConnection, token: Int) {
        try {
            val protocol = ByteArray(2)
            val n = connection.controlTransfer(0xC0, AOA_GET_PROTOCOL, 0, 0, protocol, protocol.size, CONTROL_TIMEOUT_MS)
            if (n != 2) throw IOException("AOA_UNSUPPORTED")
            val version = (protocol[0].toInt() and 0xff) or ((protocol[1].toInt() and 0xff) shl 8)
            if (version < 1) throw IOException("AOA_UNSUPPORTED")

            AOA_STRINGS.forEachIndexed { index, text ->
                if (!valid(token)) throw IOException("USB_CANCELLED")
                val bytes = (text + "\u0000").toByteArray(StandardCharsets.UTF_8)
                val sent = connection.controlTransfer(0x40, AOA_SEND_IDENT, 0, index, bytes, bytes.size, CONTROL_TIMEOUT_MS)
                if (sent != bytes.size) throw IOException("AOA_IDENT")
            }
            if (!valid(token)) throw IOException("USB_CANCELLED")
            val started = connection.controlTransfer(0x40, AOA_START, 0, 0, null, 0, CONTROL_TIMEOUT_MS)
            if (started < 0) throw IOException("AOA_START")
            connection.close()
            main.post {
                if (!valid(token)) return@post
                state = State.DISCOVERING
                requestedKey = null
                status("USB Transfer mode دەکرێتەوە…")
                pollSoon(AOA_REENUMERATE_MS)
            }
        } catch (t: Throwable) {
            try { connection.close() } catch (_: Throwable) {}
            retry(token, t)
        }
    }

    private fun completeAccessory(
        accessory: UsbAccessory,
        descriptor: ParcelFileDescriptor,
        input: InputStream,
        output: OutputStream,
        token: Int
    ) {
        if (!valid(token)) {
            try { input.close() } catch (_: Throwable) {}
            try { output.close() } catch (_: Throwable) {}
            try { descriptor.close() } catch (_: Throwable) {}
            return
        }
        this.accessoryDescriptor = descriptor
        this.input = input
        this.output = output
        this.activeAccessory = accessory
        connected = true
        state = State.CONNECTED
        status("USB پەیوەست بوو ✓")
        dispatchReady(input, output, token)
    }

    private fun completeHost(
        device: UsbDevice,
        connection: UsbDeviceConnection,
        input: InputStream,
        output: OutputStream,
        token: Int
    ) {
        if (!valid(token)) {
            try { connection.close() } catch (_: Throwable) {}
            return
        }
        this.deviceConnection = connection
        this.input = input
        this.output = output
        this.activeDeviceName = device.deviceName
        connected = true
        state = State.CONNECTED
        status("USB پەیوەست بوو ✓")
        dispatchReady(input, output, token)
    }


    /** UI/session callbacks are always delivered on Android's main thread.
     * MainActivity builds the controller/source screens from ready(), so invoking it
     * from the USB I/O executor could throw CalledFromWrongThreadException and abort
     * the session before inventory/data transfer starts.
     */
    private fun dispatchReady(input: InputStream, output: OutputStream, token: Int) {
        val callback = listener ?: return
        main.post {
            if (!valid(token) || !connected || callback !== listener) return@post
            try {
                callback.ready(input, output)
            } catch (_: Throwable) {
                closeStreams()
                connected = false
                state = State.DISCOVERING
                fail("USB session نەکرا")
            }
        }
    }

    private fun retry(token: Int, error: Throwable) {
        main.post {
            if (!valid(token) || connected) return@post
            state = State.DISCOVERING
            requestedKey = null
            val fatal = error is SecurityException || error.message == "AOA_UNSUPPORTED"
            if (fatal && error is SecurityException) {
                status("USB permission پێویستە")
            } else {
                status("USB دووبارە دەپشکنرێت…")
            }
            pollSoon(if (fatal) 800 else 450)
        }
    }

    private fun valid(token: Int): Boolean = running && token == generation && !closed.get()

    private fun status(message: String) {
        val callback = listener ?: return
        main.post {
            if (callback === listener && running) try { callback.status(message) } catch (_: Throwable) {}
        }
    }

    private fun fail(message: String) {
        val callback = listener
        closeInternal(shutdown = false)
        if (callback != null) main.post { try { callback.failed(message) } catch (_: Throwable) {} }
    }

    fun closeStreams() {
        try { input?.close() } catch (_: Throwable) {}
        try { output?.close() } catch (_: Throwable) {}
        try { deviceConnection?.close() } catch (_: Throwable) {}
        try { accessoryDescriptor?.close() } catch (_: Throwable) {}
        input = null
        output = null
        deviceConnection = null
        accessoryDescriptor = null
        activeDeviceName = null
        activeAccessory = null
    }

    fun close() = closeInternal(shutdown = false)

    fun destroy() = closeInternal(shutdown = true)

    private fun closeInternal(shutdown: Boolean) {
        generation++
        running = false
        connected = false
        closed.set(true)
        state = State.CLOSED
        requestedKey = null
        main.removeCallbacks(pollTask)
        if (registered) {
            try { context.unregisterReceiver(receiver) } catch (_: Throwable) {}
            registered = false
        }
        closeStreams()
        if (shutdown) io.shutdownNow()
    }

    private data class BulkPair(val face: UsbInterface, val input: UsbEndpoint, val output: UsbEndpoint)

    private class BulkInputStream(
        private val connection: UsbDeviceConnection,
        private val endpoint: UsbEndpoint
    ) : InputStream() {
        private val buffer = ByteArray(UsbLink.bulkSize())
        private var offset = 0
        private var count = 0

        override fun read(): Int {
            val one = ByteArray(1)
            val n = read(one, 0, 1)
            return if (n < 0) -1 else one[0].toInt() and 0xff
        }

        override fun read(out: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            if (offset >= count) {
                val n = transferIn()
                if (n <= 0) throw EOFException("USB_DISCONNECTED")
                offset = 0
                count = n
            }
            val n = minOf(len, count - offset)
            System.arraycopy(buffer, offset, out, off, n)
            offset += n
            return n
        }

        private fun transferIn(): Int {
            repeat(3) { attempt ->
                val n = try { connection.bulkTransfer(endpoint, buffer, buffer.size, IO_TIMEOUT_MS) } catch (_: Throwable) { -1 }
                if (n > 0) return n
                SystemClock.sleep(90L * (attempt + 1))
            }
            return -1
        }

        override fun close() {
            try { connection.close() } catch (_: Throwable) {}
        }
    }

    private class BulkOutputStream(
        private val connection: UsbDeviceConnection,
        private val endpoint: UsbEndpoint
    ) : OutputStream() {
        override fun write(b: Int) = write(byteArrayOf(b.toByte()), 0, 1)

        override fun write(data: ByteArray, off: Int, len: Int) {
            var offset = off
            var remaining = len
            while (remaining > 0) {
                val request = minOf(remaining, UsbLink.bulkSize())
                var n = -1
                for (attempt in 0 until 3) {
                    n = try { connection.bulkTransfer(endpoint, data, offset, request, IO_TIMEOUT_MS) } catch (_: Throwable) { -1 }
                    if (n > 0) break
                    SystemClock.sleep(90L * (attempt + 1))
                }
                if (n <= 0) throw IOException("USB_DISCONNECTED")
                offset += n
                remaining -= n
            }
        }

        override fun flush() = Unit

        override fun close() {
            try { connection.close() } catch (_: Throwable) {}
        }
    }

    companion object {
        private const val PERMISSION_GENERATION = "rebar.usb.permissionGeneration"
        private const val DISCOVERY_TIMEOUT_MS = 120_000L
        private const val POLL_MS = 350L
        private const val AOA_REENUMERATE_MS = 850L
        private const val CONTROL_TIMEOUT_MS = 5_000
        private const val IO_TIMEOUT_MS = 60_000
        private const val STREAM_BUFFER = 256 * 1024
        private const val MODERN_BULK = 64 * 1024
        private const val LEGACY_BULK = 16 * 1024

        private const val AOA_GET_PROTOCOL = 51
        private const val AOA_SEND_IDENT = 52
        private const val AOA_START = 53

        private val AOA_STRINGS = arrayOf(
            "REBARIT",
            "REBARIT CLONE",
            "Android phone transfer",
            "3.0",
            "https://rebarit.store/app",
            "rebaritclone-usb-v3"
        )

        @JvmStatic fun bulkSize(): Int = if (Build.VERSION.SDK_INT >= 28) MODERN_BULK else LEGACY_BULK

        private fun isAoa(device: UsbDevice): Boolean {
            val product = device.productId
            return device.vendorId == 0x18d1 && product in setOf(0x2d00, 0x2d01, 0x2d04, 0x2d05)
        }

        private fun matchesAccessory(accessory: UsbAccessory): Boolean {
            val maker = try { accessory.manufacturer.orEmpty() } catch (_: Throwable) { "" }
            val model = try { accessory.model.orEmpty() } catch (_: Throwable) { "" }
            return maker.equals("REBARIT", true) && model.equals("REBARIT CLONE", true)
        }

        private fun safeAccessoryIdentity(accessory: UsbAccessory): String {
            val maker = try { accessory.manufacturer.orEmpty() } catch (_: Throwable) { "" }
            val model = try { accessory.model.orEmpty() } catch (_: Throwable) { "" }
            val version = try { accessory.version.orEmpty() } catch (_: Throwable) { "" }
            return "$maker:$model:$version"
        }

        private fun phoneCandidate(device: UsbDevice): Boolean {
            val dc = device.deviceClass
            if (dc == UsbConstants.USB_CLASS_HUB || dc == UsbConstants.USB_CLASS_MASS_STORAGE || dc == UsbConstants.USB_CLASS_HID) return false
            if (dc == 0 || dc == UsbConstants.USB_CLASS_COMM || dc == UsbConstants.USB_CLASS_STILL_IMAGE || dc == 239 || dc == UsbConstants.USB_CLASS_VENDOR_SPEC) return true
            for (i in 0 until device.interfaceCount) {
                val cls = device.getInterface(i).interfaceClass
                if (cls == UsbConstants.USB_CLASS_COMM || cls == UsbConstants.USB_CLASS_STILL_IMAGE || cls == 239 || cls == UsbConstants.USB_CLASS_VENDOR_SPEC) return true
            }
            return false
        }

        private fun findBulkPair(device: UsbDevice): BulkPair? {
            for (i in 0 until device.interfaceCount) {
                val face = device.getInterface(i)
                var input: UsbEndpoint? = null
                var output: UsbEndpoint? = null
                for (j in 0 until face.endpointCount) {
                    val ep = face.getEndpoint(j)
                    if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                    if (ep.direction == UsbConstants.USB_DIR_IN) input = ep else if (ep.direction == UsbConstants.USB_DIR_OUT) output = ep
                }
                if (input != null && output != null) return BulkPair(face, input, output)
            }
            return null
        }

        @Suppress("DEPRECATION")
        private fun usbDeviceExtra(intent: Intent): UsbDevice? =
            if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            else intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)

        @Suppress("DEPRECATION")
        private fun usbAccessoryExtra(intent: Intent): UsbAccessory? =
            if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY, UsbAccessory::class.java)
            else intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY)
    }
}
