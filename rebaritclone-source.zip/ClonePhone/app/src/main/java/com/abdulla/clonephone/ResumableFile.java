package com.abdulla.clonephone;

import java.io.*;
import java.security.*;

/** Resume authenticated records with bounded memory and verify the retained source prefix. */
public final class ResumableFile {
    public interface Progress { void update(long bytes) throws Exception; }
    public interface Publisher { void publish(File file) throws Exception; }
    public interface EntryPublisher { void publish(Entry entry) throws Exception; }
    public interface Checkpoint { void save(Entry entry) throws Exception; }
    /** A pending destination can be a file, a MediaStore row, or a seekable SAF document. */
    public interface Storage {
        long length() throws IOException;
        InputStream openRead() throws IOException;
        RandomAccess openWrite() throws IOException;
        void discard() throws IOException;
        String identity();
    }
    public interface RandomAccess extends Closeable {
        void seek(long offset) throws IOException;
        void write(byte[] bytes, int offset, int length) throws IOException;
        void truncate(long length) throws IOException;
        void sync() throws IOException;
    }
    private static final class FileStorage implements Storage {
        private final File file;
        private FileStorage(File file) { this.file = file; }
        public long length() { return file.length(); }
        public InputStream openRead() throws IOException { return new FileInputStream(file); }
        public RandomAccess openWrite() throws IOException {
            final RandomAccessFile out = new RandomAccessFile(file, "rw");
            return new RandomAccess() {
                public void seek(long offset) throws IOException { out.seek(offset); }
                public void write(byte[] bytes, int offset, int length) throws IOException { out.write(bytes, offset, length); }
                public void truncate(long length) throws IOException { out.setLength(length); }
                public void sync() throws IOException { out.getFD().sync(); }
                public void close() throws IOException { out.close(); }
            };
        }
        public void discard() throws IOException {
            if (file.exists() && !file.delete()) throw new IOException("Could not delete partial file");
        }
        public String identity() { return file.getAbsolutePath(); }
    }
    public static final class Entry {
        /** Only file-backed temporary entries have a partial File. Direct destinations use storage. */
        public final File partial;
        public final Storage storage;
        public boolean done;
        public long length;
        public byte[] digest;
        public Checkpoint checkpoint;
        public Entry(File file) { partial = file; storage = new FileStorage(file); }
        public Entry(Storage storage) {
            if (storage == null) throw new NullPointerException("storage");
            partial = null; this.storage = storage;
        }
    }
    private static MessageDigest hash() throws Exception { return MessageDigest.getInstance("SHA-256"); }
    private static void rejectSource(SecureChannel channel, Exception error) {
        try { channel.write(new byte[]{0}); }
        catch (Exception wireFailure) { error.addSuppressed(wireFailure); }
    }
    private static void prefix(InputStream in, long length, MessageDigest hash, Progress progress,
                               SecureChannel.Keepalive keepalive) throws Exception {
        byte[] buffer = new byte[262144]; long bytes = 0;
        while (bytes < length) {
            keepalive.check(); progress.update(-1);
            int read = in.read(buffer, 0, (int)Math.min(buffer.length, length - bytes));
            if (read < 0) throw new IOException("SOURCE_CHANGED");
            if (read == 0) {
                int next = in.read();
                if (next < 0) throw new IOException("SOURCE_CHANGED");
                hash.update((byte)next); bytes++; continue;
            }
            hash.update(buffer, 0, read); bytes += read;
        }
    }
    public static long send(SecureChannel channel, InputStream in, long size, int chunk,
                            Progress progress) throws Exception {
        if (size < -1 || chunk < 1 || chunk > SecureChannel.MAX_FRAME) throw new IOException("Invalid file size or chunk");
        try (SecureChannel.Keepalive keepalive = channel.startKeepalive()) {
            DataInputStream state = new DataInputStream(new ByteArrayInputStream(channel.read()));
            long offset = state.readLong(); boolean done = state.readBoolean(); byte[] expected = new byte[32];
            state.readFully(expected);
            if (state.available() != 0 || offset < 0 || (size >= 0 && offset > size) || (done && size >= 0 && offset != size))
                throw new IOException("Invalid resume offset");
            MessageDigest hash = hash();
            try { prefix(in, offset, hash, progress, keepalive); }
            catch (Exception error) {
                // A transport failure/cancellation while checking a prefix does not
                // invalidate bytes the receiver already authenticated and retained.
                if ("SOURCE_CHANGED".equals(error.getMessage())) rejectSource(channel, error);
                throw error;
            }
            byte[] actual = ((MessageDigest)hash.clone()).digest();
            if (!MessageDigest.isEqual(actual, expected)) {
                IOException error = new IOException("SOURCE_CHANGED"); rejectSource(channel, error); throw error;
            }
            channel.write(new byte[]{1}); progress.update(offset);
            if (done) { if (in.read() != -1) throw new IOException("SOURCE_CHANGED"); return offset; }
            long bytes = offset; byte[] data = new byte[chunk];
            for (;;) {
                keepalive.check(); progress.update(-1);
                int read = in.read(data);
                if (read < 0) break;
                if (read == 0) {
                    int next = in.read(); if (next < 0) break; data[0] = (byte)next; read = 1;
                }
                if (bytes > Long.MAX_VALUE - read || (size >= 0 && read > size - bytes)) throw new IOException("SOURCE_CHANGED");
                hash.update(data, 0, read); channel.writeBuffered(data, read); bytes += read; progress.update(bytes);
            }
            if (size >= 0 && bytes != size) throw new IOException("SOURCE_CHANGED");
            channel.write(new byte[0]); channel.write(hash.digest());
            byte[] ack = channel.read(); if (ack.length != 1 || ack[0] != 2) throw new IOException("Invalid ACK");
            return bytes;
        }
    }
    public static long receive(SecureChannel channel, Entry entry, long size, Progress progress,
                               Publisher publisher) throws Exception {
        return receiveDirect(channel, entry, size, progress, state -> publisher.publish(state.partial));
    }
    private static void reset(Entry entry) throws IOException {
        try (RandomAccess file = entry.storage.openWrite()) { file.truncate(0); file.sync(); }
        entry.length = 0; entry.digest = null;
    }
    public static long receiveDirect(SecureChannel channel, Entry entry, long size, Progress progress,
                                     EntryPublisher publisher) throws Exception {
        if (size < -1) throw new IOException("Invalid file size");
        try (SecureChannel.Keepalive keepalive = channel.startKeepalive()) {
            MessageDigest hash = hash(); long offset = entry.done ? entry.length : entry.storage.length();
            if (offset < 0 || (size >= 0 && offset > size) || (entry.done && (entry.digest == null || entry.digest.length != 32 || (size >= 0 && offset != size))))
                throw new IOException("Invalid stored checkpoint");
            byte[] digest;
            if (entry.done) digest = entry.digest;
            else {
                if (offset > 0) try (InputStream in = new BufferedInputStream(entry.storage.openRead(), 262144)) {
                    prefix(in, offset, hash, progress, keepalive);
                }
                digest = ((MessageDigest)hash.clone()).digest();
            }
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(); DataOutputStream state = new DataOutputStream(buffer);
            state.writeLong(offset); state.writeBoolean(entry.done); state.write(digest); channel.write(buffer.toByteArray());
            byte[] accept = channel.read();
            if (accept.length != 1 || accept[0] != 1) { if (!entry.done) reset(entry); throw new IOException("SOURCE_CHANGED"); }
            progress.update(offset); if (entry.done) return offset;
            long bytes = offset;
            try (RandomAccess file = entry.storage.openWrite()) {
                file.seek(offset);
                byte[] data=new byte[SecureChannel.MAX_FRAME+1];
                for (;;) {
                    keepalive.check(); progress.update(-1); int length=channel.readInto(data);if(length==0)break;
                    if (bytes > Long.MAX_VALUE - length || (size >= 0 && length > size - bytes)) throw new IOException("Size mismatch");
                    long before = bytes;
                    try { file.write(data, 0, length); }
                    catch (IOException error) { try { file.truncate(before); } catch (IOException rollback) { error.addSuppressed(rollback); } throw error; }
                    hash.update(data,0,length);bytes+=length; progress.update(bytes);
                }
                digest = hash.digest();
                if (!MessageDigest.isEqual(digest, channel.read()) || (size >= 0 && bytes != size)) {
                    file.truncate(0); file.sync(); throw new IOException("Incomplete file");
                }
                file.sync();
            }
            publisher.publish(entry); entry.length = bytes; entry.digest = digest; entry.done = true;
            // Persist commit before ACK so a reconnect does not republish after a lost ACK.
            if (entry.checkpoint != null) entry.checkpoint.save(entry);
            if (entry.partial != null) entry.partial.delete();
            channel.write(new byte[]{2}); return bytes;
        }
    }
}
