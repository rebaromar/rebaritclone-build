package com.abdulla.clonephone;

import android.content.Context;
import android.net.*;
import android.net.wifi.*;
import android.net.wifi.p2p.*;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest;
import android.os.*;
import java.util.*;

/**
 * Local-only Android Wi-Fi transport.
 *
 * REBARIT v16.3 adds:
 * - explicit Auto / 2.4 / 5 / best-effort 6 GHz host modes
 * - Wi-Fi Direct DNS-SD Nearby discovery so the sender can discover a receiver
 *   without scanning QR when the OEM supports P2P service discovery.
 */
@SuppressWarnings("deprecation")
final class HotspotLink {
    static final int BAND_AUTO=0;
    static final int BAND_24=24;
    static final int BAND_5=5;
    static final int BAND_6=6;

    interface HostCallback {void ready(String ssid,String password);void failed(String reason);}
    interface ClientCallback {void ready(Network network);void failed();}
    interface NearbyCallback {void found(String model,String payload);void failed(String reason);}

    private final WifiManager wifi;
    private final ConnectivityManager connectivity;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WifiManager.LocalOnlyHotspotReservation reservation;
    private ConnectivityManager.NetworkCallback callback;
    private int generation,groupFrequency,requestedBand=BAND_AUTO;
    private boolean automaticFallback;
    private final WifiP2pManager p2p;
    private WifiP2pManager.Channel p2pChannel;
    private boolean ownsGroup;
    private String failure="",groupAddress="";
    private WifiManager.WifiLock performanceLock;

    private WifiP2pDnsSdServiceInfo nearbyLocalService;
    private WifiP2pDnsSdServiceRequest nearbyRequest;
    private NearbyCallback nearbyCallback;
    private final Set<String> nearbySeen=new HashSet<>();

    HotspotLink(Context context){
        wifi=(WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        connectivity=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        p2p=(WifiP2pManager)context.getSystemService(Context.WIFI_P2P_SERVICE);
        if(p2p!=null)p2pChannel=p2p.initialize(context,Looper.getMainLooper(),()->p2pChannel=null);
    }

    void start(boolean fast,HostCallback listener){start(fast?BAND_5:BAND_AUTO,listener);}

    void start(int band,HostCallback listener){
        close();failure="";automaticFallback=false;requestedBand=band;final int token=generation;
        if(band==BAND_6){
            int sixBand=sixGhzOperatingBand();
            if(Build.VERSION.SDK_INT<31||!safe6GhzSupported()||sixBand<0){listener.failed("6GHZ_UNAVAILABLE");return;}
            startP2pBand(listener,token,sixBand,0);return;
        }
        if(band==BAND_5){
            if(Build.VERSION.SDK_INT>=29&&wifi.is5GHzBandSupported())startP2pBand(listener,token,WifiP2pConfig.GROUP_OWNER_BAND_5GHZ,0);
            else listener.failed("5GHZ_UNAVAILABLE");
            return;
        }
        if(band==BAND_24){
            if(Build.VERSION.SDK_INT>=29)startP2pBand(listener,token,WifiP2pConfig.GROUP_OWNER_BAND_2GHZ,0);
            else startLocal(listener,token);
            return;
        }
        // Auto prioritizes the fast, broadly supported 5 GHz P2P path. If the
        // OEM refuses group creation, LocalOnlyHotspot is used as compatibility fallback.
        if(Build.VERSION.SDK_INT>=29&&wifi.is5GHzBandSupported())startP2pBand(listener,token,WifiP2pConfig.GROUP_OWNER_BAND_5GHZ,0);
        else startLocal(listener,token);
    }

    private boolean safe6GhzSupported(){try{return Build.VERSION.SDK_INT>=31&&wifi.is6GHzBandSupported();}catch(Throwable t){return false;}}

    /**
     * GROUP_OWNER_BAND_6GHZ is not exposed by every compile SDK/OEM combination.
     * Resolve it at runtime so the project always compiles and 6 GHz is offered
     * only on Android builds that actually expose the constant.
     */
    private int sixGhzOperatingBand(){
        try{return WifiP2pConfig.class.getField("GROUP_OWNER_BAND_6GHZ").getInt(null);}
        catch(Throwable ignored){return -1;}
    }

    private void startLocal(HostCallback listener,int token){
        try{wifi.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback(){
            @Override public void onStarted(WifiManager.LocalOnlyHotspotReservation value){
                if(token!=generation){value.close();return;}reservation=value;
                String ssid,password;
                if(Build.VERSION.SDK_INT>=30){SoftApConfiguration c=value.getSoftApConfiguration();ssid=c.getSsid();password=c.getPassphrase();}
                else{WifiConfiguration c=value.getWifiConfiguration();ssid=c.SSID;password=c.preSharedKey;}
                if(ssid==null||password==null){failure="HOTSPOT_NO_CONFIG";listener.failed(failure);return;}
                listener.ready(ssid,password);
            }
            @Override public void onFailed(int reason){if(token==generation){failure="HOTSPOT_ERROR_"+reason;listener.failed(failure);}}
            @Override public void onStopped(){if(token==generation){close();listener.failed("HOTSPOT_STOPPED");}}
        },main);}catch(SecurityException e){close();listener.failed("WIFI_PERMISSION_OR_LOCATION");}catch(Exception e){close();listener.failed(e.getClass().getSimpleName());}
    }

    private WifiP2pConfig.Builder baseP2pBuilder(){
        String suffix=SecureChannel.newCode().replace("-","");
        if(suffix.length()>6)suffix=suffix.substring(0,6);
        String pass=SecureChannel.newCode().replace("-","");
        if(pass.length()>16)pass=pass.substring(0,16);
        return new WifiP2pConfig.Builder().setNetworkName("DIRECT-rb-"+suffix).setPassphrase(pass);
    }

    private void startP2pBand(HostCallback listener,int token,int operatingBand,int attempt){
        if(token!=generation)return;
        if(p2p==null||p2pChannel==null){if(requestedBand==BAND_AUTO)startLocal(listener,token);else listener.failed("P2P_UNAVAILABLE");return;}
        WifiP2pManager.ActionListener action=p2pAction(listener,token,attempt,()->startP2pBand(listener,token,operatingBand,attempt+1));
        try{
            WifiP2pConfig config=baseP2pBuilder().setGroupOperatingBand(operatingBand).build();
            p2p.createGroup(p2pChannel,config,action);
        }catch(Exception e){action.onFailure(-1);}
    }


    private WifiP2pManager.ActionListener p2pAction(HostCallback listener,int token,int attempt,Runnable retry){
        return new WifiP2pManager.ActionListener(){
            public void onSuccess(){if(token!=generation)return;ownsGroup=true;readGroup(listener,token,0);}
            public void onFailure(int reason){if(token!=generation)return;
                long delay=P2pRetry.delay(reason,attempt);
                if(delay>=0){main.postDelayed(retry,delay);return;}
                failure="P2P_ERROR_"+reason;
                if(requestedBand==BAND_AUTO&&!automaticFallback){automaticFallback=true;startLocal(listener,token);}
                else listener.failed(failure);
            }
        };
    }

    private void readGroup(HostCallback listener,int token,int tries){
        if(token!=generation)return;
        try{p2p.requestGroupInfo(p2pChannel,group->{
            if(token!=generation)return;
            if(group!=null&&group.isGroupOwner()&&group.getPassphrase()!=null){
                p2p.requestConnectionInfo(p2pChannel,info->{
                    if(token!=generation)return;
                    if(info!=null&&info.groupFormed&&info.isGroupOwner&&info.groupOwnerAddress!=null){
                        groupFrequency=Build.VERSION.SDK_INT>=29?group.getFrequency():0;
                        if(!requestedBandMatches(groupFrequency)){close();listener.failed("REQUESTED_BAND_NOT_CONFIRMED");return;}
                        groupAddress=info.groupOwnerAddress.getHostAddress();listener.ready(group.getNetworkName(),group.getPassphrase());
                    }else if(tries<20)main.postDelayed(()->readGroup(listener,token,tries+1),500);
                    else{close();listener.failed("P2P_NO_GROUP_ADDRESS");}
                });return;
            }
            if(tries>=20){close();listener.failed("P2P_NO_GROUP_ADDRESS");return;}
            main.postDelayed(()->readGroup(listener,token,tries+1),500);
        });}catch(Exception e){close();listener.failed("P2P_PERMISSION_OR_LOCATION");}
    }

    private boolean requestedBandMatches(int frequency){
        if(requestedBand==BAND_AUTO||frequency<=0)return true;
        if(requestedBand==BAND_24)return frequency>=2400&&frequency<2500;
        if(requestedBand==BAND_5)return frequency>=4900&&frequency<5925;
        if(requestedBand==BAND_6)return frequency>=5925;
        return true;
    }

    /** Advertise the receiver's pairing payload via Wi-Fi Direct DNS-SD. */
    void advertiseNearby(String pairingPayload){
        if(p2p==null||p2pChannel==null||pairingPayload==null||pairingPayload.isEmpty())return;
        try{
            stopNearbyServices(false);
            Map<String,String> record=new HashMap<>();
            record.put("pair",pairingPayload);
            record.put("model",Build.MODEL==null?"Android":Build.MODEL);
            record.put("v","16.5");
            nearbyLocalService=WifiP2pDnsSdServiceInfo.newInstance("REBARIT_CLONE","_rebarit._tcp",record);
            p2p.addLocalService(p2pChannel,nearbyLocalService,new WifiP2pManager.ActionListener(){public void onSuccess(){}public void onFailure(int reason){}});
        }catch(Throwable ignored){}
    }

    /** Discover a nearby receiver without QR using Wi-Fi Direct service discovery. */
    void discoverNearby(NearbyCallback listener){
        if(p2p==null||p2pChannel==null){listener.failed("P2P_UNAVAILABLE");return;}
        nearbyCallback=listener;nearbySeen.clear();
        try{
            if(nearbyRequest!=null)try{p2p.removeServiceRequest(p2pChannel,nearbyRequest,null);}catch(Exception ignored){}
            p2p.setDnsSdResponseListeners(p2pChannel,(instance,registrationType,device)->{},(fullDomain,record,device)->{
                if(nearbyCallback==null||record==null)return;
                String payload=record.get("pair");if(payload==null||payload.isEmpty())return;
                String key=(device==null?"":device.deviceAddress)+"|"+payload;
                if(!nearbySeen.add(key))return;
                String model=record.get("model");if(model==null||model.isEmpty())model=device==null?"Android":device.deviceName;
                NearbyCallback cb=nearbyCallback;String finalModel=model;main.post(()->{if(cb==nearbyCallback)cb.found(finalModel,payload);});
            });
            nearbyRequest=WifiP2pDnsSdServiceRequest.newInstance();
            p2p.addServiceRequest(p2pChannel,nearbyRequest,new WifiP2pManager.ActionListener(){
                public void onSuccess(){try{p2p.discoverServices(p2pChannel,new WifiP2pManager.ActionListener(){public void onSuccess(){}public void onFailure(int reason){NearbyCallback cb=nearbyCallback;if(cb!=null)cb.failed("DISCOVERY_"+reason);}});}catch(Exception e){NearbyCallback cb=nearbyCallback;if(cb!=null)cb.failed("DISCOVERY");}}
                public void onFailure(int reason){NearbyCallback cb=nearbyCallback;if(cb!=null)cb.failed("REQUEST_"+reason);}
            });
        }catch(SecurityException e){listener.failed("WIFI_PERMISSION");}catch(Throwable e){listener.failed("DISCOVERY");}
    }

    void stopNearbyDiscovery(){
        nearbyCallback=null;nearbySeen.clear();
        if(p2p!=null&&p2pChannel!=null&&nearbyRequest!=null)try{p2p.removeServiceRequest(p2pChannel,nearbyRequest,null);}catch(Exception ignored){}
        nearbyRequest=null;
    }

    private void stopNearbyServices(boolean clearLocal){
        stopNearbyDiscovery();
        if(clearLocal&&p2p!=null&&p2pChannel!=null&&nearbyLocalService!=null)try{p2p.removeLocalService(p2pChannel,nearbyLocalService,null);}catch(Exception ignored){}
        if(clearLocal)nearbyLocalService=null;
    }

    void performance(boolean enabled){
        if(performanceLock!=null){try{if(performanceLock.isHeld())performanceLock.release();}catch(Exception ignored){}performanceLock=null;}
        if(enabled)try{performanceLock=wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF,"rebaritclone-transfer");performanceLock.setReferenceCounted(false);performanceLock.acquire();}catch(Exception ignored){}
    }

    String hostAddress(){return groupAddress==null?"":groupAddress;}

    String hostInfo(){
        String band=groupFrequency>=5925?"6 GHz • Wi-Fi Direct • "+groupFrequency+" MHz":groupFrequency>=4900&&groupFrequency<5925?"5 GHz • Wi-Fi Direct • "+groupFrequency+" MHz":groupFrequency>=2400&&groupFrequency<2500?"2.4 GHz • Wi-Fi Direct • "+groupFrequency+" MHz":"Local hotspot • Android band control";
        return (automaticFallback?"Auto fallback\n":"")+band+"\n"+capabilityInfo();
    }
    private String capabilityInfo(){try{if(Build.VERSION.SDK_INT>=31&&wifi.is6GHzBandSupported())return "6 GHz / 5 GHz / 2.4 GHz capable";if(wifi.is5GHzBandSupported())return "5 GHz / 2.4 GHz capable";return "2.4 GHz compatible";}catch(Exception e){return "2.4 GHz compatible";}}

    String linkInfo(Network network){
        try{
            WifiInfo info=null;
            if(Build.VERSION.SDK_INT>=29&&network!=null){NetworkCapabilities cap=connectivity.getNetworkCapabilities(network);if(cap!=null&&cap.getTransportInfo() instanceof WifiInfo)info=(WifiInfo)cap.getTransportInfo();}
            if(info==null)return UiText.t(225);
            int f=info.getFrequency(),rate=info.getLinkSpeed();
            String band=f>=5925?"6 GHz":f>=4900?"5 GHz":f>=2400?"2.4 GHz":"Wi-Fi";
            return band+(rate>0?" • Link "+rate+" Mbps":"")+"\n"+(f>=2400&&f<2500?UiText.t(226):UiText.t(227));
        }catch(Exception e){return UiText.t(228);}
    }

    void connect(Pairing peer,ClientCallback listener){
        close();final int token=generation;
        if(Build.VERSION.SDK_INT<29){listener.failed();return;}
        try{
            WifiNetworkSpecifier spec=new WifiNetworkSpecifier.Builder().setSsid(peer.ssid).setWpa2Passphrase(peer.password).build();
            NetworkRequest request=new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build();
            callback=new ConnectivityManager.NetworkCallback(){
                @Override public void onAvailable(Network n){main.post(()->{if(token==generation)listener.ready(n);});}
                @Override public void onUnavailable(){main.post(()->{if(token==generation){close();listener.failed();}});}
                @Override public void onLost(Network n){main.post(()->{if(token==generation){/* transfer engine owns reconnect */}});}
            };
            connectivity.requestNetwork(request,callback,60000);
        }catch(Exception e){close();listener.failed();}
    }

    Network currentWifi(){
        for(Network n:connectivity.getAllNetworks()){
            NetworkCapabilities c=connectivity.getNetworkCapabilities(n);
            if(c!=null&&c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)&&!c.hasTransport(NetworkCapabilities.TRANSPORT_VPN))return n;
        }return null;
    }

    void close(){
        generation++;groupAddress="";groupFrequency=0;stopNearbyServices(true);
        performance(false);
        if(ownsGroup&&p2p!=null&&p2pChannel!=null){try{p2p.removeGroup(p2pChannel,null);}catch(Exception ignored){}ownsGroup=false;}
        if(callback!=null){try{connectivity.unregisterNetworkCallback(callback);}catch(Exception ignored){}callback=null;}
        if(reservation!=null){try{reservation.close();}catch(Exception ignored){}reservation=null;}
    }
}
