package com.abdulla.clonephone;

import android.content.Context;
import android.net.*;
import android.net.wifi.*;
import android.net.wifi.p2p.*;
import android.os.*;
import java.util.List;

/** Local-only Android APIs. All public methods and callbacks run on the main thread. */
@SuppressWarnings("deprecation")
final class HotspotLink {
    interface HostCallback {void ready(String ssid,String password);void failed(String reason);}
    interface ClientCallback {void ready(Network network);void failed();}
    static final int BAND_AUTO=WifiBandPolicy.AUTO, BAND_24=WifiBandPolicy.GHZ_24,
            BAND_5=WifiBandPolicy.GHZ_5, BAND_6=WifiBandPolicy.GHZ_6;
    private static final int GROUP_READ_ATTEMPTS=10;
    private final WifiManager wifi;
    private final ConnectivityManager connectivity;
    private final WifiP2pManager p2p;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WifiP2pManager.Channel p2pChannel;
    private WifiManager.LocalOnlyHotspotReservation reservation;
    private ConnectivityManager.NetworkCallback callback;
    private WifiManager.WifiLock performanceLock;
    private int generation,groupFrequency;
    private boolean ownsGroup,creatingGroup,removingGroup,automaticFallback;
    private Runnable pendingHostStart;
    private String failure="",groupAddress="";

    HotspotLink(Context context){
        wifi=(WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        connectivity=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        p2p=(WifiP2pManager)context.getSystemService(Context.WIFI_P2P_SERVICE);
        if(p2p!=null)try{p2pChannel=p2p.initialize(context,Looper.getMainLooper(),()->p2pChannel=null);}catch(Exception ignored){}
    }
    String hostAddress(){return groupAddress;}

    /** Compatibility entry point: prefer 5 GHz when requested, with an automatic fallback. */
    void start(boolean fast,HostCallback listener){
        if(!fast){startBand(BAND_AUTO,listener);return;}
        close();failure="";automaticFallback=false;final int token=generation;
        queueHostStart(token,()->{
            if(supportsBand(BAND_5))startP2pBand(listener,token,BAND_5,0,()->{
                automaticFallback=true;startLocal(listener,token,true);
            },0);
            else{automaticFallback=true;startLocal(listener,token,true);}
        });
    }

    boolean supportsBand(int band){
        boolean radio24=false,radio5=false,radio6=false;
        try{
            if(wifi!=null){
                radio24=Build.VERSION.SDK_INT<31||wifi.is24GHzBandSupported();
                radio5=wifi.is5GHzBandSupported();
                radio6=Build.VERSION.SDK_INT>=30&&wifi.is6GHzBandSupported();
            }
        }catch(Exception ignored){}
        int frequency6=band==BAND_6&&radio6?supported6GHzFrequency():0;
        return WifiBandPolicy.canSelect(Build.VERSION.SDK_INT,wifi!=null,p2p!=null&&p2pChannel!=null,
                radio24,radio5,radio6,frequency6,band);
    }

    void startBand(int band,HostCallback listener){
        close();failure="";automaticFallback=false;final int token=generation;
        if(!supportsBand(band)){listener.failed(band==BAND_6?"6GHZ_UNAVAILABLE":band==BAND_5?"5GHZ_UNAVAILABLE":band==BAND_24?"2GHZ_UNAVAILABLE":"WIFI_UNAVAILABLE");return;}
        queueHostStart(token,()->{
            if(band==BAND_AUTO){
                int[] candidates=WifiBandPolicy.automaticBands(supportsBand(BAND_6),supportsBand(BAND_5),supportsBand(BAND_24));
                startAutomaticCandidate(listener,token,candidates,0);
            }else startP2pBand(listener,token,band,band==BAND_6?supported6GHzFrequency():0,null,0);
        });
    }

    private void startAutomaticCandidate(HostCallback listener,int token,int[] bands,int index){
        if(token!=generation)return;
        if(index>=bands.length){startLocal(listener,token,true);return;}
        int band=bands[index];
        startP2pBand(listener,token,band,band==BAND_6?supported6GHzFrequency():0,()->{
            automaticFallback=true;startAutomaticCandidate(listener,token,bands,index+1);
        },0);
    }

    /** Radio support alone cannot establish that Android permits a 6 GHz P2P group owner. */
    private int supported6GHzFrequency(){
        if(Build.VERSION.SDK_INT<34||wifi==null||p2p==null||p2pChannel==null)return 0;
        try{if(!wifi.is6GHzBandSupported())return 0;}catch(Exception e){return 0;}
        try{
            int value=choose6GHzChannel(wifi.getUsableChannels(ScanResult.WIFI_BAND_6_GHZ,WifiAvailableChannel.OP_MODE_WIFI_DIRECT_GO));
            if(value>0)return value;
        }catch(Exception ignored){}
        try{return choose6GHzChannel(wifi.getAllowedChannels(ScanResult.WIFI_BAND_6_GHZ,WifiAvailableChannel.OP_MODE_WIFI_DIRECT_GO));}
        catch(Exception ignored){return 0;}
    }
    private int choose6GHzChannel(List<WifiAvailableChannel> channels){
        if(channels==null)return 0;
        int[] frequencies=new int[channels.size()],modes=new int[channels.size()];
        for(int i=0;i<channels.size();i++)if(channels.get(i)!=null){frequencies[i]=channels.get(i).getFrequencyMhz();modes[i]=channels.get(i).getOperationalModes();}
        return WifiBandPolicy.choose6GHzFrequency(frequencies,modes,WifiAvailableChannel.OP_MODE_WIFI_DIRECT_GO);
    }

    private void startP2pBand(HostCallback listener,int token,int band,int frequency,Runnable fallback,int attempt){
        if(token!=generation)return;
        if(p2p==null||p2pChannel==null){attemptFailed(listener,token,"P2P_UNAVAILABLE",fallback);return;}
        if(band==BAND_6&&!WifiBandPolicy.valid6GHzFrequency(frequency)){attemptFailed(listener,token,"6GHZ_UNAVAILABLE",fallback);return;}
        creatingGroup=true;
        WifiP2pManager.ActionListener action=new WifiP2pManager.ActionListener(){
            public void onSuccess(){
                creatingGroup=false;ownsGroup=true;
                // A cancelled create can still succeed. Remove it before a new create starts.
                if(token!=generation){removeOwnedGroup(0);return;}
                readGroup(listener,token,band,fallback,0);
            }
            public void onFailure(int reason){
                creatingGroup=false;
                if(token!=generation){drainPendingHostStart();return;}
                long delay=P2pRetry.delay(reason,attempt);
                if(delay>=0){main.postDelayed(()->startP2pBand(listener,token,band,frequency,fallback,attempt+1),delay);return;}
                attemptFailed(listener,token,"P2P_ERROR_"+reason,fallback);
            }
        };
        try{
            if(Build.VERSION.SDK_INT>=29){
                String suffix=SecureChannel.newCode().substring(0,6);
                WifiP2pConfig.Builder builder=new WifiP2pConfig.Builder()
                        .setNetworkName("DIRECT-rb-"+suffix)
                        .setPassphrase(SecureChannel.newCode().substring(0,16));
                if(band==BAND_6)builder.setGroupOperatingFrequency(frequency);
                else builder.setGroupOperatingBand(band==BAND_24?WifiP2pConfig.GROUP_OWNER_BAND_2GHZ:
                        band==BAND_5?WifiP2pConfig.GROUP_OWNER_BAND_5GHZ:WifiP2pConfig.GROUP_OWNER_BAND_AUTO);
                p2p.createGroup(p2pChannel,builder.build(),action);
            }else p2p.createGroup(p2pChannel,action);
        }catch(SecurityException e){creatingGroup=false;attemptFailed(listener,token,"P2P_PERMISSION_OR_LOCATION",fallback);}
        catch(Exception e){action.onFailure(-1);}
    }

    private void readGroup(HostCallback listener,int token,int band,Runnable fallback,int tries){
        if(token!=generation)return;
        try{p2p.requestGroupInfo(p2pChannel,group->{
            if(token!=generation)return;
            if(group!=null&&group.isGroupOwner()&&group.getPassphrase()!=null){
                p2p.requestConnectionInfo(p2pChannel,info->{
                    if(token!=generation)return;
                    if(info!=null&&info.groupFormed&&info.isGroupOwner&&info.groupOwnerAddress!=null){
                        int frequency=Build.VERSION.SDK_INT>=29?group.getFrequency():0;
                        if(!WifiBandPolicy.matches(band,frequency)){
                            if(frequency==0&&tries<GROUP_READ_ATTEMPTS){main.postDelayed(()->readGroup(listener,token,band,fallback,tries+1),500);return;}
                            attemptFailed(listener,token,band==BAND_6?"6GHZ_NOT_CONFIRMED":band==BAND_5?"5GHZ_NOT_CONFIRMED":"2GHZ_NOT_CONFIRMED",fallback);return;
                        }
                        groupFrequency=frequency;groupAddress=info.groupOwnerAddress.getHostAddress();
                        listener.ready(group.getNetworkName(),group.getPassphrase());
                    }else retryReadGroup(listener,token,band,fallback,tries);
                });return;
            }
            retryReadGroup(listener,token,band,fallback,tries);
        });}catch(Exception e){attemptFailed(listener,token,"P2P_PERMISSION_OR_LOCATION",fallback);}
    }
    private void retryReadGroup(HostCallback listener,int token,int band,Runnable fallback,int tries){
        if(tries>=GROUP_READ_ATTEMPTS){attemptFailed(listener,token,"P2P_NO_GROUP_ADDRESS",fallback);return;}
        main.postDelayed(()->readGroup(listener,token,band,fallback,tries+1),500);
    }

    private void startLocal(HostCallback listener,int token,boolean fallbackP2p){
        if(token!=generation)return;
        if(Build.VERSION.SDK_INT<26||wifi==null){
            if(fallbackP2p)startP2pBand(listener,token,BAND_AUTO,0,null,0);
            else attemptFailed(listener,token,"HOTSPOT_UNAVAILABLE",null);
            return;
        }
        Runnable fallback=fallbackP2p?()->startP2pBand(listener,token,BAND_AUTO,0,null,0):null;
        try{wifi.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback(){
            @Override public void onStarted(WifiManager.LocalOnlyHotspotReservation value){
                if(token!=generation){value.close();return;}
                String ssid,password;
                if(Build.VERSION.SDK_INT>=30){SoftApConfiguration config=value.getSoftApConfiguration();ssid=config==null?null:config.getSsid();password=config==null?null:config.getPassphrase();}
                else{WifiConfiguration config=value.getWifiConfiguration();ssid=config==null?null:config.SSID;password=config==null?null:config.preSharedKey;}
                if(ssid==null||password==null){value.close();attemptFailed(listener,token,"HOTSPOT_NO_CONFIG",fallback);return;}
                reservation=value;groupFrequency=0;groupAddress="";listener.ready(ssid,password);
            }
            @Override public void onFailed(int reason){if(token==generation)attemptFailed(listener,token,"HOTSPOT_ERROR_"+reason,fallback);}
            @Override public void onStopped(){if(token==generation)attemptFailed(listener,token,"HOTSPOT_STOPPED",null);}
        },main);}catch(SecurityException e){attemptFailed(listener,token,"WIFI_PERMISSION_OR_LOCATION",fallback);}
        catch(Exception e){attemptFailed(listener,token,e.getClass().getSimpleName(),fallback);}
    }

    private void attemptFailed(HostCallback listener,int token,String reason,Runnable fallback){
        if(token!=generation)return;
        failure+=(failure.isEmpty()?"":" / ")+reason;groupAddress="";groupFrequency=0;
        if(fallback!=null)queueHostStart(token,fallback);
        else{String message=failure;close();listener.failed(message);}
    }
    private void queueHostStart(int token,Runnable action){
        if(token!=generation)return;
        if(creatingGroup||removingGroup||ownsGroup){
            pendingHostStart=()->{if(token==generation)action.run();};
            if(ownsGroup&&!creatingGroup&&!removingGroup)removeOwnedGroup(0);
        }else action.run();
    }
    private void drainPendingHostStart(){
        if(creatingGroup||removingGroup)return;
        Runnable next=pendingHostStart;pendingHostStart=null;if(next!=null)next.run();
    }
    private void removeOwnedGroup(int attempt){
        if(removingGroup||creatingGroup)return;
        if(p2p==null||p2pChannel==null){ownsGroup=false;drainPendingHostStart();return;}
        removingGroup=true;
        try{p2p.removeGroup(p2pChannel,new WifiP2pManager.ActionListener(){
            public void onSuccess(){removingGroup=false;ownsGroup=false;drainPendingHostStart();}
            public void onFailure(int reason){
                long delay=P2pRetry.delay(reason,attempt);
                if(delay>=0){main.postDelayed(()->{removingGroup=false;removeOwnedGroup(attempt+1);},delay);return;}
                // Never re-advertise old credentials after a failed removal. A fresh create
                // still has bounded BUSY retries, and a later close retries group removal.
                removingGroup=false;drainPendingHostStart();
            }
        });}catch(Exception e){removingGroup=false;drainPendingHostStart();}
    }

    void performance(boolean enabled){
        if(performanceLock!=null){try{if(performanceLock.isHeld())performanceLock.release();}catch(Exception ignored){}performanceLock=null;}
        if(enabled&&wifi!=null)try{performanceLock=wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF,"rebaritclone-transfer");performanceLock.setReferenceCounted(false);performanceLock.acquire();}catch(Exception ignored){}
    }
    String hostInfo(){
        String band=WifiBandPolicy.matches(BAND_6,groupFrequency)?"6 GHz":WifiBandPolicy.matches(BAND_5,groupFrequency)?"5 GHz":WifiBandPolicy.matches(BAND_24,groupFrequency)?"2.4 GHz":"";
        String connection=band.isEmpty()?UiText.t(224):band+" • Wi-Fi Direct • "+groupFrequency+" MHz";
        return (automaticFallback?UiText.t(252)+"\n":"")+connection+"\n"+capabilityInfo();
    }
    private String capabilityInfo(){try{if(supportsBand(BAND_6))return UiText.t(287);if(wifi!=null&&wifi.is5GHzBandSupported())return UiText.t(288);}catch(Exception ignored){}return UiText.t(289);}
    String linkInfo(Network network){
        try{
            WifiInfo info=null;
            if(Build.VERSION.SDK_INT>=29&&network!=null){NetworkCapabilities cap=connectivity.getNetworkCapabilities(network);if(cap!=null&&cap.getTransportInfo() instanceof WifiInfo)info=(WifiInfo)cap.getTransportInfo();}
            if(info==null)return UiText.t(225);
            int frequency=info.getFrequency(),rate=info.getLinkSpeed();
            String band=WifiBandPolicy.matches(BAND_6,frequency)?"6 GHz":WifiBandPolicy.matches(BAND_5,frequency)?"5 GHz":WifiBandPolicy.matches(BAND_24,frequency)?"2.4 GHz":"Wi-Fi";
            return band+(rate>0?" • Link "+rate+" Mbps":"")+"\n"+(WifiBandPolicy.matches(BAND_24,frequency)?UiText.t(226):UiText.t(227));
        }catch(Exception e){return UiText.t(228);}
    }
    void connect(Pairing peer,ClientCallback listener){
        close();final int token=generation;
        if(Build.VERSION.SDK_INT<29||connectivity==null){listener.failed();return;}
        try{
            WifiNetworkSpecifier spec=new WifiNetworkSpecifier.Builder().setSsid(peer.ssid).setWpa2Passphrase(peer.password).build();
            NetworkRequest request=new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build();
            callback=new ConnectivityManager.NetworkCallback(){
                @Override public void onAvailable(Network network){main.post(()->{if(token==generation)listener.ready(network);});}
                @Override public void onUnavailable(){main.post(()->{if(token==generation){close();listener.failed();}});}
                @Override public void onLost(Network network){main.post(()->{if(token==generation){/* Transfer engine owns reconnect/resume. */}});}
            };
            connectivity.requestNetwork(request,callback,60000);
        }catch(Exception e){close();listener.failed();}
    }
    Network currentWifi(){
        if(connectivity==null)return null;
        for(Network network:connectivity.getAllNetworks()){
            NetworkCapabilities cap=connectivity.getNetworkCapabilities(network);
            if(cap!=null&&cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)&&!cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN))return network;
        }return null;
    }
    void close(){
        generation++;pendingHostStart=null;groupAddress="";groupFrequency=0;
        performance(false);
        if(ownsGroup&&!creatingGroup&&!removingGroup)removeOwnedGroup(0);
        if(callback!=null){try{if(connectivity!=null)connectivity.unregisterNetworkCallback(callback);}catch(Exception ignored){}callback=null;}
        if(reservation!=null){WifiManager.LocalOnlyHotspotReservation old=reservation;reservation=null;try{old.close();}catch(Exception ignored){}}
    }
}
