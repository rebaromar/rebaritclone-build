package com.abdulla.clonephone;

import java.io.*;
import java.net.*;
import java.security.GeneralSecurityException;
import java.util.*;
import java.util.concurrent.CancellationException;

/** Distinguishes errors from the transfer wire from source, destination and protocol errors. */
public final class TransferFailure {
    private TransferFailure() { }
    public static final class TransportException extends IOException {
        private final boolean usbOnly;
        public TransportException(String message, Throwable cause) { this(message, cause, false); }
        private TransportException(String message, Throwable cause, boolean usbOnly) {
            super(message, cause); this.usbOnly = usbOnly;
        }
    }
    private static List<Throwable> causes(Throwable error) {
        List<Throwable> result = new ArrayList<>(); Set<Throwable> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        while (error != null && seen.add(error)) { result.add(error); error = error.getCause(); }
        return result;
    }
    private static boolean terminal(List<Throwable> causes) {
        for (Throwable error : causes) {
            if (error instanceof GeneralSecurityException || error instanceof SecurityException ||
                error instanceof CancellationException || error instanceof InterruptedException) return true;
            String message = error.getMessage();
            if (message == null) continue;
            if (message.startsWith("SOURCE_CHANGED") || message.startsWith("Protocol mismatch") ||
                message.equals("Size mismatch") || message.equals("Incomplete file") ||
                message.equals("Invalid resume offset") || message.equals("Invalid stored checkpoint") ||
                message.equals("Invalid file size") || message.equals("Invalid file size or chunk") ||
                message.equals("Pairing failed") || message.equals("Frame limit") ||
                message.equals("Invalid record type") || message.equals("Invalid ACK") ||
                message.equals("CANCEL") || message.equals("CANCELLED") || message.equals("Cancelled") ||
                message.equals("USB_CANCELLED") || message.equals("Interrupted") ||
                message.equals("REJECTED") || message.equals("DENIED")) return true;
        }
        return false;
    }
    public static boolean network(Throwable error) {
        List<Throwable> causes = causes(error); if (terminal(causes)) return false;
        for (Throwable cause : causes) {
            if (cause instanceof TransportException && !((TransportException)cause).usbOnly) return true;
            if (cause instanceof SocketException || cause instanceof SocketTimeoutException || "CONNECT".equals(cause.getMessage())) return true;
        }
        return false;
    }
    public static boolean usb(Throwable error) {
        List<Throwable> causes = causes(error); if (terminal(causes)) return false;
        for (Throwable cause : causes) {
            if (cause instanceof TransportException || "USB_DISCONNECTED".equals(cause.getMessage())) return true;
        }
        return false;
    }
    private static TransportException wire(IOException error, boolean usbOnly) {
        if (error instanceof TransportException) return (TransportException)error;
        return new TransportException(usbOnly ? "USB_DISCONNECTED" : "Connection lost", error, usbOnly);
    }
    static InputStream wireInput(InputStream input) { return input(input, false); }
    static OutputStream wireOutput(OutputStream output) { return output(output, false); }
    public static InputStream usbInput(InputStream input) { return input(input, true); }
    public static OutputStream usbOutput(OutputStream output) { return output(output, true); }
    private static InputStream input(InputStream delegate, boolean usbOnly) {
        return new FilterInputStream(delegate) {
            @Override public int read() throws IOException {
                try { int result = in.read(); if (result < 0) throw new EOFException(); return result; }
                catch (IOException error) { throw wire(error, usbOnly); }
            }
            @Override public int read(byte[] bytes, int offset, int length) throws IOException {
                try { int result = in.read(bytes, offset, length); if (result < 0) throw new EOFException(); return result; }
                catch (IOException error) { throw wire(error, usbOnly); }
            }
            @Override public void close() throws IOException {
                try { in.close(); } catch (IOException error) { throw wire(error, usbOnly); }
            }
        };
    }
    private static OutputStream output(OutputStream delegate, boolean usbOnly) {
        return new FilterOutputStream(delegate) {
            @Override public void write(int value) throws IOException {
                try { out.write(value); } catch (IOException error) { throw wire(error, usbOnly); }
            }
            @Override public void write(byte[] bytes, int offset, int length) throws IOException {
                try { out.write(bytes, offset, length); } catch (IOException error) { throw wire(error, usbOnly); }
            }
            @Override public void flush() throws IOException {
                try { out.flush(); } catch (IOException error) { throw wire(error, usbOnly); }
            }
            @Override public void close() throws IOException {
                try { out.close(); } catch (IOException error) { throw wire(error, usbOnly); }
            }
        };
    }
}
