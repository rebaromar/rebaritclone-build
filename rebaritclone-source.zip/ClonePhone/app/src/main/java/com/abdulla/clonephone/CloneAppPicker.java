package com.abdulla.clonephone;

import android.app.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Handler;
import android.os.Looper;
import android.text.*;
import android.view.*;
import android.widget.*;
import android.util.LruCache;
import java.util.*;
import java.util.concurrent.*;

/** Searchable individual APK selection. Package lookups and icon rendering stay off the UI thread. */
final class CloneAppPicker {
    static final class App {final String packageName,name;final long bytes;App(String pkg,String label,long size){packageName=pkg;name=label;bytes=size;}}
    interface Done {void selected(Set<String> packages);}
    static void show(Activity activity,List<App> apps,Set<String> previous,Done done){new CloneAppPicker(activity,apps,previous,done).show();}
    private final Activity activity;
    private final List<App> apps,visible=new ArrayList<>();
    private final Set<String> selected=new LinkedHashSet<>(),loading=new HashSet<>();
    private final LruCache<String,Bitmap> icons=new LruCache<>(32);
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ThreadPoolExecutor worker=new ThreadPoolExecutor(0,1,10,TimeUnit.SECONDS,new ArrayBlockingQueue<>(16),r->{Thread t=new Thread(r,"clone-app-icons");t.setDaemon(true);return t;},new ThreadPoolExecutor.AbortPolicy());
    private AlertDialog dialog;
    private TextView summary;
    private BaseAdapter adapter;
    private boolean closed;
    CloneAppPicker(Activity activity,List<App> apps,Set<String> previous,Done done){
        this.activity=activity;this.apps=apps;selected.addAll(previous);visible.addAll(apps);
        LinearLayout panel=new LinearLayout(activity);panel.setOrientation(LinearLayout.VERTICAL);panel.setLayoutDirection(UiText.direction());panel.setPadding(dp(16),dp(8),dp(16),0);
        EditText search=new EditText(activity);search.setSingleLine(true);search.setHint(words("گەڕان بۆ ئەپ","Search apps","البحث عن تطبيق"));panel.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));
        LinearLayout toolbar=new LinearLayout(activity);toolbar.setGravity(Gravity.CENTER_VERTICAL);summary=new TextView(activity);toolbar.addView(summary,new LinearLayout.LayoutParams(0,-2,1));Button all=new Button(activity);all.setAllCaps(false);all.setText(words("هەموو / هیچ","All / none","الكل / لا شيء"));toolbar.addView(all);panel.addView(toolbar);
        ListView list=new ListView(activity);list.setDividerHeight(0);panel.addView(list,new LinearLayout.LayoutParams(-1,dp(340)));
        adapter=new BaseAdapter(){
            public int getCount(){return visible.size();}public App getItem(int position){return visible.get(position);}public long getItemId(int position){return position;}
            public View getView(int position,View recycled,ViewGroup parent){
                LinearLayout row;Holder holder;
                if(recycled==null){row=new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,dp(10),0,dp(10));holder=new Holder();holder.icon=new ImageView(activity);row.addView(holder.icon,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout labels=new LinearLayout(activity);labels.setOrientation(LinearLayout.VERTICAL);labels.setPadding(dp(12),0,dp(8),0);holder.title=new TextView(activity);holder.title.setTextColor(0xff182333);holder.title.setTextSize(16);holder.title.setTypeface(null,Typeface.BOLD);holder.info=new TextView(activity);holder.info.setTextSize(12);holder.info.setTextColor(0xff697586);labels.addView(holder.title);labels.addView(holder.info);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));holder.check=new CheckBox(activity);holder.check.setButtonTintList(ColorStateList.valueOf(0xff1769e0));holder.check.setClickable(false);holder.check.setFocusable(false);row.addView(holder.check,new LinearLayout.LayoutParams(dp(48),dp(48)));row.setTag(holder);}else{row=(LinearLayout)recycled;holder=(Holder)row.getTag();}
                App app=getItem(position);holder.title.setText(app.name);holder.info.setText(TransferStats.size(app.bytes));holder.check.setChecked(selected.contains(app.packageName));holder.check.setContentDescription(app.name);holder.icon.setTag(app.packageName);holder.icon.setImageResource(R.drawable.clone_category_apps);holder.icon.setColorFilter(0xff1769e0);Bitmap image=icons.get(app.packageName);if(image!=null){holder.icon.clearColorFilter();holder.icon.setImageBitmap(image);}else loadIcon(app,holder.icon);return row;
            }
        };list.setAdapter(adapter);
        list.setOnItemClickListener((parent,row,position,id)->{String pkg=visible.get(position).packageName;if(!selected.remove(pkg))selected.add(pkg);adapter.notifyDataSetChanged();refresh();});
        all.setOnClickListener(v->{boolean complete=true;for(App app:visible)if(!selected.contains(app.packageName))complete=false;for(App app:visible)if(complete)selected.remove(app.packageName);else selected.add(app.packageName);adapter.notifyDataSetChanged();refresh();});
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){String query=s.toString().trim().toLowerCase(Locale.ROOT);visible.clear();for(App app:apps)if(app.name.toLowerCase(Locale.ROOT).contains(query)||app.packageName.toLowerCase(Locale.ROOT).contains(query))visible.add(app);adapter.notifyDataSetChanged();}public void afterTextChanged(Editable e){}});
        dialog=new AlertDialog.Builder(UiText.context(activity)).setTitle(words("ئەپی دڵخوازت هەڵبژێرە","Choose your apps","اختر تطبيقاتك")).setView(panel).setPositiveButton(UiText.t(124),(d,w)->done.selected(new LinkedHashSet<>(selected))).setNegativeButton(UiText.t(29),null).create();dialog.setOnDismissListener(d->{closed=true;worker.shutdownNow();});refresh();
    }
    private static final class Holder {ImageView icon;TextView title,info;CheckBox check;}
    private void loadIcon(App app,ImageView view){
        if(closed||!loading.add(app.packageName))return;
        try{worker.execute(()->{Bitmap icon=null;try{Drawable drawable=activity.getPackageManager().getApplicationIcon(app.packageName);int size=dp(42);icon=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);drawable.setBounds(0,0,size,size);drawable.draw(new Canvas(icon));}catch(Exception ignored){}final Bitmap ready=icon;main.post(()->{loading.remove(app.packageName);if(closed||activity.isDestroyed())return;if(ready!=null){icons.put(app.packageName,ready);if(app.packageName.equals(view.getTag())){view.clearColorFilter();view.setImageBitmap(ready);}}});});}catch(RejectedExecutionException full){loading.remove(app.packageName);}
    }
    private void refresh(){long bytes=0;for(App app:apps)if(selected.contains(app.packageName))bytes+=app.bytes;summary.setText(selected.size()+" / "+apps.size()+"  ·  "+TransferStats.size(bytes));}
    private void show(){dialog.show();}
    private int dp(int n){return Math.round(n*activity.getResources().getDisplayMetrics().density);}
    private String words(String ckb,String en,String ar){return "en".equals(UiText.language())?en:"ar".equals(UiText.language())?ar:ckb;}
}
