package com.abdulla.clonephone;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.hardware.Camera;
import android.view.*;
import android.widget.*;
import com.google.zxing.*;
import com.google.zxing.common.HybridBinarizer;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

@SuppressWarnings("deprecation")
public class ScanActivity extends Activity implements SurfaceHolder.Callback {
    private Camera camera;
    private SurfaceView preview;
    private TextView hint;
    private final ExecutorService decoder=Executors.newSingleThreadExecutor();
    private final AtomicBoolean decoding=new AtomicBoolean();
    private volatile boolean done, active;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);UiText.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(CloneDesign.NAVY);getWindow().setNavigationBarColor(CloneDesign.NAVY);getWindow().getDecorView().setSystemUiVisibility(0);
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setLayoutDirection(UiText.direction());root.setBackgroundColor(CloneDesign.NAVY);
        hint=new TextView(this);hint.setText(UiText.t(221));hint.setTextColor(Color.WHITE);hint.setTextSize(20);hint.setGravity(Gravity.CENTER);hint.setPadding(24,40,24,24);root.addView(hint);
        FrameLayout cameraFrame=new FrameLayout(this);root.addView(cameraFrame,new LinearLayout.LayoutParams(-1,0,1));preview=new SurfaceView(this);cameraFrame.addView(preview,new FrameLayout.LayoutParams(-1,-1));cameraFrame.addView(new Finder(this),new FrameLayout.LayoutParams(-1,-1));preview.getHolder().addCallback(this);
        TextView note=new TextView(this);note.setText(UiText.t(222));note.setTextColor(Color.WHITE);note.setGravity(Gravity.CENTER);note.setPadding(20,24,20,24);root.addView(note);
        Button back=new Button(this);CloneDesign.button(back,true);back.setText(UiText.t(29));back.setOnClickListener(v->finish());LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.setMargins(CloneDesign.dp(this,20),0,CloneDesign.dp(this,20),CloneDesign.dp(this,16));root.addView(back,bp);setContentView(root);
    }
    @Override protected void onResume(){super.onResume();active=true;if(preview.getHolder().getSurface().isValid())open();}
    @Override protected void onPause(){active=false;release();super.onPause();}
    @Override protected void onDestroy(){decoder.shutdownNow();super.onDestroy();}
    @Override public void surfaceCreated(SurfaceHolder h){if(active)open();}
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int height){}
    @Override public void surfaceDestroyed(SurfaceHolder h){release();}
    private void open(){
        if(camera!=null||done)return;
        try{
            int id=0;Camera.CameraInfo info=new Camera.CameraInfo();
            for(int i=0;i<Camera.getNumberOfCameras();i++){Camera.getCameraInfo(i,info);if(info.facing==Camera.CameraInfo.CAMERA_FACING_BACK){id=i;break;}}
            Camera.getCameraInfo(id,info);camera=Camera.open(id);Camera.Parameters p=camera.getParameters();
            Camera.Size best=null;
            // 960px is enough for a centered pairing QR and avoids copying and
            // binarizing oversized frames on mid-range phones.
            for(Camera.Size s:p.getSupportedPreviewSizes())if(s.width<=960&&(best==null||s.width*s.height>best.width*best.height))best=s;
            if(best!=null)p.setPreviewSize(best.width,best.height);
            List<String> modes=p.getSupportedFocusModes();if(modes!=null&&modes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE))p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            p.setPreviewFormat(android.graphics.ImageFormat.NV21);camera.setParameters(p);
            int rotation=getWindowManager().getDefaultDisplay().getRotation();int degrees=rotation==Surface.ROTATION_90?90:rotation==Surface.ROTATION_180?180:rotation==Surface.ROTATION_270?270:0;
            camera.setDisplayOrientation((info.orientation-degrees+360)%360);camera.setPreviewDisplay(preview.getHolder());
            camera.setPreviewCallback((data,c)->{
                if(done||!active||!decoding.compareAndSet(false,true))return;
                Camera.Size s=c.getParameters().getPreviewSize();byte[] frame=data.clone();
                try{decoder.execute(()->decode(frame,s.width,s.height));}catch(RejectedExecutionException e){decoding.set(false);}
            });camera.startPreview();
        }catch(Exception e){release();hint.setText(UiText.t(223));}
    }
    private void decode(byte[] data,int width,int height){
        try{
            MultiFormatReader reader=new MultiFormatReader();Map<DecodeHintType,Object> hints=new EnumMap<>(DecodeHintType.class);hints.put(DecodeHintType.POSSIBLE_FORMATS,Collections.singletonList(BarcodeFormat.QR_CODE));reader.setHints(hints);
            // Pairing QR codes are shown at the center of the screen. Decode that
            // area first, then fall back to the whole frame for unusual framing.
            int cropWidth=width*4/5,cropHeight=height*4/5;
            int left=(width-cropWidth)/2,top=(height-cropHeight)/2;
            Result result;
            try {
                result=reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(
                        new PlanarYUVLuminanceSource(data,width,height,left,top,cropWidth,cropHeight,false))));
            } catch (NotFoundException centeredMiss) {
                reader.reset();
                result=reader.decode(new BinaryBitmap(new HybridBinarizer(
                        new PlanarYUVLuminanceSource(data,width,height,0,0,width,height,false))),hints);
            }
            String pairing=result.getText();Pairing.parse(pairing);
            if(active&&!done){done=true;runOnUiThread(()->{setResult(RESULT_OK,new Intent().putExtra("pairing",pairing));finish();});}
        }catch(Exception ignored){}finally{decoding.set(false);}
    }
    private void release(){if(camera!=null){try{camera.setPreviewCallback(null);camera.stopPreview();camera.release();}catch(Exception ignored){}camera=null;}}
    private static final class Finder extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        Finder(android.content.Context c){super(c);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas c){float size=Math.min(getWidth()*.77f,getHeight()*.72f),left=(getWidth()-size)/2,top=(getHeight()-size)/2,right=left+size,bottom=top+size;paint.setColor(0x77101f40);c.drawRect(0,0,getWidth(),top,paint);c.drawRect(0,bottom,getWidth(),getHeight(),paint);c.drawRect(0,top,left,bottom,paint);c.drawRect(right,top,getWidth(),bottom,paint);paint.setColor(CloneDesign.TEAL);paint.setStrokeWidth(CloneDesign.dp(getContext(),4));paint.setStrokeCap(Paint.Cap.ROUND);float arm=size*.13f;for(int x=0;x<2;x++)for(int y=0;y<2;y++){float px=x==0?left:right,py=y==0?top:bottom;c.drawLine(px,py,px+(x==0?arm:-arm),py,paint);c.drawLine(px,py,px,py+(y==0?arm:-arm),paint);}}
    }

}
