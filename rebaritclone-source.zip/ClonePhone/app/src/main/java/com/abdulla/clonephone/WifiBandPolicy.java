package com.abdulla.clonephone;

/** Android-independent rules for selecting and confirming a real hotspot band. */
public final class WifiBandPolicy {
    public static final int AUTO=0, GHZ_24=24, GHZ_5=5, GHZ_6=6;
    private WifiBandPolicy(){}

    public static boolean canSelect(int sdk,boolean wifi,boolean p2p,boolean radio24,
                                    boolean radio5,boolean radio6,int frequency6,int band){
        if(band==AUTO)return wifi||p2p;
        if(!wifi||!p2p||sdk<29)return false;
        if(band==GHZ_24)return radio24;
        if(band==GHZ_5)return radio5;
        return band==GHZ_6&&sdk>=34&&radio6&&valid6GHzFrequency(frequency6);
    }

    public static int[] automaticBands(boolean band6,boolean band5,boolean band24){
        int[] result=new int[(band6?1:0)+(band5?1:0)+(band24?1:0)];int n=0;
        if(band6)result[n++]=GHZ_6;
        if(band5)result[n++]=GHZ_5;
        if(band24)result[n]=GHZ_24;
        return result;
    }

    public static boolean matches(int band,int frequency){
        if(band==AUTO)return true;
        if(frequency<=0)return false;
        if(band==GHZ_24)return frequency>=2400&&frequency<=2500;
        if(band==GHZ_5)return frequency>=4900&&frequency<5925;
        return band==GHZ_6&&valid6GHzFrequency(frequency);
    }

    public static boolean valid6GHzFrequency(int frequency){
        return frequency==5935||(frequency>=5955&&frequency<=7115&&(frequency-5955)%20==0);
    }

    /** Prefer a 6 GHz preferred scanning channel; accept only channels usable as group owner. */
    public static int choose6GHzFrequency(int[] frequencies,int[] modes,int groupOwnerMode){
        if(frequencies==null||modes==null||frequencies.length!=modes.length||groupOwnerMode==0)return 0;
        int preferred=0,other=0;
        for(int i=0;i<frequencies.length;i++){
            int frequency=frequencies[i];
            if((modes[i]&groupOwnerMode)==0||!valid6GHzFrequency(frequency))continue;
            if(other==0||frequency<other)other=frequency;
            if(frequency>=5975&&(frequency-5975)%80==0&&(preferred==0||frequency<preferred))preferred=frequency;
        }
        return preferred>0?preferred:other;
    }
}
