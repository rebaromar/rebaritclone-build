package com.abdulla.clonephone

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.util.LinkedHashSet

/** New phone = controller. Old phone = source that only approves the requested selection. */
object UsbCloneProtocol {
    const val INVENTORY_REQUEST = 41
    const val INVENTORY = 42
    const val SELECTION = 43
    const val PREPARING = 44
    const val ACCEPTED = 45
    const val DECLINED = 46
    const val ERROR = 47
    const val SOURCE_SELECTION_REQUEST = 48
    private const val VERSION = 2
    private const val MAX_CATEGORIES = 32
    private const val MAX_ID = 32

    class Category(
        @JvmField val id: String,
        @JvmField val count: Int,
        @JvmField val bytes: Long
    )

    @JvmStatic fun command(command: Int): ByteArray = byteArrayOf(command.toByte())

    @JvmStatic fun `is`(packet: ByteArray?, command: Int): Boolean =
        packet != null && packet.size == 1 && (packet[0].toInt() and 0xff) == command

    @JvmStatic
    @Throws(IOException::class)
    fun encodeInventory(categories: List<Category>): ByteArray {
        if (categories.size > MAX_CATEGORIES) throw IOException("USB_PROTOCOL")
        val buffer = ByteArrayOutputStream()
        DataOutputStream(buffer).use { out ->
            out.writeByte(INVENTORY)
            out.writeByte(VERSION)
            out.writeInt(categories.size)
            for (c in categories) {
                if (c.id.length > MAX_ID || c.count < 0 || c.bytes < -1) throw IOException("USB_PROTOCOL")
                out.writeUTF(c.id)
                out.writeInt(c.count)
                out.writeLong(c.bytes)
            }
            out.flush()
        }
        return buffer.toByteArray()
    }

    @JvmStatic
    @Throws(IOException::class)
    fun decodeInventory(packet: ByteArray): List<Category> {
        val input = DataInputStream(ByteArrayInputStream(packet))
        if (input.readUnsignedByte() != INVENTORY || input.readUnsignedByte() != VERSION) throw IOException("USB_PROTOCOL")
        val count = input.readInt()
        if (count !in 0..MAX_CATEGORIES) throw IOException("USB_PROTOCOL")
        val result = ArrayList<Category>(count)
        repeat(count) {
            val id = input.readUTF()
            val files = input.readInt()
            val bytes = input.readLong()
            if (id.length > MAX_ID || files < 0 || bytes < -1) throw IOException("USB_PROTOCOL")
            result.add(Category(id, files, bytes))
        }
        if (input.available() != 0) throw IOException("USB_PROTOCOL")
        return result
    }

    @JvmStatic
    @Throws(IOException::class)
    fun encodeSelection(ids: Collection<String>): ByteArray {
        if (ids.size > MAX_CATEGORIES) throw IOException("USB_PROTOCOL")
        val buffer = ByteArrayOutputStream()
        DataOutputStream(buffer).use { out ->
            out.writeByte(SELECTION)
            out.writeByte(VERSION)
            out.writeInt(ids.size)
            for (id in ids) {
                if (id.length > MAX_ID) throw IOException("USB_PROTOCOL")
                out.writeUTF(id)
            }
            out.flush()
        }
        return buffer.toByteArray()
    }

    @JvmStatic
    @Throws(IOException::class)
    fun decodeSelection(packet: ByteArray): LinkedHashSet<String> {
        val input = DataInputStream(ByteArrayInputStream(packet))
        if (input.readUnsignedByte() != SELECTION || input.readUnsignedByte() != VERSION) throw IOException("USB_PROTOCOL")
        val count = input.readInt()
        if (count !in 0..MAX_CATEGORIES) throw IOException("USB_PROTOCOL")
        val result = LinkedHashSet<String>()
        repeat(count) {
            val id = input.readUTF()
            if (id.length > MAX_ID) throw IOException("USB_PROTOCOL")
            result.add(id)
        }
        if (input.available() != 0) throw IOException("USB_PROTOCOL")
        return result
    }
}
