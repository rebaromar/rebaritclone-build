package com.abdulla.clonephone

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom

/** Logical controller/source handshake, independent from physical USB host/accessory role. */
object UsbSession {
    private const val MAGIC = 0x52425533 // RBU3
    private const val VERSION = 3
    private const val CONTROLLER = 1
    private const val SOURCE = 2

    @JvmStatic
    @Throws(Exception::class)
    fun open(input: InputStream, output: OutputStream, receiver: Boolean): SecureChannel {
        val wireIn = DataInputStream(input)
        val wireOut = DataOutputStream(output)
        val mine = ByteArray(24).also { SecureRandom().nextBytes(it) }
        val myRole = if (receiver) CONTROLLER else SOURCE

        wireOut.writeInt(MAGIC)
        wireOut.writeByte(VERSION)
        wireOut.writeByte(myRole)
        wireOut.write(mine)
        wireOut.flush()

        if (wireIn.readInt() != MAGIC) throw IOException("USB_PEER")
        val peerVersion = wireIn.readUnsignedByte()
        val peerRole = wireIn.readUnsignedByte()
        val peer = ByteArray(24)
        wireIn.readFully(peer)
        if (peerVersion != VERSION) throw IOException("USB_VERSION")
        if (peerRole !in CONTROLLER..SOURCE || peerRole == myRole) throw IOException("USB_ROLE")

        val digest = MessageDigest.getInstance("SHA-256")
        if (receiver) {
            digest.update(mine)
            digest.update(peer)
        } else {
            digest.update(peer)
            digest.update(mine)
        }
        digest.update("rebaritclone-usb-v3".toByteArray(StandardCharsets.UTF_8))
        return SecureChannel(input, output, digest.digest(), receiver)
    }
}
