package com.abdulla.clonephone;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import java.nio.ByteBuffer;

/** Compatible with the original nearby bootstrap; transfer keys require receiver approval. */
final class NearbyProtocol {
    static final int PORT = 39842;
    private static final int BLUETOOTH_SERVICE_FAMILY = 0x72626332;

    // Advertise only a public fingerprint of the SSID, never credentials or transfer keys.
    static UUID bluetoothService(String ssid) {
        if (!validSsid(ssid)) throw new IllegalArgumentException("Invalid SSID");
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(ssid.getBytes(StandardCharsets.UTF_8));
            ByteBuffer value = ByteBuffer.allocate(16);
            value.putInt(BLUETOOTH_SERVICE_FAMILY).put(digest, 0, 12);
            ((java.nio.Buffer) value).flip();
            return new UUID(value.getLong(), value.getLong());
        } catch (java.security.NoSuchAlgorithmException error) { throw new AssertionError(error); }
    }

    static boolean isBluetoothService(UUID uuid) {
        return uuid != null && (int)(uuid.getMostSignificantBits() >>> 32) == BLUETOOTH_SERVICE_FAMILY;
    }

    static boolean validBluetoothOffer(UUID discoveredService, String ssid, String password) {
        return isBluetoothService(discoveredService) && validSsid(ssid) && validPassword(password)
                && bluetoothService(ssid).equals(discoveredService);
    }
    interface Approval { String approve(String name, int bands) throws Exception; }
    interface Alive { boolean current(); }

    static boolean serve(DataInputStream in, DataOutputStream out, Approval approval,
            Alive alive) throws Exception {
        String protocol = in.readUTF();
        boolean modern = "REBAR-NEARBY-2".equals(protocol);
        if (!modern && !"REBAR-NEARBY-1".equals(protocol)) throw new IOException("PROTOCOL");
        String name = in.readUTF();
        int bands = modern ? in.readInt() & 7 : 1;
        if (name.length() > 100 || (bands & 1) == 0) throw new IOException("PEER");
        if (!alive.current()) return false;
        String payload = approval.approve(name, bands);
        if (!alive.current()) return false;
        if (payload == null) payload = "";
        if (payload.length() > 700) throw new IOException("PAIR");
        out.writeUTF(payload);
        out.flush();
        if (!modern || payload.isEmpty()) return false;
        if (!"READY".equals(in.readUTF()) || !alive.current()) throw new IOException("PAIR");
        out.writeUTF("CONNECT");
        out.flush();
        return true;
    }

    static String request(DataInputStream in, DataOutputStream out, String name, int bands)
            throws IOException {
        out.writeUTF("REBAR-NEARBY-2");
        out.writeUTF(name == null ? "Android" : name.substring(0, Math.min(100, name.length())));
        out.writeInt(bands & 7);
        out.flush();
        String payload = in.readUTF();
        if (payload.isEmpty()) throw new IOException("DECLINED");
        if (payload.length() > 700) throw new IOException("PAIR");
        return payload;
    }

    // Call only after validating the pairing payload.
    static void confirm(DataInputStream in, DataOutputStream out) throws IOException {
        out.writeUTF("READY");
        out.flush();
        if (!"CONNECT".equals(in.readUTF())) throw new IOException("PAIR");
    }

    static boolean hotspotName(String ssid) {
        return ssid != null && (ssid.startsWith("DIRECT-rb-REBARIT-")
                || ssid.matches("DIRECT-rb-[0-9a-fA-F]{6}")
                || ssid.startsWith("AndroidShare_") || ssid.startsWith("AndroidShare"));
    }

    static boolean validPassword(String value) {
        if (value == null || value.length() < 8 || value.length() > 63) return false;
        // These hotspots use a WPA2 passphrase; Android expects printable ASCII.
        for (int i = 0; i < value.length(); i++) {
            if (value.charAt(i) < 32 || value.charAt(i) > 126) return false;
        }
        return true;
    }

    static boolean validSsid(String ssid) {
        return ssid != null && !ssid.isEmpty()
                && ssid.getBytes(StandardCharsets.UTF_8).length <= 32
                && ssid.indexOf('\u0000') < 0;
    }
}
