package com.abdulla.clonephone;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

/** Logical sender/receiver handshake independent from the physical USB host/accessory role. */
public final class UsbSession {
    private static final int MAGIC = 0x52425532; // RBU2
    private static final int VERSION = 2;
    private static final int RECEIVER = 1;
    private static final int SENDER = 2;

    public static SecureChannel open(InputStream in, OutputStream out, boolean receiver) throws Exception {
        DataInputStream wireIn = new DataInputStream(in);
        DataOutputStream wireOut = new DataOutputStream(out);
        byte[] mine = new byte[16];
        new SecureRandom().nextBytes(mine);
        int myRole = receiver ? RECEIVER : SENDER;

        wireOut.writeInt(MAGIC);
        wireOut.writeByte(VERSION);
        wireOut.writeByte(myRole);
        wireOut.write(mine);
        wireOut.flush();

        if (wireIn.readInt() != MAGIC) throw new IOException("USB_PEER");
        int peerVersion = wireIn.readUnsignedByte();
        int peerRole = wireIn.readUnsignedByte();
        byte[] peer = new byte[16];
        wireIn.readFully(peer);
        if (peerVersion != VERSION || peerRole == myRole || (peerRole != RECEIVER && peerRole != SENDER)) throw new IOException("USB_ROLE");

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        if (receiver) { digest.update(mine); digest.update(peer); }
        else { digest.update(peer); digest.update(mine); }
        digest.update("rebaritclone-usb-v2".getBytes(StandardCharsets.UTF_8));
        byte[] key = digest.digest();
        return new SecureChannel(in, out, key, receiver);
    }
}
