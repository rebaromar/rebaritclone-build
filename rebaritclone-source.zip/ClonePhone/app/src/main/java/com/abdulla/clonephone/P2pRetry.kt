package com.abdulla.clonephone

/** Retry transient Android Wi-Fi Direct BUSY (2); do not retry permanent errors. */
object P2pRetry {
    @JvmStatic
    fun delay(reason: Int, attempt: Int): Long {
        if (reason != 2 || attempt < 0 || attempt >= 3) return -1L
        return 750L shl attempt
    }
}
