package com.abdulla.clonephone;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** Private, uncompressed transfer container for an unmodified base APK and its splits. */
public final class AppBundle {
    public static final String MIME="application/x-rebaritclone-app";
    public static final long MAX_BYTES=16L*1024*1024*1024;
    public static final int MAX_PARTS=256;
    private static final int MAGIC=0x52424150; // RBAP
    private static final int VERSION=1;
    public interface Sink {void part(String name,InputStream input)throws Exception;}

    /** Exact container size, computable without reading APK contents. */
    public static long encodedSize(List<File> apks)throws IOException{
        if(apks==null||apks.isEmpty()||apks.size()>MAX_PARTS)throw new IOException("Invalid APK count");
        long size=7,payload=0;
        for(int i=0;i<apks.size();i++){
            File apk=apks.get(i);if(apk==null||!apk.isFile()||!apk.canRead())throw new IOException("APK unavailable");
            long length=apk.length();if(length<=0||length>MAX_BYTES-payload)throw new IOException("App too large");payload+=length;
            byte[] name=partName(i).getBytes(StandardCharsets.UTF_8);if(name.length>255)throw new IOException("Invalid APK name");
            long addition=2L+name.length+8L+length;if(addition>Long.MAX_VALUE-size)throw new IOException("App too large");size+=addition;
        }
        return size;
    }

    /** Writes the new streaming format directly to any output; no temporary bundle is needed. */
    public static void writeTo(List<File> apks,OutputStream destination)throws Exception{
        encodedSize(apks);
        DataOutputStream out=new DataOutputStream(new BufferedOutputStream(destination,1048576));
        out.writeInt(MAGIC);out.writeByte(VERSION);out.writeShort(apks.size());byte[] data=new byte[1048576];long total=0;
        for(int i=0;i<apks.size();i++){
            File apk=apks.get(i);long expected=apk.length();byte[] name=partName(i).getBytes(StandardCharsets.UTF_8);
            out.writeShort(name.length);out.write(name);out.writeLong(expected);
            try(InputStream in=new BufferedInputStream(new FileInputStream(apk),1048576)){
                long copied=0;int n;while(copied<expected){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();n=in.read(data,0,(int)Math.min(data.length,expected-copied));if(n<0)throw new IOException("APK changed during export");if(n==0)continue;copied+=n;total+=n;if(total>MAX_BYTES)throw new IOException("App too large");out.write(data,0,n);}
                if(in.read()!=-1)throw new IOException("APK changed during export");
            }
        }
        out.flush();
    }

    /** Returns a streaming archive with exact length, so selection and resume need no staging copy. */
    public static InputStream open(List<File> apks)throws IOException{
        long expected=encodedSize(apks);ByteArrayOutputStream header=new ByteArrayOutputStream();DataOutputStream data=new DataOutputStream(header);
        data.writeInt(MAGIC);data.writeByte(VERSION);data.writeShort(apks.size());
        Vector<InputStream> inputs=new Vector<>();inputs.add(new ByteArrayInputStream(header.toByteArray()));
        try{
            for(int i=0;i<apks.size();i++){
                File apk=apks.get(i);long length=apk.length();byte[] name=partName(i).getBytes(StandardCharsets.UTF_8);
                ByteArrayOutputStream descriptor=new ByteArrayOutputStream();DataOutputStream entry=new DataOutputStream(descriptor);
                entry.writeShort(name.length);entry.write(name);entry.writeLong(length);entry.flush();inputs.add(new ByteArrayInputStream(descriptor.toByteArray()));
                if(apk.length()!=length)throw new IOException("APK changed during export");
                inputs.add(new ExactLengthInputStream(new BufferedInputStream(new FileInputStream(apk),1048576),length));
            }
            InputStream sequence=new SequenceInputStream(inputs.elements());
            return new FilterInputStream(sequence){long read;boolean verified;
                private void count(int n)throws IOException{if(n>0){read+=n;if(read>expected)throw new IOException("APK changed during export");}else if(n<0&&!verified){verified=true;if(read!=expected)throw new IOException("APK changed during export");}}
                @Override public int read()throws IOException{int n=super.read();count(n<0?-1:1);return n;}
                @Override public int read(byte[] b,int off,int len)throws IOException{int n=super.read(b,off,len);count(n);return n;}
            };
        }catch(Exception error){for(InputStream in:inputs)try{in.close();}catch(Exception ignored){}if(error instanceof IOException)throw (IOException)error;throw new IOException("Cannot open app bundle",error);}
    }

    private static String partName(int index){return index==0?"base.apk":"split-"+index+".apk";}
    private static final class ExactLengthInputStream extends FilterInputStream{
        private final long expected;private long read;private boolean verified;
        ExactLengthInputStream(InputStream in,long expected){super(in);this.expected=expected;}
        private int check(int value)throws IOException{if(value<0){if(!verified){verified=true;if(read!=expected)throw new IOException("APK changed during export");}}else if(++read>expected)throw new IOException("APK changed during export");return value;}
        @Override public int read()throws IOException{return check(super.read());}
        @Override public int read(byte[] b,int off,int len)throws IOException{if(len==0)return 0;if(read==expected){int extra=super.read();if(extra!=-1)throw new IOException("APK changed during export");verified=true;return -1;}int n=super.read(b,off,(int)Math.min(len,expected-read));if(n<0){check(-1);return -1;}read+=n;if(read>expected)throw new IOException("APK changed during export");return n;}
        @Override public void close()throws IOException{super.close();}
    }

    public static void write(List<File> apks,File destination)throws Exception{
        boolean success=false;try(OutputStream out=new FileOutputStream(destination)){writeTo(apks,out);success=true;}finally{if(!success)destination.delete();}
    }
    public static void read(InputStream source,Sink sink)throws Exception{
        PushbackInputStream probe=new PushbackInputStream(new BufferedInputStream(source,1048576),4);byte[] signature=new byte[4];int got=0;while(got<signature.length){int n=probe.read(signature,got,signature.length-got);if(n<0)break;got+=n;}
        if(got==4){int magic=((signature[0]&255)<<24)|((signature[1]&255)<<16)|((signature[2]&255)<<8)|(signature[3]&255);if(magic==MAGIC){readRaw(probe,sink);return;}probe.unread(signature);}
        else if(got>0)probe.unread(signature,0,got);
        readZip(probe,sink);
    }
    private static void readRaw(InputStream source,Sink sink)throws Exception{
        DataInputStream input=new DataInputStream(source);if(input.readUnsignedByte()!=VERSION)throw new IOException("Unsupported app bundle");int count=input.readUnsignedShort();
        if(count<1||count>MAX_PARTS)throw new IOException("Invalid APK count");Set<String> names=new HashSet<>();long total=0;
        for(int i=0;i<count;i++){
            int nameLength=input.readUnsignedShort();if(nameLength<1||nameLength>255)throw new IOException("Invalid APK name");byte[] rawName=new byte[nameLength];input.readFully(rawName);String name=new String(rawName,StandardCharsets.UTF_8);long length=input.readLong();
            if(!name.matches("base\\.apk|split-[0-9]{1,3}\\.apk")||!names.add(name)||length<=0||length>MAX_BYTES-total)throw new IOException("Invalid APK part");total+=length;
            InputStream bounded=new FilterInputStream(input){long remaining=length;
                @Override public int read()throws IOException{byte[] one=new byte[1];return read(one,0,1)==-1?-1:one[0]&255;}
                @Override public int read(byte[] b,int off,int len)throws IOException{if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();if(remaining==0)return -1;int n=in.read(b,off,(int)Math.min(len,remaining));if(n<0)throw new EOFException("Incomplete APK part");remaining-=n;return n;}
                @Override public void close(){}
            };
            sink.part(name,bounded);if(bounded.read()!=-1)throw new IOException("Incomplete APK staging");
        }
        if(!names.contains("base.apk")||input.read()!=-1)throw new IOException("Invalid app bundle ending");
    }
    private static void readZip(InputStream source,Sink sink)throws Exception{
        Set<String> names=new HashSet<>();final long[] total={0};
        try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(source,1048576))){ZipEntry entry;
            while((entry=zip.getNextEntry())!=null){String name=entry.getName();
                if(entry.isDirectory()||!name.matches("base\\.apk|split-[0-9]{1,3}\\.apk")||!names.add(name)||names.size()>MAX_PARTS)throw new IOException("Invalid app bundle");
                InputStream bounded=new FilterInputStream(zip){
                    public int read()throws IOException{byte[] b=new byte[1];return read(b,0,1)==-1?-1:b[0]&255;}
                    public int read(byte[] b,int o,int l)throws IOException{if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();int n=in.read(b,o,l);if(n>0){total[0]+=n;if(total[0]>MAX_BYTES)throw new IOException("App too large");}return n;}
                    public void close(){} // Session sink must not close the outer archive.
                };
                sink.part(name,bounded);if(bounded.read()!=-1)throw new IOException("Incomplete APK staging");zip.closeEntry();
            }
        }
        if(!names.contains("base.apk"))throw new IOException("Missing base APK");
    }
}
