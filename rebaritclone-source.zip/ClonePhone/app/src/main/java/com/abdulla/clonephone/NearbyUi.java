package com.abdulla.clonephone;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class NearbyUi {
    static String words(String ckb, String en, String ar) {
        String language = UiText.language();
        return "en".equals(language) ? en : "ar".equals(language) ? ar : ckb;
    }

    static String receiverSubtitle() {
        return words("لە مۆبایلی کۆن «پەیوەستبوونی خۆکار» هەڵبژێرە، یان QR سکان بکە.",
                "Choose Automatic connection on the old phone, or scan this QR.",
                "اختر الاتصال التلقائي على الهاتف القديم، أو امسح رمز QR هذا.");
    }

    static String sourceSubtitle() {
        return words("بە خۆکار پەیوەست بە، یان QR سکان بکە.",
                "Connect automatically, or scan the QR.",
                "اتصل تلقائيًا، أو امسح رمز QR.");
    }

    private static int dp(Activity activity, int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private static TextView text(Activity activity, String value, boolean strong) {
        TextView view = new TextView(activity);
        view.setText(value);
        view.setTextColor(Color.rgb(30, 44, 65));
        view.setTextSize(strong ? 17 : 14);
        view.setPadding(0, dp(activity, 5), 0, dp(activity, 5));
        if (strong) view.setTypeface(null, Typeface.BOLD);
        return view;
    }

    static void receiverInfo(Activity activity, LinearLayout body, String ssid, String password) {
        if (ssid == null || ssid.isEmpty()) return;
        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(activity, 18), dp(activity, 14), dp(activity, 18), dp(activity, 14));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(234, 245, 255));
        background.setCornerRadius(dp(activity, 18));
        card.setBackground(background);
        card.addView(text(activity, words("هۆتسپۆت ئامادەیە", "Hotspot ready", "نقطة الاتصال جاهزة"), true));
        TextView name = text(activity, words("ناوی هۆتسپۆت: ", "Hotspot name: ", "اسم نقطة الاتصال: ") + ssid, false);
        name.setTextIsSelectable(true);
        card.addView(name);
        card.addView(text(activity, words("بۆ پەیوەندی خۆکار، Wi-Fi و بلوتووس چالاک بکە و داواکاری پەیوەندی پەسەند بکە. نووسینی وشەی نهێنی پێویست نییە.",
                "For automatic connection, enable Wi-Fi and Bluetooth and approve the connection request. No Wi-Fi password needs to be typed.",
                "للاتصال التلقائي، فعّل Wi-Fi وBluetooth ووافق على طلب الاتصال. لا حاجة لكتابة كلمة مرور Wi-Fi."), false));
        Button visible = new Button(activity);
        visible.setAllCaps(false);
        visible.setText(words("دووبارە مۆبایلەکە دیار بکە", "Make this phone visible again", "اجعل هذا الهاتف مرئيًا مجددًا"));
        visible.setOnClickListener(v -> NearbyBluetooth.visibleFor(activity));
        card.addView(visible);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(activity, 18);
        body.addView(card, params);
    }

    static void searchActions(Activity activity, LinearLayout body, final NearbyClone nearby) {
        body.addView(text(activity, words("Wi-Fi و بلوتووس لە هەردوو مۆبایلەکە چالاک بکە. لە مۆبایلی نوێ دیارکردنی مۆبایلەکە پەسەند بکە، پاشان لێرە هەڵیبژێرە.",
                "Enable Wi-Fi and Bluetooth on both phones. Allow the new phone to be visible, then select it here.",
                "فعّل Wi-Fi وBluetooth على الهاتفين. اسمح بظهور الهاتف الجديد، ثم اختره هنا."), false));
    }
}
