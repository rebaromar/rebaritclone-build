package com.abdulla.clonephone;

/** Additional bytes needed for direct destination writes, using 64-bit file sizes. */
public final class TransferSpace {
    private TransferSpace() { }

    public static long remaining(long[] sizes, long[] retained, boolean[] done) {
        if (sizes == null || retained == null || done == null || sizes.length != retained.length || sizes.length != done.length)
            throw new IllegalArgumentException("Mismatched transfer sizes");
        long required = 0L;
        for (int index = 0; index < sizes.length; index++) {
            long additional = remaining(sizes[index], retained[index], done[index]);
            if (additional > Long.MAX_VALUE - required) return Long.MAX_VALUE;
            required += additional;
        }
        return required;
    }

    public static long remaining(long size, long retained, boolean done) {
        // Unknown sizes cannot be reserved in advance. The destination enforces capacity.
        if (done || size <= 0L) return 0L;
        return size - Math.min(size, Math.max(0L, retained));
    }

    public static boolean fits(long required, long available) {
        if (required < 0L) throw new IllegalArgumentException("Invalid required space");
        return available < 0L || required <= available;
    }
}
