package com.abdulla.clonephone;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Secure RFCOMM bootstrap: Android authenticates the link, the receiver approves credentials. */
final class NearbyBluetooth {
    private static final int PERMISSION = 0x7263;
    private static final int ENABLE = 0x7264;
    private static final int VISIBLE = 0x7265;
    private static WeakReference<NearbyBluetooth> permissionOwner = new WeakReference<>(null);
    private static WeakReference<NearbyBluetooth> activityOwner = new WeakReference<>(null);
    private static WeakReference<NearbyBluetooth> hostOwner = new WeakReference<>(null);
    private final Activity activity;
    private final BluetoothAdapter adapter;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, Peer> peers = new HashMap<>();
    private BroadcastReceiver receiver;
    private Discovery discovery;
    private NearbyClone.Host host;
    private Runnable bootstrapped;
    private String hostSsid;
    private volatile BluetoothServerSocket server;
    private volatile BluetoothSocket active;
    private Thread hostThread;
    private Thread pairThread;
    private volatile int generation;
    private boolean ownsDiscovery;
    private boolean awaitingActivity;
    private Runnable afterPermission;
    private boolean discovering;
    private boolean hosting;

    interface Discovery { void device(String name, String address, UUID service); }
    interface Connection { void ready(Pairing peer); void failed(); }
    private static final class Peer {
        final BluetoothDevice device;
        final UUID service;
        Peer(BluetoothDevice device, UUID service) { this.device = device; this.service = service; }
    }

    NearbyBluetooth(Context context) {
        activity = context instanceof Activity ? (Activity) context : null;
        BluetoothAdapter available = null;
        try {
            BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            if (manager != null) available = manager.getAdapter();
        } catch (Exception ignored) { }
        adapter = available;
    }

    private boolean usable() {
        return activity != null && !activity.isFinishing() && !activity.isDestroyed() && adapter != null;
    }
    private boolean current(int token) { return token == generation && usable(); }
    private boolean granted(String permission) {
        return activity.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void withPermissions(boolean hostMode, Runnable next) {
        if (!usable()) return;
        String[] needed = Build.VERSION.SDK_INT >= 31
                ? new String[]{Manifest.permission.BLUETOOTH_CONNECT, hostMode ? Manifest.permission.BLUETOOTH_ADVERTISE : Manifest.permission.BLUETOOTH_SCAN}
                : hostMode ? new String[0] : new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
        boolean ready = true;
        for (String permission : needed) ready &= granted(permission);
        if (ready) { next.run(); return; }
        afterPermission = next;
        permissionOwner = new WeakReference<>(this);
        activity.requestPermissions(needed, PERMISSION);
    }

    static boolean permissionResult(Activity activity, int code) {
        if (code != PERMISSION) return false;
        NearbyBluetooth owner = permissionOwner.get();
        permissionOwner.clear();
        if (owner == null || owner.activity != activity || !owner.usable()) return true;
        Runnable next = owner.afterPermission;
        owner.afterPermission = null;
        boolean allowed = Build.VERSION.SDK_INT >= 31
                ? owner.granted(Manifest.permission.BLUETOOTH_CONNECT)
                    && owner.granted(owner.hosting ? Manifest.permission.BLUETOOTH_ADVERTISE : Manifest.permission.BLUETOOTH_SCAN)
                : owner.hosting || owner.granted(Manifest.permission.ACCESS_FINE_LOCATION);
        if (allowed && next != null) next.run();
        return true;
    }

    static boolean activityResult(Activity activity, int request, int result) {
        if (request != ENABLE && request != VISIBLE) return false;
        NearbyBluetooth owner = activityOwner.get();
        activityOwner.clear();
        if (owner == null || owner.activity != activity || !owner.usable()) return true;
        owner.awaitingActivity = false;
        if (request == VISIBLE && result > 0 && owner.hosting) owner.openServer();
        else if (request == ENABLE && result == Activity.RESULT_OK && owner.discovering) owner.beginDiscovery();
        return true;
    }

    private void register() {
        if (receiver != null || !usable()) return;
        receiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                try {
                    String action = intent.getAction();
                    if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        inspect(device);
                    } else if (BluetoothDevice.ACTION_UUID.equals(action)) {
                        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        android.os.Parcelable[] values = intent.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID);
                        if (device != null && values != null) for (android.os.Parcelable value : values) {
                            if (value instanceof ParcelUuid) found(device, ((ParcelUuid) value).getUuid());
                        }
                    } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                        ownsDiscovery = false;
                        if (discovering) {
                            int token = generation;
                            main.postDelayed(() -> { if (current(token) && discovering) beginDiscovery(); }, 4000);
                        }
                    } else if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)
                            && intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1) == BluetoothAdapter.STATE_ON
                            && !awaitingActivity) {
                        if (hosting) openServer();
                        else if (discovering) beginDiscovery();
                    }
                } catch (SecurityException ignored) { }
            }
        };
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothDevice.ACTION_UUID);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) activity.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED);
        else activity.registerReceiver(receiver, filter);
    }

    void advertise(NearbyClone.Host host, String ssid, Runnable bootstrapped) {
        if (!usable() || !NearbyProtocol.validSsid(ssid)) return;
        boolean changed = !ssid.equals(hostSsid);
        this.host = host;
        this.hostSsid = ssid;
        this.bootstrapped = bootstrapped;
        hosting = true;
        hostOwner = new WeakReference<>(this);
        discovering = false;
        if (changed && server != null) {
            if (hostThread != null) { hostThread.interrupt(); hostThread = null; }
            try { server.close(); } catch (IOException ignored) { }
            server = null;
            try { if (active != null) active.close(); } catch (IOException ignored) { }
        }
        withPermissions(true, () -> {
            register();
            try {
                if (adapter.isEnabled()) openServer();
                if (!awaitingActivity && adapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE)
                    makeVisible();
            } catch (SecurityException ignored) { }
        });
    }

    void makeVisible() {
        if (!usable() || !hosting) return;
        withPermissions(true, () -> {
            try {
                activityOwner = new WeakReference<>(this);
                awaitingActivity = true;
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                        .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
                activity.startActivityForResult(intent, VISIBLE);
            } catch (Exception ignored) { awaitingActivity = false; }
        });
    }

    static void visibleFor(Activity activity) {
        NearbyBluetooth owner = hostOwner.get();
        if (owner != null && owner.activity == activity) owner.makeVisible();
    }

    private void openServer() {
        if (!usable() || !hosting || server != null || hostSsid == null) return;
        final int token = generation;
        try {
            if (!adapter.isEnabled()) return;
            // Secure RFCOMM uses Android bonding, authentication, and link encryption.
            BluetoothServerSocket hosted = adapter.listenUsingRfcommWithServiceRecord("REBARIT CLONE", NearbyProtocol.bluetoothService(hostSsid));
            server = hosted;
            hostThread = new Thread(() -> {
                while (current(token) && hosting && server == hosted) {
                    BluetoothSocket client = null;
                    try {
                        client = hosted.accept();
                        active = client;
                        BluetoothSocket accepted = client;
                        Runnable timeout = () -> {
                            if (active == accepted) try { accepted.close(); } catch (IOException ignored) { }
                        };
                        main.postDelayed(timeout, 75000);
                        try {
                            boolean approved = NearbyProtocol.serve(new DataInputStream(client.getInputStream()),
                                    new DataOutputStream(client.getOutputStream()), host::approve,
                                    () -> current(token) && server == hosted);
                            if (approved) main.post(() -> { if (current(token)) bootstrapped.run(); });
                        } finally { main.removeCallbacks(timeout); }
                    } catch (Exception ignored) {
                        if (!current(token) || server != hosted) break;
                    } finally {
                        if (active == client) active = null;
                        if (client != null) try { client.close(); } catch (IOException ignored) { }
                    }
                }
            }, "rebar-bluetooth-host");
            hostThread.start();
        } catch (Exception ignored) { }
    }

    void discover(Discovery listener) {
        if (!usable()) return;
        discovery = listener;
        discovering = true;
        hosting = false;
        withPermissions(false, () -> {
            register();
            try {
                if (adapter.isEnabled()) beginDiscovery();
                else if (!awaitingActivity) {
                    activityOwner = new WeakReference<>(this);
                    awaitingActivity = true;
                    activity.startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), ENABLE);
                }
            } catch (Exception ignored) { awaitingActivity = false; }
        });
    }

    private void beginDiscovery() {
        if (!usable() || !discovering || awaitingActivity) return;
        try {
            if (!adapter.isEnabled()) return;
            for (BluetoothDevice device : adapter.getBondedDevices()) inspect(device);
            if (!ownsDiscovery) ownsDiscovery = adapter.startDiscovery();
        } catch (Exception ignored) { }
    }

    private void inspect(BluetoothDevice device) {
        if (device == null || !discovering) return;
        try {
            ParcelUuid[] cached = device.getUuids();
            if (cached != null) for (ParcelUuid value : cached) found(device, value.getUuid());
            device.fetchUuidsWithSdp();
        } catch (Exception ignored) { }
    }

    private void found(BluetoothDevice device, UUID uuid) {
        if (!discovering || discovery == null || !NearbyProtocol.isBluetoothService(uuid)) return;
        try {
            String address = device.getAddress();
            Peer previous = peers.put(address, new Peer(device, uuid));
            if (previous == null || !previous.service.equals(uuid)) {
                String name = device.getName();
                discovery.device(name == null ? "REBARIT CLONE" : name, "bt:" + address, uuid);
            }
        } catch (SecurityException ignored) { }
    }

    String addressFor(String ssid) {
        if (!NearbyProtocol.validSsid(ssid)) return null;
        UUID expected = NearbyProtocol.bluetoothService(ssid);
        for (Map.Entry<String, Peer> entry : peers.entrySet()) {
            if (expected.equals(entry.getValue().service)) return "bt:" + entry.getKey();
        }
        return null;
    }

    void stopDiscovery() {
        discovering = false;
        discovery = null;
        main.removeCallbacksAndMessages(null);
        if (ownsDiscovery && adapter != null) {
            try { adapter.cancelDiscovery(); } catch (SecurityException ignored) { }
            ownsDiscovery = false;
        }
    }

    void connect(String address, int bands, Connection listener) {
        Peer peer = address != null && address.startsWith("bt:") ? peers.get(address.substring(3)) : null;
        if (peer == null || !usable()) { listener.failed(); return; }
        stopDiscovery();
        final int token = ++generation;
        final boolean[] finished = {false};
        Runnable failed = () -> {
            if (current(token) && !finished[0]) { finished[0] = true; listener.failed(); }
        };
        pairThread = new Thread(() -> {
            BluetoothSocket socket = null;
            Runnable timeout = null;
            try {
                socket = peer.device.createRfcommSocketToServiceRecord(peer.service);
                active = socket;
                BluetoothSocket connecting = socket;
                timeout = () -> {
                    if (!current(token) || finished[0]) return;
                    try { connecting.close(); } catch (IOException ignored) { }
                    failed.run();
                };
                main.postDelayed(timeout, 180000);
                socket.connect();
                if (!current(token)) return;
                DataInputStream in = new DataInputStream(socket.getInputStream());
                DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                String payload = NearbyProtocol.request(in, out, Build.MODEL, bands);
                Pairing approved = Pairing.parse(payload);
                if (!NearbyProtocol.validBluetoothOffer(peer.service, approved.ssid, approved.password))
                    throw new IOException("PAIR");
                if (!current(token)) return;
                NearbyProtocol.confirm(in, out);
                main.post(() -> {
                    if (current(token) && !finished[0]) { finished[0] = true; listener.ready(approved); }
                });
            } catch (Exception ignored) { main.post(failed); }
            finally {
                if (timeout != null) main.removeCallbacks(timeout);
                if (active == socket) active = null;
                if (socket != null) try { socket.close(); } catch (IOException ignored) { }
            }
        }, "rebar-bluetooth-pair");
        pairThread.start();
    }

    void close() {
        ++generation;
        stopDiscovery();
        hosting = false;
        host = null;
        afterPermission = null;
        awaitingActivity = false;
        if (permissionOwner.get() == this) permissionOwner.clear();
        if (activityOwner.get() == this) activityOwner.clear();
        if (hostOwner.get() == this) hostOwner.clear();
        if (hostThread != null) { hostThread.interrupt(); hostThread = null; }
        if (pairThread != null) { pairThread.interrupt(); pairThread = null; }
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        server = null;
        try { if (active != null) active.close(); } catch (IOException ignored) { }
        active = null;
        if (receiver != null && activity != null) {
            try { activity.unregisterReceiver(receiver); } catch (Exception ignored) { }
            receiver = null;
        }
        peers.clear();
    }
}
