package com.abdulla.clonephone;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** Direct shared-storage browsing and recursive folder selection, without changing files. */
final class StorageFiles {
    private StorageFiles(){}

    static List<File> list(File root,File directory,PickerFiles.Check check)throws IOException{
        check.run();String base=root.getCanonicalPath(),prefix=prefix(base);allowed(directory,base,prefix);
        if(!directory.isDirectory()||!directory.canRead())throw new IOException("Folder is not readable: "+directory.getName());
        File[] children=children(directory);List<File> result=new ArrayList<>();Set<String> seen=new HashSet<>();
        for(File child:children){
            check.run();String canonical=child.getCanonicalPath();
            if(!inside(canonical,base,prefix)||restricted(canonical,base,prefix)||marker(child,canonical)||!child.canRead()||!seen.add(canonical))continue;
            if(child.isDirectory()||child.isFile())result.add(child);
        }
        result.sort((a,b)->{boolean ad=a.isDirectory(),bd=b.isDirectory();return ad!=bd?(ad?-1:1):a.getName().compareToIgnoreCase(b.getName());});
        check.run();return result;
    }

    static List<File> collect(File root,Collection<File> selections,PickerFiles.Check check)throws IOException{
        return collect(root,selections,check,batch->{});
    }

    /** Parent directory for transfer metadata, relative to the canonical shared-storage root. */
    static String relativeDirectory(File root,File file)throws IOException{
        String base=root.getCanonicalPath(),prefix=prefix(base),path=allowed(file,base,prefix);
        if(!file.isFile())throw new IOException("Transfer source is not a file");
        String parent=new File(path).getParent();
        if(parent==null||parent.equals(base))return "";
        if(!parent.startsWith(prefix))throw new IOException("Transfer source is outside shared storage");
        return parent.substring(prefix.length()).replace(File.separatorChar,'/')+"/";
    }

    // Batches are progress only: callers commit a folder selection after this method returns.
    static List<File> collect(File root,Collection<File> selections,PickerFiles.Check check,PickerFiles.Batch batch)throws IOException{
        check.run();String base=root.getCanonicalPath(),prefix=prefix(base);
        if(!root.isDirectory()||!root.canRead())throw new IOException("Storage is not readable");
        ArrayDeque<File> pending=new ArrayDeque<>();Set<String> directories=new HashSet<>(),files=new HashSet<>();
        List<File> result=new ArrayList<>(),buffer=new ArrayList<>();long lastBatch=System.nanoTime();boolean first=true;
        for(File selected:selections){check.run();allowed(selected,base,prefix);if(!selected.canRead())throw new IOException("Selection is not readable: "+selected.getName());pending.addLast(selected);}
        while(!pending.isEmpty()){
            check.run();File item=pending.removeFirst();String canonical=item.getCanonicalPath();
            if(!inside(canonical,base,prefix)||restricted(canonical,base,prefix)||marker(item,canonical))continue;
            if(item.isDirectory()){
                if(!directories.add(canonical))continue;if(!item.canRead())throw new IOException("Folder is not readable: "+item.getName());
                for(File child:children(item)){check.run();pending.addLast(child);}
            }else if(item.isFile()){
                if(!item.canRead())throw new IOException("File is not readable: "+item.getName());if(!files.add(canonical))continue;
                // Use one canonical file URI even when selected through overlapping folders or aliases.
                File file=new File(canonical);result.add(file);buffer.add(file);
                if(first||buffer.size()>=24||System.nanoTime()-lastBatch>=120_000_000L){emit(buffer,batch,check);first=false;lastBatch=System.nanoTime();}
            }else throw new IOException("Selection no longer exists: "+item.getName());
        }
        if(!buffer.isEmpty())emit(buffer,batch,check);check.run();result.sort((a,b)->a.getAbsolutePath().compareToIgnoreCase(b.getAbsolutePath()));check.run();return result;
    }

    private static void emit(List<File> buffer,PickerFiles.Batch batch,PickerFiles.Check check)throws IOException{
        check.run();List<File> ready=Collections.unmodifiableList(new ArrayList<>(buffer));buffer.clear();batch.found(ready);check.run();
    }
    private static File[] children(File directory)throws IOException{
        try{File[] children=directory.listFiles();if(children==null)throw new IOException("Folder is not readable: "+directory.getName());return children;}
        catch(SecurityException denied){throw new IOException("Folder access was denied: "+directory.getName(),denied);}
    }
    private static String allowed(File file,String base,String prefix)throws IOException{
        String canonical=file.getCanonicalPath();if(!inside(canonical,base,prefix)||restricted(canonical,base,prefix))throw new IOException("Folder is outside accessible shared storage");return canonical;
    }
    private static boolean marker(File file,String canonical){return file.getName().equals(".nomedia")||new File(canonical).getName().equals(".nomedia");}
    private static String prefix(String base){return base.endsWith(File.separator)?base:base+File.separator;}
    private static boolean inside(String path,String base,String prefix){return path.equals(base)||path.startsWith(prefix);}
    private static boolean restricted(String path,String base,String prefix){
        if(path.equals(base))return false;String relative=path.substring(prefix.length()).replace(File.separatorChar,'/');
        return relative.equals("Android/data")||relative.startsWith("Android/data/")||relative.equals("Android/obb")||relative.startsWith("Android/obb/");
    }
}
