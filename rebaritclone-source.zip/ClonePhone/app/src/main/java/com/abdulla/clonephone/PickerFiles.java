package com.abdulla.clonephone;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** File-manager classification and cancellable shared-storage discovery. */
final class PickerFiles {
    interface Check { void run() throws IOException; }
    interface Batch { void found(List<File> files) throws IOException; }
    static String extension(String name){int dot=name.lastIndexOf('.');return dot<0?"":name.substring(dot+1).toLowerCase(Locale.ROOT);}
    static boolean packageFile(String name){switch(extension(name)){case "apk":case "apks":case "xapk":case "apkm":case "rbapp":return true;default:return false;}}
    static boolean matches(String name,long size,String path,String filter){
        String ext=extension(name),where=path.replace('\\','/').toLowerCase(Locale.ROOT);
        switch(filter){
            case "PDF":return ext.equals("pdf");
            case "EXCEL":return Arrays.asList("xls","xlsx","xlsm","csv","ods").contains(ext);
            case "PPT":return Arrays.asList("ppt","pptx","pps","ppsx","odp").contains(ext);
            case "TXT":return Arrays.asList("txt","log","md","json","xml").contains(ext);
            case "DOC":return Arrays.asList("doc","docx","docm","rtf","odt").contains(ext);
            case "WPS":return Arrays.asList("wps","et","dps").contains(ext);
            case "Zip":return Arrays.asList("zip","rar","iso","7z","tar","gz","bz2").contains(ext);
            case "Large Files":return size>50L*1024*1024;
            case "Status":return where.contains("/whatsapp/media/.statuses/");
            case "Media":return where.contains("/whatsapp/media/")&&!where.contains("/.statuses/");
            default:return true;
        }
    }
    static List<File> scan(File root,Check check)throws IOException{
        List<File> found=new ArrayList<>();ArrayDeque<File> pending=new ArrayDeque<>();Set<String> visited=new HashSet<>();
        String base=root.getCanonicalPath();pending.add(root);
        while(!pending.isEmpty()){
            check.run();File directory=pending.removeFirst();String canonical=directory.getCanonicalPath();
            if(!canonical.equals(base)&&!canonical.startsWith(base+File.separator))continue;
            if(!visited.add(canonical))continue;
            String relative=canonical.equals(base)?"":canonical.substring(base.length()+1).replace(File.separatorChar,'/');
            if(relative.equals("Android/data")||relative.equals("Android/obb"))continue;
            File[] children=directory.listFiles();if(children==null)continue;
            for(File child:children){check.run();if(child.isDirectory())pending.addLast(child);else if(child.isFile()&&child.canRead()&&!child.getName().equals(".nomedia")){String filePath=child.getCanonicalPath();if(filePath.startsWith(base+File.separator))found.add(child);}}
        }
        found.sort((a,b)->Long.compare(b.lastModified(),a.lastModified()));return found;
    }

    /** Discover packages without collecting or sorting the phone's other files. */
    static List<File> scanPackages(File root,Check check,Batch batch)throws IOException{
        List<File> found=new ArrayList<>(),buffer=new ArrayList<>();
        ArrayDeque<File> pending=new ArrayDeque<>(),downloads=new ArrayDeque<>(),bluetooth=new ArrayDeque<>();
        Set<String> visited=new HashSet<>();
        Map<File,Long> modified=new HashMap<>();
        String base=root.getCanonicalPath(),prefix=base.endsWith(File.separator)?base:base+File.separator;
        pending.add(root);long lastBatch=System.nanoTime();boolean first=true;
        while(!pending.isEmpty()||!downloads.isEmpty()||!bluetooth.isEmpty()){
            check.run();int priority=!downloads.isEmpty()?2:!bluetooth.isEmpty()?1:0;
            File directory=(priority==2?downloads:priority==1?bluetooth:pending).removeFirst();
            String canonical=directory.getCanonicalPath();
            if(!canonical.equals(base)&&!canonical.startsWith(prefix))continue;
            if(!visited.add(canonical))continue;
            String relative=canonical.equals(base)?"":canonical.substring(prefix.length()).replace(File.separatorChar,'/');
            if(restricted(relative))continue;
            File[] children=directory.listFiles();if(children==null)continue;
            for(File child:children){
                check.run();
                // Most children are photos/media: only test their directory status.
                // File/read checks and canonical paths are reserved for packages.
                if(packageFile(child.getName())&&child.isFile()&&child.canRead()){
                    String filePath=child.getCanonicalPath();
                    if(filePath.startsWith(prefix)&&!restricted(filePath.substring(prefix.length()).replace(File.separatorChar,'/'))){
                        found.add(child);modified.put(child,child.lastModified());buffer.add(child);
                        if(first||buffer.size()>=24||System.nanoTime()-lastBatch>=120_000_000L){
                            emitPackages(buffer,batch,check);lastBatch=System.nanoTime();first=false;
                        }
                    }
                }else if(child.isDirectory()){
                    String name=child.getName().toLowerCase(Locale.ROOT);
                    if(priority==2||name.equals("download")||name.equals("downloads"))downloads.addLast(child);
                    else if(priority==1||name.equals("bluetooth"))bluetooth.addLast(child);
                    else pending.addLast(child);
                }
                if(!buffer.isEmpty()&&System.nanoTime()-lastBatch>=120_000_000L){
                    emitPackages(buffer,batch,check);lastBatch=System.nanoTime();
                }
            }
            // Finish incoming-package directory trees before other storage folders.
            if(!buffer.isEmpty()){emitPackages(buffer,batch,check);lastBatch=System.nanoTime();}
        }
        check.run();
        found.sort((a,b)->Long.compare(modified.get(b),modified.get(a)));
        check.run();return found;
    }
    private static boolean restricted(String relative){
        return relative.equals("Android/data")||relative.startsWith("Android/data/")
                ||relative.equals("Android/obb")||relative.startsWith("Android/obb/");
    }
    private static void emitPackages(List<File> buffer,Batch batch,Check check)throws IOException{
        check.run();List<File> ready=Collections.unmodifiableList(new ArrayList<>(buffer));buffer.clear();
        batch.found(ready);check.run();
    }
}
