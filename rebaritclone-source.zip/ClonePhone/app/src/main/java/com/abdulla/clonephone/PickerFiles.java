package com.abdulla.clonephone;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** File-manager classification and cancellable shared-storage discovery. */
final class PickerFiles {
    interface Check { void run() throws IOException; }
    static String extension(String name){int dot=name.lastIndexOf('.');return dot<0?"":name.substring(dot+1).toLowerCase(Locale.ROOT);}
    static boolean packageFile(String name){return Arrays.asList("apk","apks","xapk","apkm","rbapp").contains(extension(name));}
    static boolean matches(String name,long size,String path,String filter){
        String ext=extension(name),where=path.replace('\\','/').toLowerCase(Locale.ROOT);
        switch(filter){
            case "PDF":return ext.equals("pdf");
            case "EXCEL":return Arrays.asList("xls","xlsx","xlsm","csv","ods").contains(ext);
            case "PPT":return Arrays.asList("ppt","pptx","pps","ppsx","odp").contains(ext);
            case "TXT":return Arrays.asList("txt","log","md","json","xml").contains(ext);
            case "DOC":return Arrays.asList("doc","docx","docm","rtf","odt").contains(ext);
            case "WPS":return Arrays.asList("wps","et","dps").contains(ext);
            case "Zip":return Arrays.asList("zip","rar","iso","7z","tar","gz","bz2").contains(ext);
            case "Large Files":return size>50L*1024*1024;
            case "Status":return where.contains("/whatsapp/media/.statuses/");
            case "Media":return where.contains("/whatsapp/media/")&&!where.contains("/.statuses/");
            default:return true;
        }
    }
    static List<File> scan(File root,Check check)throws IOException{
        List<File> found=new ArrayList<>();ArrayDeque<File> pending=new ArrayDeque<>();Set<String> visited=new HashSet<>();
        String base=root.getCanonicalPath();pending.add(root);
        while(!pending.isEmpty()){
            check.run();File directory=pending.removeFirst();String canonical=directory.getCanonicalPath();
            if(!canonical.equals(base)&&!canonical.startsWith(base+File.separator))continue;
            if(!visited.add(canonical))continue;
            String relative=canonical.equals(base)?"":canonical.substring(base.length()+1).replace(File.separatorChar,'/');
            if(relative.equals("Android/data")||relative.equals("Android/obb"))continue;
            File[] children=directory.listFiles();if(children==null)continue;
            for(File child:children){check.run();if(child.isDirectory())pending.addLast(child);else if(child.isFile()&&child.canRead()&&!child.getName().equals(".nomedia")){String filePath=child.getCanonicalPath();if(filePath.startsWith(base+File.separator))found.add(child);}}
        }
        found.sort((a,b)->Long.compare(b.lastModified(),a.lastModified()));return found;
    }
}
