package com.abdulla.clonephone;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** File-manager classification and cancellable shared-storage discovery. */
final class PickerFiles {
    interface Check { void run() throws IOException; }
    interface Batch { void found(List<File> files) throws IOException; }
    static String extension(String name){int dot=name.lastIndexOf('.');return dot<0?"":name.substring(dot+1).toLowerCase(Locale.ROOT);}
    static boolean packageFile(String name){switch(extension(name)){case "apk":case "apks":case "xapk":case "apkm":case "rbapp":return true;default:return false;}}
    static boolean matches(String name,long size,String path,String filter){return matches(name,"",size,path,filter);}
    static boolean matches(String name,String mime,long size,String path,String filter){
        String ext=extension(name==null?"":name),where=(path==null?"":path).replace('\\','/').toLowerCase(Locale.ROOT);
        String type=mime==null?"":mime.toLowerCase(Locale.ROOT);int parameter=type.indexOf(';');if(parameter>=0)type=type.substring(0,parameter);type=type.trim();
        switch(filter){
            case "PDF":return ext.equals("pdf")||type.equals("application/pdf");
            case "EXCEL":return Arrays.asList("xls","xlsx","xlsm","xlsb","xlt","xltx","xltm","csv","ods","ots").contains(ext)||type.equals("application/vnd.ms-excel")||type.startsWith("application/vnd.ms-excel.")||type.startsWith("application/vnd.openxmlformats-officedocument.spreadsheetml.")||type.equals("text/csv")||type.equals("application/vnd.oasis.opendocument.spreadsheet")||type.equals("application/vnd.oasis.opendocument.spreadsheet-template");
            case "PPT":return Arrays.asList("ppt","pptx","pptm","pot","potx","potm","pps","ppsx","ppsm","odp","otp").contains(ext)||type.equals("application/vnd.ms-powerpoint")||type.startsWith("application/vnd.ms-powerpoint.")||type.startsWith("application/vnd.openxmlformats-officedocument.presentationml.")||type.equals("application/vnd.oasis.opendocument.presentation")||type.equals("application/vnd.oasis.opendocument.presentation-template");
            case "TXT":return Arrays.asList("txt","text","log","md","json","xml","yaml","yml").contains(ext)||type.equals("text/plain")||type.equals("text/markdown")||type.equals("application/json")||type.equals("application/xml")||type.equals("text/xml");
            case "DOC":return Arrays.asList("doc","docx","docm","dot","dotx","dotm","rtf","odt","ott").contains(ext)||type.equals("application/msword")||type.startsWith("application/vnd.ms-word.")||type.startsWith("application/vnd.openxmlformats-officedocument.wordprocessingml.")||type.equals("application/rtf")||type.equals("text/rtf")||type.equals("application/vnd.oasis.opendocument.text")||type.equals("application/vnd.oasis.opendocument.text-template");
            case "WPS":return Arrays.asList("wps","wpt","et","ett","dps","dpt").contains(ext)||type.startsWith("application/kswps")||type.startsWith("application/kset")||type.startsWith("application/ksdps")||type.startsWith("application/vnd.kingsoft.")||type.equals("application/vnd.ms-works");
            case "ALL":return matches(name,type,size,path,"PDF")||matches(name,type,size,path,"EXCEL")||matches(name,type,size,path,"PPT")||matches(name,type,size,path,"TXT")||matches(name,type,size,path,"DOC")||matches(name,type,size,path,"WPS");
            case "Zip":return Arrays.asList("zip","rar","iso","7z","tar","gz","bz2","xz","tgz").contains(ext)||type.equals("application/zip")||type.equals("application/x-zip-compressed")||type.equals("application/vnd.rar")||type.equals("application/x-rar-compressed")||type.equals("application/x-7z-compressed")||type.equals("application/x-tar")||type.equals("application/gzip");
            case "Large Files":return size>50L*1024*1024;
            case "Status":return whatsappMedia(where)&&where.contains("/.statuses/");
            case "Media":return whatsappMedia(where)&&!where.contains("/.statuses/");
            default:return true;
        }
    }
    private static boolean whatsappMedia(String path){return path.contains("/whatsapp/media/")||path.contains("/whatsapp business/media/")||path.contains("/whatsappbusiness/media/");}
    /** Stream document matches rather than waiting for a complete shared-storage scan. */
    static List<File> scanDocuments(File root,String filter,Check check,Batch batch)throws IOException{
        if(!root.isDirectory()||!root.canRead())throw new IOException("Storage is not readable");
        List<File> found=new ArrayList<>(),buffer=new ArrayList<>();
        ArrayDeque<File> pending=new ArrayDeque<>(),priority=new ArrayDeque<>();Set<String> visited=new HashSet<>(),files=new HashSet<>();
        Map<File,Long> modified=new HashMap<>();String base=root.getCanonicalPath(),prefix=base.endsWith(File.separator)?base:base+File.separator;
        pending.add(root);long lastBatch=System.nanoTime();boolean first=true;
        while(!pending.isEmpty()||!priority.isEmpty()){
            check.run();boolean preferred=!priority.isEmpty();File directory=(preferred?priority:pending).removeFirst();String canonical=directory.getCanonicalPath();
            if(!canonical.equals(base)&&!canonical.startsWith(prefix))continue;if(!visited.add(canonical))continue;
            String relative=canonical.equals(base)?"":canonical.substring(prefix.length()).replace(File.separatorChar,'/');if(restricted(relative))continue;
            File[] children=directory.listFiles();if(children==null){if(canonical.equals(base))throw new IOException("Storage is not readable");continue;}
            for(File child:children){
                check.run();
                if(child.isDirectory()){
                    String name=child.getName().toLowerCase(Locale.ROOT);
                    if(preferred||name.equals("download")||name.equals("downloads")||name.equals("documents"))priority.addLast(child);else pending.addLast(child);
                }else if(!child.getName().equals(".nomedia")&&matches(child.getName(),filter.equals("Large Files")?child.length():0,child.getAbsolutePath(),filter)&&child.isFile()&&child.canRead()){
                    String path=child.getCanonicalPath();if(!path.startsWith(prefix)||restricted(path.substring(prefix.length()).replace(File.separatorChar,'/'))||!files.add(path))continue;
                    found.add(child);modified.put(child,child.lastModified());buffer.add(child);
                    if(first||buffer.size()>=24||System.nanoTime()-lastBatch>=120_000_000L){emitPackages(buffer,batch,check);lastBatch=System.nanoTime();first=false;}
                }
                if(!buffer.isEmpty()&&System.nanoTime()-lastBatch>=120_000_000L){emitPackages(buffer,batch,check);lastBatch=System.nanoTime();}
            }
            if(!buffer.isEmpty()){emitPackages(buffer,batch,check);lastBatch=System.nanoTime();}
        }
        check.run();found.sort((a,b)->Long.compare(modified.get(b),modified.get(a)));check.run();return found;
    }
    static List<File> scan(File root,Check check)throws IOException{
        List<File> found=new ArrayList<>();ArrayDeque<File> pending=new ArrayDeque<>();Set<String> visited=new HashSet<>();
        String base=root.getCanonicalPath();pending.add(root);
        while(!pending.isEmpty()){
            check.run();File directory=pending.removeFirst();String canonical=directory.getCanonicalPath();
            if(!canonical.equals(base)&&!canonical.startsWith(base+File.separator))continue;
            if(!visited.add(canonical))continue;
            String relative=canonical.equals(base)?"":canonical.substring(base.length()+1).replace(File.separatorChar,'/');
            if(relative.equals("Android/data")||relative.equals("Android/obb"))continue;
            File[] children=directory.listFiles();if(children==null)continue;
            for(File child:children){check.run();if(child.isDirectory())pending.addLast(child);else if(child.isFile()&&child.canRead()&&!child.getName().equals(".nomedia")){String filePath=child.getCanonicalPath();if(filePath.startsWith(base+File.separator))found.add(child);}}
        }
        found.sort((a,b)->Long.compare(b.lastModified(),a.lastModified()));return found;
    }

    /** Discover packages without collecting or sorting the phone's other files. */
    static List<File> scanPackages(File root,Check check,Batch batch)throws IOException{
        List<File> found=new ArrayList<>(),buffer=new ArrayList<>();
        ArrayDeque<File> pending=new ArrayDeque<>(),downloads=new ArrayDeque<>(),bluetooth=new ArrayDeque<>();
        Set<String> visited=new HashSet<>();
        Map<File,Long> modified=new HashMap<>();
        String base=root.getCanonicalPath(),prefix=base.endsWith(File.separator)?base:base+File.separator;
        pending.add(root);long lastBatch=System.nanoTime();boolean first=true;
        while(!pending.isEmpty()||!downloads.isEmpty()||!bluetooth.isEmpty()){
            check.run();int priority=!downloads.isEmpty()?2:!bluetooth.isEmpty()?1:0;
            File directory=(priority==2?downloads:priority==1?bluetooth:pending).removeFirst();
            String canonical=directory.getCanonicalPath();
            if(!canonical.equals(base)&&!canonical.startsWith(prefix))continue;
            if(!visited.add(canonical))continue;
            String relative=canonical.equals(base)?"":canonical.substring(prefix.length()).replace(File.separatorChar,'/');
            if(restricted(relative))continue;
            File[] children=directory.listFiles();if(children==null)continue;
            for(File child:children){
                check.run();
                // Most children are photos/media: only test their directory status.
                // File/read checks and canonical paths are reserved for packages.
                if(packageFile(child.getName())&&child.isFile()&&child.canRead()){
                    String filePath=child.getCanonicalPath();
                    if(filePath.startsWith(prefix)&&!restricted(filePath.substring(prefix.length()).replace(File.separatorChar,'/'))){
                        found.add(child);modified.put(child,child.lastModified());buffer.add(child);
                        if(first||buffer.size()>=24||System.nanoTime()-lastBatch>=120_000_000L){
                            emitPackages(buffer,batch,check);lastBatch=System.nanoTime();first=false;
                        }
                    }
                }else if(child.isDirectory()){
                    String name=child.getName().toLowerCase(Locale.ROOT);
                    if(priority==2||name.equals("download")||name.equals("downloads"))downloads.addLast(child);
                    else if(priority==1||name.equals("bluetooth"))bluetooth.addLast(child);
                    else pending.addLast(child);
                }
                if(!buffer.isEmpty()&&System.nanoTime()-lastBatch>=120_000_000L){
                    emitPackages(buffer,batch,check);lastBatch=System.nanoTime();
                }
            }
            // Finish incoming-package directory trees before other storage folders.
            if(!buffer.isEmpty()){emitPackages(buffer,batch,check);lastBatch=System.nanoTime();}
        }
        check.run();
        found.sort((a,b)->Long.compare(modified.get(b),modified.get(a)));
        check.run();return found;
    }
    private static boolean restricted(String relative){
        return relative.equals("Android/data")||relative.startsWith("Android/data/")
                ||relative.equals("Android/obb")||relative.startsWith("Android/obb/");
    }
    private static void emitPackages(List<File> buffer,Batch batch,Check check)throws IOException{
        check.run();List<File> ready=Collections.unmodifiableList(new ArrayList<>(buffer));buffer.clear();
        batch.found(ready);check.run();
    }
}
