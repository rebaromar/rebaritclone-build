package com.abdulla.clonephone;

import android.content.Context;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.*;
import android.net.wifi.p2p.nsd.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/** Only device identity is advertised. Pairing credentials require receiver consent. */
final class NearbyClone {
    interface Discovery {void device(String name,String address);void failed();}
    interface Connection {void ready(Pairing peer);void failed();}
    interface Host {String approve(String name);}
    private static final String SERVICE="_rebarclone._tcp";
    private static final int PORT=39842;
    private final WifiP2pManager manager;
    private final WifiP2pManager.Channel channel;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WifiP2pDnsSdServiceInfo service;
    private WifiP2pDnsSdServiceRequest request;
    private volatile ServerSocket server;
    private volatile Socket active;
    private volatile int generation;
    private boolean connected,connecting;
    private Thread hostThread;
    NearbyClone(Context context){
        manager=(WifiP2pManager)context.getSystemService(Context.WIFI_P2P_SERVICE);
        WifiP2pManager.Channel initialized=null;
        try{if(manager!=null)initialized=manager.initialize(context,Looper.getMainLooper(),null);}catch(Exception ignored){}
        channel=initialized;
    }
    private WifiP2pManager.ActionListener action(Runnable success,Runnable failure){return new WifiP2pManager.ActionListener(){public void onSuccess(){success.run();}public void onFailure(int reason){failure.run();}};}
    void advertise(Host host){
        if(server!=null||manager==null||channel==null)return;
        final int token=generation;
        try{
            server=new ServerSocket();server.setReuseAddress(true);server.bind(new InetSocketAddress(PORT));server.setSoTimeout(1000);
            Map<String,String> record=new HashMap<>();record.put("name",Build.MODEL);record.put("v","1");
            service=WifiP2pDnsSdServiceInfo.newInstance("REBAR",SERVICE,record);
            manager.addLocalService(channel,service,action(()->{},()->{}));
            hostThread=new Thread(()->{
                while(token==generation){
                    try(Socket client=server.accept()){
                        active=client;client.setSoTimeout(10000);
                        DataInputStream input=new DataInputStream(client.getInputStream());
                        if(!"REBAR-NEARBY-1".equals(input.readUTF()))continue;
                        String name=input.readUTF();if(name.length()>100)continue;
                        String payload=host.approve(name);
                        if(token!=generation)break;
                        DataOutputStream output=new DataOutputStream(client.getOutputStream());output.writeUTF(payload==null?"":payload);output.flush();
                    }catch(SocketTimeoutException ignored){}catch(Exception error){if(token!=generation)break;}
                    finally{active=null;}
                }
            },"clone-nearby-host");hostThread.start();
        }catch(Exception error){close();}
    }
    void discover(Discovery listener){
        close();final int token=generation;
        if(manager==null||channel==null){listener.failed();return;}
        try{
            manager.setDnsSdResponseListeners(channel,(instance,type,device)->{},(domain,record,device)->{
                if(token!=generation||!domain.toLowerCase(Locale.ROOT).contains("_rebarclone._tcp")||!"1".equals(record.get("v")))return;
                String name=record.get("name");listener.device(name==null?device.deviceName:name,device.deviceAddress);
            });
            request=WifiP2pDnsSdServiceRequest.newInstance();
            manager.addServiceRequest(channel,request,action(()->pollDiscovery(token,listener),listener::failed));
        }catch(Exception error){listener.failed();}
    }
    private void pollDiscovery(int token,Discovery listener){
        if(token!=generation)return;
        try{manager.discoverServices(channel,action(()->{},()->{if(token==generation)listener.failed();}));}catch(Exception error){listener.failed();}
        main.postDelayed(()->pollDiscovery(token,listener),12000);
    }
    void connect(String address,Connection listener){
        final int token=++generation;clearDiscovery();
        try{
            WifiP2pConfig config=new WifiP2pConfig();config.deviceAddress=address;config.wps.setup=WpsInfo.PBC;config.groupOwnerIntent=0;
            connecting=true;manager.connect(channel,config,action(()->awaitGroup(token,listener,0),listener::failed));
        }catch(Exception error){listener.failed();}
    }
    private void awaitGroup(int token,Connection listener,int attempt){
        if(token!=generation)return;
        if(attempt>=60){listener.failed();return;}
        try{manager.requestConnectionInfo(channel,info->{
            if(token!=generation)return;
            if(info!=null&&info.groupFormed&&!info.isGroupOwner&&info.groupOwnerAddress!=null){
                connecting=false;connected=true;String address=info.groupOwnerAddress.getHostAddress();
                new Thread(()->{
                    try(Socket client=new Socket()){
                        active=client;client.connect(new InetSocketAddress(address,PORT),8000);client.setSoTimeout(65000);
                        DataOutputStream out=new DataOutputStream(client.getOutputStream());out.writeUTF("REBAR-NEARBY-1");out.writeUTF(Build.MODEL);out.flush();
                        String value=new DataInputStream(client.getInputStream()).readUTF();Pairing parsed=Pairing.parse(value);
                        Pairing peer=new Pairing(Collections.singletonList(address),parsed.key);
                        main.post(()->{if(token==generation)listener.ready(peer);});
                    }catch(Exception error){main.post(()->{if(token==generation)listener.failed();});}finally{active=null;}
                },"clone-nearby-connect").start();
            }else main.postDelayed(()->awaitGroup(token,listener,attempt+1),1000);
        });}catch(Exception error){listener.failed();}
    }
    private void clearDiscovery(){
        try{if(request!=null)manager.removeServiceRequest(channel,request,null);if(service!=null)manager.removeLocalService(channel,service,null);if(manager!=null&&channel!=null)manager.stopPeerDiscovery(channel,null);}catch(Exception ignored){}
        request=null;service=null;
    }
    void close(){
        generation++;clearDiscovery();
        if(hostThread!=null){hostThread.interrupt();hostThread=null;}
        if(connecting){try{manager.cancelConnect(channel,null);}catch(Exception ignored){}connecting=false;}
        try{if(server!=null)server.close();}catch(Exception ignored){}server=null;
        try{if(active!=null)active.close();}catch(Exception ignored){}active=null;
        if(connected){try{manager.removeGroup(channel,null);}catch(Exception ignored){}connected=false;}
    }
}
