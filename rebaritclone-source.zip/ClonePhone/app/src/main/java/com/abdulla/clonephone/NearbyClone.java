package com.abdulla.clonephone;

import android.content.Context;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.*;
import android.net.wifi.p2p.nsd.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.util.*;

/** Discovery publishes identity only. Credentials are released over the local link after consent. */
final class NearbyClone {
    interface Discovery {void device(String name,String address);void failed();}
    interface Connection {void ready(Pairing peer);void failed();}
    interface Host {String approve(String name,int bands);}
    private static final String SERVICE="_rebarclone._tcp";
    private static final int PORT=39842;
    private final WifiP2pManager manager;
    private final WifiP2pManager.Channel channel;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WifiP2pDnsSdServiceInfo service;
    private WifiP2pDnsSdServiceRequest request;
    private volatile ServerSocket server;
    private volatile Socket active;
    private volatile int generation;
    private boolean connected,connecting;
    private Thread hostThread;
    private final Map<String,Map<String,String>> peers=new HashMap<>();
    private int clientMask=1;
    void clientBands(int mask){clientMask=Build.VERSION.SDK_INT>=29?mask:1;}
    NearbyClone(Context context){
        manager=(WifiP2pManager)context.getSystemService(Context.WIFI_P2P_SERVICE);
        WifiP2pManager.Channel initialized=null;
        try{if(manager!=null)initialized=manager.initialize(context,Looper.getMainLooper(),null);}catch(Exception ignored){}
        channel=initialized;
    }
    private WifiP2pManager.ActionListener action(Runnable success,Runnable failure){return new WifiP2pManager.ActionListener(){public void onSuccess(){success.run();}public void onFailure(int reason){failure.run();}};}
    private void publish(Map<String,String> record){
        final int token=generation;WifiP2pDnsSdServiceInfo old=service;
        WifiP2pDnsSdServiceInfo next=WifiP2pDnsSdServiceInfo.newInstance("REBAR",SERVICE,record);service=next;
        Runnable add=()->{if(token==generation&&service==next)addService(next,token,0);};
        if(old==null)add.run();else manager.removeLocalService(channel,old,action(add,add));
    }
    private void addService(WifiP2pDnsSdServiceInfo next,int token,int attempt){
        if(token!=generation||service!=next)return;
        try{manager.addLocalService(channel,next,action(()->{},()->{if(attempt<3)main.postDelayed(()->addService(next,token,attempt+1),500);}));}catch(Exception ignored){}
    }
    void advertise(Host host,String ssid,Runnable bootstrapped){
        if(manager==null||channel==null)return;
        try{
            Map<String,String> record=new HashMap<>();record.put("name",Build.MODEL);record.put("v","1");record.put("ssid",ssid);publish(record);
            if(server!=null)return;
            final int token=generation;ServerSocket hosted=new ServerSocket();hosted.setReuseAddress(true);hosted.bind(new InetSocketAddress(PORT));hosted.setSoTimeout(1000);server=hosted;
            hostThread=new Thread(()->{
                while(token==generation){
                    try(Socket client=hosted.accept()){
                        active=client;client.setSoTimeout(15000);DataInputStream input=new DataInputStream(client.getInputStream());
                        String protocol=input.readUTF();boolean modern="REBAR-NEARBY-2".equals(protocol);
                        if(!modern&&!"REBAR-NEARBY-1".equals(protocol))continue;
                        String name=input.readUTF();if(name.length()>100)continue;
                        int bands=modern?input.readInt()&7:1;if((bands&1)==0)continue;
                        String payload=host.approve(name,bands);if(token!=generation)break;
                        DataOutputStream output=new DataOutputStream(client.getOutputStream());output.writeUTF(payload==null?"":payload);output.flush();
                        if(modern&&payload!=null&&!payload.isEmpty()&&"READY".equals(input.readUTF())){
                            output.writeUTF("CONNECT");output.flush();main.post(()->{if(token==generation)bootstrapped.run();});
                        }
                    }catch(SocketTimeoutException ignored){}catch(Exception error){if(token!=generation)break;}finally{active=null;}
                }
            },"clone-nearby-host");hostThread.start();
        }catch(Exception error){close();}
    }
    void discover(Discovery listener){
        close();final int token=generation;
        if(manager==null||channel==null){listener.failed();return;}
        try{
            manager.setDnsSdResponseListeners(channel,(instance,type,device)->{},(domain,record,device)->{
                if(token!=generation||!domain.toLowerCase(Locale.ROOT).contains("_rebarclone._tcp")||!"1".equals(record.get("v"))||record.containsKey("target"))return;
                peers.put(device.deviceAddress,new HashMap<>(record));String name=record.get("name");listener.device(name==null?device.deviceName:name,device.deviceAddress);
            });
            request=WifiP2pDnsSdServiceRequest.newInstance();manager.addServiceRequest(channel,request,action(()->pollDiscovery(token,listener),listener::failed));
        }catch(Exception error){listener.failed();}
    }
    private void pollDiscovery(int token,Discovery listener){
        if(token!=generation)return;
        try{manager.discoverServices(channel,new WifiP2pManager.ActionListener(){public void onSuccess(){}public void onFailure(int reason){if(token==generation&&reason!=WifiP2pManager.BUSY)listener.failed();}});}catch(Exception error){listener.failed();}
        main.postDelayed(()->pollDiscovery(token,listener),6000);
    }
    void connectKnown(String ssid,Connection listener,Runnable fallback){
        boolean[] found={false};discover(new Discovery(){
            public void device(String name,String address){Map<String,String> peer=peers.get(address);if(!found[0]&&peer!=null&&ssid.equals(peer.get("ssid"))){found[0]=true;connect(address,listener);}}
            public void failed(){if(!found[0]){found[0]=true;close();fallback.run();}}
        });final int token=generation;
        main.postDelayed(()->{if(token==generation&&!found[0]){found[0]=true;close();fallback.run();}},8000);
    }
    void connect(String address,Connection listener){
        final int token=++generation;
        if(manager==null||channel==null){listener.failed();return;}
        boolean[] finished={false},started={false};
        Connection guarded=new Connection(){public void ready(Pairing peer){if(token==generation&&!finished[0]){finished[0]=true;listener.ready(peer);}}public void failed(){if(token==generation&&!finished[0]){finished[0]=true;listener.failed();}}};
        Runnable start=()->{if(token==generation&&!started[0]&&!finished[0]){started[0]=true;connectNow(address,guarded,token,0);}};
        main.postDelayed(guarded::failed,110000);
        try{
            if(request!=null){manager.removeServiceRequest(channel,request,null);request=null;}
            manager.stopPeerDiscovery(channel,action(start,start));
            main.postDelayed(start,2500);
        }catch(Exception error){guarded.failed();}
    }
    private void connectNow(String address,Connection listener,int token,int attempt){
        if(token!=generation)return;
        try{
            WifiP2pConfig config=new WifiP2pConfig();config.deviceAddress=address;config.wps.setup=WpsInfo.PBC;config.groupOwnerIntent=0;connecting=true;
            manager.connect(channel,config,new WifiP2pManager.ActionListener(){
                public void onSuccess(){if(token==generation)awaitGroup(token,listener,0);}
                public void onFailure(int reason){if(token!=generation)return;if(reason==WifiP2pManager.BUSY&&attempt<4)main.postDelayed(()->connectNow(address,listener,token,attempt+1),700L*(attempt+1));else listener.failed();}
            });
        }catch(Exception error){if(token==generation)listener.failed();}
    }
    private void awaitGroup(int token,Connection listener,int attempt){
        if(token!=generation)return;if(attempt>=45){listener.failed();return;}
        try{manager.requestConnectionInfo(channel,info->{
            if(token!=generation)return;
            if(info!=null&&info.groupFormed&&!info.isGroupOwner&&info.groupOwnerAddress!=null){
                connecting=false;connected=true;String owner=info.groupOwnerAddress.getHostAddress();
                manager.requestGroupInfo(channel,group->{if(token!=generation)return;if(group==null||group.getInterface()==null||group.getInterface().isEmpty())main.postDelayed(()->awaitGroup(token,listener,attempt+1),500);else bootstrap(owner,group.getInterface(),token,listener);});
            }else main.postDelayed(()->awaitGroup(token,listener,attempt+1),1000);
        });}catch(Exception error){if(token==generation)listener.failed();}
    }
    private void bootstrap(String owner,String iface,int token,Connection listener){
        new Thread(()->{
            for(int attempt=0;attempt<4&&token==generation;attempt++){
                boolean consentStarted=false;
                try(Socket client=new Socket()){
                    active=client;
                    // Bind the local P2P address instead of inheriting a cellular/default route.
                    NetworkInterface network=iface.isEmpty()?null:NetworkInterface.getByName(iface);
                    if(network!=null)for(InetAddress address:Collections.list(network.getInetAddresses()))if(address instanceof Inet4Address&&!address.isLoopbackAddress()){client.bind(new InetSocketAddress(address,0));break;}
                    client.connect(new InetSocketAddress(owner,PORT),8000);client.setSoTimeout(65000);
                    DataOutputStream out=new DataOutputStream(client.getOutputStream());out.writeUTF("REBAR-NEARBY-2");out.writeUTF(Build.MODEL);out.writeInt(clientMask);out.flush();consentStarted=true;
                    DataInputStream in=new DataInputStream(client.getInputStream());String value=in.readUTF();if(value.isEmpty())throw new IOException("DECLINED");Pairing parsed=Pairing.parse(value);
                    out.writeUTF("READY");out.flush();if(!"CONNECT".equals(in.readUTF()))throw new IOException("PAIR");
                    Pairing peer=new Pairing(Collections.singletonList(owner),parsed.key);peer.localAddress=client.getLocalAddress().getHostAddress();
                    if(Build.VERSION.SDK_INT>=29){peer.ssid=parsed.ssid;peer.password=parsed.password;}
                    main.post(()->{if(token==generation)listener.ready(peer);});return;
                }catch(Exception error){
                    if(token!=generation)return;
                    if(consentStarted||attempt==3){main.post(()->{if(token==generation)listener.failed();});return;}
                    try{Thread.sleep(600);}catch(InterruptedException interrupted){Thread.currentThread().interrupt();return;}
                }finally{active=null;}
            }
        },"clone-nearby-connect").start();
    }
    private void clearDiscovery(){
        try{if(request!=null)manager.removeServiceRequest(channel,request,null);if(service!=null)manager.removeLocalService(channel,service,null);if(manager!=null&&channel!=null)manager.stopPeerDiscovery(channel,null);}catch(Exception ignored){}
        request=null;service=null;
    }
    void close(){
        generation++;clearDiscovery();peers.clear();if(hostThread!=null){hostThread.interrupt();hostThread=null;}
        if(connecting){try{manager.cancelConnect(channel,null);}catch(Exception ignored){}connecting=false;}
        try{if(server!=null)server.close();}catch(Exception ignored){}server=null;try{if(active!=null)active.close();}catch(Exception ignored){}active=null;
        if(connected){try{manager.removeGroup(channel,null);}catch(Exception ignored){}connected=false;}
    }
}
