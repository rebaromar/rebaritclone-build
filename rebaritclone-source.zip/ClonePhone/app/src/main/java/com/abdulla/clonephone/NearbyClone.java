package com.abdulla.clonephone;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.RouteInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSpecifier;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pGroup;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.widget.EditText;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** QR-free discovery via Wi-Fi Direct and secure Bluetooth hotspot bootstrap. */
final class NearbyClone {
    private static final String SERVICE = "_rebarclone._tcp";
    private static final int SCAN_PERMISSION = 0x7262;
    private static WeakReference<NearbyClone> permissionOwner = new WeakReference<>(null);
    private final Context context;
    private final WifiManager wifi;
    private final ConnectivityManager connectivity;
    private final WifiP2pManager manager;
    private final WifiP2pManager.Channel channel;
    private final NearbyBluetooth bluetooth;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, Map<String, String>> peers = new HashMap<>();
    private final Map<String, String> peerBySsid = new HashMap<>();
    private final Set<String> shown = new LinkedHashSet<>();
    private WifiP2pDnsSdServiceRequest request;
    private WifiP2pDnsSdServiceInfo service;
    private BroadcastReceiver scans;
    private Discovery discovery;
    private AlertDialog dialog;
    private ConnectivityManager.NetworkCallback wifiCallback;
    private Network clientNetwork;
    private Pairing bluetoothApproved;
    private boolean scanPermissionWaiting;
    private volatile int generation;
    private volatile Socket active;
    private volatile ServerSocket server;
    private Thread hostThread;
    private boolean connecting;
    private boolean connected;
    private boolean scanningNow;
    private boolean p2pPending;
    private boolean locationPrompted;
    private int createdNetwork = -1;
    private int previousNetwork = -1;
    private int clientMask = 1;

    interface Connection { void failed(); void ready(Pairing pairing); }
    interface Discovery { void device(String name, String address); void failed(); }
    interface Host { String approve(String name, int bands) throws Exception; }

    NearbyClone(Context context) {
        this.context = context;
        this.bluetooth = new NearbyBluetooth(context);
        this.wifi = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        this.connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        this.manager = (WifiP2pManager) context.getSystemService(Context.WIFI_P2P_SERVICE);
        WifiP2pManager.Channel initialized = null;
        try {
            if (manager != null) initialized = manager.initialize(context, Looper.getMainLooper(), null);
        } catch (Exception ignored) { }
        this.channel = initialized;
    }

    void clientBands(int mask) { clientMask = mask | 1; }
    Network network() { return clientNetwork; }

    private boolean current(int token) { return token == generation; }
    private boolean usableActivity() {
        return context instanceof Activity && !((Activity) context).isFinishing()
                && !((Activity) context).isDestroyed();
    }

    private WifiP2pManager.ActionListener action(Runnable success, Runnable failure) {
        return new WifiP2pManager.ActionListener() {
            public void onSuccess() { success.run(); }
            public void onFailure(int reason) { failure.run(); }
        };
    }

    void advertise(Host host, String ssid, Runnable bootstrapped) {
        final int token = generation;
        bluetooth.advertise(host, ssid, bootstrapped);
        if (manager != null && channel != null) {
            Map<String, String> record = new HashMap<>();
            record.put("name", Build.MODEL);
            record.put("v", "1");
            record.put("ssid", ssid);
            WifiP2pDnsSdServiceInfo old = service;
            WifiP2pDnsSdServiceInfo next = WifiP2pDnsSdServiceInfo.newInstance("REBAR", SERVICE, record);
            service = next;
            Runnable publish = () -> addService(next, token, 0);
            try {
                if (old == null) publish.run();
                else manager.removeLocalService(channel, old, action(publish, publish));
            } catch (Exception ignored) { }
        }
        // The bootstrap server is also needed for LocalOnlyHotspot, even without a P2P group.
        if (server != null) return;
        try {
            ServerSocket hosted = new ServerSocket();
            hosted.setReuseAddress(true);
            hosted.bind(new InetSocketAddress(NearbyProtocol.PORT));
            hosted.setSoTimeout(1000);
            server = hosted;
            hostThread = new Thread(() -> hostLoop(hosted, host, bootstrapped, token), "rebar-hotspot-host");
            hostThread.start();
        } catch (IOException ignored) {
            close();
        }
    }

    private void addService(WifiP2pDnsSdServiceInfo next, int token, int attempt) {
        if (!current(token) || service != next) return;
        try {
            manager.addLocalService(channel, next, action(() -> {
                if (!current(token)) return;
                try { manager.discoverPeers(channel, null); } catch (Exception ignored) { }
            }, () -> {
                if (attempt < 4) main.postDelayed(() -> addService(next, token, attempt + 1), 700);
            }));
        } catch (Exception ignored) { }
    }

    private void hostLoop(ServerSocket hosted, Host host, Runnable bootstrapped, int token) {
        while (current(token)) {
            try (Socket client = hosted.accept()) {
                active = client;
                client.setSoTimeout(70000); // Receiver approval can take up to 60 seconds.
                boolean ready = NearbyProtocol.serve(new DataInputStream(client.getInputStream()),
                        new DataOutputStream(client.getOutputStream()), host::approve, () -> current(token));
                if (ready) main.post(() -> { if (current(token)) bootstrapped.run(); });
            } catch (SocketTimeoutException ignored) {
            } catch (Exception ignored) {
                if (!current(token)) return;
            } finally {
                active = null;
            }
        }
    }

    void discover(Discovery listener) {
        close();
        discovery = listener;
        final int token = generation;
        startWifiScans(token);
        startBluetoothDiscovery();
        if (manager == null || channel == null) {
            if (wifi == null) listener.failed();
            return;
        }
        try {
            manager.setDnsSdResponseListeners(channel, (instance, type, device) -> { },
                    (domain, record, device) -> {
                if (!current(token) || !domain.toLowerCase(Locale.ROOT).contains(SERVICE)
                        || !"1".equals(record.get("v")) || record.containsKey("target")) return;
                peers.put(device.deviceAddress, new HashMap<>(record));
                String ssid = record.get("ssid");
                String name = record.get("name");
                if (name == null || name.isEmpty()) name = device.deviceName;
                if (NearbyProtocol.validSsid(ssid)) {
                    peerBySsid.put(ssid, device.deviceAddress);
                    emit(name, "wifi:" + ssid, token);
                } else emit(name, device.deviceAddress, token);
            });
            request = WifiP2pDnsSdServiceRequest.newInstance();
            manager.addServiceRequest(channel, request, action(() -> pollDiscovery(token), () -> {
                if (current(token) && wifi == null) listener.failed();
            }));
        } catch (Exception ignored) {
            if (wifi == null) listener.failed();
        }
    }

    private void emit(String name, String address, int token) {
        if (current(token) && discovery != null && shown.add(address)) {
            discovery.device(name == null || name.isEmpty() ? "REBARIT CLONE" : name, address);
        }
    }

    private void startBluetoothDiscovery() {
        if (discovery == null || scanPermissionWaiting) return;
        if (Build.VERSION.SDK_INT < 31 && !fineLocationGranted()) return;
        final int token = generation;
        bluetooth.discover((name, address, service) -> emit(name, address, token));
    }

    static boolean activityResult(Activity activity, int request, int result) {
        return NearbyBluetooth.activityResult(activity, request, result);
    }

    private void pollDiscovery(int token) {
        if (!current(token) || discovery == null) return;
        try { manager.discoverServices(channel, null); } catch (Exception ignored) { }
        main.postDelayed(() -> pollDiscovery(token), 6000);
    }

    private boolean fineLocationGranted() {
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean locationEnabled() {
        LocationManager location = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (location == null) return false;
        if (Build.VERSION.SDK_INT >= 28) return location.isLocationEnabled();
        try { return location.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || location.isProviderEnabled(LocationManager.NETWORK_PROVIDER); }
        catch (Exception ignored) { return false; }
    }

    private void startWifiScans(int token) {
        if (wifi == null || !current(token)) return;
        if (scans == null) {
            scans = new BroadcastReceiver() {
                public void onReceive(Context ignored, Intent intent) {
                    if (!current(token)) return;
                    if (WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equals(intent.getAction())) readScans(token);
                    else if (fineLocationGranted() && locationEnabled()) scanNow(token, false);
                }
            };
            IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
            filter.addAction(LocationManager.PROVIDERS_CHANGED_ACTION);
            filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
            try {
                if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(scans, filter, Context.RECEIVER_EXPORTED);
                else context.registerReceiver(scans, filter);
            } catch (Exception ignored) { scans = null; }
        }
        if (!fineLocationGranted()) {
            // Android 13+ automatic pairing works through nearby-device permissions;
            // precise location is optional and only adds raw Wi-Fi scan results.
            if (Build.VERSION.SDK_INT >= 33) return;
            if (!usableActivity()) return;
            permissionOwner = new WeakReference<>(this);
            scanPermissionWaiting = true;
            ((Activity) context).requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION}, SCAN_PERMISSION);
            return;
        }
        scanNow(token, true);
    }

    static boolean permissionResult(Activity activity, int requestCode) {
        if (requestCode != SCAN_PERMISSION) return NearbyBluetooth.permissionResult(activity, requestCode);
        NearbyClone owner = permissionOwner.get();
        permissionOwner.clear();
        if (owner != null && owner.context == activity && owner.discovery != null) {
            owner.scanPermissionWaiting = false;
            if (owner.fineLocationGranted()) owner.scanNow(owner.generation, true);
            else owner.scanPermissionInfo();
            owner.main.post(owner::startBluetoothDiscovery);
        }
        return true;
    }

    private void scanPermissionInfo() {
        if (!usableActivity()) return;
        dialog = new AlertDialog.Builder(UiText.context((Activity) context))
                .setTitle(NearbyUi.words("گەڕان بۆ هۆتسپۆت", "Find hotspots", "البحث عن نقاط الاتصال"))
                .setMessage(NearbyUi.words("بۆ دۆزینەوەی هۆتسپۆت، ڕێگەپێدانی شوێنی ورد پێویستە. دەتوانیت لە ڕێکخستنەکان چالاکی بکەیت، یان بە Wi-Fi Direct و QR پەیوەست بیت.",
                        "Hotspot scanning needs precise location permission. Enable it in app settings, or use Wi-Fi Direct discovery or QR.",
                        "يتطلب البحث عن نقاط الاتصال إذن الموقع الدقيق. فعّله في إعدادات التطبيق، أو استخدم Wi-Fi Direct أو رمز QR."))
                .setPositiveButton(NearbyUi.words("ڕێکخستنەکان", "Settings", "الإعدادات"), (d, w) ->
                        context.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                android.net.Uri.parse("package:" + context.getPackageName()))))
                .setNegativeButton(android.R.string.cancel, null).show();
    }

    private void scanNow(int token, boolean prompt) {
        if (!current(token) || discovery == null || wifi == null || scanningNow) return;
        if (!fineLocationGranted()) return;
        if (!locationEnabled()) {
            if (prompt && !locationPrompted && usableActivity()) {
                locationPrompted = true;
                dialog = new AlertDialog.Builder(UiText.context((Activity) context))
                        .setTitle(NearbyUi.words("دۆزینەوەی هۆتسپۆت", "Find the hotspot", "البحث عن نقطة الاتصال"))
                        .setMessage(NearbyUi.words("بۆ گەڕان بۆ هۆتسپۆت، شوێن (Location) چالاک بکە.",
                                "Turn on Location to scan for nearby hotspots.", "فعّل الموقع للبحث عن نقاط الاتصال القريبة."))
                        .setPositiveButton(NearbyUi.words("چالاککردن", "Turn on", "تفعيل"), (d, w) ->
                                context.startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                        .setNegativeButton(android.R.string.cancel, null).show();
            }
            return;
        }
        scanningNow = true;
        readScans(token); // Include recent cached results when Android throttles a fresh scan.
        try { wifi.startScan(); } catch (Exception ignored) { }
        main.postDelayed(() -> {
            scanningNow = false;
            if (current(token)) scanNow(token, false);
        }, 35000);
    }

    private void readScans(int token) {
        if (!current(token) || discovery == null || !fineLocationGranted() || !locationEnabled()) return;
        try {
            List<ScanResult> results = wifi.getScanResults();
            if (results == null) return;
            for (ScanResult result : results) {
                String ssid = result.SSID;
                if (!NearbyProtocol.validSsid(ssid)) continue;
                if (!NearbyProtocol.hotspotName(ssid) && !peerBySsid.containsKey(ssid)) continue;
                long age = SystemClock.elapsedRealtime() - result.timestamp / 1000;
                if (result.timestamp > 0 && age > 90000) continue;
                String address = peerBySsid.get(ssid);
                Map<String, String> record = address == null ? null : peers.get(address);
                String name = record == null ? ssid : record.get("name");
                emit(name, "wifi:" + ssid, token);
            }
        } catch (SecurityException ignored) { }
    }

    void manualHotspot() {
        if (discovery == null || !usableActivity()) return;
        final int token = generation;
        EditText input = new EditText(context);
        input.setSingleLine(true);
        input.setHint(NearbyUi.words("ناوی هۆتسپۆتی مۆبایلی نوێ", "Hotspot name on the new phone", "اسم نقطة الاتصال على الهاتف الجديد"));
        dialog = new AlertDialog.Builder(UiText.context((Activity) context))
                .setTitle(NearbyUi.words("ناوی هۆتسپۆت", "Hotspot name", "اسم نقطة الاتصال"))
                .setView(input).setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(android.R.string.ok, null).create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String ssid = input.getText().toString();
            if (!NearbyProtocol.validSsid(ssid)) {
                input.setError(NearbyUi.words("ناوەکە دروست بنووسە", "Enter a valid hotspot name", "أدخل اسم نقطة اتصال صالحًا"));
                return;
            }
            dialog.dismiss();
            emit(ssid, "wifi:" + ssid, token);
        });
    }

    void connectKnown(String ssid, Connection listener, Runnable fallback) {
        final boolean[] found = {false};
        discover(new Discovery() {
            public void device(String name, String address) {
                if (!found[0] && ("wifi:" + ssid).equals(address)) {
                    found[0] = true;
                    connect(address, listener);
                }
            }
            public void failed() {
                if (!found[0]) { found[0] = true; close(); fallback.run(); }
            }
        });
        final int token = generation;
        main.postDelayed(() -> {
            if (current(token) && !found[0]) { found[0] = true; close(); fallback.run(); }
        }, 8000);
    }

    void connect(String address, Connection listener) {
        final String ssid = address.startsWith("wifi:") ? address.substring(5) : null;
        final String peer = ssid == null ? address : peerBySsid.get(ssid);
        final int token = ++generation;
        main.removeCallbacksAndMessages(null);
        discovery = null;
        stopScans();
        final boolean[] finished = {false};
        Connection once = new Connection() {
            public void failed() {
                if (!current(token) || finished[0]) return;
                finished[0] = true;
                listener.failed();
            }
            public void ready(Pairing pairing) {
                if (!current(token) || finished[0]) return;
                finished[0] = true;
                listener.ready(pairing);
            }
        };
        Runnable start = () -> {
            if (!current(token)) return;
            if (address.startsWith("bt:")) connectBluetoothAddress(address, once, token);
            else if (peer != null && manager != null && channel != null) {
                p2pPending = true;
                Runnable fallback = () -> {
                    if (!current(token) || !p2pPending) return;
                    p2pPending = false;
                    connecting = false;
                    try {
                        manager.cancelConnect(channel, null);
                        if (connected) manager.removeGroup(channel, null);
                    } catch (Exception ignored) { }
                    connected = false;
                    if (ssid == null) once.failed();
                    else connectBluetooth(ssid, once, token, 0);
                };
                main.postDelayed(fallback, 45000);
                connectP2p(peer, once, token, 0, fallback);
            } else if (ssid != null) connectBluetooth(ssid, once, token, 0);
            else once.failed();
        };
        final boolean[] started = {false};
        Runnable guardedStart = () -> {
            if (current(token) && !started[0]) { started[0] = true; start.run(); }
        };
        try {
            if (request != null && manager != null) manager.removeServiceRequest(channel, request, null);
            request = null;
            if (manager != null && channel != null) manager.stopPeerDiscovery(channel, action(guardedStart, guardedStart));
            else guardedStart.run();
        } catch (Exception ignored) { guardedStart.run(); }
        main.postDelayed(guardedStart, 2000);
    }

    private void connectP2p(String address, Connection listener, int token, int attempt, Runnable fallback) {
        if (!current(token) || !p2pPending) return;
        try {
            WifiP2pConfig config = new WifiP2pConfig();
            config.deviceAddress = address;
            config.wps.setup = 0;
            config.groupOwnerIntent = 0;
            connecting = true;
            manager.connect(channel, config, new WifiP2pManager.ActionListener() {
                public void onSuccess() { if (current(token) && p2pPending) awaitGroup(token, listener, 0, fallback); }
                public void onFailure(int reason) {
                    if (!current(token) || !p2pPending) return;
                    if (reason == WifiP2pManager.BUSY && attempt < 4) {
                        main.postDelayed(() -> connectP2p(address, listener, token, attempt + 1, fallback), (attempt + 1) * 700);
                    } else { connecting = false; fallback.run(); }
                }
            });
        } catch (Exception ignored) { connecting = false; fallback.run(); }
    }

    private void awaitGroup(int token, Connection listener, int attempt, Runnable fallback) {
        if (!current(token) || !p2pPending) return;
        if (attempt >= 35) {
            connecting = false;
            try { manager.cancelConnect(channel, null); } catch (Exception ignored) { }
            fallback.run();
            return;
        }
        try {
            manager.requestConnectionInfo(channel, info -> {
                if (!current(token) || !p2pPending) return;
                if (info != null && info.groupFormed && !info.isGroupOwner && info.groupOwnerAddress != null) {
                    connecting = false;
                    connected = true;
                    manager.requestGroupInfo(channel, group -> {
                        if (!current(token) || !p2pPending) return;
                        if (group != null && group.getInterface() != null && !group.getInterface().isEmpty()) {
                            p2pPending = false;
                            bootstrap(Collections.singletonList(info.groupOwnerAddress.getHostAddress()),
                                    group.getInterface(), null, token, listener);
                        } else main.postDelayed(() -> awaitGroup(token, listener, attempt + 1, fallback), 1000);
                    });
                } else main.postDelayed(() -> awaitGroup(token, listener, attempt + 1, fallback), 1000);
            });
        } catch (Exception ignored) { fallback.run(); }
    }

    private void connectBluetooth(String ssid, Connection listener, int token, int attempt) {
        if (!current(token)) return;
        String address = bluetooth.addressFor(ssid);
        if (address != null) connectBluetoothAddress(address, listener, token);
        else if (attempt < 25) main.postDelayed(() -> connectBluetooth(ssid, listener, token, attempt + 1), 1000);
        else listener.failed();
    }

    private void connectBluetoothAddress(String address, Connection listener, int token) {
        if (!current(token)) return;
        bluetooth.connect(address, clientMask, new NearbyBluetooth.Connection() {
            public void failed() { if (current(token)) listener.failed(); }
            public void ready(Pairing approved) {
                if (!current(token)) return;
                bluetoothApproved = approved;
                joinHotspot(approved.ssid, approved.password, listener, token);
            }
        });
    }

    private void joinHotspot(String ssid, String password, Connection listener, int token) {
        if (!current(token) || connectivity == null || wifi == null) { listener.failed(); return; }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                WifiNetworkSpecifier spec = new WifiNetworkSpecifier.Builder().setSsid(ssid)
                        .setWpa2Passphrase(password).build();
                NetworkRequest request = new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                        .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build();
                wifiCallback = new ConnectivityManager.NetworkCallback() {
                    private boolean available;
                    public void onAvailable(Network network) {
                        main.post(() -> {
                            if (!current(token) || available) return;
                            available = true;
                            clientNetwork = network;
                            awaitRoutes(network, token, listener, 0);
                        });
                    }
                    public void onUnavailable() { main.post(() -> { if (current(token)) listener.failed(); }); }
                    public void onLost(Network network) { main.post(() -> { if (current(token)) listener.failed(); }); }
                };
                connectivity.requestNetwork(request, wifiCallback, 60000);
            } else {
                WifiInfo old = wifi.getConnectionInfo();
                previousNetwork = old == null ? -1 : old.getNetworkId();
                WifiConfiguration config = new WifiConfiguration();
                config.SSID = quote(ssid);
                config.preSharedKey = quote(password);
                config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
                createdNetwork = wifi.addNetwork(config);
                if (createdNetwork < 0 || !wifi.enableNetwork(createdNetwork, true)) { listener.failed(); return; }
                wifi.reconnect();
                awaitLegacyWifi(ssid, token, listener, 0);
            }
        } catch (Exception ignored) { listener.failed(); }
    }

    private static String quote(String value) {
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private void awaitLegacyWifi(String ssid, int token, Connection listener, int attempt) {
        if (!current(token)) return;
        if (attempt >= 60) { listener.failed(); return; }
        WifiInfo info = wifi.getConnectionInfo();
        if (info != null && (ssid.equals(info.getSSID()) || quote(ssid).equals(info.getSSID()))) {
            for (Network network : connectivity.getAllNetworks()) {
                NetworkCapabilities cap = connectivity.getNetworkCapabilities(network);
                if (cap != null && cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        && !cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                    clientNetwork = network;
                    awaitRoutes(network, token, listener, 0);
                    return;
                }
            }
        }
        main.postDelayed(() -> awaitLegacyWifi(ssid, token, listener, attempt + 1), 1000);
    }

    private void awaitRoutes(Network network, int token, Connection listener, int attempt) {
        if (!current(token)) return;
        Set<String> gateways = new LinkedHashSet<>();
        LinkProperties properties = connectivity.getLinkProperties(network);
        if (properties != null) {
            for (RouteInfo route : properties.getRoutes()) {
                InetAddress address = route.getGateway();
                if (address instanceof Inet4Address && Pairing.local(address.getHostAddress())) {
                    gateways.add(address.getHostAddress());
                }
            }
        }
        if (!gateways.isEmpty()) {
            if (bluetoothApproved != null) {
                Pairing peer = new Pairing(new ArrayList<>(gateways), bluetoothApproved.key);
                peer.ssid = bluetoothApproved.ssid;
                peer.password = bluetoothApproved.password;
                listener.ready(peer);
            } else bootstrap(new ArrayList<>(gateways), "", network, token, listener);
        }
        else if (attempt < 12) main.postDelayed(() -> awaitRoutes(network, token, listener, attempt + 1), 1000);
        else listener.failed();
    }

    private void bootstrap(List<String> owners, String iface, Network network, int token, Connection listener) {
        new Thread(() -> {
            for (int attempt = 0; attempt < 4 && current(token); attempt++) {
                for (String owner : owners) {
                    try (Socket client = network == null ? new Socket() : network.getSocketFactory().createSocket()) {
                        active = client;
                        if (!iface.isEmpty()) {
                            NetworkInterface ni = NetworkInterface.getByName(iface);
                            if (ni != null) for (InetAddress local : Collections.list(ni.getInetAddresses())) {
                                if (local instanceof Inet4Address && !local.isLoopbackAddress()) {
                                    client.bind(new InetSocketAddress(local, 0));
                                    break;
                                }
                            }
                        }
                        client.connect(new InetSocketAddress(owner, NearbyProtocol.PORT), 8000);
                        client.setSoTimeout(70000);
                        DataInputStream in = new DataInputStream(client.getInputStream());
                        DataOutputStream out = new DataOutputStream(client.getOutputStream());
                        String value = NearbyProtocol.request(in, out, Build.MODEL, clientMask);
                        Pairing parsed = Pairing.parse(value);
                        if (!current(token)) return;
                        NearbyProtocol.confirm(in, out);
                        Pairing peer = new Pairing(Collections.singletonList(owner), parsed.key);
                        peer.localAddress = client.getLocalAddress().getHostAddress();
                        if (network != null) { peer.ssid = parsed.ssid; peer.password = parsed.password; }
                        main.post(() -> {
                            if (current(token)) { bluetooth.stopDiscovery(); listener.ready(peer); }
                        });
                        return;
                    } catch (Exception error) {
                        if (!current(token)) return;
                        // A rejection is final; never prompt the receiver again automatically.
                        if ("DECLINED".equals(error.getMessage()) || "PAIR".equals(error.getMessage())
                                || error instanceof IllegalArgumentException) {
                            main.post(() -> { if (current(token)) listener.failed(); });
                            return;
                        }
                    } finally { active = null; }
                }
                try { Thread.sleep(600); }
                catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); return; }
            }
            main.post(() -> { if (current(token)) listener.failed(); });
        }, "rebar-hotspot-pair").start();
    }

    private void stopScans() {
        scanningNow = false;
        if (scans != null) {
            try { context.unregisterReceiver(scans); } catch (Exception ignored) { }
            scans = null;
        }
    }

    void close() {
        ++generation;
        main.removeCallbacksAndMessages(null);
        discovery = null;
        scanPermissionWaiting = false;
        bluetooth.close();
        bluetoothApproved = null;
        locationPrompted = false;
        if (permissionOwner.get() == this) permissionOwner.clear();
        stopScans();
        if (dialog != null) {
            try { dialog.dismiss(); } catch (Exception ignored) { }
            dialog = null;
        }
        try {
            if (manager != null && channel != null) {
                if (request != null) manager.removeServiceRequest(channel, request, null);
                if (service != null) manager.removeLocalService(channel, service, null);
                manager.stopPeerDiscovery(channel, null);
                if (connecting) manager.cancelConnect(channel, null);
                if (connected) manager.removeGroup(channel, null);
            }
        } catch (Exception ignored) { }
        request = null;
        service = null;
        connecting = false;
        connected = false;
        p2pPending = false;
        peers.clear();
        peerBySsid.clear();
        shown.clear();
        if (hostThread != null) { hostThread.interrupt(); hostThread = null; }
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        server = null;
        try { if (active != null) active.close(); } catch (IOException ignored) { }
        active = null;
        if (wifiCallback != null) {
            try { connectivity.unregisterNetworkCallback(wifiCallback); } catch (Exception ignored) { }
            wifiCallback = null;
        }
        clientNetwork = null;
        if (createdNetwork >= 0 && wifi != null) {
            try {
                wifi.removeNetwork(createdNetwork);
                if (previousNetwork >= 0) { wifi.enableNetwork(previousNetwork, true); wifi.reconnect(); }
            } catch (Exception ignored) { }
        }
        createdNetwork = -1;
        previousNetwork = -1;
    }
}
