package com.abdulla.clonephone;

import android.content.Context;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.*;
import android.net.wifi.p2p.nsd.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/** Only device identity is advertised. Pairing credentials require receiver consent. */
final class NearbyClone {
    interface Discovery {void device(String name,String address);void failed();}
    interface Connection {void ready(Pairing peer);void failed();}
    interface Host {String approve(String name);}
    interface BandRequest {void requested(String name,int band,Runnable accept);}
    private static final String SERVICE="_rebarclone._tcp";
    private static final int PORT=39842;
    private final WifiP2pManager manager;
    private final WifiP2pManager.Channel channel;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WifiP2pDnsSdServiceInfo service;
    private WifiP2pDnsSdServiceRequest request;
    private volatile ServerSocket server;
    private volatile Socket active;
    private volatile int generation;
    private boolean connected,connecting;
    private Thread hostThread;
    private final String hostId=UUID.randomUUID().toString();
    private final Map<String,Map<String,String>> peers=new HashMap<>();
    private Map<String,String> hostRecord;
    private String waitingHostId="",waitingAddress="",waitingRequest="",acceptedRequest="",promptRequest="";
    private int clientMask=1;
    private Connection waitingConnection;
    void clientBands(int mask){clientMask=mask;}
    private int number(String value){try{return Integer.parseInt(value);}catch(Exception ignored){return 0;}}
    private void publish(Map<String,String> record){
        final int token=generation;WifiP2pDnsSdServiceInfo old=service;
        WifiP2pDnsSdServiceInfo next=WifiP2pDnsSdServiceInfo.newInstance("REBAR",SERVICE,record);service=next;
        Runnable add=()->{if(token==generation&&service==next)addService(next,token,0);};
        if(old==null)add.run();else manager.removeLocalService(channel,old,action(add,add));
    }
    private void addService(WifiP2pDnsSdServiceInfo next,int token,int attempt){
        if(token!=generation||service!=next)return;
        try{manager.addLocalService(channel,next,action(()->{},()->{if(attempt<3)main.postDelayed(()->addService(next,token,attempt+1),500);}));}catch(Exception ignored){}
    }
    /** QR users also negotiate against the matching receiver; legacy hosts use the QR link. */
    void connectKnown(String ssid,Connection listener,Runnable fallback){
        boolean[] found={false};
        discover(new Discovery(){
            public void device(String name,String address){Map<String,String> peer=peers.get(address);if(!found[0]&&peer!=null&&ssid.equals(peer.get("ssid"))){found[0]=true;connect(address,listener);}}
            public void failed(){if(!found[0]){found[0]=true;close();fallback.run();}}
        });
        final int token=generation;
        main.postDelayed(()->{if(token==generation&&!found[0]){found[0]=true;close();fallback.run();}},8000);
    }

    NearbyClone(Context context){
        manager=(WifiP2pManager)context.getSystemService(Context.WIFI_P2P_SERVICE);
        WifiP2pManager.Channel initialized=null;
        try{if(manager!=null)initialized=manager.initialize(context,Looper.getMainLooper(),null);}catch(Exception ignored){}
        channel=initialized;
    }
    private WifiP2pManager.ActionListener action(Runnable success,Runnable failure){return new WifiP2pManager.ActionListener(){public void onSuccess(){success.run();}public void onFailure(int reason){failure.run();}};}
    void advertise(Host host,int mask,int band,boolean automatic,String ssid,BandRequest change){
        if(manager==null||channel==null)return;
        try{
            hostRecord=new HashMap<>();hostRecord.put("name",Build.MODEL);hostRecord.put("v","1");hostRecord.put("id",hostId);hostRecord.put("mask",String.valueOf(mask));hostRecord.put("band",String.valueOf(band));hostRecord.put("auto",automatic?"1":"0");hostRecord.put("ack",acceptedRequest);hostRecord.put("ssid",ssid);publish(hostRecord);
            if(server!=null)return;
        }catch(Exception ignored){return;}

        final int token=generation;
        try{
            server=new ServerSocket();server.setReuseAddress(true);server.bind(new InetSocketAddress(PORT));server.setSoTimeout(1000);
            manager.setDnsSdResponseListeners(channel,(instance,type,device)->{},(domain,record,device)->{
                if(token!=generation||hostRecord==null||!domain.toLowerCase(Locale.ROOT).contains("_rebarclone._tcp")||!hostId.equals(record.get("target"))||!"1".equals(hostRecord.get("auto")))return;
                String id=record.get("request");if(id==null||!id.matches("[a-f0-9-]{36}")||id.equals(promptRequest))return;
                int best=WifiBandPolicy.fastestCommonBand(number(hostRecord.get("mask")),number(record.get("mask")));if(best==WifiBandPolicy.AUTO)return;
                promptRequest=id;String name=record.get("name");
                change.requested(name==null?device.deviceName:name,best,()->{
                    if(token!=generation)return;acceptedRequest=id;
                    if(best==number(hostRecord.get("band"))){hostRecord.put("ack",id);publish(hostRecord);}
                });
            });
            request=WifiP2pDnsSdServiceRequest.newInstance();manager.addServiceRequest(channel,request,action(()->pollHost(token),()->{}));
            hostThread=new Thread(()->{
                while(token==generation){
                    try(Socket client=server.accept()){
                        active=client;client.setSoTimeout(10000);
                        DataInputStream input=new DataInputStream(client.getInputStream());
                        if(!"REBAR-NEARBY-1".equals(input.readUTF()))continue;
                        String name=input.readUTF();if(name.length()>100)continue;
                        String payload=host.approve(name);
                        if(token!=generation)break;
                        DataOutputStream output=new DataOutputStream(client.getOutputStream());output.writeUTF(payload==null?"":payload);output.flush();
                    }catch(SocketTimeoutException ignored){}catch(Exception error){if(token!=generation)break;}
                    finally{active=null;}
                }
            },"clone-nearby-host");hostThread.start();
        }catch(Exception error){close();}
    }
    private void pollHost(int token){
        if(token!=generation||server==null)return;
        try{manager.discoverServices(channel,action(()->{},()->{}));}catch(Exception ignored){}
        main.postDelayed(()->pollHost(token),10000);
    }
    void discover(Discovery listener){
        close();final int token=generation;
        if(manager==null||channel==null){listener.failed();return;}
        try{
            manager.setDnsSdResponseListeners(channel,(instance,type,device)->{},(domain,record,device)->{
                if(token!=generation||!domain.toLowerCase(Locale.ROOT).contains("_rebarclone._tcp")||!"1".equals(record.get("v")))return;
                if(record.containsKey("target"))return;
                peers.put(device.deviceAddress,new HashMap<>(record));
                if(waitingConnection!=null&&waitingHostId.equals(record.get("id"))&&waitingRequest.equals(record.get("ack"))){Connection next=waitingConnection;waitingAddress="";waitingConnection=null;connectNow(device.deviceAddress,next);return;}
                String name=record.get("name");listener.device(name==null?device.deviceName:name,device.deviceAddress);
            });
            request=WifiP2pDnsSdServiceRequest.newInstance();
            manager.addServiceRequest(channel,request,action(()->pollDiscovery(token,listener),listener::failed));
        }catch(Exception error){listener.failed();}
    }
    private void pollDiscovery(int token,Discovery listener){
        if(token!=generation)return;
        try{manager.discoverServices(channel,action(()->{},()->{if(token==generation)listener.failed();}));}catch(Exception error){listener.failed();}
        main.postDelayed(()->pollDiscovery(token,listener),12000);
    }
    void connect(String address,Connection listener){
        Map<String,String> peer=peers.get(address);
        int best=peer==null?0:WifiBandPolicy.fastestCommonBand(number(peer.get("mask")),clientMask);
        if(peer!=null&&best!=0&&best!=number(peer.get("band"))&&"1".equals(peer.get("auto"))&&peer.containsKey("id")){
            waitingAddress=address;waitingHostId=peer.get("id");waitingConnection=listener;waitingRequest=UUID.randomUUID().toString();final int token=generation;
            Map<String,String> requestRecord=new HashMap<>();requestRecord.put("v","1");requestRecord.put("name",Build.MODEL);requestRecord.put("target",peer.get("id"));requestRecord.put("request",waitingRequest);requestRecord.put("mask",String.valueOf(clientMask));
            try{publish(requestRecord);}catch(Exception error){waitingAddress="";waitingConnection=null;listener.failed();return;}
            main.postDelayed(()->{if(token==generation&&waitingConnection==listener){waitingAddress="";waitingConnection=null;listener.failed();}},65000);
        }else connectNow(address,listener);
    }
    private void connectNow(String address,Connection listener){
        final int token=++generation;clearDiscovery();
        try{
            WifiP2pConfig config=new WifiP2pConfig();config.deviceAddress=address;config.wps.setup=WpsInfo.PBC;config.groupOwnerIntent=0;
            connecting=true;manager.connect(channel,config,action(()->awaitGroup(token,listener,0),listener::failed));
        }catch(Exception error){listener.failed();}
    }
    private void awaitGroup(int token,Connection listener,int attempt){
        if(token!=generation)return;
        if(attempt>=60){listener.failed();return;}
        try{manager.requestConnectionInfo(channel,info->{
            if(token!=generation)return;
            if(info!=null&&info.groupFormed&&!info.isGroupOwner&&info.groupOwnerAddress!=null){
                connecting=false;connected=true;String address=info.groupOwnerAddress.getHostAddress();
                new Thread(()->{
                    try(Socket client=new Socket()){
                        active=client;client.connect(new InetSocketAddress(address,PORT),8000);client.setSoTimeout(65000);
                        DataOutputStream out=new DataOutputStream(client.getOutputStream());out.writeUTF("REBAR-NEARBY-1");out.writeUTF(Build.MODEL);out.flush();
                        String value=new DataInputStream(client.getInputStream()).readUTF();Pairing parsed=Pairing.parse(value);
                        Pairing peer=new Pairing(Collections.singletonList(address),parsed.key);
                        main.post(()->{if(token==generation)listener.ready(peer);});
                    }catch(Exception error){main.post(()->{if(token==generation)listener.failed();});}finally{active=null;}
                },"clone-nearby-connect").start();
            }else main.postDelayed(()->awaitGroup(token,listener,attempt+1),1000);
        });}catch(Exception error){listener.failed();}
    }
    private void clearDiscovery(){
        try{if(request!=null)manager.removeServiceRequest(channel,request,null);if(service!=null)manager.removeLocalService(channel,service,null);if(manager!=null&&channel!=null)manager.stopPeerDiscovery(channel,null);}catch(Exception ignored){}
        request=null;service=null;
    }
    void close(){
        generation++;clearDiscovery();peers.clear();waitingHostId="";waitingRequest="";waitingAddress="";waitingConnection=null;hostRecord=null;acceptedRequest="";promptRequest="";
        if(hostThread!=null){hostThread.interrupt();hostThread=null;}
        if(connecting){try{manager.cancelConnect(channel,null);}catch(Exception ignored){}connecting=false;}
        try{if(server!=null)server.close();}catch(Exception ignored){}server=null;
        try{if(active!=null)active.close();}catch(Exception ignored){}active=null;
        if(connected){try{manager.removeGroup(channel,null);}catch(Exception ignored){}connected=false;}
    }
}
