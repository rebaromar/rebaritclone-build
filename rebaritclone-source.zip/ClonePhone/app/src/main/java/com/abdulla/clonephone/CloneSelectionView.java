package com.abdulla.clonephone;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

/** Source-phone selection with a fixed summary/action and independently scrolling categories. */
final class CloneSelectionView extends LinearLayout {
    interface Actions { void send(Set<String> categories,Set<String> packages); void back(); }
    private final Activity activity;
    private final List<UsbCloneProtocol.Category> categories;
    private final List<CloneAppPicker.App> apps;
    private final Set<String> appPackages=new LinkedHashSet<>();
    private TextView appsInfo,appsAction;
    private final LinkedHashMap<String,CheckBox> checks=new LinkedHashMap<>();
    private final TextView summary;
    private final Button send,all;
    private static final int BLUE=0xff1769e0,INK=0xff182333,MUTED=0xff697586;
    CloneSelectionView(Activity activity,List<UsbCloneProtocol.Category> categories,List<CloneAppPicker.App> apps,Actions actions){
        super(activity);this.activity=activity;this.categories=new ArrayList<>();for(UsbCloneProtocol.Category category:categories)if(!"files".equals(category.id))this.categories.add(category);this.apps=apps;for(CloneAppPicker.App app:apps)appPackages.add(app.packageName);
        setOrientation(VERTICAL);setLayoutDirection(UiText.direction());setBackgroundColor(Color.WHITE);
        setPadding(dp(20),dp(12),dp(20),dp(12));
        LinearLayout header=new LinearLayout(activity);header.setGravity(Gravity.CENTER_VERTICAL);addView(header,new LayoutParams(-1,dp(52)));
        TextView back=text("‹",30,INK,true);back.setGravity(Gravity.CENTER);back.setContentDescription(words("گەڕانەوە","Back","رجوع"));header.addView(back,new LayoutParams(dp(44),-1));back.setOnClickListener(v->actions.back());
        header.addView(text(words("هەڵبژاردنی داتا","Select data","اختيار البيانات"),21,INK,true),new LayoutParams(0,-2,1));
        all=new Button(activity);all.setAllCaps(false);all.setTextSize(13);all.setTextColor(BLUE);all.setBackgroundColor(Color.TRANSPARENT);header.addView(all,new LayoutParams(-2,dp(48)));
        TextView connected=text(words("پەیوەست بە مۆبایلی نوێ","Connected to the new phone","متصل بالهاتف الجديد"),13,0xff23815b,false);connected.setPadding(dp(12),dp(10),dp(12),dp(10));connected.setBackground(box(0xffedf8f2,10));addView(connected,new LayoutParams(-1,-2));
        TextView hint=text(words("ئەو داتایانە هەڵبژێرە کە دەیانگوازیتەوە.","Choose the data to transfer.","اختر البيانات التي تريد نقلها."),14,MUTED,false);hint.setPadding(0,dp(14),0,dp(10));addView(hint);
        ScrollView scroll=new ScrollView(activity);scroll.setFillViewport(true);addView(scroll,new LayoutParams(-1,0,1));LinearLayout rows=new LinearLayout(activity);rows.setOrientation(VERTICAL);scroll.addView(rows);
        for(UsbCloneProtocol.Category category:this.categories){
            LinearLayout row=new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(16),dp(12),dp(16));row.setBackground(box(0xfff7f9fc,18));
            ImageView icon=new ImageView(activity);icon.setImageResource(icon(category.id));int accent=accent(category.id);icon.setColorFilter(accent);icon.setPadding(dp(12),dp(12),dp(12),dp(12));icon.setBackground(box((accent&0x00ffffff)|0x16000000,16));icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);row.addView(icon,new LayoutParams(dp(52),dp(52)));
            LinearLayout labels=new LinearLayout(activity);labels.setOrientation(VERTICAL);labels.setPadding(dp(14),0,dp(8),0);row.addView(labels,new LayoutParams(0,-2,1));labels.addView(text(name(category.id),16,INK,true));
            String detail=category.count==0?words("داتای بەردەست نییە","No accessible data","لا توجد بيانات متاحة"):category.count+words(" دانە"," items"," عنصر")+(category.bytes>=0?"  ·  "+TransferStats.size(category.bytes):"");
            TextView info=text(detail,12,MUTED,false);info.setPadding(0,dp(5),0,0);labels.addView(info);
            if("apps".equals(category.id)){
                appsInfo=info;appsAction=text(words("هەڵبژاردنی ئەپەکان  ›","Choose individual apps  ›","اختيار التطبيقات  ›"),13,BLUE,true);appsAction.setPadding(0,dp(10),0,dp(8));labels.addView(appsAction);
                appsAction.setOnClickListener(v->CloneAppPicker.show(activity,apps,appPackages,chosen->{appPackages.clear();appPackages.addAll(chosen);CheckBox appCheck=checks.get("apps");if(appCheck!=null)appCheck.setChecked(!chosen.isEmpty());refresh();}));
            }
            CheckBox check=new CheckBox(activity);check.setButtonTintList(ColorStateList.valueOf(BLUE));check.setChecked(category.count>0);check.setEnabled(category.count>0);check.setContentDescription(name(category.id));row.addView(check,new LayoutParams(dp(48),dp(48)));checks.put(category.id,check);
            LayoutParams rp=new LayoutParams(-1,-2);rp.bottomMargin=dp(10);rows.addView(row,rp);
            row.setAlpha(category.count>0?1f:.5f);row.setOnClickListener(v->{if(check.isEnabled())check.setChecked(!check.isChecked());});check.setOnCheckedChangeListener((b,on)->{row.setBackground(box(on?0xffeef4ff:0xfff7f9fc,18));refresh();});
            if(check.isChecked())row.setBackground(box(0xffeef4ff,18));
        }
        LinearLayout footer=new LinearLayout(activity);footer.setOrientation(VERTICAL);footer.setPadding(0,dp(12),0,0);addView(footer,new LayoutParams(-1,-2));summary=text("",14,INK,true);summary.setPadding(0,0,0,dp(10));footer.addView(summary);
        send=new Button(activity);send.setAllCaps(false);send.setText(words("دەستپێکردنی گواستنەوە","Start transfer","بدء النقل"));send.setTextColor(Color.WHITE);send.setTextSize(16);send.setTypeface(null,Typeface.BOLD);send.setBackground(box(BLUE,14));footer.addView(send,new LayoutParams(-1,dp(54)));
        send.setOnClickListener(v->{Set<String> chosen=selection();if(!chosen.isEmpty()){send.setEnabled(false);all.setEnabled(false);for(CheckBox check:checks.values())check.setEnabled(false);actions.send(chosen,new LinkedHashSet<>(appPackages));}});
        all.setOnClickListener(v->{boolean complete=true;for(CheckBox check:checks.values())if(check.isEnabled()&&!check.isChecked())complete=false;for(CheckBox check:checks.values())if(check.isEnabled())check.setChecked(!complete);refresh();});refresh();
    }
    private Set<String> selection(){LinkedHashSet<String> selected=new LinkedHashSet<>();for(Map.Entry<String,CheckBox> row:checks.entrySet())if(row.getValue().isEnabled()&&row.getValue().isChecked()&&(!"apps".equals(row.getKey())||!appPackages.isEmpty()))selected.add(row.getKey());return selected;}
    private void refresh(){if(summary==null||send==null||all==null)return;Set<String> selected=selection();long count=0,bytes=0;boolean unknown=false,complete=true;for(UsbCloneProtocol.Category c:categories){if(c.count>0&&!selected.contains(c.id))complete=false;if(selected.contains(c.id)){if("apps".equals(c.id)){count+=appPackages.size();for(CloneAppPicker.App app:apps)if(appPackages.contains(app.packageName))bytes+=app.bytes;}else{count+=c.count;if(c.bytes<0)unknown=true;else bytes+=c.bytes;}}}
        if(appsInfo!=null){long appBytes=0;for(CloneAppPicker.App app:apps)if(appPackages.contains(app.packageName))appBytes+=app.bytes;appsInfo.setText(appPackages.size()+" / "+apps.size()+words(" دانە"," apps"," تطبيق")+"  ·  "+TransferStats.size(appBytes));}
        summary.setText(count+words(" دانە هەڵبژێردراوە"," items selected"," عنصر محدد")+"  ·  "+TransferStats.size(bytes)+(unknown?" +":""));send.setEnabled(!selected.isEmpty());send.setAlpha(send.isEnabled()?1f:.45f);all.setText(complete?words("لابردنی هەموو","Clear all","إلغاء الكل"):words("هەڵبژاردنی هەموو","Select all","تحديد الكل"));}
    static String name(String id){switch(id){case "photos":return UiText.t(16);case "videos":return UiText.t(18);case "audio":return UiText.t(20);case "documents":return "en".equals(UiText.language())?"Documents":"ar".equals(UiText.language())?"المستندات":"بەڵگەنامەکان";case "files":return UiText.t(26);case "apps":return UiText.t(22);case "contacts":return UiText.t(24);case "calls":return UiText.t(229);case "sms":return UiText.t(230);default:return id;}}
    private int icon(String id){switch(id){case "documents":return R.drawable.clone_category_documents;case "photos":return R.drawable.clone_category_photos;case "videos":return R.drawable.clone_category_videos;case "audio":return R.drawable.clone_category_audio;case "apps":return R.drawable.clone_category_apps;case "contacts":return R.drawable.clone_category_contacts;case "calls":return R.drawable.clone_category_calls;case "sms":return R.drawable.clone_category_sms;default:return R.drawable.clone_category_files;}}
    private int accent(String id){switch(id){case "documents":return 0xffd97706;case "photos":return 0xff2563eb;case "videos":return 0xff7c3aed;case "audio":return 0xffdb2777;case "apps":return 0xff0891b2;case "contacts":return 0xff059669;case "calls":return 0xff16a34a;case "sms":return 0xff4f46e5;default:return 0xffd97706;}}
    private String words(String ckb,String en,String ar){return "en".equals(UiText.language())?en:"ar".equals(UiText.language())?ar:ckb;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable box(int color,int radius){GradientDrawable shape=new GradientDrawable();shape.setColor(color);shape.setCornerRadius(dp(radius));return shape;}
    private TextView text(String label,int size,int color,boolean bold){TextView view=new TextView(activity);view.setText(label);view.setTextSize(size);view.setTextColor(color);view.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);if(bold)view.setTypeface(null,Typeface.BOLD);return view;}
}
