package com.abdulla.clonephone;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.hardware.usb.UsbManager;
import android.net.*;
import android.provider.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.res.ColorStateList;
import android.view.*;
import android.widget.*;
import com.google.zxing.*;
import com.google.zxing.common.*;
import com.google.zxing.qrcode.QRCodeWriter;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int FILES=10,FOLDER=11,SCAN=12,QR_IMAGE=13,WIFI_SETTINGS=14,LOCATION_SETTINGS=15,UNINSTALL_APP=16,CAMERA_PERMISSION=20,DATA_PERMISSION=21,HOTSPOT_PERMISSION=22,SETUP_PERMISSION=23,SETUP_SETTINGS=24,PORT=39841,MAX_FILES=100000;
    private static final int BLUE=0xff4f46e5,INK=0xff152238,MUTED=0xff627089,BG=0xfff3f5fa;
    // A permanent catalogue URL: keep this QR unchanged and publish each new APK
    // (and its version notes) at this address.
    private static final String DOWNLOAD_CATALOG_URL="https://app.mediafire.com/folder/omye30rljf3px";
    // The public release manifest.  It contains only version metadata and the
    // direct, signed APK URL; a missing or unreachable manifest is ignored.
    private static final String UPDATE_MANIFEST_URL="https://rebaritclone-update-admin.rebar4qwrna.workers.dev/update.json";
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final LinkedHashMap<String,List<Item>> groups=new LinkedHashMap<>();
    private final List<Item> selection=new ArrayList<>();
    private final Map<String,Set<String>> selectedRecords=new HashMap<>();
    private final Set<String> selectedApps=new HashSet<>();
    private final LinkedHashMap<String,Item> receivedFiles=new LinkedHashMap<>();
    private final LinkedHashMap<String,String> receivedApps=new LinkedHashMap<>();
    private void installReceivedApps(){if(receivedApps.isEmpty())return;Intent i=new Intent(this,AppInstallActivity.class);i.putStringArrayListExtra("uris",new ArrayList<>(receivedApps.keySet()));i.putStringArrayListExtra("names",new ArrayList<>(receivedApps.values()));startActivity(i);}
    private LinearLayout body,root;
    private NearbyClone nearby;
    private boolean nearbyTransfer,cloneAutoNegotiation;
    private int failedCloneBands,clonePeerBandMask=7,pendingNearbyBand;
    private Set<String> cloneAppSelection;
    private final long[] cloneRecordCounts=new long[3];
    private AlertDialog nearbyApproval;
    private SendFilePicker sendPicker;
    private static final int SEND_PICKER_PERMISSION=27,SEND_FILES_SETTINGS=28;
    private final List<SendFilePicker.Entry> pickerContacts=new ArrayList<>();
    private void closeGallery(){
        if(sendPicker!=null){
            if(uninstallPicker==sendPicker){uninstallQueue.clear();uninstallPicker=null;}
            sendPicker.close();sendPicker=null;
        }
    }
    private TextView subtitle,status,percentage,details;
    private final TextView[] categoryProgress=new TextView[TransferStats.KINDS];
    private ProgressBar progress;
    private String screen="home",pendingCategory,pairText;
    private Uri folder,lastContact;
    private volatile Socket socket;
    private volatile ServerSocket listener;
    private volatile boolean busy,cancelled;
    private volatile CountDownLatch approval;
    private AlertDialog approvalDialog;
    private final ArrayDeque<String> uninstallQueue=new ArrayDeque<>();
    private String uninstallCurrentPackage;
    private SendFilePicker uninstallPicker;

    /** Selected user apps are removed only by Android's own confirmation UI. */
    private void uninstallPickerApps(List<SendFilePicker.Entry> entries){
        if(busy||uninstallCurrentPackage!=null||uninstallPicker!=null||sendPicker==null)return;
        LinkedHashSet<String> packages=new LinkedHashSet<>();
        for(SendFilePicker.Entry entry:entries){
            if(entry.app==null)continue;
            String packageName=entry.app.packageName;
            try{
                ApplicationInfo app=getPackageManager().getApplicationInfo(packageName,0);
                if(!packageName.equals(getPackageName())&&(app.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))==0)packages.add(packageName);
            }catch(PackageManager.NameNotFoundException ignored){}
        }
        if(packages.isEmpty()){toast("هیچ ئەپێکی دامەزراوی گونجاو بۆ سڕینەوە هەڵنەبژێردراوە");return;}
        savePickerSelection();uninstallPicker=sendPicker;
        uninstallQueue.clear();uninstallQueue.addAll(packages);launchNextUninstall();
    }
    private void uninstallPickerFinished(String packageName,boolean success){
        if(success){
            selectedApps.remove(packageName);
            // Prepared bundles are rebuilt from the remaining installed selection.
            groups.remove("apps");
            appLabelCache.remove(packageName);
        }
        if(uninstallPicker!=null&&uninstallPicker==sendPicker)uninstallPicker.uninstallFinished(packageName,success);
    }
    private void launchNextUninstall(){
        if(isFinishing()||isDestroyed()||uninstallPicker==null||uninstallPicker!=sendPicker){uninstallQueue.clear();uninstallCurrentPackage=null;uninstallPicker=null;return;}
        while(!uninstallQueue.isEmpty()){
            String packageName=uninstallQueue.removeFirst();
            try{
                ApplicationInfo app=getPackageManager().getApplicationInfo(packageName,0);
                if(packageName.equals(getPackageName())||(app.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0)continue;
                uninstallCurrentPackage=packageName;
                Intent uninstall=new Intent(Intent.ACTION_UNINSTALL_PACKAGE,Uri.parse("package:"+packageName));
                uninstall.putExtra(Intent.EXTRA_RETURN_RESULT,true);
                startActivityForResult(uninstall,UNINSTALL_APP);
                return;
            }catch(PackageManager.NameNotFoundException ignored){uninstallPickerFinished(packageName,true);}
            catch(ActivityNotFoundException|SecurityException error){
                uninstallCurrentPackage=null;uninstallQueue.clear();uninstallPickerFinished(packageName,false);uninstallPicker=null;
                toast("نەتوانرا پەنجەرەی Android Uninstall بکرێتەوە");return;
            }
        }
        uninstallCurrentPackage=null;uninstallPicker=null;
        toast("سڕینەوەی ئەپە هەڵبژێردراوەکان تەواو بوو");
    }
    private int completed;
    private long totalBytes,finishedBytes,lastUpdate,startTime;
    private boolean totalKnown;
    private TransferStats transferStats;
    private long resumedBytes,transferStarted;
    private String sendingId="",sendingManifest="",receivingId="",receivingManifest="",receivingBatch,usbApprovedManifest="";
    private Uri receivingLegacy;
    private final Map<Integer,ResumableFile.Entry> resumeEntries=new HashMap<>();
    private File receivingJournal;
    private boolean migratingReceiveJournal;
    private String pendingJournalHeader;
    private final Map<String,Uri> receivedIdentity=new HashMap<>();
    private final Map<Integer,SavedFile> resumeTargets=new HashMap<>();
    private boolean returnHomeAfterJob;
    private final LinkedHashSet<String> cloneControllerSelectionCache=new LinkedHashSet<>();
    private final LinkedHashSet<String> cloneSourceConsentCache=new LinkedHashSet<>();
    private List<Item> cloneRetryItems=new ArrayList<>();
    private boolean restartReceiveBand,receivedRecordBackup;
    private int receiveBand=HotspotLink.BAND_AUTO;
    private volatile boolean receivePeerConnected;
    // Phone Clone Wi-Fi flow: old phone hosts the QR/source, new phone scans and controls selection.
    private boolean phoneCloneController,phoneCloneSource,cloneControllerAuthorized,restartCloneBand;
    private int cloneBand=HotspotLink.BAND_AUTO,cloneRequestedBand=HotspotLink.BAND_AUTO;
    private String manifest(List<Item> items,boolean source){StringBuilder b=new StringBuilder();for(Item i:items)b.append(source?i.uri.toString():"").append('\n').append(safeName(i.name)).append('\n').append(validMime(i.mime)).append('\n').append(i.size).append('\n').append(safeRelativePath(i.relativePath)).append('\n').append(i.modified).append('\n').append(i.taken).append('\n');return b.toString();}
    private HotspotLink hotspot;
    private UsbLink usb;
    private boolean usbMode,resumeFolder,resumeUsbFolder;
    private List<Item> usbRetryItems=new ArrayList<>();
    private final LinkedHashSet<String> usbControllerSelectionCache=new LinkedHashSet<>();
    private final LinkedHashSet<String> usbSourceConsentCache=new LinkedHashSet<>();
    private boolean usbAutoResume=false;
    private int usbReconnectAttempts=0;
    private String lastHotspotError="";
    private Network transferNetwork;
    private boolean linking;
    private String hotspotSsid="",hotspotPassword="";
    private volatile Pairing pendingPeer;
    private String hostPairCode="";
    private boolean hostRecoveryInProgress;
    private boolean senderPaired;
    private SecureChannel selectedUsbChannel;
    private Runnable afterWifiPermission,afterCloneLinkSettings;
    private int linkGeneration;
    private List<String[]> setupSteps;
    private int setupIndex;
    private boolean setupReceiving,setupActive,setupWaiting,usbSourcePermissionFlow,usbControllerAuthorized;
    private final List<File> usbPreparedTemps=new ArrayList<>();
    private long lastNotification;
    private static final String TRANSFER_CHANNEL="transfer";
    private void startUsbSourcePermissions(){
        if(setupActive)return;
        usbSourcePermissionFlow=true;setupReceiving=false;setupActive=true;setupWaiting=false;setupIndex=0;
        setupSteps=PermissionPlan.forUsbSource(Build.VERSION.SDK_INT);
        page("permissions",UiText.t(246),"مۆبایلی کۆن: تەنها مۆڵەتە پێویستەکان بۆ خوێندنەوەی داتاکان",0);
        note("مۆبایلی تازە دیاری دەکات چی وەربگرێت. لەم مۆبایلە تەنها ڕەزامەندی دەدرێت.");
        nextPermission();
    }
    private void startPermissions(boolean receiving){
        if(setupActive)return;
        phoneCloneController=receiving;phoneCloneSource=!receiving;cloneControllerAuthorized=false;
        setupReceiving=receiving;setupActive=true;setupWaiting=false;setupIndex=0;
        setupSteps=PermissionPlan.forRole(Build.VERSION.SDK_INT,receiving);
        clonePage("permissions",UiText.t(246),UiText.t(247),0);
        note(UiText.t(248));
        nextPermission();
    }
    private void nextPermission(){
        if(!setupActive||isDestroyed()||isFinishing()||setupWaiting)return;
        while(setupIndex<setupSteps.size()){
            String[] step=setupSteps.get(setupIndex++);
            boolean missing=false;for(String permission:step)missing|=checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED;
            if(!missing)continue;
            setupWaiting=true;
            try{requestPermissions(step,SETUP_PERMISSION);return;}
            catch(SecurityException e){setupWaiting=false;}
        }
        permissionSummary();
    }
    private void permissionSummary(){
        boolean missing=false;
        for(String[] step:setupSteps)for(String permission:step)if(!permission.equals(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)&&checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED)missing=true;
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(manager!=null&&!manager.areNotificationsEnabled())missing=true;
        if(!missing){finishPermissions();return;}
        page("permissions",UiText.t(246),UiText.t(249),0);
        note(UiText.t(248));
        button(UiText.t(250),false,()->{try{startActivityForResult(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())),SETUP_SETTINGS);}catch(ActivityNotFoundException e){toast(UiText.t(249));}});
        button(UiText.t(28),true,()->finishPermissions());
        button(UiText.t(29),false,()->{setupActive=false;usbSourcePermissionFlow=false;home();});
    }
    private void finishPermissions(){
        boolean receiving=setupReceiving;setupActive=false;setupWaiting=false;
        if(usbSourcePermissionFlow){usbSourcePermissionFlow=false;startUsb(false);return;}
        if(receiving){
            if(Build.VERSION.SDK_INT<29&&folder==null){resumeFolder=true;chooseFolder();return;}
            startCloneReceiverHost(cloneBand);
        }else cloneSourceScanPage();
    }
    private void transferNotification(String message,int percent,boolean finished){
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(manager==null||!manager.areNotificationsEnabled())return;
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        long now=SystemClock.elapsedRealtime();if(!finished&&percent>=0&&now-lastNotification<1500)return;lastNotification=now;
        manager.createNotificationChannel(new NotificationChannel(TRANSFER_CHANNEL,UiText.t(251),NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder notification=new Notification.Builder(this,TRANSFER_CHANNEL).setSmallIcon(android.R.drawable.stat_sys_upload).setContentTitle("REBARIT CLONE").setContentText(message).setContentIntent(tap).setOnlyAlertOnce(true).setOngoing(!finished).setAutoCancel(finished).setVisibility(Notification.VISIBILITY_PRIVATE);
        if(!finished)notification.setProgress(1000,Math.max(0,percent),percent<0);
        try{manager.notify(74,notification.build());}catch(SecurityException ignored){}
    }
    private final Handler main=new Handler(Looper.getMainLooper());
    // Cached labels used when restoring the send picker selection.
    private final ConcurrentHashMap<String,String> appLabelCache=new ConcurrentHashMap<>();

    // VIP v11.9: smart clone / preflight / history / health / privacy state.
    private final ArrayList<String> transferHistory=new ArrayList<>();
    private boolean privacyMode=true;
    private long vipTransferStarted=0L;
    private String vipTransport="AUTO";
    private void vipHistory(String line){
        String stamp=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date());
        transferHistory.add(0,stamp+" • "+line);
        while(transferHistory.size()>30)transferHistory.remove(transferHistory.size()-1);
        try{getPreferences(0).edit().putString("vip_history",android.text.TextUtils.join("\n",transferHistory)).apply();}catch(Exception ignored){}
    }
    private void loadVipHistory(){
        if(!transferHistory.isEmpty())return;
        String raw=getPreferences(0).getString("vip_history","");
        if(!raw.isEmpty())transferHistory.addAll(Arrays.asList(raw.split("\n")));
    }
    private long freeStorage(){
        try{android.os.StatFs s=new android.os.StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());return s.getAvailableBytes();}catch(Exception e){return -1;}
    }
    private String preflightText(List<Item> items){
        long total=0;boolean unknown=false;for(Item i:items){if(i.size<0)unknown=true;else total+=i.size;}
        long free=freeStorage();String storage=free<0?"—":TransferStats.size(free);
        return "VIP Transfer Check\n"+items.size()+" files • "+TransferStats.size(total)+(unknown?" +":"")+"\nFree storage: "+storage+"\nBattery: "+batteryPercent()+"%\nPrivacy: Device-to-Device only";
    }
    private int batteryPercent(){
        try{android.os.BatteryManager b=(android.os.BatteryManager)getSystemService(BATTERY_SERVICE);return b.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);}catch(Exception e){return -1;}
    }
    private long remainingStorage(List<Item> items)throws IOException{
        long[] sizes=new long[items.size()],retained=new long[items.size()];boolean[] done=new boolean[items.size()];
        for(int n=0;n<items.size();n++){
            sizes[n]=items.get(n).size;ResumableFile.Entry entry=resumeEntries.get(n+1);
            if(entry!=null){done[n]=entry.done;retained[n]=entry.done?entry.length:entry.storage.length();}
        }
        return TransferSpace.remaining(sizes,retained,done);
    }
    private long[] pendingStorage(List<Item> items)throws IOException{
        long[] pending=new long[items.size()+1];
        for(int n=items.size()-1;n>=0;n--){ResumableFile.Entry entry=resumeEntries.get(n+1);long retained=entry==null?0:entry.done?entry.length:entry.storage.length();long extra=TransferSpace.remaining(items.get(n).size,retained,entry!=null&&entry.done);pending[n]=extra>Long.MAX_VALUE-pending[n+1]?Long.MAX_VALUE:extra+pending[n+1];}
        return pending;
    }
    private boolean enoughStorage(List<Item> items)throws IOException{
        return Build.VERSION.SDK_INT<29||TransferSpace.fits(remainingStorage(items),freeStorage());
    }
    private void showTransferHistory(){
        loadVipHistory();page("vipHistory","Transfer History","REBARIT CLONE VIP",0);
        if(transferHistory.isEmpty())summaryCard("No transfers yet");
        else for(String h:transferHistory)summaryCard(h);
        button(UiText.t(111),false,()->home());
    }


    static class Item {
        Uri uri;String name,mime,relativePath="";long size,modified=-1,taken=-1;
        Item(){}
        Item(Uri u,String n,String m,long s){uri=u;name=n;mime=m;size=s;}
    }
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);UiText.init(this);hotspot=new HotspotLink(this);usb=new UsbLink(this);onlineUpdate=new OnlineUpdate(this,()->busy);restoreSenderCheckpoint();home();handleUsbLaunch(getIntent());}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handleUsbLaunch(intent);}
    private void handleUsbLaunch(Intent intent){
        try{
            if(intent==null)return;String a=intent.getAction();
            if(!UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)&&!UsbManager.ACTION_USB_ACCESSORY_ATTACHED.equals(a))return;
            main.postDelayed(()->{
                try{
                    if(isDestroyed()||busy||linking||usbAutoResume||"usb".equals(screen)||"usbWaiting".equals(screen))return;
                    // USB system intents must never crash the Activity. The user still chooses
                    // the logical new-phone/old-phone role inside REBARIT CLONE.
                    usbRoles();
                }catch(Throwable ignored){}
            },250);
        }catch(Throwable ignored){}
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable box(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private TextView label(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.START);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);t.setLineSpacing(dp(4),1);t.setFontFeatureSettings("kern");if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private void gap(int height){Space s=new Space(this);body.addView(s,new LinearLayout.LayoutParams(1,dp(height)));}
    private TextView text(String value,int size,int color,boolean bold){TextView t=label(value,size,color,bold);body.addView(t);return t;}
    private void page(String id,String title,String description,int step){
        closeGallery();
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        screen=id;root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setLayoutDirection(UiText.direction());
        root.setPadding(dp(24),dp(18),dp(24),dp(14));setContentView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);root.addView(top);
        TextView brand=label("REBARIT CLONE",19,INK,true);brand.setTextDirection(View.TEXT_DIRECTION_LTR);top.addView(brand,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView badge=label(UiText.t(295)+versionName(),11,BLUE,true);badge.setPadding(dp(10),dp(6),dp(10),dp(6));badge.setBackground(box(0xffe8e8ff,20));top.addView(badge);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(12),0,dp(24));scroll.addView(body);
        // The journey is always shown in the same order:
        // 1. Connect  →  2. Select  →  3. Transfer.
        if(step>0){steps(step);gap(24);}
        text(title,28,INK,true);gap(10);subtitle=text(description,15,MUTED,false);gap(24);
    }
    private void steps(int active){
        LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);body.addView(line,new LinearLayout.LayoutParams(-1,-2));
        for(int n=1;n<=3;n++){TextView chip=label((n<active?"✓":String.valueOf(n))+"  "+UiText.t(n==1?270:n==2?269:271),11,n==active?Color.WHITE:n<active?BLUE:MUTED,true);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(4),dp(10),dp(4),dp(10));chip.setBackground(box(n==active?BLUE:n<active?0xffe8e8ff:0xffe9edf5,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),0,dp(2),0);line.addView(chip,lp);}
    }
    private TextView summaryCard(String message){TextView v=text(message,16,INK,true);v.setPadding(dp(18),dp(18),dp(18),dp(18));v.setBackground(box(Color.WHITE,20));return v;}
    private Button button(String title,boolean primary,Runnable click){
        Button b=new Button(this);b.setText(title);b.setTextSize(16);b.setAllCaps(false);b.setTypeface(null,Typeface.BOLD);b.setTextColor(primary?Color.WHITE:BLUE);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x222563eb),box(primary?BLUE:0xffeaf0fd,18),null));
        b.setMinHeight(dp(56));b.setPadding(dp(16),dp(14),dp(16),dp(14));b.setElevation(primary?dp(2):0);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));body.addView(b,lp);b.setOnClickListener(v->click.run());return b;
    }
    private void note(String message){gap(12);TextView t=text(message,13,MUTED,false);t.setPadding(dp(14),dp(12),dp(14),dp(12));t.setBackground(box(0xffe9edf5,14));}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private void alert(String title,String message){new AlertDialog.Builder(UiText.context(this)).setTitle(title).setMessage(message).setPositiveButton(UiText.t(2),null).show();}
    private void chooseLanguage(){
        String[] codes={"ckb","en","ar"};String[] labels={"کوردی","English","العربية"};int selected=Arrays.asList(codes).indexOf(UiText.language());
        new AlertDialog.Builder(UiText.context(this)).setTitle(receiveText("زمان","Language","اللغة")).setSingleChoiceItems(labels,selected,(dialog,which)->{UiText.select(this,codes[which]);dialog.dismiss();home();}).setNegativeButton(UiText.t(61),null).show();
    }
    private static final int NIGHT=0xff050b12,LIGHT=0xfff4faff;
    private void darkScreen(String id,String title){
        closeGallery();
        screen=id;root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(NIGHT);root.setLayoutDirection(UiText.direction());root.setPadding(dp(22),dp(12),dp(22),dp(12));setContentView(root);
        getWindow().setStatusBarColor(NIGHT);getWindow().setNavigationBarColor(NIGHT);getWindow().getDecorView().setSystemUiVisibility(0);
        FrameLayout bar=new FrameLayout(this);root.addView(bar,new LinearLayout.LayoutParams(-1,dp(50)));
        if(!id.equals("home")){TextView back=label("‹",32,LIGHT,true);back.setGravity(Gravity.CENTER);back.setContentDescription(UiText.t(29));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(40),-1,Gravity.START|Gravity.CENTER_VERTICAL);bar.addView(back,bp);back.setOnClickListener(v->home());}
        LinearLayout brandBox=new LinearLayout(this);brandBox.setOrientation(LinearLayout.VERTICAL);brandBox.setGravity(Gravity.CENTER);
        TextView brand=label(id.equals("home")?"REBARIT CLONE":title,id.equals("home")?18:20,LIGHT,true);brand.setGravity(Gravity.CENTER);brand.setTextDirection(View.TEXT_DIRECTION_LTR);brandBox.addView(brand,new LinearLayout.LayoutParams(-2,-2));
        if(id.equals("home")){TextView version=label("v"+versionName(),10,0xff8ea6b8,false);version.setGravity(Gravity.CENTER);version.setTextDirection(View.TEXT_DIRECTION_LTR);brandBox.addView(version,new LinearLayout.LayoutParams(-2,-2));}
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER);bar.addView(brandBox,cp);
        TextView menu=label("⋮",28,LIGHT,true);menu.setGravity(Gravity.CENTER);menu.setContentDescription(UiText.t(262));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(40),-1,Gravity.END|Gravity.CENTER_VERTICAL);bar.addView(menu,mp);
        menu.setOnClickListener(v->{PopupMenu options=new PopupMenu(this,menu);options.getMenu().add(receiveText("زمان","Language","اللغة")).setOnMenuItemClickListener(i->{chooseLanguage();return true;});options.getMenu().add(UiText.t(310)).setOnMenuItemClickListener(i->{shareOwnApk();return true;});
            options.getMenu().add(UiText.t(290)).setOnMenuItemClickListener(i->{showAppDownloadQr();return true;});options.getMenu().add(onlineUpdate.menuTitle()).setOnMenuItemClickListener(i->{onlineUpdate.checkManually();return true;});options.show();});
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(12),0,dp(16));scroll.addView(body);
    }
    private void appDownloadPage(){
        page("download",UiText.t(290),UiText.t(291),0);
        try{
            int side=620;BitMatrix matrix=new QRCodeWriter().encode(DOWNLOAD_CATALOG_URL,BarcodeFormat.QR_CODE,side,side);int[] pixels=new int[side*side];
            for(int y=0;y<side;y++)for(int x=0;x<side;x++)pixels[y*side+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
            ImageView qr=new ImageView(this);qr.setImageBitmap(Bitmap.createBitmap(pixels,side,side,Bitmap.Config.ARGB_8888));qr.setContentDescription(UiText.t(292));qr.setScaleType(ImageView.ScaleType.FIT_CENTER);qr.setBackground(box(Color.WHITE,24));qr.setPadding(dp(10),dp(10),dp(10),dp(10));
            int width=Math.min(dp(286),getResources().getDisplayMetrics().widthPixels-dp(48));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(width,width);lp.gravity=Gravity.CENTER;body.addView(qr,lp);
        }catch(Exception e){throw new IllegalStateException(e);}
        gap(18);TextView version=text(UiText.t(295)+versionName(),15,BLUE,true);version.setGravity(Gravity.CENTER);
        TextView url=text(DOWNLOAD_CATALOG_URL,13,MUTED,false);url.setTextDirection(View.TEXT_DIRECTION_LTR);url.setGravity(Gravity.CENTER);url.setTextIsSelectable(true);gap(12);
        button(UiText.t(293),true,this::openDownloadCatalog);
        button(UiText.t(294),false,()->{android.content.ClipboardManager c=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);c.setPrimaryClip(ClipData.newPlainText("rebaritclone download",DOWNLOAD_CATALOG_URL));toast(UiText.t(296));});
        button(UiText.t(29),false,this::home);
    }
    private String versionName(){try{return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception e){return "";}}
    private void showAppDownloadQr(){
        final String url="https://rebarit.store/app";
        LinearLayout panel=new LinearLayout(UiText.context(this));panel.setOrientation(LinearLayout.VERTICAL);panel.setGravity(Gravity.CENTER);panel.setPadding(dp(24),dp(24),dp(24),dp(20));
        TextView title=label("دابەزاندنی بەرنامە",22,INK,true);title.setGravity(Gravity.CENTER);panel.addView(title);
        TextView sub=label("QR ـەکە سکان بکە",13,MUTED,false);sub.setGravity(Gravity.CENTER);sub.setPadding(0,dp(6),0,dp(16));panel.addView(sub);
        ImageView qr=new ImageView(this);
        try{
            BitMatrix matrix=new QRCodeWriter().encode(url,BarcodeFormat.QR_CODE,720,720);
            int side=720;int[] pixels=new int[side*side];
            for(int y=0;y<side;y++)for(int x=0;x<side;x++)pixels[y*side+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
            qr.setImageBitmap(Bitmap.createBitmap(pixels,side,side,Bitmap.Config.ARGB_8888));
        }catch(Exception e){qr.setContentDescription("QR error");}
        panel.addView(qr,new LinearLayout.LayoutParams(dp(280),dp(280)));
        TextView address=label("rebarit.store/app",18,BLUE,true);address.setTextDirection(View.TEXT_DIRECTION_LTR);address.setGravity(Gravity.CENTER);address.setPadding(0,dp(14),0,dp(4));panel.addView(address);
        AlertDialog dialog=new AlertDialog.Builder(UiText.context(this)).setView(panel).setNegativeButton("داخستن",null).create();dialog.show();
    }

    private void shareOwnApk(){
        try{
            Uri apk=Uri.parse("content://"+getPackageName()+".share/apk");
            Intent send=new Intent(Intent.ACTION_SEND);
            send.setType("application/vnd.android.package-archive");
            send.putExtra(Intent.EXTRA_STREAM,apk);
            send.setClipData(ClipData.newRawUri(UiText.t(310),apk));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send,UiText.t(310)));
        }catch(ActivityNotFoundException|SecurityException e){toast(UiText.t(311));}
    }
    private void openDownloadCatalog(){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(DOWNLOAD_CATALOG_URL)));}catch(Exception e){toast(UiText.t(297));}}
    private OnlineUpdate onlineUpdate;
    @Override protected void onResume(){super.onResume();if(onlineUpdate!=null)onlineUpdate.resume();}
    @Override protected void onPause(){if(onlineUpdate!=null)onlineUpdate.pause();super.onPause();}
    private void home(){
        if(!busy){stopLink();senderPaired=false;selectedUsbChannel=null;phoneCloneController=false;phoneCloneSource=false;cloneControllerAuthorized=false;restartCloneBand=false;restartReceiveBand=false;}
        closeGallery();
        screen="home";
        getWindow().setStatusBarColor(0xfff7faff);
        getWindow().setNavigationBarColor(0xfff7faff);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xfff7faff);
        root.setLayoutDirection(UiText.direction());
        setContentView(root);

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,-1));

        body=new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18),dp(18),dp(18),dp(28));
        scroll.addView(body,new ScrollView.LayoutParams(-1,-2));

        // Single premium home header — no duplicated REBAR IT CLONE title.
        FrameLayout header=new FrameLayout(this);
        body.addView(header,new LinearLayout.LayoutParams(-1,dp(116)));

        LinearLayout brandBox=new LinearLayout(this);
        brandBox.setOrientation(LinearLayout.VERTICAL);
        brandBox.setGravity(Gravity.CENTER);
        TextView brand=label("REBAR IT CLONE",30,0xff0d1830,true);
        brand.setGravity(Gravity.CENTER);
        brand.setTextDirection(View.TEXT_DIRECTION_LTR);
        brand.setLetterSpacing(0.02f);
        brandBox.addView(brand,new LinearLayout.LayoutParams(-2,-2));

        TextView version=label(receiveText("وەشانی نوێ  ","Version  ","الإصدار  ")+versionName(),12,0xff2459ea,true);
        version.setGravity(Gravity.CENTER);
        version.setPadding(dp(14),dp(6),dp(14),dp(6));
        version.setBackground(box(0xffeaf0ff,22));
        LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-2,-2);
        vp.gravity=Gravity.CENTER;
        vp.topMargin=dp(10);
        brandBox.addView(version,vp);

        FrameLayout.LayoutParams brandLp=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER);
        header.addView(brandBox,brandLp);

        TextView menu=label("⋮",28,0xff5f6f86,true);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription(UiText.t(262));
        FrameLayout.LayoutParams menuLp=new FrameLayout.LayoutParams(dp(42),dp(48),Gravity.END|Gravity.TOP);
        header.addView(menu,menuLp);
        menu.setOnClickListener(v->{
            PopupMenu options=new PopupMenu(this,menu);
            options.getMenu().add(receiveText("زمان","Language","اللغة")).setOnMenuItemClickListener(i->{chooseLanguage();return true;});
            options.getMenu().add(UiText.t(310)).setOnMenuItemClickListener(i->{shareOwnApk();return true;});
            options.getMenu().add(UiText.t(290)).setOnMenuItemClickListener(i->{showAppDownloadQr();return true;});
            options.getMenu().add(onlineUpdate.menuTitle()).setOnMenuItemClickListener(i->{onlineUpdate.checkManually();return true;});
            options.show();
        });

        premiumHomeCard(
                receiveText("مۆبايل بۆ مۆبايل","Phone to phone","من هاتف إلى هاتف"),
                R.drawable.action_clone,0xff1677ff,0xff4ba1ff,0xffeef6ff,()->deviceRoles(false));
        premiumHomeCard(
                receiveText("ناردن","Send","إرسال"),
                R.drawable.action_send,0xff0fbf62,0xff35d97d,0xffeffcf4,this::openSendPicker);
        premiumHomeCard(
                receiveText("وەرگرتن","Receive","استقبال"),
                R.drawable.action_receive,0xff7c3aed,0xffa855f7,0xfff6efff,this::startReceiveQr);
        premiumHomeCard(
                receiveText("ناردن بە کێبڵ","Send via cable","الإرسال عبر كابل"),
                R.drawable.action_usb,0xffff3b5c,0xffff6b7f,0xffffeef1,this::usbRoles);
    }

    private void premiumHomeCard(String title,int iconResource,int accentStart,int accentEnd,int pale,Runnable click){
        LinearLayout card=new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18),dp(15),dp(16),dp(15));

        GradientDrawable surface=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.WHITE,pale});
        surface.setCornerRadius(dp(28));
        surface.setStroke(dp(1),0xffe7edf5);
        card.setBackground(new RippleDrawable(ColorStateList.valueOf((accentStart&0x00ffffff)|0x18000000),surface,null));
        card.setElevation(dp(2));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(128));
        cp.setMargins(0,0,0,dp(14));
        body.addView(card,cp);

        // Soft circular arrow pill on the leading edge.
        TextView arrow=label("›",35,accentStart,false);
        arrow.setGravity(Gravity.CENTER);
        GradientDrawable arrowBg=box((accentStart&0x00ffffff)|0x12000000,40);
        arrowBg.setStroke(dp(1),(accentStart&0x00ffffff)|0x26000000);
        arrow.setBackground(arrowBg);
        card.addView(arrow,new LinearLayout.LayoutParams(dp(40),dp(40)));

        LinearLayout words=new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setGravity(Gravity.CENTER_VERTICAL);
        words.setPadding(dp(12),0,dp(10),0);
        card.addView(words,new LinearLayout.LayoutParams(0,-1,1));

        TextView t=label(title,22,0xff101a31,true);
        t.setSingleLine(true);
        if(Build.VERSION.SDK_INT>=26)t.setAutoSizeTextTypeUniformWithConfiguration(14,22,1,android.util.TypedValue.COMPLEX_UNIT_SP);
        t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        words.addView(t,new LinearLayout.LayoutParams(-1,-2));

        ImageView icon=new ImageView(this);
        icon.setImageResource(iconResource);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        icon.setPadding(dp(12),dp(12),dp(12),dp(12));
        icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        GradientDrawable iconBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{accentStart,accentEnd});
        iconBg.setCornerRadius(dp(24));
        icon.setBackground(iconBg);
        icon.setElevation(dp(3));
        card.addView(icon,new LinearLayout.LayoutParams(dp(64),dp(64)));

        card.setFocusable(true);
        card.setClickable(true);
        card.setOnClickListener(v->click.run());
    }

    private void landingCard(String title,String description,String action,int first,int second,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(20),dp(20),dp(20),dp(16));
        GradientDrawable background=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{first,second});background.setCornerRadius(dp(20));card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff),background,null));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(14));body.addView(card,cp);
        TextView heading=label(title,23,LIGHT,true);card.addView(heading);
        TextView sub=label(description,13,Color.WHITE,false);card.addView(sub);
        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.END);footer.setPadding(0,dp(16),0,0);card.addView(footer);
        TextView pill=label(action+"  ›",14,Color.WHITE,true);pill.setGravity(Gravity.CENTER);pill.setPadding(dp(20),dp(5),dp(20),dp(5));GradientDrawable border=box(Color.TRANSPARENT,24);border.setStroke(dp(1),0xddffffff);pill.setBackground(border);footer.addView(pill);
        card.setFocusable(true);card.setOnClickListener(v->click.run());
    }
    private void landingUsbCard(String title,String description,String action,int first,int second,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(20),dp(18),dp(20),dp(16));
        GradientDrawable background=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{first,second});background.setCornerRadius(dp(20));card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff),background,null));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(14));body.addView(card,cp);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER);card.addView(top,new LinearLayout.LayoutParams(-1,-2));
        TextView usbBadge=label("USB",20,Color.WHITE,true);usbBadge.setGravity(Gravity.CENTER);usbBadge.setPadding(dp(16),dp(8),dp(16),dp(8));
        GradientDrawable badgeBg=box(0x26ffffff,16);badgeBg.setStroke(dp(1),0x90ffffff);usbBadge.setBackground(badgeBg);top.addView(usbBadge);top.setPadding(0,0,0,dp(12));
        TextView heading=label(title,23,LIGHT,true);heading.setGravity(Gravity.CENTER);card.addView(heading);
        TextView sub=label(description,13,Color.WHITE,false);sub.setGravity(Gravity.CENTER);card.addView(sub);
        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.CENTER);footer.setPadding(0,dp(16),0,0);card.addView(footer);
        TextView pill=label(action+"  ›",14,Color.WHITE,true);pill.setGravity(Gravity.CENTER);pill.setPadding(dp(20),dp(5),dp(20),dp(5));GradientDrawable border=box(Color.TRANSPARENT,24);border.setStroke(dp(1),0xddffffff);pill.setBackground(border);footer.addView(pill);
        card.setFocusable(true);card.setOnClickListener(v->click.run());
    }
    private String cloneWords(String value){
        switch(value){
            case "مۆبایل بۆ مۆبایل":return receiveText("مۆبایل بۆ مۆبایل","Phone to phone","من هاتف إلى هاتف");
            case "ئەمە مۆبایلە کۆنەکەیە یان نوێیەکە؟":return receiveText("ئەمە مۆبایلە کۆنەکەیە یان نوێیەکە؟","Is this the old phone or the new phone?","هل هذا الهاتف القديم أم الجديد؟");
            case "مۆبایلی کۆن":return receiveText("مۆبایلی کۆن","Old phone","الهاتف القديم");
            case "مۆبایلی نوێ":return receiveText("مۆبایلی نوێ","New phone","الهاتف الجديد");
            case "QR ـی مۆبایلی نوێ سکان بکە":return receiveText("QR ـی مۆبایلی نوێ سکان بکە","Scan the QR code on the new phone","امسح رمز QR على الهاتف الجديد");
            case "پەیوەستبوون":return receiveText("پەیوەستبوون","Connecting","جارٍ الاتصال");
            case "پەیوەندی بە مۆبایلی نوێ دادەمەزرێت…":return receiveText("پەیوەندی بە مۆبایلی نوێ دادەمەزرێت…","Connecting to the new phone…","جارٍ الاتصال بالهاتف الجديد…");
            case "پەیوەست بوو":return receiveText("پەیوەست بوو","Connected","تم الاتصال");
            case "لە مۆبایلی کۆن داتا هەڵبژێرە و گواستنەوە دەست پێ بکە":return receiveText("لە مۆبایلی کۆن داتا هەڵبژێرە و گواستنەوە دەست پێ بکە","Select data and start the transfer on the old phone","حدد البيانات وابدأ النقل على الهاتف القديم");
            case "پەیوەندی و QR ئامادە دەکرێت…":return receiveText("پەیوەندی و QR ئامادە دەکرێت…","Preparing the connection and QR code…","جارٍ تجهيز الاتصال ورمز QR…");
            case "ئامادەکردنی داتا":return receiveText("ئامادەکردنی داتا","Preparing data","جارٍ تجهيز البيانات");
            case "چاوەڕێی بەردەوامبوون لە مۆبایلی نوێ":return receiveText("چاوەڕێی بەردەوامبوون لە مۆبایلی نوێ","Waiting for Continue on the new phone","بانتظار المتابعة على الهاتف الجديد");
            case "داتای هەڵبژێردراو بۆ گواستنەوە ئامادە دەکرێت…":return receiveText("داتای هەڵبژێردراو بۆ گواستنەوە ئامادە دەکرێت…","Preparing the selected data for transfer…","جارٍ تجهيز البيانات المحددة للنقل…");
            case "لەم مۆبایلە QR پیشان بدە؛ لە مۆبایلی کۆن سکانی بکە":return receiveText("لەم مۆبایلە QR پیشان بدە؛ لە مۆبایلی کۆن سکانی بکە","Scan this QR code with the old phone","امسح هذا الرمز بالهاتف القديم");
            case "داتاکان بە پەیوەندیی ڕاستەوخۆ دەگوازرێنەوە":return receiveText("داتاکان بە پەیوەندیی ڕاستەوخۆ دەگوازرێنەوە","Transferring over a direct connection","جارٍ النقل عبر اتصال مباشر");
            case "سکانی QR":return receiveText("سکانی QR","Scan QR code","مسح رمز QR");
            case "ڕێکخستنی پەیوەندی":return receiveText("ڕێکخستنی پەیوەندی","Connection settings","إعدادات الاتصال");
            case "چاوەڕێی مۆبایلی کۆن…":return receiveText("چاوەڕێی مۆبایلی کۆن…","Waiting for the old phone…","بانتظار الهاتف القديم…");
            case "چاوەڕێی هەڵبژاردنی داتا…":return receiveText("چاوەڕێی هەڵبژاردنی داتا…","Waiting for data selection…","بانتظار اختيار البيانات…");
            case "چاوەڕێی پەیوەندی…":return receiveText("چاوەڕێی پەیوەندی…","Waiting for connection…","بانتظار الاتصال…");
            case "پەیوەندی":return receiveText("پەیوەندی","Connection","الاتصال");
            case "خۆکار":return receiveText("خۆکار","Automatic","تلقائي");
            default:return value;
        }
    }
    private void clonePage(String id,String title,String description,int step){
        closeGallery();screen=id;status=null;
        getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(UiText.direction());root.setBackgroundColor(Color.WHITE);root.setPadding(dp(24),dp(12),dp(24),dp(12));setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);root.addView(header,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView brand=label(receiveText("مۆبایل بۆ مۆبایل","Phone to phone","من هاتف إلى هاتف"),18,INK,true);header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        if(step>0){TextView number=label(step+" / 3",12,MUTED,false);number.setTextDirection(View.TEXT_DIRECTION_LTR);header.addView(number);}
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(0,dp(24),0,dp(24));scroll.addView(body);
        text(cloneWords(title),28,INK,true);gap(12);subtitle=text(cloneWords(description),15,MUTED,false);gap(28);
    }
    private void cloneDeviceArt(int drawable){
        ImageView image=new ImageView(this);image.setImageResource(drawable);image.setColorFilter(BLUE);image.setPadding(dp(28),dp(28),dp(28),dp(28));image.setBackground(box(0xffeef4ff,28));image.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(140),dp(140));lp.gravity=Gravity.CENTER;body.addView(image,lp);
    }
    private void deviceRoles(boolean files){
        clonePage(files?"fileRoles":"deviceRoles","مۆبایل بۆ مۆبایل","ئەمە مۆبایلە کۆنەکەیە یان نوێیەکە؟",0);
        gap(22);TextView info=label("دڵنیابە هەردوو مۆبایلەکە باتریی پێویستیان هەیە",14,MUTED,false);info.setGravity(Gravity.CENTER);body.addView(info);
        gap(36);
        cloneRoleCard("من مۆبایلە تازەکەم","وەرگرتنی داتا","↓",0xff18bd69,()->startPermissions(true));
        cloneRoleCard("من مۆبایلە کۆنەکەم","ناردنی داتا","▯",0xff1976f3,()->startPermissions(false));
    }
    private void cloneRoleCard(String title,String sub,String glyph,int color,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(22),dp(18),dp(22),dp(18));card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),box(Color.WHITE,18),null));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(112));lp.setMargins(0,0,0,dp(16));body.addView(card,lp);
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,21,INK,true));TextView st=label(sub,14,MUTED,false);st.setPadding(0,dp(8),0,0);words.addView(st);
        ImageView icon=new ImageView(this);icon.setImageResource(glyph.equals("↓")?R.drawable.action_receive:R.drawable.action_send);icon.setColorFilter(color);icon.setPadding(dp(12),dp(12),dp(12),dp(12));icon.setBackground(box(0xffeef4ff,18));card.addView(icon,new LinearLayout.LayoutParams(dp(64),dp(64)));card.setElevation(dp(2));card.setOnClickListener(v->click.run());
    }
    private void usbRoles(){
        if(busy)return;
        stopLink();usbMode=true;senderPaired=false;selectedUsbChannel=null;usbReconnectAttempts=0;selection.clear();usbApprovedManifest="";usbControllerAuthorized=false;receivingBatch=null;clearUsbResumeState();
        darkScreen("usbRoles",UiText.t(312));
        gap(18);
        text(UiText.t(315),27,LIGHT,true).setGravity(Gravity.CENTER);
        gap(8);
        text(UiText.t(316),13,0xff8ea6b8,false).setGravity(Gravity.CENTER);
        gap(24);
        darkRole(UiText.t(7),UiText.t(318),"↓",0xff9690ff,()->usbReceiverSetup());
        darkRole(UiText.t(5),"تەنها ڕەزامەندی بدە؛ مۆبایلی تازە هەڵدەبژێرێت","↑",0xff35d8b4,this::startUsbSourcePermissions);
        gap(12);
        text(UiText.t(319),12,0xff8ea6b8,false).setGravity(Gravity.CENTER);
    }
    private void darkRole(String title,String description,String glyph,int accent,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(18),dp(22),dp(18),dp(22));card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),box(0xff0d1822,20),null));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(16));body.addView(card,cp);
        TextView icon=label(glyph,30,NIGHT,true);icon.setGravity(Gravity.CENTER);icon.setBackground(box(accent,15));card.addView(icon,new LinearLayout.LayoutParams(dp(50),dp(54)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(dp(16),0,dp(10),0);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,21,LIGHT,true));words.addView(label(description,13,0xffa9bdca,false));card.setFocusable(true);card.setOnClickListener(v->click.run());
    }
    private static class FlowArt extends View{
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        FlowArt(Context context){super(context);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas canvas){
            float w=getWidth(),h=getHeight();
            paint.setShader(new RadialGradient(w*.85f,h*.7f,w*.7f,new int[]{0xff123448,0xff10182a,NIGHT},new float[]{0,.55f,1},Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h,paint);paint.setShader(null);
            float unit=Math.min(w/340f,h/160f);canvas.save();canvas.translate((w-340*unit)/2,(h-160*unit)/2);canvas.scale(unit,unit);
            for(int i=0;i<2;i++){float x=i==0?62:218;paint.setColor(i==0?0xff293951:0xff254b50);canvas.drawRoundRect(x,12,x+66,144,13,13,paint);paint.setColor(i==0?0xff92a6c4:0xff57dac2);canvas.drawRoundRect(x+7,20,x+59,132,8,8,paint);paint.setColor(0xff152338);canvas.drawRoundRect(x+22,24,x+44,29,3,3,paint);for(int row=0;row<3;row++){paint.setColor(i==0?0xff435a7c:0xff238c82);canvas.drawRoundRect(x+14,47+row*22,x+52,59+row*22,4,4,paint);}}
            paint.setColor(0xffb3a9ff);paint.setStrokeWidth(4);paint.setStrokeCap(Paint.Cap.ROUND);canvas.drawLine(150,68,190,68,paint);canvas.drawLine(182,60,190,68,paint);canvas.drawLine(182,76,190,68,paint);paint.setColor(0xff57dac2);canvas.drawLine(190,91,150,91,paint);canvas.drawLine(158,83,150,91,paint);canvas.drawLine(158,99,150,91,paint);canvas.restore();

        }
    }
    private void role(String title,String description,String icon,Runnable action){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(20),dp(22),dp(20),dp(22));card.setBackground(box(Color.WHITE,22));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(14));body.addView(card,cp);
        TextView glyph=label(icon,32,BLUE,true);glyph.setGravity(Gravity.CENTER);glyph.setBackground(box(0xffedf3ff,16));card.addView(glyph,new LinearLayout.LayoutParams(dp(58),dp(64)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(dp(16),0,dp(16),0);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,21,INK,true));words.addView(label(description,13,MUTED,false));card.setOnClickListener(v->action.run());
    }
    private void categories(){
        page("categories",UiText.t(14),UiText.t(15),2);
        summaryCard("✦ REBARIT CLONE • FULL VIP");
        button("⚡ Smart Clone",true,()->connectPage());
        button("Transfer History",false,()->showTransferHistory());

        section(UiText.t(284));
        category("photos",UiText.t(16),UiText.t(17),"▧");
        category("videos",UiText.t(18),UiText.t(19),"▷");
        section(UiText.t(285));
        category("files",UiText.t(26),UiText.t(27),"＋");
        category("apps",UiText.t(22),UiText.t(23),"APK");
        category("audio",UiText.t(20),UiText.t(21),"♫");
        section(UiText.t(286));
        category("contacts",UiText.t(24),UiText.t(232),"☏");
        category("calls",UiText.t(229),UiText.t(233),"↔");
        category("sms",UiText.t(230),UiText.t(234),"✉");
        gap(14);summaryCard(selectionSummary(selectedItems()));
        button(UiText.t(28),true,()->prepareSelection());
        button(UiText.t(29),false,()->home());
        note(UiText.t(30));
    }
    private List<Item> selectedItems(){LinkedHashMap<String,Item> unique=new LinkedHashMap<>();for(List<Item> list:groups.values())for(Item item:list){String p=item.relativePath==null?"":item.relativePath.toLowerCase(Locale.ROOT);if(privacyMode&&(p.startsWith("android/data/")||p.startsWith("android/obb/")||p.contains("/.private/")))continue;unique.put(item.uri.toString(),item);}return new ArrayList<>(unique.values());}
    private TransferStats stats(List<Item> items){String[] names=new String[items.size()],mimes=new String[items.size()];long[] sizes=new long[items.size()];for(int n=0;n<items.size();n++){Item i=items.get(n);names[n]=i.name;mimes[n]=i.mime;sizes[n]=i.size;}return new TransferStats(names,mimes,sizes);}
    private String selectionSummary(List<Item> items){TransferStats s=stats(items);return items.size()+UiText.t(31)+TransferStats.size(s.totalBytes)+(s.totalKnown?"":UiText.t(32));}
    private int countSelected(){HashSet<String> unique=new HashSet<>();for(List<Item> list:groups.values())for(Item i:list)unique.add(i.uri.toString());return unique.size();}
    private void section(String name){TextView t=text(name,13,BLUE,true);t.setPadding(dp(4),dp(10),0,dp(8));}
    private void category(String id,String title,String desc,String glyph){
        boolean chosen=groups.containsKey(id);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(16),dp(16),dp(16),dp(16));GradientDrawable tile=box(chosen?0xffeeedff:Color.WHITE,20);tile.setStroke(dp(1),chosen?0xffb8b3fa:0xffe2e7f0);row.setBackground(new RippleDrawable(ColorStateList.valueOf(0x184f46e5),tile,null));row.setFocusable(true);row.setContentDescription(title+". "+(chosen?UiText.t(272):desc));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(10));body.addView(row,lp);
        int accent=id.equals("photos")?0xffd4517d:id.equals("videos")?0xff715bd5:id.equals("files")?0xff168477:id.equals("apps")?0xffd58026:BLUE;
        TextView icon=label(glyph,id.equals("apps")?13:24,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(box(accent,14));row.addView(icon,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(dp(12),0,dp(12),0);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,18,INK,true));words.addView(label(chosen?(isRecords(id)?selectedRecords.getOrDefault(id,Collections.emptySet()).size()+UiText.t(238)+" • ":"")+selectionSummary(groups.get(id)):desc,12,MUTED,false));
        TextView tick=label(chosen?"✓":"○",24,chosen?BLUE:0xffb5bfd0,true);row.addView(tick);
        row.setOnClickListener(v->{if(id.equals("apps")){chooseApps();return;}if((id.equals("sms")||id.equals("calls"))&&chosen){groups.remove(id);selectedRecords.remove(id);categories();return;}if(isRecords(id)){requestCategory(id);return;}if(chosen){groups.remove(id);categories();}else if(id.equals("files"))pickFiles();else requestCategory(id);});
    }
    private void chooseApps(){if(!busy)openSendPicker();}
    private void openSendPicker(){
        closeGallery();screen="sendPicker";
        getWindow().setStatusBarColor(0xfffafafa);getWindow().setNavigationBarColor(0xfffafafa);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|(Build.VERSION.SDK_INT>=26?View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR:0));
        List<SendFilePicker.Entry> initial=new ArrayList<>();
        for(Map.Entry<String,List<Item>> group:groups.entrySet())if(!group.getKey().equals("apps")&&!(group.getKey().equals("contacts")&&!pickerContacts.isEmpty()))for(Item i:group.getValue()){
            SendFilePicker.Entry e=new SendFilePicker.Entry();e.uri=i.uri;e.name=i.name;e.mime=i.mime;e.size=i.size;initial.add(e);
        }
        for(String pkg:selectedApps)try{ApplicationInfo app=getPackageManager().getApplicationInfo(pkg,0);SendFilePicker.Entry e=new SendFilePicker.Entry();e.app=app;e.name=quickAppLabel(app);e.mime=AppBundle.MIME;e.size=new File(app.sourceDir).length();initial.add(e);}catch(Exception ignored){}
        initial.addAll(pickerContacts);
        sendPicker=new SendFilePicker(this,initial,new SendFilePicker.Actions(){
            public void back(){home();}
            public void browse(){savePickerSelection();pickFiles();}
            public void permission(String tab){
                if(tab.equals("files")||tab.equals("apps")){
                    if(Build.VERSION.SDK_INT>=30){
                        new AlertDialog.Builder(MainActivity.this).setTitle("File access").setMessage("Allow access to shared files to show saved APKs, documents, archives and WhatsApp media. You can also use Browse other files to choose individual files.")
                            .setPositiveButton("Allow access",(d,w)->{try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName())),SEND_FILES_SETTINGS);}catch(Exception e){try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),SEND_FILES_SETTINGS);}catch(Exception unavailable){savePickerSelection();pickFiles();}}})
                            .setNeutralButton("Browse files",(d,w)->{savePickerSelection();pickFiles();}).setNegativeButton("Cancel",null).show();
                    }else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},SEND_PICKER_PERMISSION);
                    return;
                }
                String permission=tab.equals("contacts")?Manifest.permission.READ_CONTACTS:Build.VERSION.SDK_INT>=33?tab.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:tab.equals("videos")?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;
                if(Build.VERSION.SDK_INT>=34&&(tab.equals("photos")||tab.equals("videos")))requestPermissions(new String[]{permission,Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED},SEND_PICKER_PERMISSION);else requestPermissions(new String[]{permission},SEND_PICKER_PERMISSION);
            }
            public void uninstall(List<SendFilePicker.Entry> entries){uninstallPickerApps(entries);}
            public void next(List<SendFilePicker.Entry> entries){completePickerSelection(entries);}
        });setContentView(sendPicker);
    }
    private List<ApplicationInfo> storePickerSelection(List<SendFilePicker.Entry> entries){
        List<Item> files=new ArrayList<>();List<ApplicationInfo> apps=new ArrayList<>();
        pickerContacts.clear();
        for(SendFilePicker.Entry e:entries)if(e.contact!=null)pickerContacts.add(e);else if(e.app!=null)apps.add(e.app);else files.add(new Item(e.uri,e.name,e.mime,e.size));
        selectedApps.clear();for(ApplicationInfo app:apps)selectedApps.add(app.packageName);
        groups.keySet().removeIf(key->!key.equals("apps"));if(!files.isEmpty())groups.put("picker",files);
        return apps;
    }
    private void completePickerSelection(List<SendFilePicker.Entry> entries){
        List<ApplicationInfo> apps=storePickerSelection(entries);
        List<PersonalRecords.Row> contacts=new ArrayList<>();Set<String> ids=new HashSet<>();for(SendFilePicker.Entry e:pickerContacts){contacts.add(e.contact);ids.add(e.contact.id);}
        if(contacts.isEmpty()){selectedRecords.remove("contacts");finishPickerSelection(apps);return;}
        busy=true;cancelled=false;loading("Preparing contacts…");
        worker.execute(()->{try{
            File file=PersonalRecords.export(this,"contacts",contacts,()->checkCancel());
            runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.put("contacts",new ArrayList<>(Collections.singletonList(new Item(Uri.fromFile(file),"contacts-selected.vcf","text/x-vcard",file.length()))));selectedRecords.put("contacts",ids);finishPickerSelection(apps);});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;openSendPicker();alert("Contacts",friendly(e));});}});
    }
    private void finishPickerSelection(List<ApplicationInfo> apps){if(apps.isEmpty()){groups.remove("apps");selectedApps.clear();prepareSelection();}else exportApps(apps,true);}
    private void savePickerSelection(){if(sendPicker==null)return;List<ApplicationInfo> apps=storePickerSelection(sendPicker.selection());selectedApps.clear();for(ApplicationInfo app:apps)selectedApps.add(app.packageName);}
    private String quickAppLabel(ApplicationInfo app){
        String v=appLabelCache.get(app.packageName);if(v!=null)return v;
        try{v=getPackageManager().getApplicationLabel(app).toString();}catch(Exception e){v=app.packageName;}
        appLabelCache.put(app.packageName,v);return v;
    }
    private void exportApps(List<ApplicationInfo> apps){exportApps(apps,false);}
    private void exportApps(List<ApplicationInfo> apps,boolean advance){
        if(apps.isEmpty()){groups.remove("apps");selectedApps.clear();categories();return;}
        busy=true;cancelled=false;loading(UiText.t(38));
        worker.execute(()->{List<Item> exported=new ArrayList<>();Set<String> successful=new HashSet<>();StringBuilder failed=new StringBuilder();
            for(ApplicationInfo old:apps){File bundle=null;try{
                checkCancel();PackageInfo before=getPackageManager().getPackageInfo(old.packageName,0);ApplicationInfo app=before.applicationInfo;
                List<File> parts=new ArrayList<>();parts.add(new File(app.sourceDir));if(app.splitSourceDirs!=null)for(String path:app.splitSourceDirs)parts.add(new File(path));
                bundle=File.createTempFile("app-",".rbapp",getCacheDir());AppBundle.write(parts,bundle);checkCancel();PackageInfo after=getPackageManager().getPackageInfo(app.packageName,0);
                if(before.lastUpdateTime!=after.lastUpdateTime||before.versionCode!=after.versionCode)throw new IOException("App updated during export");
                String label=safeName(getPackageManager().getApplicationLabel(app).toString());if(label.length()>100)label=label.substring(0,100);
                exported.add(new Item(Uri.fromFile(bundle),label+".rbapp",AppBundle.MIME,bundle.length()));successful.add(app.packageName);
            }catch(Exception e){if(bundle!=null)bundle.delete();failed.append(old.packageName).append("\n");if(cancelled)break;}}
            runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.remove("apps");if(!exported.isEmpty())groups.put("apps",exported);selectedApps.clear();selectedApps.addAll(successful);if(advance&&failed.length()==0)prepareSelection();else categories();
                if(failed.length()>0)alert(UiText.t(39),UiText.t(40)+failed.toString());});
        });
    }
    private void pickFiles(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);startActivityForResult(i,FILES);}
    private void requestCategory(String id){
        pendingCategory=id;List<String> permissions=new ArrayList<>();
        if(id.equals("contacts"))permissions.add(Manifest.permission.READ_CONTACTS);
        else if(id.equals("calls"))permissions.add(Manifest.permission.READ_CALL_LOG);
        else if(id.equals("sms"))permissions.add(Manifest.permission.READ_SMS);
        else if(Build.VERSION.SDK_INT>=33){permissions.add(id.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:id.equals("videos")?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO);
            if(Build.VERSION.SDK_INT>=34&&!id.equals("audio"))permissions.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);
        }else permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if(checkSelfPermission(permissions.get(0))==PackageManager.PERMISSION_GRANTED){loadCategory(id);return;}
        requestPermissions(permissions.toArray(new String[0]),DATA_PERMISSION);
    }
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] grants){
        super.onRequestPermissionsResult(code,perms,grants);
        if(NearbyClone.permissionResult(this,code))return;
        if(code==SETUP_PERMISSION){setupWaiting=false;main.post(()->nextPermission());return;}
        if(code==SEND_PICKER_PERMISSION){if(sendPicker!=null)sendPicker.reload();return;}
        if(code==HOTSPOT_PERMISSION){
            String needed=Build.VERSION.SDK_INT>=33?Manifest.permission.NEARBY_WIFI_DEVICES:Manifest.permission.ACCESS_FINE_LOCATION;
            Runnable next=afterWifiPermission;afterWifiPermission=null;
            if(next!=null){if(checkSelfPermission(needed)==PackageManager.PERMISSION_GRANTED)next.run();else{if("hotspot".equals(screen))receiverSetup();alert(UiText.t(41),UiText.t(42));}}
        }
        if(code==CAMERA_PERMISSION){if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)scan();else toast(UiText.t(43));}
        if(code==DATA_PERMISSION){boolean allowed=false;for(int g:grants)allowed|=g==PackageManager.PERMISSION_GRANTED;
            if(allowed)loadCategory(pendingCategory);else if(isRecords(pendingCategory))alert(UiText.t(41),UiText.t(235));else toast(UiText.t(44));}
    }
    private void loading(String message){page("loading",message,UiText.t(45),1);ProgressBar p=new ProgressBar(this);body.addView(p);}
    private void loadCategory(String id){
        if(isRecords(id)){loadRecords(id);return;}
        busy=true;cancelled=false;loading(UiText.t(46));
        worker.execute(()->{
            try{
                List<Item> found=media(id);
                checkCancel();runOnUiThread(()->{if(isDestroyed())return;busy=false;if(!found.isEmpty())groups.put(id,found);categories();if(found.isEmpty())toast(UiText.t(47));
                    else if(Build.VERSION.SDK_INT>=34&&(id.equals("photos")||id.equals("videos"))&&checkSelfPermission(id.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_MEDIA_VIDEO)!=PackageManager.PERMISSION_GRANTED)toast(UiText.t(48));});
            }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(49),friendly(e));});}
        });
    }
    private List<Item> media(String category)throws Exception{
        Uri collection=category.equals("photos")?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:category.equals("videos")?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        List<Item> out=new ArrayList<>();
        try(Cursor c=getContentResolver().query(collection,new String[]{"_id","_display_name","mime_type","_size",Build.VERSION.SDK_INT>=29?MediaStore.MediaColumns.RELATIVE_PATH:MediaStore.MediaColumns.DATA,MediaStore.MediaColumns.DATE_MODIFIED,MediaStore.Images.ImageColumns.DATE_TAKEN},null,null,"date_added DESC")){
            if(c!=null)while(c.moveToNext()){checkCancel();if(out.size()>=MAX_FILES)throw new IOException("TOO_MANY");
                Item item=new Item(ContentUris.withAppendedId(collection,c.getLong(0)),safeName(c.getString(1)),validMime(c.getString(2)),c.isNull(3)?-1:c.getLong(3));
                String path=c.isNull(4)?"":c.getString(4);
                if(Build.VERSION.SDK_INT<29&&path!=null){int slash=path.lastIndexOf('/');path=slash>0?path.substring(0,slash+1):"";String root=Environment.getExternalStorageDirectory().getAbsolutePath()+"/";if(path.startsWith(root))path=path.substring(root.length());}
                item.relativePath=safeRelativePath(path);if(!c.isNull(5))item.modified=c.getLong(5)*1000L;if(!c.isNull(6))item.taken=c.getLong(6);out.add(item);
            }
        }return out;
    }
    private boolean isRecords(String id){return "contacts".equals(id)||"calls".equals(id)||"sms".equals(id);}
    private void loadRecords(String kind){
        if(busy)return;busy=true;cancelled=false;loading(UiText.t(46));
        worker.execute(()->{try{PersonalRecords.Result result=PersonalRecords.load(this,kind,()->checkCancel());
            runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();if(result.rows.isEmpty())toast(UiText.t(47));else if(kind.equals("sms")||kind.equals("calls")){if(result.limited)toast(UiText.t(239));exportRecords(kind,result.rows);}else chooseRecords(kind,result);});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(49),e instanceof SecurityException?UiText.t(235):UiText.t(244));});}});
    }
    private void chooseRecords(String kind,PersonalRecords.Result result){
        Set<String> chosen=new HashSet<>(selectedRecords.getOrDefault(kind,Collections.emptySet()));List<PersonalRecords.Row> visible=new ArrayList<>();Set<String> available=new HashSet<>();for(PersonalRecords.Row row:result.rows)available.add(row.id);chosen.retainAll(available);if(!kind.equals("contacts")&&!selectedRecords.containsKey(kind))chosen.addAll(available);
        LinearLayout layout=new LinearLayout(UiText.context(this));layout.setOrientation(1);layout.setPadding(dp(16),dp(8),dp(16),0);layout.setLayoutDirection(UiText.direction());
        EditText search=new EditText(UiText.context(this));search.setSingleLine(true);search.setHint(UiText.t(236));layout.addView(search);
        TextView note=label(kind.equals("contacts")?UiText.t(232):UiText.t(231),13,MUTED,false);layout.addView(note);if(result.limited)layout.addView(label(UiText.t(239),13,MUTED,false));
        TextView count=label("",15,BLUE,true);layout.addView(count);
        LinearLayout actions=new LinearLayout(this);layout.addView(actions);Button all=new Button(this);all.setText(UiText.t(237));actions.addView(all,new LinearLayout.LayoutParams(0,-2,1));Button none=new Button(this);none.setText(UiText.t(245));actions.addView(none,new LinearLayout.LayoutParams(0,-2,1));
        ListView list=new ListView(UiText.context(this));list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);layout.addView(list,new LinearLayout.LayoutParams(-1,Math.min(dp(340),getResources().getDisplayMetrics().heightPixels/3)));
        Runnable refresh=()->{String term=search.getText().toString().toLowerCase(Locale.ROOT);visible.clear();List<String> labels=new ArrayList<>();for(PersonalRecords.Row row:result.rows)if(row.label.toLowerCase(Locale.ROOT).contains(term)){visible.add(row);labels.add(row.label);}
            list.setAdapter(new ArrayAdapter<>(UiText.context(this),android.R.layout.simple_list_item_multiple_choice,labels));list.clearChoices();for(int n=0;n<visible.size();n++)list.setItemChecked(n,chosen.contains(visible.get(n).id));count.setText(chosen.size()+UiText.t(238));};
        list.setOnItemClickListener((parent,view,pos,id)->{String key=visible.get(pos).id;if(list.isItemChecked(pos))chosen.add(key);else chosen.remove(key);count.setText(chosen.size()+UiText.t(238));});
        all.setOnClickListener(v->{for(PersonalRecords.Row row:visible)chosen.add(row.id);refresh.run();});none.setOnClickListener(v->{chosen.clear();refresh.run();});
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refresh.run();
        new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(kind.equals("contacts")?24:kind.equals("calls")?229:230)).setView(layout)
            .setPositiveButton(UiText.t(36),(d,w)->{List<PersonalRecords.Row> rows=new ArrayList<>();for(PersonalRecords.Row row:result.rows)if(chosen.contains(row.id))rows.add(row);exportRecords(kind,rows);})
            .setNegativeButton(UiText.t(61),null).show();
    }
    private void exportRecords(String kind,List<PersonalRecords.Row> rows){
        if(rows.isEmpty()){groups.remove(kind);selectedRecords.remove(kind);categories();return;}
        busy=true;cancelled=false;loading(UiText.t(186));
        worker.execute(()->{try{File file=PersonalRecords.export(this,kind,rows,()->checkCancel());
            String name=kind.equals("contacts")?"contacts-selected.vcf":kind+"-selected-backup.json";String mime=kind.equals("contacts")?"text/x-vcard":"application/json";
            Set<String> ids=new HashSet<>();for(PersonalRecords.Row row:rows)ids.add(row.id);
            runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.put(kind,new ArrayList<>(Collections.singletonList(new Item(Uri.fromFile(file),name,mime,file.length()))));selectedRecords.put(kind,ids);categories();});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(49),e instanceof SecurityException?UiText.t(235):UiText.t(244));});}});
    }
    private void prepareSelection(){
        if(countSelected()==0){toast(UiText.t(50));return;}
        if(countSelected()>MAX_FILES){toast(UiText.t(51));return;}
        selection.clear();Set<String> unique=new HashSet<>();for(List<Item> list:groups.values())for(Item i:list)if(unique.add(i.uri.toString()))selection.add(i);
        if(!senderPaired){connectPage();return;}
        if(selectedUsbChannel!=null){SecureChannel channel=selectedUsbChannel;selectedUsbChannel=null;usbMode=true;transferPage(true);List<Item> items=new ArrayList<>(selection);usbRetryItems=new ArrayList<>(items);usbReconnectAttempts=0;job(false,()->sendFiles(channel,items));}
        else if(pendingPeer!=null)send(pendingPeer);else connectPage();
    }
    private void connectPage(){
        senderPaired=false;if(selectedUsbChannel!=null){selectedUsbChannel=null;stopLink();}
        page("connect",UiText.t(52),UiText.t(278),1);
        body.addView(new Phones(this),new LinearLayout.LayoutParams(-1,dp(160)));gap(18);
        text(UiText.t(53),16,INK,false);gap(22);
        button(UiText.t(54),true,()->scan());
        button(UiText.t(29),false,()->home());
        TextView manual=text(UiText.t(58),13,MUTED,false);manual.setPadding(0,dp(14),0,0);manual.setOnClickListener(v->manualPairing());
    }

    /** New phone hosts a local link; the old phone scans and selects its own data. */
    private void cloneSourceScanPage(){
        phoneCloneSource=true;phoneCloneController=false;usbMode=false;senderPaired=false;pendingPeer=null;
        clonePage("cloneSourceScan","مۆبایلی کۆن",NearbyUi.sourceSubtitle(),1);
        cloneDeviceArt(R.drawable.action_send);gap(24);
        button(receiveText("پەیوەستبوونی خۆکار","Automatic connection","الاتصال التلقائي"),true,this::findNearbyClone);
        button(cloneWords("سکانی QR"),false,this::scan);
        button(UiText.t(29),false,()->{phoneCloneSource=false;home();});
    }
    private NearbyClone nearby(){if(nearby==null)nearby=new NearbyClone(this);nearby.clientBands(hotspot.clientBandMask());return nearby;}
    private void findNearbyClone(){
        if(busy||linking)return;
        sourceWifiReady(()->{
            clonePage("cloneNearby","مۆبایلی کۆن","",1);
            status=text(receiveText("گەڕان بۆ مۆبایلی نوێ…","Looking for the new phone…","جار البحث عن الهاتف الجديد…"),16,BLUE,true);
            text(receiveText("لە مۆبایلی نوێ بەشی مۆبایلی نوێ بکەرەوە.","Open New phone on the receiving phone.","افتح الهاتف الجديد على هاتف الاستقبال."),14,MUTED,false);
            LinearLayout devices=new LinearLayout(this);devices.setOrientation(LinearLayout.VERTICAL);body.addView(devices);
            ProgressBar searching=new ProgressBar(this);body.addView(searching,new LinearLayout.LayoutParams(dp(36),dp(36)));
            Set<String> shown=new HashSet<>();final int token=linkGeneration;boolean[] connecting={false};
            nearby().discover(new NearbyClone.Discovery(){
                public void device(String name,String address){
                    if(isDestroyed()||token!=linkGeneration||!screen.equals("cloneNearby")||connecting[0]||!shown.add(address))return;
                    status.setText(receiveText("مۆبایلەکە هەڵبژێرە","Select your phone","اختر هاتفك"));
                    searching.setVisibility(View.GONE);
                    LinearLayout device=new LinearLayout(MainActivity.this);device.setGravity(Gravity.CENTER_VERTICAL);device.setPadding(dp(18),dp(16),dp(18),dp(16));device.setBackground(box(Color.WHITE,18));
                    ImageView icon=new ImageView(MainActivity.this);icon.setImageResource(R.drawable.action_clone);device.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
                    LinearLayout details=new LinearLayout(MainActivity.this);details.setOrientation(LinearLayout.VERTICAL);details.setPadding(dp(16),0,dp(16),0);device.addView(details,new LinearLayout.LayoutParams(0,-2,1));
                    details.addView(label(name,18,INK,true));details.addView(label(receiveText("پەیوەستبوون بەبێ سکان","Connect without scanning","اتصال دون مسح"),13,MUTED,false));
                    LinearLayout.LayoutParams row=new LinearLayout.LayoutParams(-1,-2);row.topMargin=dp(12);devices.addView(device,row);
                    device.setOnClickListener(v->{if(connecting[0])return;connecting[0]=true;linking=true;for(int i=0;i<devices.getChildCount();i++)devices.getChildAt(i).setEnabled(false);searching.setVisibility(View.VISIBLE);status.setText(receiveText("داواکاری پەیوەندی لە هەردوو مۆبایلەکە پەسەند بکە","Approve the connection request on both phones","وافق على طلب الاتصال على الهاتفين"));
                        nearby().connect(address,new NearbyClone.Connection(){
                            public void ready(Pairing peer){if(isDestroyed()||token!=linkGeneration||!screen.equals("cloneNearby"))return;linking=false;connectDiscoveredClone(peer);}
                            public void failed(){if(isDestroyed()||token!=linkGeneration||!screen.equals("cloneNearby"))return;linking=false;nearby().close();alert(receiveText("پەیوەندی نەکرا","Connection failed","تعذر الاتصال"),receiveText("بلوتووس لە هەردوو مۆبایلەکە چالاک بکە و مۆبایلی نوێ دیار بکە، پاشان دووبارە بگەڕێ. دەتوانیت سکانی QRـیش هەڵبژێریت.","Enable Bluetooth on both phones and allow the new phone to be visible, then search again. You can also choose Scan QR.","فعّل Bluetooth على الهاتفين واسمح بظهور الهاتف الجديد، ثم ابحث مجددًا. يمكنك أيضًا اختيار مسح QR."));cloneSourceScanPage();}
                        });
                    });
                }
                public void failed(){if(token==linkGeneration&&screen.equals("cloneNearby"))status.setText(receiveText("Wi‑Fi و ڕێگەپێدانی ئامێرە نزیکەکان چالاک بکە؛ دووبارە بگەڕێ.","Enable Wi-Fi and nearby-device permission, then search again.","فعّل Wi-Fi وإذن الأجهزة القريبة، ثم ابحث مجددًا."));}
            });
            NearbyUi.searchActions(this,body,nearby());
            button(receiveText("دووبارە گەڕان","Search again","البحث مجددًا"),false,this::findNearbyClone);
            button(UiText.t(29),false,()->{linking=false;stopLink();cloneSourceScanPage();});
        });
    }
    private String approveNearby(String name,int bands){
        CountDownLatch latch=new CountDownLatch(1);String[] accepted={null};final int token=linkGeneration;
        runOnUiThread(()->{
            if(isDestroyed()||cancelled||token!=linkGeneration||!screen.equals("cloneReceiverQr")||nearbyApproval!=null&&nearbyApproval.isShowing()){latch.countDown();return;}
            nearbyApproval=new AlertDialog.Builder(UiText.context(this)).setTitle(receiveText("پەیوەندی بە مۆبایلی کۆن","Connect old phone","الاتصال بالهاتف القديم"))
                .setMessage(name).setPositiveButton(UiText.t(124),(d,w)->{clonePeerBandMask=bands;pendingNearbyBand=0;accepted[0]=pairText;latch.countDown();}).setNegativeButton(UiText.t(29),(d,w)->latch.countDown()).setOnCancelListener(d->latch.countDown()).create();nearbyApproval.show();
        });
        try{latch.await(60,TimeUnit.SECONDS);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}
        runOnUiThread(()->{if(nearbyApproval!=null){nearbyApproval.dismiss();nearbyApproval=null;}});
        return token==linkGeneration&&!cancelled?accepted[0]:null;
    }
    private void connectDiscoveredClone(Pairing peer){
        if(busy)return;
        // Keep the authenticated P2P link: removing its group also disconnects the receiver.
        transferNetwork=nearby().network();
        nearbyTransfer=transferNetwork==null;pendingPeer=peer;hotspot.performance(true);
        clonePage("cloneConnect","پەیوەستبوون","پەیوەندی بە مۆبایلی نوێ دادەمەزرێت…",1);
        status=text(receiveText("پەیوەندی دروست بوو؛ داتا ئامادە دەکرێت…","Connected; preparing your data…","تم الاتصال؛ جارٍ تجهيز البيانات…"),16,BLUE,true);
        button(UiText.t(29),false,this::returnToHome);
        startCloneSourceTransfer(peer,null);
    }
    private void connectCloneReceiver(Pairing peer){
        if(busy)return;
        nearbyTransfer=false;if(nearby!=null)nearby.close();
        phoneCloneSource=true;phoneCloneController=false;pendingPeer=peer;usbMode=false;
        final int token=++linkGeneration;
        sourceWifiReady(()->{
            if(isDestroyed()||token!=linkGeneration||!phoneCloneSource)return;
            clonePage("cloneConnect","پەیوەستبوون","پەیوەندی بە مۆبایلی نوێ دادەمەزرێت…",1);
            status=text(receiveText("داواکاری Wi-Fi لەم مۆبایلە پەسەند بکە","Approve the Wi-Fi request on this phone.","وافق على طلب Wi-Fi على هذا الهاتف."),16,BLUE,false);
            button(UiText.t(29),false,this::returnToHome);
            if(!peer.ssid.isEmpty()&&Build.VERSION.SDK_INT>=29){
                // QR already contains the credentials. Do not depend on DNS-SD or a second P2P pairing.
                hotspot.connect(peer,new HotspotLink.ClientCallback(){
                    public void ready(Network network){if(isDestroyed()||token!=linkGeneration||!phoneCloneSource)return;transferNetwork=network;hotspot.performance(true);if(!busy)startCloneSourceTransfer(peer,network);}
                    public void failed(){if(isDestroyed()||token!=linkGeneration||!phoneCloneSource)return;if(busy){closeActiveSocket();return;}cloneManualJoin(peer);}
                });
            }else{
                Network network=hotspot.currentWifi();
                if(peer.ssid.isEmpty()&&network!=null){transferNetwork=network;startCloneSourceTransfer(peer,network);}else cloneManualJoin(peer);
            }
        });
    }
    private void cloneManualJoin(Pairing peer){
        clonePage("cloneManual","پەیوەستبوون","",1);
        text(receiveText("Wi-Fi ـی مۆبایلی نوێ هەڵبژێرە","Select the new phone’s Wi-Fi","اختر Wi-Fi الهاتف الجديد"),17,INK,true);
        text(peer.ssid,17,BLUE,true).setTextDirection(View.TEXT_DIRECTION_LTR);
        text(peer.password,16,INK,false).setTextIsSelectable(true);
        button(UiText.t(71),true,()->startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        button(UiText.t(72),true,()->{Network network=hotspot.currentWifi();if(network==null){toast(UiText.t(73));return;}pendingPeer=peer;transferNetwork=network;startCloneSourceTransfer(peer,network);});
        button(UiText.t(29),false,this::returnToHome);
    }
    private void sourceWifiReady(Runnable action){
        wifiPermission(()->{
            android.net.wifi.WifiManager wm=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if(wm==null){alert(UiText.t(41),UiText.t(73));return;}
            if(!wm.isWifiEnabled()||Build.VERSION.SDK_INT<33&&!locationEnabled()){
                final int token=linkGeneration;
                afterCloneLinkSettings=()->{if(!isDestroyed()&&token==linkGeneration&&phoneCloneSource)sourceWifiReady(action);};
                boolean wifiOff=!wm.isWifiEnabled();
                startActivityForResult(new Intent(wifiOff?(Build.VERSION.SDK_INT>=29?Settings.Panel.ACTION_WIFI:Settings.ACTION_WIFI_SETTINGS):Settings.ACTION_LOCATION_SOURCE_SETTINGS),wifiOff?WIFI_SETTINGS:LOCATION_SETTINGS);return;
            }
            action.run();
        });
    }
    private void startCloneSourceTransfer(Pairing peer,Network network){
        if(busy)return;
        job(false,()->{
            int attempt=0;
            for(;;){
                checkCancel();
                try{
                    SecureChannel channel=connectTransferPeer(peer);
                    try(SecureChannel.Keepalive alive=channel.startKeepalive()){cloneSourceSession(channel);}
                    return;
                }catch(Exception error){
                    closeActiveSocket();
                    if(cancelled||!recoverableNetwork(error))throw error;
                    reconnectPause(attempt++);
                }
            }
        });
    }
    private void cloneControllerSession(SecureChannel channel)throws Exception{
        cloneControllerAuthorized=false;
        channel.write(UsbCloneProtocol.command(UsbCloneProtocol.SOURCE_SELECTION_REQUEST));
        List<UsbCloneProtocol.Category> inventory=UsbCloneProtocol.decodeInventory(channel.read());
        runOnUiThread(()->{if(!isDestroyed()&&!cancelled){clonePage("cloneWaiting","پەیوەست بوو","لە مۆبایلی کۆن داتا هەڵبژێرە و گواستنەوە دەست پێ بکە",2);cloneDeviceArt(R.drawable.action_receive);status=text(cloneWords("چاوەڕێی هەڵبژاردنی داتا…"),16,BLUE,false);button(UiText.t(111),false,this::cancel);}});
        byte[] packet=channel.read();if(UsbCloneProtocol.is(packet,UsbCloneProtocol.DECLINED))throw new IOException("DECLINED");
        Set<String> selected=UsbCloneProtocol.decodeSelection(packet);
        Set<String> available=new HashSet<>();for(UsbCloneProtocol.Category c:inventory)if(c.count>0)available.add(c.id);
        if(selected.isEmpty()||!available.containsAll(selected))throw new IOException("PROTOCOL");
        cloneControllerSelectionCache.clear();cloneControllerSelectionCache.addAll(selected);
        Arrays.fill(cloneRecordCounts,0);for(UsbCloneProtocol.Category c:inventory)if(selected.contains(c.id)){int kind="contacts".equals(c.id)?0:"calls".equals(c.id)?1:"sms".equals(c.id)?2:-1;if(kind>=0)cloneRecordCounts[kind]=c.count;}
        for(;;){
            byte[] reply=channel.read();
            if(UsbCloneProtocol.is(reply,UsbCloneProtocol.PREPARING)){tell("داتاکان لە مۆبایلی کۆن ئامادە دەکرێن…");continue;}
            if(UsbCloneProtocol.is(reply,UsbCloneProtocol.DECLINED))throw new IOException("DECLINED");
            if(UsbCloneProtocol.is(reply,UsbCloneProtocol.ERROR))throw new IOException("SOURCE_PREPARE");
            if(!UsbCloneProtocol.is(reply,UsbCloneProtocol.ACCEPTED))throw new IOException("PROTOCOL");break;
        }
        cloneControllerAuthorized=true;try{receiveFiles(channel);}finally{cloneControllerAuthorized=false;}
    }
    private void startCloneReceiverHost(int band){
        if(busy||linking)return;
        phoneCloneController=true;phoneCloneSource=false;usbMode=false;cloneBand=band;cloneRequestedBand=band;cloneAutoNegotiation=band==HotspotLink.BAND_AUTO;failedCloneBands=0;clonePeerBandMask=7;hotspot.freshCredentials();
        stopLink();
        wifiPermission(()->{
            android.net.wifi.WifiManager wm=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if(!wm.isWifiEnabled()){startActivityForResult(new Intent(Build.VERSION.SDK_INT>=29?Settings.Panel.ACTION_WIFI:Settings.ACTION_WIFI_SETTINGS),WIFI_SETTINGS);return;}
            if(Build.VERSION.SDK_INT<33&&!locationEnabled()){startActivityForResult(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS),LOCATION_SETTINGS);return;}
            linking=true;int token=++linkGeneration;
            clonePage("cloneReceiverStarting","مۆبایلی نوێ","پەیوەندی و QR ئامادە دەکرێت…",1);ProgressBar p=new ProgressBar(this);body.addView(p);
            hotspot.startBand(band==HotspotLink.BAND_AUTO&&hotspot.supportsBand(HotspotLink.BAND_24)?HotspotLink.BAND_24:band,new HotspotLink.HostCallback(){
                public void ready(String ssid,String password){if(isDestroyed()||token!=linkGeneration)return;hotspotSsid=ssid;hotspotPassword=password;waitForCloneReceiverAddress(token,0);}
                public void failed(String reason){if(isDestroyed()||token!=linkGeneration)return;linking=false;lastHotspotError=reason;if(busy){restartHostedLink(true);return;}deviceRoles(false);alert("Wi‑Fi Direct ئامادە نەبوو",cloneBandName(band)+" • "+reason);}
            });
        });
    }
    private void waitForCloneReceiverAddress(int token,int attempt){
        if(isDestroyed()||token!=linkGeneration)return;
        List<String> hosts=wifiAddresses();
        if(!hosts.isEmpty()){linking=false;launchCloneReceiverServer(hosts);return;}
        if(attempt>=20){linking=false;lastHotspotError="LOCAL_ADDRESS_NOT_FOUND";deviceRoles(false);alert("پەیوەندی ئامادە نەبوو","ناونیشانی Wi‑Fi Direct نەدۆزرایەوە.");return;}
        main.postDelayed(()->waitForCloneReceiverAddress(token,attempt+1),500);
    }
    private void launchCloneReceiverServer(List<String> hosts){
        String code=SecureChannel.newCode();hostPairCode=code;
        pairText=Pairing.encodeHotspot(hosts,code,hotspotSsid,hotspotPassword);byte[] key=SecureChannel.parseCode(code);
        job(true,()->{
            listener=new ServerSocket();listener.setReuseAddress(true);listener.bind(new InetSocketAddress(PORT));listener.setSoTimeout(1000);
            runOnUiThread(()->{if(!isDestroyed()&&!cancelled)cloneReceiverQrPage(pairText);});
            for(;;){
                checkCancel();
                try{
                    socket=listener.accept();tuneTransferSocket(socket);socket.setSoTimeout(15000);
                    SecureChannel channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,true);
                    socket.setSoTimeout(300000);
                    try(SecureChannel.Keepalive alive=channel.startKeepalive()){cloneControllerSession(channel);}
                    return;
                }catch(SocketTimeoutException timeout){boolean connected=socket!=null;closeActiveSocket();checkCancel();if(connected)showReconnectWaiting();}
                catch(Exception error){
                    closeActiveSocket();
                    if(cancelled||!recoverableNetwork(error))throw error;
                    showReconnectWaiting();
                }
            }
        });
    }
    private void cloneSourceSession(SecureChannel channel)throws Exception{
        byte[] request=channel.read();
        if(!UsbCloneProtocol.is(request,UsbCloneProtocol.SOURCE_SELECTION_REQUEST))throw new IOException("Protocol mismatch: update both phones");
        tell("لیستی داتاکان ئامادە دەکرێت…");List<UsbCloneProtocol.Category> inventory=usbInventory();channel.write(UsbCloneProtocol.encodeInventory(inventory));
        Set<String> selected;
        boolean rememberedConsent=!cloneRetryItems.isEmpty()&&!cloneSourceConsentCache.isEmpty();
        if(rememberedConsent)selected=new LinkedHashSet<>(cloneSourceConsentCache);
        else selected=chooseCloneSourceCategories(inventory);
        if(selected.isEmpty()){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.DECLINED));throw new IOException("DECLINED");}
        channel.write(UsbCloneProtocol.encodeSelection(selected));channel.write(UsbCloneProtocol.command(UsbCloneProtocol.PREPARING));
        runOnUiThread(()->{if(!isDestroyed()&&!cancelled){clonePage("clonePreparing","ئامادەکردنی داتا",rememberedConsent?"چاوەڕێی بەردەوامبوون لە مۆبایلی نوێ":"داتای هەڵبژێردراو بۆ گواستنەوە ئامادە دەکرێت…",2);ProgressBar p=new ProgressBar(this);body.addView(p);status=text("ئامادەکردنی داتا…",16,BLUE,false);button(UiText.t(111),false,this::cancel);}});
        List<Item> items;
        if(rememberedConsent)items=new ArrayList<>(cloneRetryItems);
        else{
            try{items=usbPrepareItems(selected);}catch(Exception e){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.ERROR));throw e;}
            cloneRetryItems=new ArrayList<>(items);cloneSourceConsentCache.clear();cloneSourceConsentCache.addAll(selected);
        }
        if(items.isEmpty()){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.ERROR));throw new IOException("SOURCE_PREPARE");}
        channel.write(UsbCloneProtocol.command(UsbCloneProtocol.ACCEPTED));runOnUiThread(()->{if(!isDestroyed()&&!cancelled)transferPage(true);});sendFiles(channel,items);
    }
    private Set<String> chooseCloneSourceCategories(List<UsbCloneProtocol.Category> inventory)throws Exception{
        List<CloneAppPicker.App> availableApps=cloneApps();
        CountDownLatch latch=new CountDownLatch(1);approval=latch;Set<String> chosen=new LinkedHashSet<>();
        runOnUiThread(()->{
            if(isDestroyed()||cancelled){latch.countDown();return;}
            closeGallery();screen="cloneSelection";status=null;
            root=new CloneSelectionView(this,inventory,availableApps,new CloneSelectionView.Actions(){
                public void send(Set<String> categories,Set<String> packages){cloneAppSelection=new LinkedHashSet<>(packages);chosen.addAll(categories);latch.countDown();}
                public void back(){returnHomeAfterJob=true;latch.countDown();}
            });setContentView(root);
        });
        try{latch.await();checkCancel();return new LinkedHashSet<>(chosen);}finally{if(approval==latch)approval=null;}
    }
    private void cloneReceiverQrPage(String payload){
        if(hotspotSsid!=null&&!hotspotSsid.isEmpty())nearby().advertise(this::approveNearby,hotspotSsid,()->{pendingNearbyBand=0;});
        clonePage("cloneReceiverQr","مۆبایلی نوێ",NearbyUi.receiverSubtitle(),1);
        NearbyUi.receiverInfo(this,body,hotspotSsid,hotspotPassword);
        try{
            int side=660;BitMatrix matrix=new QRCodeWriter().encode(payload,BarcodeFormat.QR_CODE,side,side);int[] pixels=new int[side*side];for(int y=0;y<side;y++)for(int x=0;x<side;x++)pixels[y*side+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
            ImageView qr=new ImageView(this);qr.setImageBitmap(Bitmap.createBitmap(pixels,side,side,Bitmap.Config.ARGB_8888));qr.setContentDescription("QR");qr.setScaleType(ImageView.ScaleType.FIT_CENTER);qr.setBackground(box(0xfff5f7fa,20));qr.setPadding(dp(16),dp(16),dp(16),dp(16));int width=Math.min(dp(270),getResources().getDisplayMetrics().widthPixels-dp(64));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(width,width);lp.gravity=Gravity.CENTER;body.addView(qr,lp);
        }catch(Exception e){throw new IllegalStateException(e);}
        gap(20);status=text(cloneWords("چاوەڕێی مۆبایلی کۆن…"),16,BLUE,true);status.setGravity(Gravity.CENTER);
        if(hotspotSsid!=null&&!hotspotSsid.isEmpty())text(receiveText("بەبێ سکان: لە مۆبایلی کۆن «پەیوەستبوونی خۆکار» هەڵبژێرە: ","Without scanning: choose Automatic connection on the old phone: ","بدون مسح: اختر الاتصال التلقائي على الهاتف القديم: ")+Build.MODEL,14,MUTED,false);
        gap(12);TextView settings=text(cloneWords("ڕێکخستنی پەیوەندی"),14,MUTED,false);settings.setGravity(Gravity.CENTER);settings.setPadding(0,dp(12),0,dp(12));settings.setOnClickListener(v->showCloneConnectionSettings());
        button(UiText.t(133),false,this::returnToHome);
    }
    private void showCloneConnectionSettings(){
        List<Integer> bands=new ArrayList<>();List<String> names=new ArrayList<>();int selected=0;
        for(int band:new int[]{HotspotLink.BAND_AUTO,HotspotLink.BAND_5,HotspotLink.BAND_6,HotspotLink.BAND_24})if(hotspot.supportsBand(band)){if(band==(cloneAutoNegotiation?HotspotLink.BAND_AUTO:cloneBand))selected=bands.size();bands.add(band);names.add(band==HotspotLink.BAND_AUTO?cloneWords("خۆکار"):band==HotspotLink.BAND_5?"5 GHz":band==HotspotLink.BAND_6?"6 GHz":"2.4 GHz");}
        new AlertDialog.Builder(UiText.context(this)).setTitle(cloneWords("پەیوەندی")).setSingleChoiceItems(names.toArray(new String[0]),selected,(dialog,index)->{dialog.dismiss();int band=bands.get(index);if((band!=cloneBand||(band==HotspotLink.BAND_AUTO)!=cloneAutoNegotiation)&&"cloneReceiverQr".equals(screen)){cloneRequestedBand=band;restartCloneBand=true;cancel();}}).setNegativeButton(UiText.t(29),null).show();
    }
    private String cloneBandName(int band){return band==HotspotLink.BAND_6?"6G":band==HotspotLink.BAND_5?"5G":band==HotspotLink.BAND_24?"2.4G":"AUTO";}

    private void pairedWifi(Pairing peer){
        if(busy)return;busy=true;cancelled=false;page("pairVerify",UiText.t(64),UiText.t(278),1);
        int token=linkGeneration;
        worker.execute(()->{boolean ok=false;for(String host:peer.hosts){try{checkCancel();socket=transferNetwork.getSocketFactory().createSocket();socket.connect(new InetSocketAddress(host,PORT),4500);socket.setSoTimeout(10000);new SecureChannel(socket.getInputStream(),socket.getOutputStream(),peer.key,false);ok=true;break;}catch(Exception ignored){}finally{try{if(socket!=null)socket.close();}catch(Exception ignored){}}}
            final boolean ready=ok;runOnUiThread(()->{if(isDestroyed()||token!=linkGeneration)return;busy=false;if(ready&&!cancelled){pendingPeer=peer;senderPaired=true;usbMode=false;if(hadInterruptedTransfer()&&!sendingId.isEmpty()&&!selection.isEmpty())send(peer);else categories();}else{connectPage();alert(UiText.t(62),UiText.t(63));}});});
    }
    private void scan(){if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION);return;}startActivityForResult(new Intent(this,ScanActivity.class),SCAN);}
    private void manualPairing(){EditText e=new EditText(this);e.setHint("rebaritclone:v3:…");e.setTextDirection(View.TEXT_DIRECTION_LTR);new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(59)).setView(e).setPositiveButton(UiText.t(60),(d,w)->usePair(e.getText().toString())).setNegativeButton(UiText.t(61),null).show();}
    private void usePair(String value){
        final Pairing peer;
        try{peer=Pairing.parse(value);}catch(IllegalArgumentException error){alert(UiText.t(62),UiText.t(63));return;}
        try{pendingPeer=peer;
            if(busy&&!usbMode){
                closeActiveSocket();
                if(!peer.ssid.isEmpty()&&Build.VERSION.SDK_INT>=29)hotspot.connect(peer,new HotspotLink.ClientCallback(){
                    public void ready(Network network){if(!isDestroyed()&&!cancelled){transferNetwork=network;hotspot.performance(true);}}
                    public void failed(){if(!isDestroyed()&&!cancelled)showReconnectWaiting();}
                });
                else transferNetwork=hotspot.currentWifi();
                showReconnectWaiting();return;
            }
            if(phoneCloneSource){connectCloneReceiver(peer);return;}
            if(!peer.ssid.isEmpty()&&Build.VERSION.SDK_INT>=29)wifiPermission(()->connectHotspot(peer));
            else {transferNetwork=hotspot.currentWifi();if(transferNetwork==null)manualJoin(peer);else pairedWifi(peer);}
        }catch(Exception error){android.util.Log.w("CloneLink","Unable to start pairing",error);alert(receiveText("پەیوەندی نەکرا","Connection failed","تعذر الاتصال"),friendly(error));}
    }
    private void wifiPermission(Runnable action){
        String permission=Build.VERSION.SDK_INT>=33?Manifest.permission.NEARBY_WIFI_DEVICES:Manifest.permission.ACCESS_FINE_LOCATION;
        if(checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED){action.run();return;}
        afterWifiPermission=action;
        requestPermissions(Build.VERSION.SDK_INT>=33?new String[]{permission}:new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,permission},HOTSPOT_PERMISSION);
    }
    private void connectHotspot(Pairing peer){
        linking=true;int token=++linkGeneration;
        page("link",UiText.t(64),UiText.t(65),1);
        text(peer.ssid,19,BLUE,true);button(UiText.t(66),false,()->{stopLink();manualJoin(peer);});button(UiText.t(29),false,()->{stopLink();connectPage();});
        hotspot.connect(peer,new HotspotLink.ClientCallback(){
            public void ready(Network network){if(isDestroyed()||token!=linkGeneration)return;linking=false;transferNetwork=network;if(!busy)pairedWifi(peer);}
            public void failed(){if(isDestroyed()||token!=linkGeneration)return;if(busy){closeActiveSocket();return;}linking=false;manualJoin(peer);}
        });
    }
    private void manualJoin(Pairing peer){
        page("manual",UiText.t(67),UiText.t(68),1);
        if(!peer.ssid.isEmpty()){text(UiText.t(69)+peer.ssid,17,INK,true);gap(12);text(UiText.t(70)+peer.password,16,BLUE,false).setTextIsSelectable(true);}
        button(UiText.t(71),true,()->startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        button(UiText.t(72),true,()->{transferNetwork=hotspot.currentWifi();if(transferNetwork==null)toast(UiText.t(73));else pairedWifi(peer);});
        button(UiText.t(29),false,()->connectPage());
    }
    private void stopLink(){if(nearby!=null)nearby.close();nearbyTransfer=false;if(nearbyApproval!=null){nearbyApproval.dismiss();nearbyApproval=null;}linkGeneration++;linking=false;hostRecoveryInProgress=false;afterWifiPermission=null;afterCloneLinkSettings=null;hotspot.close();if(usb!=null)usb.close();transferNetwork=null;}
    private void startReceiveQr(){
        if(busy||linking)return;
        stopLink();phoneCloneSource=false;phoneCloneController=false;cloneControllerAuthorized=false;usbMode=false;
        senderPaired=false;restartReceiveBand=false;receiveBand=HotspotLink.BAND_AUTO;
        hotspotSsid="";hotspotPassword="";beginHotspot();
    }
    private String receiveText(String ckb,String en,String ar){return "en".equals(UiText.language())?en:"ar".equals(UiText.language())?ar:ckb;}
    private String receiveBandName(int band){return band==HotspotLink.BAND_24?"2.4 GHz":band==HotspotLink.BAND_5?"5 GHz":band==HotspotLink.BAND_6?"6 GHz":"Auto";}
    private void receivePreparing(){
        page("hotspot",UiText.t(74),receiveText("QR و پەیوەندی ئامادە دەکرێت…","Preparing the connection and QR…","جارٍ إعداد الاتصال ورمز QR…"),1);
        ProgressBar spinner=new ProgressBar(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(48),dp(48));lp.gravity=Gravity.CENTER;body.addView(spinner,lp);gap(14);
        text(receiveBandName(receiveBand),17,BLUE,true).setGravity(Gravity.CENTER);
        button(UiText.t(111),false,()->{restartReceiveBand=false;if(busy)cancel();else{stopLink();home();}});
    }
    private void beginHotspot(){
        if(busy||linking)return;
        receivePreparing();final int requestToken=linkGeneration;
        if(Build.VERSION.SDK_INT<29&&folder==null){resumeFolder=true;chooseFolder();return;}
        wifiPermission(()->{
            if(isDestroyed()||requestToken!=linkGeneration||!"hotspot".equals(screen))return;
            android.net.wifi.WifiManager wm=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if(wm==null){lastHotspotError="WIFI_UNAVAILABLE";hotspotFailure();return;}
            if(!wm.isWifiEnabled()){startActivityForResult(new Intent(Build.VERSION.SDK_INT>=29?Settings.Panel.ACTION_WIFI:Settings.ACTION_WIFI_SETTINGS),WIFI_SETTINGS);return;}
            if(Build.VERSION.SDK_INT<33&&!locationEnabled()){startActivityForResult(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS),LOCATION_SETTINGS);return;}
            lastHotspotError="";hotspotSsid="";hotspotPassword="";linking=true;int token=++linkGeneration;
            long timeout=receiveBand==HotspotLink.BAND_AUTO?90000L:45000L;
            main.postDelayed(()->{if(!isDestroyed()&&token==linkGeneration&&linking&&!busy){lastHotspotError="HOTSPOT_TIMEOUT";hotspotFailure();}},timeout);
            hotspot.startBand(receiveBand,new HotspotLink.HostCallback(){
                public void ready(String ssid,String password){if(isDestroyed()||token!=linkGeneration)return;hotspotSsid=ssid;hotspotPassword=password;waitForAddress(token,0);}
                public void failed(String reason){if(isDestroyed()||token!=linkGeneration)return;lastHotspotError=reason;linking=false;if(busy){restartHostedLink(false);return;}hotspotFailure();}
            });
        });
    }
    private boolean locationEnabled(){
        android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
        return Build.VERSION.SDK_INT>=28?lm.isLocationEnabled():lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)||lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER);
    }
    private void hotspotFailure(){
        stopLink();hotspotSsid="";hotspotPassword="";
        String failed=lastHotspotError;
        page("receiver",UiText.t(77),UiText.t(78),1);
        note(receiveBandName(receiveBand)+" • "+failed+" • "+Build.MANUFACTURER+" "+Build.MODEL+" • Android "+Build.VERSION.RELEASE);
        button(receiveText("↻ هەڵبژاردنی خۆکار","↻ Try Auto","↻ اختيار تلقائي"),true,()->{receiveBand=HotspotLink.BAND_AUTO;beginHotspot();});
        if(receiveBand!=HotspotLink.BAND_AUTO)button(receiveText("↻ هەمان باند دووبارە","↻ Retry this band","↻ إعادة محاولة هذا النطاق"),false,()->beginHotspot());
        button(UiText.t(81),false,()->manualHost());
        button(UiText.t(29),false,()->home());
    }
    private void waitForAddress(int token,int attempt){
        if(isDestroyed()||token!=linkGeneration)return;
        if(!wifiAddresses().isEmpty()){linking=false;receive();return;}
        if(attempt>=15){lastHotspotError="LOCAL_ADDRESS_NOT_FOUND";linking=false;hotspotFailure();return;}
        main.postDelayed(()->waitForAddress(token,attempt+1),1000);
    }
    private void manualHost(){
        stopLink();receiveBand=HotspotLink.BAND_AUTO;hotspotSsid="";hotspotPassword="";
        page("manualhost",UiText.t(83),UiText.t(84),1);
        if(!lastHotspotError.isEmpty())note(UiText.t(85)+lastHotspotError+"\n"+Build.MANUFACTURER+" "+Build.MODEL+" • Android "+Build.VERSION.RELEASE);
        button(UiText.t(86),true,()->{try{startActivity(new Intent("android.settings.TETHER_SETTINGS"));}catch(Exception e){startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));}});
        button(UiText.t(87),true,()->{if(Build.VERSION.SDK_INT<29&&folder==null)chooseFolder();else receive();});
        note(UiText.t(88));
        button(UiText.t(29),false,()->receiverSetup());
    }
    private void decodeImage(Uri uri){
        busy=true;loading(UiText.t(89));worker.execute(()->{
            try{
                BitmapFactory.Options opt=new BitmapFactory.Options();opt.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,opt);}
                opt.inSampleSize=1;while(opt.outWidth/opt.inSampleSize>1600||opt.outHeight/opt.inSampleSize>1600)opt.inSampleSize*=2;opt.inJustDecodeBounds=false;
                Bitmap bitmap;try(InputStream in=getContentResolver().openInputStream(uri)){bitmap=BitmapFactory.decodeStream(in,null,opt);}if(bitmap==null)throw new IOException("QR");
                int w=bitmap.getWidth(),h=bitmap.getHeight();int[] pixels=new int[w*h];bitmap.getPixels(pixels,0,w,0,0,w,h);bitmap.recycle();
                Map<DecodeHintType,Object> hints=new EnumMap<>(DecodeHintType.class);hints.put(DecodeHintType.TRY_HARDER,true);hints.put(DecodeHintType.POSSIBLE_FORMATS,Collections.singletonList(BarcodeFormat.QR_CODE));
                String payload=new MultiFormatReader().decode(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(w,h,pixels))),hints).getText();Pairing.parse(payload);
                runOnUiThread(()->{if(isDestroyed())return;busy=false;usePair(payload);});
            }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;connectPage();alert(UiText.t(90),UiText.t(91));});}
        });
    }
    private void startUsb(boolean receiving){
        if(busy)return;
        if(receiving&&Build.VERSION.SDK_INT<29&&folder==null){resumeUsbFolder=true;chooseFolder();return;}
        stopLink();usbMode=true;linking=true;int token=++linkGeneration;
        page("usb",UiText.t(92),UiText.t(93),1);
        body.addView(new CableArt(this),new LinearLayout.LayoutParams(-1,dp(150)));gap(12);
        summaryCard(receiving?UiText.t(94):UiText.t(95));
        note(UiText.t(96));
        status=summaryCard(UiText.t(97));status.setTextColor(BLUE);
        button(UiText.t(29),false,()->{stopLink();if(receiving)usbReceiverSetup();else usbRoles();});
        try{usb.start(receiving,new UsbLink.Listener(){
            public void ready(InputStream in,OutputStream out){
                if(isDestroyed()||token!=linkGeneration)return;linking=false;
                if(!receiving){
                    page("usbWaiting","چاوەڕێی مۆبایلی تازە","مۆبایلی تازە دیاری دەکات چی وەربگرێت",1);button(UiText.t(111),false,()->cancel());
                    job(false,()->{SecureChannel channel=UsbSession.open(in,out,false);try(SecureChannel.Keepalive alive=channel.startKeepalive()){usbSourceSession(channel);}});
                    return;
                }
                page("usbWaiting","کۆنترۆڵ لەم مۆبایلەیە","لیستی داتاکانی مۆبایلی کۆن وەردەگیرێت…",1);button(UiText.t(111),false,()->cancel());
                job(true,()->{SecureChannel channel=UsbSession.open(in,out,true);try(SecureChannel.Keepalive alive=channel.startKeepalive()){usbControllerSession(channel);}});
            }
            public void status(String message){runOnUiThread(()->{if(!isDestroyed()&&token==linkGeneration&&status!=null)status.setText(message);});}
            public void failed(String reason){if(isDestroyed()||token!=linkGeneration)return;linking=false;
                clearUsbAttemptState();
                if(usbAutoResume&&!cancelled){
                    usbReconnectAttempts=Math.min(Integer.MAX_VALUE-1,usbReconnectAttempts+1);showReconnectWaiting();
                    int retryToken=linkGeneration;main.postDelayed(()->{if(!isDestroyed()&&!cancelled&&!busy&&usbAutoResume&&retryToken==linkGeneration)startUsb(receiving);},usbRetryDelay());return;
                }
                if(receiving){usbReceiverSetup();note("USB پەیوەندی نەکرا. کێبڵی Data بەکاربهێنە، USB permission = Allow.");}
                else{usbRoles();note("USB پەیوەندی نەکرا. کێبڵی Data بەکاربهێنە و USB permission ڕێگەپێبدە.");}
                toast(reason);
            }
        });}catch(Throwable e){
            linking=false;clearUsbAttemptState();
            if(receiving)usbReceiverSetup();else usbRoles();
            toast("USB نەتوانرا دەستپێبکات • دووبارە هەوڵ بدە");
        }
    }
    private void usbReceiverSetup(){
        if(busy)return;stopLink();usbMode=true;
        page("usbReceiver",UiText.t(102),UiText.t(273),1);
        body.addView(new CableArt(this),new LinearLayout.LayoutParams(-1,dp(180)));gap(18);
        summaryCard("1. کێبڵی USB-C پەیوەست بکە");gap(10);summaryCard("2. ئەم مۆبایلە لیستی داتاکانی مۆبایلی کۆن دەبینێت");gap(10);summaryCard("3. لێرە دیاری بکە چی وەربگریت؛ کۆنەکە تەنها ڕەزامەندی دەدات");gap(16);
        Button usbReceive=button("↓  وەرگرتن بە USB",true,()->startUsb(true));usbReceive.setTextSize(18);usbReceive.setMinHeight(dp(68));
        note("کێبڵی USB-C پەیوەست بکە؛ وەرگر خۆکارانە چاوەڕێ دەکات. ئەگەر Android داوای USB permission کرد، Allow هەڵبژێرە.");
        main.postDelayed(()->{if(!isDestroyed()&&!busy&&"usbReceiver".equals(screen))startUsb(true);},500);
        button(UiText.t(29),false,()->home());
    }
    private static class CableArt extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        CableArt(Context c){super(c);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
        protected void onDraw(Canvas c){float scale=Math.min(getWidth()/340f,getHeight()/175f);c.save();c.translate((getWidth()-340*scale)/2,(getHeight()-175*scale)/2);c.scale(scale,scale);
            p.setColor(0xffe9e8ff);c.drawRoundRect(0,0,340,175,24,24,p);
            for(int n=0;n<2;n++){float x=n==0?53:231;p.setColor(n==0?0xff627089:BLUE);c.drawRoundRect(x,18,x+56,126,10,10,p);p.setColor(Color.WHITE);c.drawRoundRect(x+5,24,x+51,117,6,6,p);p.setColor(0xffd5d9ed);c.drawRoundRect(x+18,28,x+38,32,2,2,p);p.setColor(n==0?0xff627089:BLUE);c.drawCircle(x+28,72,12,p);}
            p.setColor(BLUE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);Path cable=new Path();cable.moveTo(81,125);cable.lineTo(81,142);cable.cubicTo(81,165,259,165,259,142);cable.lineTo(259,125);c.drawPath(cable,p);p.setStyle(Paint.Style.FILL);c.drawRoundRect(73,121,89,132,3,3,p);c.drawRoundRect(251,121,267,132,3,3,p);p.setTextSize(16);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);c.drawText("USB-C",170,80,p);c.restore();}
    }
    private void receiverSetup(){
        page("receiver",UiText.t(99),UiText.t(100),1);
        body.addView(new Phones(this),new LinearLayout.LayoutParams(-1,dp(140)));gap(14);
        button(UiText.t(101),true,()->beginHotspot());
        button(UiText.t(103),false,()->manualHost());
        note(UiText.t(104));
        button(UiText.t(29),false,()->home());
    }
    private void chooseFolder(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);startActivityForResult(i,FOLDER);}
    private List<String> wifiAddresses(){
        LinkedHashSet<String> values=new LinkedHashSet<>();Set<String> clientInterfaces=new HashSet<>();
        if(hotspot!=null&&Pairing.local(hotspot.hostAddress()))values.add(hotspot.hostAddress());
        try{
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            for(Network n:cm.getAllNetworks()){NetworkCapabilities cap=cm.getNetworkCapabilities(n);LinkProperties lp=cm.getLinkProperties(n);
                if(cap!=null&&lp!=null&&cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)&&!cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN)){
                    clientInterfaces.add(lp.getInterfaceName());
                    if(hotspotSsid.isEmpty())for(LinkAddress la:lp.getLinkAddresses())if(la.getAddress() instanceof Inet4Address&&Pairing.local(la.getAddress().getHostAddress()))values.add(la.getAddress().getHostAddress());
                }
            }
            for(NetworkInterface ni:Collections.list(NetworkInterface.getNetworkInterfaces())){
                String name=ni.getName().toLowerCase(Locale.ROOT);
                if(!hotspotSsid.isEmpty()&&clientInterfaces.contains(ni.getName()))continue;
                if(!ni.isUp()||!(name.startsWith("wlan")||name.startsWith("swlan")||name.startsWith("ap")||name.startsWith("wlp")||name.startsWith("p2p")||name.startsWith("br")))continue;
                for(InetAddress a:Collections.list(ni.getInetAddresses()))if(a instanceof Inet4Address&&Pairing.local(a.getHostAddress()))values.add(a.getHostAddress());
            }
        }catch(Exception ignored){}List<String> result=new ArrayList<>(values);return result.subList(0,Math.min(result.size(),8));
    }
    private String usbCategoryName(String id){
        if("photos".equals(id))return UiText.t(16);if("videos".equals(id))return UiText.t(18);if("audio".equals(id))return UiText.t(20);
        if("documents".equals(id))return CloneSelectionView.name(id);if("files".equals(id))return UiText.t(26);if("apps".equals(id))return UiText.t(22);if("contacts".equals(id))return UiText.t(24);
        if("calls".equals(id))return UiText.t(229);if("sms".equals(id))return UiText.t(230);return id;
    }
    private long[] usbMediaStat(String id)throws Exception{
        Uri uri="photos".equals(id)?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:"videos".equals(id)?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        long count=0,bytes=0;try(Cursor c=getContentResolver().query(uri,new String[]{MediaStore.MediaColumns.SIZE},null,null,null)){while(c!=null&&c.moveToNext()){checkCancel();count++;if(!c.isNull(0)&&c.getLong(0)>0)bytes+=c.getLong(0);}}
        return new long[]{count,bytes};
    }
    private boolean usbSharedFileCandidate(String name,String mime,String path){
        name=name==null?"":name.toLowerCase(Locale.ROOT);mime=mime==null?"":mime.toLowerCase(Locale.ROOT);path=safeRelativePath(path).toLowerCase(Locale.ROOT);
        if(path.startsWith("android/data/")||path.startsWith("android/obb/"))return false;
        if(mime.startsWith("image/")||mime.startsWith("video/")||mime.startsWith("audio/"))return false;
        if(name.endsWith(".apk")||mime.equals("application/vnd.android.package-archive"))return false;
        return !name.isEmpty();
    }
    private long[] usbDocumentsStat()throws Exception{
        Uri uri=MediaStore.Files.getContentUri("external");long count=0,bytes=0;
        String pathColumn=Build.VERSION.SDK_INT>=29?MediaStore.MediaColumns.RELATIVE_PATH:MediaStore.MediaColumns.DATA;
        try(Cursor c=getContentResolver().query(uri,new String[]{MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.MIME_TYPE,MediaStore.MediaColumns.SIZE,pathColumn},null,null,null)){
            while(c!=null&&c.moveToNext()){checkCancel();String name=c.isNull(0)?"":c.getString(0),mime=c.isNull(1)?"":c.getString(1),path=c.isNull(3)?"":c.getString(3);if(!usbSharedFileCandidate(name,mime,path)||!DocumentTypes.matches(name,mime))continue;count++;if(!c.isNull(2)&&c.getLong(2)>0)bytes+=c.getLong(2);}
        }return new long[]{count,bytes};
    }
    private long[] usbAppsStat(){long count=0,bytes=0;try{for(ApplicationInfo a:getPackageManager().getInstalledApplications(0)){if(a.packageName.equals(getPackageName())||(a.flags&ApplicationInfo.FLAG_SYSTEM)!=0)continue;count++;if(a.sourceDir!=null)bytes+=Math.max(0,new File(a.sourceDir).length());if(a.splitSourceDirs!=null)for(String s:a.splitSourceDirs)bytes+=Math.max(0,new File(s).length());}}catch(Exception ignored){}return new long[]{count,bytes};}
    private List<UsbCloneProtocol.Category> usbInventory()throws Exception{
        List<UsbCloneProtocol.Category> out=new ArrayList<>();String[] ids={"photos","videos","audio","documents","apps","contacts","calls","sms"};
        for(String id:ids){checkCancel();try{long[] stat;if("photos".equals(id)||"videos".equals(id)||"audio".equals(id))stat=usbMediaStat(id);else if("documents".equals(id))stat=usbDocumentsStat();else if("apps".equals(id))stat=usbAppsStat();else{PersonalRecords.Result r=PersonalRecords.load(this,id,()->checkCancel());stat=new long[]{r.rows.size(),-1};}out.add(new UsbCloneProtocol.Category(id,(int)Math.min(Integer.MAX_VALUE,stat[0]),stat[1]));}catch(SecurityException e){out.add(new UsbCloneProtocol.Category(id,0,-1));}}
        return out;
    }
    private List<Item> usbDocuments()throws Exception{
        List<Item> out=new ArrayList<>();Uri collection=MediaStore.Files.getContentUri("external");String pathColumn=Build.VERSION.SDK_INT>=29?MediaStore.MediaColumns.RELATIVE_PATH:MediaStore.MediaColumns.DATA;
        try(Cursor c=getContentResolver().query(collection,new String[]{MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.MIME_TYPE,MediaStore.MediaColumns.SIZE,pathColumn,MediaStore.MediaColumns.DATE_MODIFIED},null,null,MediaStore.MediaColumns.DATE_MODIFIED+" DESC")){
            while(c!=null&&c.moveToNext()){checkCancel();String name=c.isNull(1)?"":c.getString(1),mime=c.isNull(2)?"application/octet-stream":c.getString(2),path=c.isNull(4)?"":c.getString(4);if(!usbSharedFileCandidate(name,mime,path)||!DocumentTypes.matches(name,mime))continue;
                Item i=new Item(ContentUris.withAppendedId(collection,c.getLong(0)),safeName(name),validMime(mime),c.isNull(3)?-1:c.getLong(3));
                if(Build.VERSION.SDK_INT<29&&path!=null){int slash=path.lastIndexOf('/');path=slash>0?path.substring(0,slash+1):"";String ext=Environment.getExternalStorageDirectory().getAbsolutePath()+"/";if(path.startsWith(ext))path=path.substring(ext.length());}
                i.relativePath=safeRelativePath(path);if(!c.isNull(5))i.modified=c.getLong(5)*1000L;if(out.size()>=MAX_FILES)throw new IOException("TOO_MANY");out.add(i);
            }
        }return out;
    }
    private List<CloneAppPicker.App> cloneApps()throws Exception{
        List<CloneAppPicker.App> apps=new ArrayList<>();
        for(ApplicationInfo app:getPackageManager().getInstalledApplications(0)){
            checkCancel();if(app.packageName.equals(getPackageName())||(app.flags&ApplicationInfo.FLAG_SYSTEM)!=0)continue;
            long bytes=app.sourceDir==null?0:Math.max(0,new File(app.sourceDir).length());if(app.splitSourceDirs!=null)for(String path:app.splitSourceDirs)bytes+=Math.max(0,new File(path).length());
            apps.add(new CloneAppPicker.App(app.packageName,quickAppLabel(app),bytes));
        }
        apps.sort((a,b)->a.name.compareToIgnoreCase(b.name));return apps;
    }
    private List<Item> usbExportApps()throws Exception{
        List<Item> out=new ArrayList<>();for(ApplicationInfo old:getPackageManager().getInstalledApplications(0)){checkCancel();if(old.packageName.equals(getPackageName())||(old.flags&ApplicationInfo.FLAG_SYSTEM)!=0||phoneCloneSource&&cloneAppSelection!=null&&!cloneAppSelection.contains(old.packageName))continue;File bundle=null;
            try{PackageInfo before=getPackageManager().getPackageInfo(old.packageName,0);ApplicationInfo app=before.applicationInfo;List<File> parts=new ArrayList<>();parts.add(new File(app.sourceDir));if(app.splitSourceDirs!=null)for(String p:app.splitSourceDirs)parts.add(new File(p));bundle=File.createTempFile("usb-app-",".rbapp",getCacheDir());AppBundle.write(parts,bundle);PackageInfo after=getPackageManager().getPackageInfo(app.packageName,0);if(before.lastUpdateTime!=after.lastUpdateTime||before.versionCode!=after.versionCode)throw new IOException("App updated during export");usbPreparedTemps.add(bundle);String label=safeName(getPackageManager().getApplicationLabel(app).toString());out.add(new Item(Uri.fromFile(bundle),label+".rbapp",AppBundle.MIME,bundle.length()));}
            catch(Exception e){if(bundle!=null&&!usbPreparedTemps.contains(bundle))bundle.delete();if(phoneCloneSource&&cloneAppSelection!=null&&cloneAppSelection.contains(old.packageName))throw new IOException("Cannot prepare selected app",e);}
        }return out;
    }
    private Item usbExportRecords(String kind)throws Exception{
        PersonalRecords.Result r=PersonalRecords.load(this,kind,()->checkCancel());if(r.rows.isEmpty())return null;File file=PersonalRecords.export(this,kind,r.rows,()->checkCancel());usbPreparedTemps.add(file);String name="contacts".equals(kind)?"contacts-all.vcf":kind+"-all-backup.json";String mime="contacts".equals(kind)?"text/x-vcard":"application/json";return new Item(Uri.fromFile(file),name,mime,file.length());
    }
    private List<Item> usbPrepareItems(Set<String> selected)throws Exception{
        usbCleanupPrepared();List<Item> items=new ArrayList<>();
        for(String id:selected){checkCancel();tell("ئامادەکردنی "+usbCategoryName(id)+"…");if("photos".equals(id)||"videos".equals(id)||"audio".equals(id))items.addAll(media(id));else if("documents".equals(id))items.addAll(usbDocuments());else if("files".equals(id))throw new IOException("Protocol mismatch: update both phones");else if("apps".equals(id))items.addAll(usbExportApps());else if(isRecords(id)){Item x=usbExportRecords(id);if(x!=null)items.add(x);}if(items.size()>MAX_FILES)throw new IOException("TOO_MANY");}
        return items;
    }
    private void usbCleanupPrepared(){for(File f:new ArrayList<>(usbPreparedTemps))try{f.delete();}catch(Exception ignored){}usbPreparedTemps.clear();}
    private Set<String> chooseUsbControllerCategories(List<UsbCloneProtocol.Category> categories)throws Exception{
        CountDownLatch latch=new CountDownLatch(1);approval=latch;LinkedHashSet<String> chosen=new LinkedHashSet<>();boolean[] accepted={false};
        runOnUiThread(()->{if(isDestroyed()||cancelled){latch.countDown();return;}List<UsbCloneProtocol.Category> visible=new ArrayList<>();for(UsbCloneProtocol.Category c:categories)if(c.count>0&&!"files".equals(c.id))visible.add(c);if(visible.isEmpty()){latch.countDown();return;}String[] labels=new String[visible.size()];boolean[] checks=new boolean[visible.size()];
            for(int n=0;n<visible.size();n++){UsbCloneProtocol.Category c=visible.get(n);checks[n]=true;chosen.add(c.id);labels[n]=usbCategoryName(c.id)+"   •   "+c.count+"   •   "+(c.bytes<0?"—":TransferStats.size(c.bytes));}
            AlertDialog dialog=new AlertDialog.Builder(UiText.context(this)).setTitle("لە مۆبایلی کۆن چی وەربگریت؟").setMultiChoiceItems(labels,checks,(d,w,on)->{String id=visible.get(w).id;if(on)chosen.add(id);else chosen.remove(id);}).setPositiveButton("وەرگرتن",null).setNegativeButton(UiText.t(29),(d,w)->latch.countDown()).setCancelable(false).create();approvalDialog=dialog;
            dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(chosen.isEmpty()){toast("لانیکەم یەک بەش هەڵبژێرە");return;}accepted[0]=true;dialog.dismiss();latch.countDown();}));dialog.show();
        });
        latch.await();approval=null;approvalDialog=null;if(cancelled)throw new IOException("Cancelled");if(!accepted[0])return Collections.emptySet();return new LinkedHashSet<>(chosen);
    }
    private boolean confirmUsbSourceRequest(Set<String> selected,List<UsbCloneProtocol.Category> inventory)throws InterruptedException{
        CountDownLatch latch=new CountDownLatch(1);approval=latch;boolean[] yes={false};StringBuilder list=new StringBuilder();long bytes=0;int count=0;boolean unknown=false;
        for(UsbCloneProtocol.Category c:inventory)if(selected.contains(c.id)){list.append("• ").append(usbCategoryName(c.id)).append(" — ").append(c.count).append("\n");count+=c.count;if(c.bytes<0)unknown=true;else bytes+=c.bytes;}
        final String message=list+"\n"+count+" فایل/تۆمار • "+TransferStats.size(bytes)+(unknown?" +":"")+"\n\nمۆبایلی تازە داوای ئەم داتایانە دەکات.";
        runOnUiThread(()->{if(isDestroyed()||cancelled){latch.countDown();return;}approvalDialog=new AlertDialog.Builder(UiText.context(this)).setTitle("ڕەزامەندی بۆ ناردن").setMessage(message).setPositiveButton("ڕێگە دەدەم",(d,w)->{yes[0]=true;latch.countDown();}).setNegativeButton("ڕەتکردنەوە",(d,w)->latch.countDown()).setCancelable(false).create();approvalDialog.show();});
        latch.await();approval=null;approvalDialog=null;return yes[0]&&!cancelled;
    }
    private void usbControllerSession(SecureChannel channel)throws Exception{
        usbControllerAuthorized=false;channel.write(UsbCloneProtocol.command(UsbCloneProtocol.INVENTORY_REQUEST));List<UsbCloneProtocol.Category> inventory=UsbCloneProtocol.decodeInventory(channel.read());
        LinkedHashSet<String> selected=new LinkedHashSet<>();
        if(usbAutoResume&&!usbControllerSelectionCache.isEmpty()){
            HashSet<String> available=new HashSet<>();for(UsbCloneProtocol.Category c:inventory)if(c.count>0)available.add(c.id);
            selected.addAll(usbControllerSelectionCache);
            if(selected.isEmpty())throw new IOException("USB_SOURCE_CHANGED");
        }else{selected.addAll(chooseUsbControllerCategories(inventory));usbControllerSelectionCache.clear();usbControllerSelectionCache.addAll(selected);}
        channel.write(UsbCloneProtocol.encodeSelection(selected));if(selected.isEmpty())throw new IOException("DECLINED");
        runOnUiThread(()->{if(!isDestroyed()&&!cancelled){page("selectionWaiting","چاوەڕێی ڕەزامەندی","لە مۆبایلی کۆن «ڕێگە دەدەم» هەڵبژێرە",2);button(UiText.t(111),false,()->cancel());}});
        for(;;){byte[] reply=channel.read();if(UsbCloneProtocol.is(reply,UsbCloneProtocol.PREPARING)){tell("مۆبایلی کۆن داتاکان ئامادە دەکات…");continue;}if(UsbCloneProtocol.is(reply,UsbCloneProtocol.DECLINED))throw new IOException("DECLINED");if(UsbCloneProtocol.is(reply,UsbCloneProtocol.ERROR))throw new IOException("USB_SOURCE_PREPARE");if(!UsbCloneProtocol.is(reply,UsbCloneProtocol.ACCEPTED))throw new IOException("USB_PROTOCOL");break;}
        usbControllerAuthorized=true;try{receiveFiles(channel);}finally{usbControllerAuthorized=false;}
    }
    private void usbSourceSession(SecureChannel channel)throws Exception{
        byte[] request=channel.read();if(!UsbCloneProtocol.is(request,UsbCloneProtocol.INVENTORY_REQUEST))throw new IOException("USB_PROTOCOL");tell("لیستی داتاکان دەنێردرێت…");List<UsbCloneProtocol.Category> inventory=usbInventory();channel.write(UsbCloneProtocol.encodeInventory(inventory));LinkedHashSet<String> selected=UsbCloneProtocol.decodeSelection(channel.read());if(selected.isEmpty()){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.DECLINED));throw new IOException("DECLINED");}
        Set<String> allowed=new HashSet<>();for(UsbCloneProtocol.Category c:inventory)allowed.add(c.id);selected.retainAll(allowed);if(selected.isEmpty()){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.DECLINED));throw new IOException("DECLINED");}
        boolean rememberedConsent=usbAutoResume&&!usbSourceConsentCache.isEmpty()&&usbSourceConsentCache.equals(selected);
        if(!rememberedConsent&&!confirmUsbSourceRequest(selected,inventory)){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.DECLINED));throw new IOException("DECLINED");}
        if(!rememberedConsent){usbSourceConsentCache.clear();usbSourceConsentCache.addAll(selected);}
        runOnUiThread(()->{if(!isDestroyed()&&!cancelled){page("usbPreparing",usbAutoResume?"گواستنەوە خۆکارانە بەردەوام دەبێتەوە":"ئامادەکردنی داتا",usbAutoResume?"لە هەمان شوێنی پچڕان دەست پێدەکاتەوە":"ڕەزامەندی درا • داتاکان بۆ مۆبایلی تازە ئامادە دەکرێن",2);ProgressBar p=new ProgressBar(this);body.addView(p);}});
        channel.write(UsbCloneProtocol.command(UsbCloneProtocol.PREPARING));List<Item> items;
        if(usbAutoResume&&!usbRetryItems.isEmpty())items=new ArrayList<>(usbRetryItems);
        else try{items=usbPrepareItems(selected);usbRetryItems=new ArrayList<>(items);}catch(Exception e){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.ERROR));throw e;}
        if(items.isEmpty()){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.ERROR));throw new IOException("USB_SOURCE_PREPARE");}
        channel.write(UsbCloneProtocol.command(UsbCloneProtocol.ACCEPTED));runOnUiThread(()->{if(!isDestroyed()&&!cancelled)transferPage(true);});sendFiles(channel,items);
    }
    private void qrPage(String payload){
        page("qr",UiText.t(105),UiText.t(106),1);
        try{
            int side=660;BitMatrix matrix=new QRCodeWriter().encode(payload,BarcodeFormat.QR_CODE,side,side);int[] pixels=new int[side*side];for(int y=0;y<side;y++)for(int x=0;x<side;x++)pixels[y*side+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
            Bitmap bitmap=Bitmap.createBitmap(pixels,side,side,Bitmap.Config.ARGB_8888);ImageView qr=new ImageView(this);qr.setImageBitmap(bitmap);qr.setContentDescription(UiText.t(107));qr.setScaleType(ImageView.ScaleType.FIT_CENTER);qr.setBackground(box(Color.WHITE,24));qr.setPadding(dp(8),dp(8),dp(8),dp(8));
            int width=Math.min(dp(280),getResources().getDisplayMetrics().widthPixels-dp(48));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(width,width);lp.gravity=Gravity.CENTER;body.addView(qr,lp);
        }catch(Exception e){throw new IllegalStateException(e);}
        gap(16);text(receiveText("باندی Wi-Fi","Wi-Fi band","نطاق Wi-Fi"),15,INK,true).setGravity(Gravity.CENTER);gap(10);
        LinearLayout bands=new LinearLayout(this);bands.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);body.addView(bands,new LinearLayout.LayoutParams(-1,-2));
        addReceiveBandButton(bands,HotspotLink.BAND_AUTO);addReceiveBandButton(bands,HotspotLink.BAND_24);addReceiveBandButton(bands,HotspotLink.BAND_5);addReceiveBandButton(bands,HotspotLink.BAND_6);
        gap(12);status=text(UiText.t(108),17,BLUE,true);status.setGravity(Gravity.CENTER);
        note(receiveText("Auto باشترین باندی گونجاو هەڵدەبژێرێت. باندە کاڵەکان لەم مۆبایلەدا بەردەست نین.","Auto chooses the best available band. Dimmed bands are unavailable on this phone.","يختار Auto أفضل نطاق متاح. النطاقات الباهتة غير متاحة على هذا الهاتف."));
        note(hotspot.hostInfo()+UiText.t(110));
        button(UiText.t(133),false,this::returnToHome);
        TextView copy=text(UiText.t(112),13,MUTED,false);copy.setGravity(Gravity.CENTER);copy.setPadding(0,dp(16),0,0);
        copy.setOnClickListener(v->{android.content.ClipboardManager c=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);ClipData clip=ClipData.newPlainText("rebaritclone pairing",payload);if(Build.VERSION.SDK_INT>=33){PersistableBundle extras=new PersistableBundle();extras.putBoolean("android.content.extra.IS_SENSITIVE",true);clip.getDescription().setExtras(extras);}c.setPrimaryClip(clip);toast(UiText.t(113));});
    }
    private void addReceiveBandButton(LinearLayout row,int band){
        boolean supported=hotspot.supportsBand(band),selected=receiveBand==band;
        TextView b=label(receiveBandName(band),12,selected?Color.WHITE:INK,true);b.setTextDirection(View.TEXT_DIRECTION_LTR);b.setGravity(Gravity.CENTER);b.setPadding(dp(3),dp(14),dp(3),dp(14));b.setAlpha(supported?1f:.35f);b.setEnabled(supported);b.setSelected(selected);b.setBackground(box(selected?BLUE:0xffedf2f8,18));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(3),0,dp(3),0);row.addView(b,lp);
        if(supported)b.setOnClickListener(v->{
            if(band==receiveBand||!"qr".equals(screen)||!busy||receivePeerConnected||restartReceiveBand)return;
            receiveBand=band;hotspotSsid="";hotspotPassword="";pairText="";
            receivePreparing();cancel();restartReceiveBand=true;
        });
    }
    private void transferPage(boolean sending){
        lastNotification=0;transferNotification(sending?UiText.t(114):UiText.t(115),-1,false);
        if(phoneCloneSource||phoneCloneController)clonePage("transfer",sending?UiText.t(114):UiText.t(115),"داتاکان بە پەیوەندیی ڕاستەوخۆ دەگوازرێنەوە",3);
        else page("transfer",sending?UiText.t(114):UiText.t(115),UiText.t(116),3);

        gap(16);percentage=text(UiText.t(118),64,BLUE,true);percentage.setGravity(Gravity.CENTER);gap(20);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);progress.setProgressBackgroundTintList(ColorStateList.valueOf(0xffe0e4f1));progress.setProgressTintList(ColorStateList.valueOf(BLUE));body.addView(progress,new LinearLayout.LayoutParams(-1,dp(14)));gap(26);
        status=text(UiText.t(119),17,INK,true);status.setVisibility(phoneCloneSource||phoneCloneController?View.VISIBLE:View.GONE);details=summaryCard(UiText.t(120));details.setLineSpacing(dp(10),1);gap(16);
        Arrays.fill(categoryProgress,null);
        if(transferStats!=null){
            for(int kind:new int[]{0,1,4,8,3,2,5,6,7})if(transferStats.total(kind)>0){categoryProgress[kind]=summaryCard(categoryProgressText(kind,0,-1));categoryProgress[kind].setTextSize(14);gap(8);}
        }
        gap(16);
        button(UiText.t(121),false,()->new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(122)).setMessage(UiText.t(123)).setPositiveButton(UiText.t(111),(d,w)->cancel()).setNegativeButton(UiText.t(124),null).show());
    }
    private void resultPage(boolean success,String message,boolean receiving){
        transferNotification(success?UiText.t(125):UiText.t(126),0,true);
        if(phoneCloneSource||phoneCloneController)clonePage("result",success?UiText.t(125):UiText.t(126),message,0);else page("result",success?UiText.t(125):UiText.t(126),message,0);gap(24);
        TextView icon=text(success?"✓":"!",80,success?0xff12a875:0xffd68122,true);icon.setGravity(Gravity.CENTER);gap(20);
        text(completed+UiText.t(127),22,INK,true).setGravity(Gravity.CENTER);note(UiText.t(128));
        if(transferStats!=null){
            summaryCard(UiText.t(253)+(transferStats.total(0)-transferStats.remaining(0,completed)));gap(8);
            summaryCard(UiText.t(254)+(transferStats.total(1)-transferStats.remaining(1,completed)));gap(8);
            long seconds=transferStarted==0?0:Math.max(0,(SystemClock.elapsedRealtime()-transferStarted)/1000);
            text(UiText.t(255)+String.format(Locale.US,"%02d:%02d:%02d",seconds/3600,(seconds/60)%60,seconds%60),20,INK,true);
        }
        if(receiving&&!receivedFiles.isEmpty())button(UiText.t(256),true,()->showReceivedFiles());
        if(receiving&&receivedRecordBackup)note(UiText.t(231));
        if(receiving&&!receivedApps.isEmpty())button(UiText.t(129),true,()->installReceivedApps());
        if(receiving&&completed>0){note(Build.VERSION.SDK_INT>=29?UiText.t(130):UiText.t(131));
            if(lastContact!=null)button(UiText.t(132),true,()->importContacts());
        }
        button(UiText.t(133),false,this::returnToHome);

    }
    private void showReceivedFiles(){
        List<Item> files=new ArrayList<>(receivedFiles.values());String[] names=new String[files.size()];
        for(int n=0;n<files.size();n++)names[n]=files.get(n).name;
        new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(256)).setItems(names,(dialog,index)->{
            Item item=files.get(index);openReceivedLocation(item);
        }).setNegativeButton(UiText.t(29),null).show();
    }
    private void openReceivedLocation(Item item){
        // Resolve the destination recorded by the provider, rather than the sender's path.
        worker.execute(()->{
            Uri directory=null;String path="";
            try{
                if(Build.VERSION.SDK_INT>=29&&"media".equals(item.uri.getAuthority())){
                    try(Cursor c=getContentResolver().query(item.uri,new String[]{MediaStore.MediaColumns.RELATIVE_PATH},null,null,null)){if(c!=null&&c.moveToFirst())path=c.getString(0);}
                    if(path!=null&&!path.isEmpty())directory=DocumentsContract.buildDocumentUri("com.android.externalstorage.documents","primary:"+path.replaceAll("/+$",""));
                }else if(DocumentsContract.isDocumentUri(this,item.uri)){
                    String id=DocumentsContract.getDocumentId(item.uri);int slash=id.lastIndexOf('/');
                    if(slash>=0)directory=DocumentsContract.buildDocumentUriUsingTree(item.uri,id.substring(0,slash));
                    else if(receivingLegacy!=null)directory=receivingLegacy;
                }
            }catch(Exception ignored){}
            final Uri target=directory;final String location=path==null?"":path;
            runOnUiThread(()->{
                if(isDestroyed())return;
                if(target!=null)try{
                    Intent browse=new Intent(Intent.ACTION_VIEW).setDataAndType(target,DocumentsContract.Document.MIME_TYPE_DIR).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);browse.setClipData(ClipData.newRawUri("received location",target));startActivity(browse);return;
                }catch(ActivityNotFoundException|SecurityException ignored){}
                if(Build.VERSION.SDK_INT>=26&&target!=null)try{
                    Intent browse=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE).putExtra(DocumentsContract.EXTRA_INITIAL_URI,target);startActivity(browse);return;
                }catch(ActivityNotFoundException|SecurityException ignored){}
                alert(receiveText("شوێنی فایل","File location","مكان الملف"),location+item.name);
            });
        });
    }
    private void importContacts(){
        try{Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(lastContact,"text/x-vcard").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("contacts",lastContact));startActivity(i);}
        catch(Exception e){alert(UiText.t(132),UiText.t(136));}
    }
    private void tell(String value){runOnUiThread(()->{if(!isDestroyed()&&status!=null)status.setText(value);});}
    private void resetTotals(List<Item> items){if(transferStarted==0)transferStarted=SystemClock.elapsedRealtime();transferStats=stats(items);totalBytes=transferStats.totalBytes;finishedBytes=0;resumedBytes=0;totalKnown=transferStats.totalKnown;lastUpdate=0;startTime=SystemClock.elapsedRealtime();}
    private String eta(long remaining,double rate,long elapsed){
        if(remaining==0)return UiText.t(137);if(remaining<0||rate<=0||elapsed<3000)return UiText.t(138);
        long seconds=(long)Math.ceil(remaining/rate);return seconds>=3600?(seconds/3600)+UiText.t(139)+(seconds%3600/60)+UiText.t(140):seconds>=60?(seconds/60)+UiText.t(141)+(seconds%60)+UiText.t(142):seconds+UiText.t(142);
    }
    private String categoryProgressText(int kind,int done,int current){
        String id=kind==0?"photos":kind==1?"videos":kind==2?"apps":kind==4?"audio":kind==5?"contacts":kind==6?"calls":kind==7?"sms":kind==8?"documents":"files";
        int total=transferStats.total(kind),remaining=transferStats.remaining(kind,done),finished=total-remaining;
        String state=remaining==0?receiveText("✓ تەواوبوو","✓ Complete","✓ مكتمل"):current==kind?receiveText("گواستنەوە…","Transferring…","جار النقل…"):receiveText("چاوەڕوان","Waiting","في الانتظار");
        String unit=kind>=5&&kind<=7?receiveText(" فایلەکانی پاشەکەوت"," backup files"," ملفات نسخ احتياطي"):receiveText(" دانە"," items"," عنصر");
        String records=kind>=5&&kind<=7&&phoneCloneController&&cloneRecordCounts[kind-5]>0?"\n"+cloneRecordCounts[kind-5]+receiveText(" تۆمار لە پاشەکەوتەکەدا"," records in this backup"," سجل في النسخة الاحتياطية"):"";
        return CloneSelectionView.name(id)+"  •  "+state+"\n"+finished+" / "+total+unit+"  •  "+remaining+receiveText(" ماوە"," remaining"," متبقي")+"\n"+TransferStats.size(transferStats.bytes(kind))+records;
    }
    private void updateProgress(int index,int count,Item item,long bytes,boolean force){
        long now=SystemClock.elapsedRealtime();if(!force&&now-lastUpdate<200)return;lastUpdate=now;long moved=finishedBytes+bytes;
        int done=Math.min(count,index-1+(force?1:0));
        int percent=totalKnown&&totalBytes>0?(int)Math.min(done==count?1000:999,moved*1000.0/totalBytes):(int)(done*1000.0/Math.max(1,count));
        long remaining=transferStats.remainingBytes(moved),elapsed=now-startTime;
        double rate=Math.max(0,moved-resumedBytes)/Math.max(1,elapsed/1000.0);
        String all=TransferStats.size(totalBytes)+(totalKnown?"":UiText.t(143));
        String info=UiText.t(144)+all+UiText.t(145)+TransferStats.size(moved)+
            UiText.t(155)+String.format(Locale.US,"%.1f MB/s",rate/1000000.0)+UiText.t(156)+(remaining==0&&done<count?UiText.t(157):eta(remaining,rate,elapsed));
        final String display=info;final int currentKind=force?-1:TransferStats.kind(item.name,item.mime);
        runOnUiThread(()->{if(!screen.equals("transfer")||isDestroyed())return;transferNotification((percent/10)+"% • "+done+" / "+count,percent,false);progress.setProgress(percent);percentage.setText((percent/10)+UiText.t(158));status.setText(index+" / "+count+"  •  "+item.name);details.setText(display);for(int kind=0;kind<categoryProgress.length;kind++)if(categoryProgress[kind]!=null)categoryProgress[kind].setText(categoryProgressText(kind,done,currentKind));});
    }
    interface Work{void run()throws Exception;}
    private void job(boolean receiving,Work work){
        if(busy)return;busy=true;cancelled=false;completed=0;lastContact=null;transferStats=null;transferStarted=0;hotspot.performance(!usbMode);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);startTransferService();
        markInterrupted(true);
        worker.execute(()->{boolean ok=false;String message;Exception failure=null;
            try{checkCancel();work.run();ok=true;message=UiText.t(159);}
            catch(Exception e){failure=e;message=cancelled?UiText.t(160):friendly(e);}
            finally{closeNetwork();stopTransferService();if(ok)markInterrupted(false);}
            final boolean success=ok;final String result=message;final Exception error=failure;
            runOnUiThread(()->{
                if(isDestroyed())return;stopLink();busy=false;
                if(returnHomeAfterJob){returnHomeAfterJob=false;clearRecoveryState();home();return;}
                if(restartCloneBand){restartCloneBand=false;cancelled=false;main.postDelayed(()->startCloneReceiverHost(cloneRequestedBand),220);return;}
                if(restartReceiveBand){restartReceiveBand=false;cancelled=false;int token=linkGeneration;main.postDelayed(()->{if(!isDestroyed()&&token==linkGeneration&&"hotspot".equals(screen))beginHotspot();},250);return;}
                if(success){
                    clearUsbAttemptState();clearRecoveryState();resultPage(true,result,receiving);if(receiving&&!receivedApps.isEmpty())installReceivedApps();
                }else if(usbMode&&!cancelled&&error!=null&&recoverableUsb(error)){
                    usbAutoResume=true;usbReconnectAttempts=Math.min(Integer.MAX_VALUE-1,usbReconnectAttempts+1);clearUsbAttemptState();showReconnectWaiting();int retryToken=linkGeneration;main.postDelayed(()->{if(!isDestroyed()&&!cancelled&&!busy&&usbAutoResume&&retryToken==linkGeneration)startUsb(receiving);},usbRetryDelay());
                }else{
                    if(cancelled){clearRecoveryState();}resultPage(false,result,receiving);
                }
            });
        });
    }
    private void clearPreparedRecovery(){
        usbCleanupPrepared();usbAutoResume=false;usbControllerAuthorized=false;usbReconnectAttempts=0;
        usbControllerSelectionCache.clear();usbSourceConsentCache.clear();usbRetryItems.clear();
        cloneControllerSelectionCache.clear();cloneSourceConsentCache.clear();cloneRetryItems.clear();cloneAppSelection=null;
    }
    private void clearRecoveryState(){
        clearPreparedRecovery();sendingId="";sendingManifest="";receivingId="";receivingManifest="";usbApprovedManifest="";
        for(ResumableFile.Entry entry:resumeEntries.values())if(!entry.done)try{entry.storage.discard();}catch(Exception ignored){}
        resumeEntries.clear();resumeTargets.clear();clearUsbRecoveryPrefs();
    }
    private long usbRetryDelay(){return usbReconnectAttempts<=1?700L:usbReconnectAttempts==2?1500L:3000L;}
    private void clearUsbRecoveryPrefs(){clearReceiveCheckpoint();getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().remove("sender_items").remove("receive").remove("interrupted").apply();}
    private void clearUsbAttemptState(){
        if(!usbMode)return;
        usbControllerAuthorized=false;
    }
    private void clearUsbResumeState(){clearRecoveryState();}
    private void startTransferService(){try{Intent i=new Intent(this,TransferService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}catch(Exception ignored){}}
    private void stopTransferService(){try{stopService(new Intent(this,TransferService.class));}catch(Exception ignored){}}
    private void markInterrupted(boolean active){getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().putBoolean("interrupted",active).putLong("time",System.currentTimeMillis()).apply();}
    private boolean hadInterruptedTransfer(){return getSharedPreferences("transfer_recovery",MODE_PRIVATE).getBoolean("interrupted",false);}
    private void saveReceiveCheckpoint(int index)throws IOException{
        try{
            if(receivingJournal==null){
                receivingJournal=new File(getFilesDir(),"receive-"+UUID.randomUUID()+".journal");
                JSONObject header=new JSONObject();header.put("schema",19);header.put("session",receivingId);header.put("manifest",receivingManifest);header.put("batch",receivingBatch==null?"":receivingBatch);header.put("legacy",receivingLegacy==null?"":receivingLegacy.toString());header.put("journal",receivingJournal.getName());
                pendingJournalHeader=header.toString();
                if(!migratingReceiveJournal&&!getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().putString("receive",pendingJournalHeader).commit())throw new IOException("Checkpoint unavailable");
            }
            ResumableFile.Entry entry=resumeEntries.get(index);SavedFile target=resumeTargets.get(index);
            JSONObject state=new JSONObject();state.put("index",index);state.put("uri",entry.storage.identity());state.put("done",entry.done);state.put("length",entry.length);state.put("committed",target!=null&&target.committed);
            if(entry.digest!=null)state.put("digest",android.util.Base64.encodeToString(entry.digest,android.util.Base64.NO_WRAP));
            byte[] record=state.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);java.util.zip.CRC32 crc=new java.util.zip.CRC32();crc.update(record);
            // Append only the changed file. A large manifest is never rewritten per ACK.
            try(FileOutputStream file=new FileOutputStream(receivingJournal,true)){
                DataOutputStream out=new DataOutputStream(file);out.writeInt(record.length);out.write(record);out.writeInt((int)crc.getValue());out.flush();file.getFD().sync();
            }
        }catch(org.json.JSONException error){throw new IOException("Checkpoint unavailable",error);}
    }
    private JSONObject readReceiveJournal(File file)throws Exception{
        JSONObject entries=new JSONObject();if(!file.exists())return entries;
        try(RandomAccessFile input=new RandomAccessFile(file,"rw")){
            long valid=0;
            while(input.getFilePointer()<input.length()){
                try{
                    int length=input.readInt();if(length<1||length>65536)break;
                    byte[] data=new byte[length];input.readFully(data);int checksum=input.readInt();java.util.zip.CRC32 crc=new java.util.zip.CRC32();crc.update(data);if((int)crc.getValue()!=checksum)break;
                    JSONObject state=new JSONObject(new String(data,java.nio.charset.StandardCharsets.UTF_8));int index=state.getInt("index");if(index<1||index>MAX_FILES)break;entries.put(String.valueOf(index),state);valid=input.getFilePointer();
                }catch(EOFException|org.json.JSONException truncated){break;}
            }
            // Discard a torn tail before the next append, retaining every durable record.
            if(valid<input.length()){input.setLength(valid);input.getFD().sync();}
        }
        return entries;
    }
    private void restoreReceiveCheckpoint(String session,String sig,List<Item> items)throws Exception{
        if(!resumeEntries.isEmpty())return;
        String raw=getSharedPreferences("transfer_recovery",MODE_PRIVATE).getString("receive","");if(raw.isEmpty())return;
        JSONObject journal;
        try{journal=new JSONObject(raw);}catch(org.json.JSONException invalid){return;}
        if((journal.optInt("schema")!=18&&journal.optInt("schema")!=19)||!session.equals(journal.optString("session"))||!sig.equals(journal.optString("manifest")))return;
        receivingId=session;receivingManifest=sig;receivingBatch=journal.optString("batch",Long.toString(System.currentTimeMillis()));
        String legacy=journal.optString("legacy");if(!legacy.isEmpty())receivingLegacy=Uri.parse(legacy);
        JSONObject entries=journal.optJSONObject("entries");
        if(journal.optInt("schema")==19){String name=journal.optString("journal");if(!name.matches("receive-[a-f0-9-]{36}\\.journal"))return;receivingJournal=new File(getFilesDir(),name);entries=readReceiveJournal(receivingJournal);}
        if(entries==null)return;
        Iterator<String> keys=entries.keys();
        while(keys.hasNext()){
            String key=keys.next();int index=Integer.parseInt(key);if(index<1||index>items.size())throw new IOException("Invalid stored checkpoint");
            JSONObject state=entries.getJSONObject(key);Uri uri=Uri.parse(state.getString("uri"));
            SavedFile target=new SavedFile(items.get(index-1),uri,state.optBoolean("committed"));
            UriResumeStorage store=new UriResumeStorage(getContentResolver(),uri,Build.VERSION.SDK_INT<29);
            ResumableFile.Entry entry=new ResumableFile.Entry(store);entry.done=state.optBoolean("done");entry.length=state.optLong("length");
            if(entry.done){entry.digest=android.util.Base64.decode(state.getString("digest"),android.util.Base64.DEFAULT);if(entry.digest.length!=32)throw new IOException("Invalid stored checkpoint");rememberReceived(target,items.get(index-1));}
            else{store.validateWritable();store.length();}
            entry.checkpoint=ignored->saveReceiveCheckpoint(index);resumeTargets.put(index,target);resumeEntries.put(index,entry);
        }
        if(journal.optInt("schema")==18&&!resumeEntries.isEmpty()){
            migratingReceiveJournal=true;
            try{
                for(int index:new ArrayList<>(resumeEntries.keySet()))saveReceiveCheckpoint(index);
                if(!getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().putString("receive",pendingJournalHeader).commit())throw new IOException("Checkpoint unavailable");
            }finally{migratingReceiveJournal=false;}
        }
    }
    private void saveSenderCheckpoint(List<Item> items){
        try{
            org.json.JSONArray rows=new org.json.JSONArray();for(Item item:items){JSONObject row=new JSONObject();row.put("uri",item.uri==null?"":item.uri.toString());row.put("name",item.name);row.put("mime",item.mime);row.put("size",item.size);row.put("path",item.relativePath);row.put("modified",item.modified);row.put("taken",item.taken);rows.put(row);}
            JSONObject journal=new JSONObject();journal.put("items",rows);journal.put("session",sendingId);journal.put("manifest",sendingManifest);
            getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().putString("sender_items",journal.toString()).commit();
        }catch(Exception ignored){}
    }
    private void restoreSenderCheckpoint(){
        if(!hadInterruptedTransfer()||!selection.isEmpty())return;
        String raw=getSharedPreferences("transfer_recovery",MODE_PRIVATE).getString("sender_items","");if(raw.isEmpty())return;
        try{
            JSONObject journal=new JSONObject(raw);sendingId=journal.optString("session");sendingManifest=journal.optString("manifest");org.json.JSONArray rows=journal.getJSONArray("items");
            for(int n=0;n<rows.length();n++){JSONObject row=rows.getJSONObject(n);String uri=row.optString("uri");if(uri.isEmpty())continue;Item item=new Item(Uri.parse(uri),row.optString("name"),row.optString("mime"),row.optLong("size",-1));item.relativePath=row.optString("path","");item.modified=row.optLong("modified",-1);item.taken=row.optLong("taken",-1);selection.add(item);}
            if(!selection.isEmpty())toast(receiveText("گواستنەوەی پێشوو دۆزرایەوە؛ دوای پەیوەستبوونەوە لە هەمان شوێن بەردەوام دەبێت.","Previous transfer found. It can continue from its saved position after reconnecting.","عُثر على النقل السابق. يمكن متابعته من الموضع المحفوظ بعد إعادة الاتصال."));
        }catch(Exception ignored){}
    }
    private void clearSenderCheckpoint(){getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().remove("sender_items").apply();}
    private void clearReceiveCheckpoint(){
        if(receivingJournal!=null){receivingJournal.delete();receivingJournal=null;pendingJournalHeader=null;}
        try{String raw=getSharedPreferences("transfer_recovery",MODE_PRIVATE).getString("receive","");if(!raw.isEmpty()){String name=new JSONObject(raw).optString("journal");if(name.matches("receive-[a-f0-9-]{36}\\.journal"))new File(getFilesDir(),name).delete();}}catch(Exception ignored){}
        getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().remove("receive").apply();
    }
    private String friendly(Exception e){
        if("SOURCE_CHANGED".equals(e.getMessage())||"USB_SOURCE_CHANGED".equals(e.getMessage()))return UiText.t(161);
        if(e instanceof SecurityException)return UiText.t(162);
        if("TOO_MANY".equals(e.getMessage()))return UiText.t(163);
        if("DECLINED".equals(e.getMessage()))return UiText.t(164);
        if((e.getMessage()!=null&&e.getMessage().startsWith("Protocol mismatch"))||"USB_VERSION".equals(e.getMessage()))return receiveText("ئەپەکە لە هەردوو مۆبایل بۆ وەشانی 18.0 یان نوێتر نوێ بکەرەوە.","Update both phones to version 18.0 or later.","حدّث التطبيق على الهاتفين إلى الإصدار 18.0 أو أحدث.");
        if("Not enough storage".equals(e.getMessage()))return receiveText("بۆشایی پێویست بۆ بەشی ماوەی فایلەکان نییە.","There is not enough free space for the remaining files.","لا توجد مساحة كافية للأجزاء المتبقية من الملفات.");
        if(e.getMessage()!=null&&e.getMessage().contains("choose local device storage"))return receiveText("بۆ گواستنەوەی فایلە گەورەکان فۆڵدەری ناوخۆی مۆبایل هەڵبژێرە.","Choose a folder on device storage for resumable large files.","اختر مجلدًا على تخزين الجهاز لنقل الملفات الكبيرة مع الاستئناف.");
        if(usbMode)return UiText.t(165);
        if(e instanceof java.net.SocketTimeoutException)return UiText.t(166);
        if(e instanceof java.net.ConnectException||"CONNECT".equals(e.getMessage()))return UiText.t(167);
        if("PAIR".equals(e.getMessage()))return UiText.t(168);
        if(e instanceof EOFException||e instanceof java.net.SocketException)return UiText.t(169);
        return UiText.t(170);
    }
    private void cancel(){if(nearby!=null)nearby.close();if(nearbyApproval!=null)nearbyApproval.dismiss();restartReceiveBand=false;cancelled=true;closeNetwork();CountDownLatch a=approval;if(a!=null)a.countDown();if(approvalDialog!=null)approvalDialog.dismiss();tell(UiText.t(171));}
    private void closeNetwork(){if(usb!=null)usb.closeStreams();try{if(socket!=null)socket.close();}catch(Exception ignored){}try{if(listener!=null)listener.close();}catch(Exception ignored){}}
    private void checkCancel()throws IOException{if(cancelled||Thread.currentThread().isInterrupted())throw new IOException("Cancelled");}
    private void expect(SecureChannel c,int expected)throws Exception{byte[] p=c.read();if(p.length!=1||p[0]!=expected)throw new IOException("DECLINED");}
    private void tuneTransferSocket(Socket s)throws SocketException{
        s.setKeepAlive(true);s.setTcpNoDelay(true);s.setSendBufferSize(4194304);s.setReceiveBufferSize(4194304);s.setSoTimeout(300000);
    }
    private static boolean recoverableNetwork(Exception error){return TransferFailure.network(error);}
    private static boolean recoverableUsb(Exception error){return TransferFailure.usb(error);}
    private void closeActiveSocket(){Socket active=socket;socket=null;if(active!=null)try{active.close();}catch(Exception ignored){}}
    private void restartHostedLink(boolean clone){
        if(isDestroyed()||cancelled||!busy||usbMode||hostRecoveryInProgress)return;
        hostRecoveryInProgress=true;closeActiveSocket();showReconnectWaiting();int token=++linkGeneration;
        startHostedRecovery(clone,token);
    }
    private void startHostedRecovery(boolean clone,int token){
        if(isDestroyed()||cancelled||!busy||token!=linkGeneration){hostRecoveryInProgress=false;return;}
        hotspot.startBandReusing(clone?cloneBand:receiveBand,hotspotSsid,hotspotPassword,new HotspotLink.HostCallback(){
            public void ready(String ssid,String password){
                if(isDestroyed()||cancelled||token!=linkGeneration)return;
                hotspotSsid=ssid;hotspotPassword=password;finishHostedRecovery(clone,token,0);
            }
            public void failed(String reason){
                if(isDestroyed()||cancelled||token!=linkGeneration)return;
                lastHotspotError=reason;
                if(clone&&cloneAutoNegotiation&&cloneBand!=HotspotLink.BAND_24){failedCloneBands|=cloneBand==HotspotLink.BAND_6?4:2;cloneBand=(hotspot.hostBandMask()&clonePeerBandMask&~failedCloneBands&2)!=0?HotspotLink.BAND_5:HotspotLink.BAND_24;main.postDelayed(()->startHostedRecovery(true,token),500);return;}
                if(!hostRecoveryInProgress){restartHostedLink(clone);return;}showReconnectWaiting();main.postDelayed(()->startHostedRecovery(clone,token),3000);
            }
        });
    }
    private void finishHostedRecovery(boolean clone,int token,int attempt){
        if(isDestroyed()||cancelled||!busy||token!=linkGeneration)return;
        List<String> hosts=wifiAddresses();
        if(hosts.isEmpty()){
            if(attempt>=20){startHostedRecovery(clone,token);return;}
            main.postDelayed(()->finishHostedRecovery(clone,token,attempt+1),500);return;
        }
        hostRecoveryInProgress=false;hotspot.performance(true);
        pairText=hotspotSsid.isEmpty()?Pairing.encode(hosts,hostPairCode):Pairing.encodeHotspot(hosts,hostPairCode,hotspotSsid,hotspotPassword);
        if(socket==null||!socket.isConnected()||socket.isClosed()){if(clone)cloneReceiverQrPage(pairText);else qrPage(pairText);}
    }
    private void showReconnectWaiting(){
        runOnUiThread(()->{
            if(isDestroyed()||cancelled||(!busy&&!usbAutoResume))return;
            page("reconnecting",receiveText("پەیوەندی پچڕا","Connection interrupted","انقطع الاتصال"),receiveText("هەردوو ئەپەکە کراوە بهێڵەوە و پەیوەندی بگەڕێنەوە. دوای پەیوەستبوون تەنها «بەردەوام بە» هەڵبژێرە.","Keep both apps open and reconnect. Then approve Continue to resume.","أبقِ التطبيقين مفتوحين وأعد الاتصال، ثم وافق على متابعة لاستئناف النقل."),3);
            ProgressBar spinner=new ProgressBar(this);body.addView(spinner);
            if(!usbMode&&(phoneCloneSource||(!phoneCloneController&&!sendingId.isEmpty())))button(receiveText("سکانی QR بۆ پەیوەستبوونەوە","Scan QR to reconnect","مسح QR لإعادة الاتصال"),true,this::scan);
            button(UiText.t(133),false,this::returnToHome);
        });
    }
    private void returnToHome(){
        returnHomeAfterJob=true;
        if(busy)cancel();
        else{stopLink();clearRecoveryState();returnHomeAfterJob=false;home();}
    }
    private void reconnectPause(int attempt)throws Exception{
        showReconnectWaiting();long ms=Math.min(6000L,800L*(Math.min(attempt,8)+1));
        for(long n=0;n<ms;n+=100){checkCancel();Thread.sleep(100);}
    }
    private SecureChannel connectTransferPeer(Pairing peer)throws Exception{
        Exception last=null;
        Pairing active=pendingPeer==null?peer:pendingPeer;
        for(String host:active.hosts){
            checkCancel();
            try{
                Network network=transferNetwork;
                ConnectivityManager cm=getSystemService(ConnectivityManager.class);
                if(network==null||cm.getNetworkCapabilities(network)==null){network=hotspot.currentWifi();transferNetwork=network;}
                if(network==null&&!nearbyTransfer)throw new ConnectException("CONNECT");
                socket=nearbyTransfer?new Socket():network.getSocketFactory().createSocket();if(nearbyTransfer&&!active.localAddress.isEmpty())socket.bind(new InetSocketAddress(active.localAddress,0));tuneTransferSocket(socket);socket.setSoTimeout(15000);
                socket.connect(new InetSocketAddress(host,PORT),8000);checkCancel();
                SecureChannel channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),active.key,false);
                socket.setSoTimeout(300000);return channel;
            }catch(Exception error){last=error;closeActiveSocket();if(cancelled||!recoverableNetwork(error))throw error;}
        }
        if(last!=null)throw last;throw new ConnectException("CONNECT");
    }
    private void send(Pairing peer){
        if(busy)return;usbMode=false;
        transferPage(true);List<Item> items=new ArrayList<>(selection);saveSenderCheckpoint(items);
        job(false,()->{
            int attempt=0;
            for(;;)try{
                SecureChannel channel=connectTransferPeer(peer);
                try(SecureChannel.Keepalive alive=channel.startKeepalive()){sendFiles(channel,items);}
                break;
            }catch(Exception error){
                closeActiveSocket();if(cancelled||!recoverableNetwork(error))throw error;
                reconnectPause(attempt++);
            }
        });
    }
    private void sendFiles(SecureChannel channel,List<Item> items)throws Exception{
            for(Item item:items)enrichTransferMeta(item);vipTransferStarted=SystemClock.elapsedRealtime();
            if(items.isEmpty()||items.size()>MAX_FILES)throw new IOException("TOO_MANY");
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(buffer);String sig=manifest(items,true);if(sendingId.isEmpty()||!sig.equals(sendingManifest)){sendingId=UUID.randomUUID().toString();sendingManifest=sig;}
            saveSenderCheckpoint(items);out.writeUTF(sendingId);out.writeInt(items.size());channel.write(buffer.toByteArray());
            for(Item item:items){checkCancel();enrichTransferMeta(item);buffer.reset();out.writeUTF(safeName(item.name));out.writeUTF(validMime(item.mime));out.writeLong(item.size);out.writeUTF(safeRelativePath(item.relativePath));out.writeLong(item.modified);out.writeLong(item.taken);channel.write(buffer.toByteArray());}
            tell(UiText.t(173));expect(channel,1);resetTotals(items);completed=0;int index=0;
            for(Item item:items){checkCancel();index++;final int position=index;final boolean[] first={true};long bytes;
                try(InputStream in=new BufferedInputStream(openSource(item.uri),1048576)){
                    if(in==null)throw new IOException("Source unavailable");
                    bytes=ResumableFile.send(channel,in,item.size,usbMode?524288:1048576,n->{checkCancel();if(n<0)return;if(first[0]){resumedBytes+=n;first[0]=false;}updateProgress(position,items.size(),item,n,false);});
                }
                completed++;updateProgress(index,items.size(),item,bytes,true);finishedBytes+=bytes;
             }TransferCompletion.sender(channel,usbMode);if(!usbMode){clearSenderCheckpoint();markInterrupted(false);}vipHistory("Sent • "+items.size()+" files • "+TransferStats.size(finishedBytes));sendingId="";sendingManifest="";
    }

    private InputStream openSource(Uri uri)throws Exception{return "file".equals(uri.getScheme())?new FileInputStream(new File(uri.getPath())):getContentResolver().openInputStream(uri);}
    private void receive(){
        if(busy)return;usbMode=false;receivePeerConnected=false;
        List<String> hosts=wifiAddresses();if(hosts.isEmpty()){alert(UiText.t(174),UiText.t(175));return;}
        String code=SecureChannel.newCode();hostPairCode=code;pairText=hotspotSsid.isEmpty()?Pairing.encode(hosts,code):Pairing.encodeHotspot(hosts,code,hotspotSsid,hotspotPassword);byte[] key=SecureChannel.parseCode(code);
        page("waiting",UiText.t(176),UiText.t(45),1);
        job(true,()->{
            listener=new ServerSocket();checkCancel();listener.setReuseAddress(true);listener.bind(new InetSocketAddress(PORT));listener.setSoTimeout(1000);
            runOnUiThread(()->{if(!isDestroyed()&&!cancelled)qrPage(pairText);});
            for(;;){
            SecureChannel channel=null;
            while(channel==null){checkCancel();
                try{socket=listener.accept();tuneTransferSocket(socket);socket.setSoTimeout(15000);channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,true);}
                catch(SocketTimeoutException e){if(socket!=null)try{socket.close();}catch(Exception ignored){}}
                catch(Exception e){checkCancel();if(socket!=null)try{socket.close();}catch(Exception ignored){}}
            }
            socket.setSoTimeout(300000);checkCancel();receivePeerConnected=true;
            runOnUiThread(()->{if(!isDestroyed()&&!cancelled){page("selectionWaiting",UiText.t(279),UiText.t(280),2);button(UiText.t(111),false,()->cancel());}});
            try(SecureChannel.Keepalive alive=channel.startKeepalive()){receiveFiles(channel);break;}
            catch(Exception e){if(cancelled||listener.isClosed()||!recoverableNetwork(e))throw e;
                try{socket.close();}catch(Exception ignored){}showReconnectWaiting();Thread.sleep(700);
            }
            }
        });
    }
    private void receiveFiles(SecureChannel channel)throws Exception{
        DataInputStream header=new DataInputStream(new ByteArrayInputStream(channel.read()));String session=header.readUTF();
        if(!session.matches("[a-f0-9-]{36}"))throw new IOException("Invalid session");int count=header.readInt();if(count<1||count>MAX_FILES||header.available()!=0)throw new IOException("TOO_MANY");
        List<Item> items=new ArrayList<>();
        for(int n=0;n<count;n++){
            checkCancel();DataInputStream meta=new DataInputStream(new ByteArrayInputStream(channel.read()));Item item=new Item();
            item.name=safeName(meta.readUTF());item.mime=validMime(meta.readUTF());item.size=meta.readLong();item.relativePath=safeRelativePath(meta.readUTF());item.modified=meta.readLong();item.taken=meta.readLong();
            if(item.size< -1||meta.available()!=0)throw new IOException("Invalid metadata");items.add(item);
        }
        String sig=manifest(items,false);restoreReceiveCheckpoint(session,sig,items);
        boolean sameSession=session.equals(receivingId)&&sig.equals(receivingManifest);
        boolean approved=usbMode?(usbControllerAuthorized||sig.equals(usbApprovedManifest)):(phoneCloneController&&cloneControllerAuthorized)||sameSession;
        if(sameSession&&!resumeEntries.isEmpty()){
            if(!confirmResume()){channel.write(new byte[]{0});throw new IOException("DECLINED");}
        }else if(!approved&&!confirm(items)){channel.write(new byte[]{0});throw new IOException("DECLINED");}
        checkCancel();
        if(!sameSession){
            if(usbMode&&usbAutoResume&&!receivingId.isEmpty())throw new IOException("USB_SOURCE_CHANGED");
            for(ResumableFile.Entry entry:resumeEntries.values())if(!entry.done)try{entry.storage.discard();}catch(Exception ignored){}
            resumeEntries.clear();resumeTargets.clear();clearReceiveCheckpoint();receivedFiles.clear();receivedIdentity.clear();receivedApps.clear();receivedRecordBackup=false;
            receivingId=session;receivingManifest=sig;receivingBatch=Long.toString(System.currentTimeMillis());receivingLegacy=null;
        }
        if(usbMode)usbApprovedManifest=sig;
        if(receivingBatch==null||receivingBatch.isEmpty())receivingBatch=Long.toString(System.currentTimeMillis());
        if(!enoughStorage(items)){channel.write(new byte[]{0});throw new IOException("Not enough storage");}
        if(Build.VERSION.SDK_INT<29&&receivingLegacy==null){
            Uri parent=DocumentsContract.buildDocumentUriUsingTree(folder,DocumentsContract.getTreeDocumentId(folder));
            receivingLegacy=DocumentsContract.createDocument(getContentResolver(),parent,DocumentsContract.Document.MIME_TYPE_DIR,"rebaritclone-"+receivingBatch);
            if(receivingLegacy==null)throw new IOException("Folder unavailable");
        }
        // Validate the actual destination/provider and volume before accepting data.
        try{
            ResumableFile.Entry first=receiveEntry(1,items.get(0));
            if(!TransferSpace.fits(remainingStorage(items),((UriResumeStorage)first.storage).availableBytes()))throw new IOException("Not enough storage");
        }catch(Exception error){channel.write(new byte[]{0});throw error;}
        channel.write(new byte[]{1});resetTotals(items);completed=0;runOnUiThread(()->{if(!isDestroyed()&&!cancelled)transferPage(false);});
        long[] pending=pendingStorage(items);int index=0;
        for(Item item:items){
            checkCancel();index++;final int position=index;final boolean[] first={true};ResumableFile.Entry entry=receiveEntry(index,item);
            if(!entry.done&&!TransferSpace.fits(pending[index-1],((UriResumeStorage)entry.storage).availableBytes()))throw new IOException("Not enough storage");
            SavedFile target=resumeTargets.get(index);
            long bytes=ResumableFile.receiveDirect(channel,entry,item.size,n->{checkCancel();if(n<0)return;if(first[0]){resumedBytes+=n;first[0]=false;}updateProgress(position,count,item,n,false);},state->{
                target.commit(item.name);((UriResumeStorage)state.storage).renamed(target.uri);rememberReceived(target,item);
            });
            completed++;updateProgress(index,count,item,bytes,true);finishedBytes+=bytes;
        }
        TransferCompletion.receiver(channel,usbMode);clearReceiveCheckpoint();markInterrupted(false);vipHistory("Received • "+items.size()+" files • "+TransferStats.size(finishedBytes));
    }
    private ResumableFile.Entry receiveEntry(int index,Item item)throws Exception{
        ResumableFile.Entry old=resumeEntries.get(index);if(old!=null)return old;
        SavedFile target=new SavedFile(item,receivingBatch,receivingLegacy);
        try{
            UriResumeStorage store=new UriResumeStorage(getContentResolver(),target.uri,Build.VERSION.SDK_INT<29);store.validateWritable();
            ResumableFile.Entry entry=new ResumableFile.Entry(store);entry.checkpoint=ignored->saveReceiveCheckpoint(index);
            resumeTargets.put(index,target);resumeEntries.put(index,entry);saveReceiveCheckpoint(index);return entry;
        }catch(Exception error){resumeTargets.remove(index);resumeEntries.remove(index);target.discard();throw error;}
    }

    private void rememberReceived(SavedFile file,Item item){
        Item saved=new Item(file.uri,item.name,item.mime,item.size);saved.relativePath=item.relativePath;saved.modified=item.modified;saved.taken=item.taken;receivedFiles.put(file.uri.toString(),saved);receivedIdentity.put(receivedKey(item),file.uri);
        if(item.name.equals("calls-selected-backup.json")||item.name.equals("sms-selected-backup.json"))receivedRecordBackup=true;
        String lower=item.name.toLowerCase(Locale.ROOT);if(lower.endsWith(".rbapp")||lower.endsWith(".apk"))receivedApps.put(file.uri.toString(),item.name);if(lower.endsWith(".vcf"))lastContact=file.uri;
    }

    private String receivedKey(Item item){return item.name+"\n"+item.size+"\n"+safeRelativePath(item.relativePath);}
    private Uri findSessionDuplicate(Item item){return receivedIdentity.get(receivedKey(item));}
    private Uri findDuplicate(Item item){
        Uri session=findSessionDuplicate(item);if(session!=null)return session;
        if(Build.VERSION.SDK_INT<29)return null;
        try{
            Uri collection=item.mime.startsWith("image/")?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:item.mime.startsWith("video/")?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:item.mime.startsWith("audio/")?MediaStore.Audio.Media.EXTERNAL_CONTENT_URI:MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String path=MediaDestination.relativePath(item.mime,safeRelativePath(item.relativePath),Build.VERSION.SDK_INT);
            try(Cursor c=getContentResolver().query(collection,new String[]{MediaStore.MediaColumns._ID},MediaStore.MediaColumns.DISPLAY_NAME+"=? AND "+MediaStore.MediaColumns.SIZE+"=? AND "+MediaStore.MediaColumns.RELATIVE_PATH+"=?",new String[]{item.name,String.valueOf(item.size),path},null)){
                if(c!=null&&c.moveToFirst())return ContentUris.withAppendedId(collection,c.getLong(0));
            }
        }catch(Exception ignored){}
        return null;
    }
    private class SavedFile{
        Uri uri;boolean committed,duplicate;final Item item;
        SavedFile(Item item,Uri existing,boolean finalized){this.item=item;uri=existing;committed=finalized;}
        SavedFile(Item item,String batch,Uri legacy)throws Exception{this.item=item;
            if(Build.VERSION.SDK_INT>=29){Uri collection;
                if(item.mime.startsWith("image/")){collection=MediaStore.Images.Media.EXTERNAL_CONTENT_URI;}
                else if(item.mime.startsWith("video/")){collection=MediaStore.Video.Media.EXTERNAL_CONTENT_URI;}
                else if(item.mime.startsWith("audio/")){collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;}
                else{collection=MediaStore.Downloads.EXTERNAL_CONTENT_URI;}
                ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,item.name);values.put(MediaStore.MediaColumns.MIME_TYPE,item.mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH,MediaDestination.relativePath(item.mime,safeRelativePath(item.relativePath),Build.VERSION.SDK_INT));
                if(item.modified>0)values.put(MediaStore.MediaColumns.DATE_MODIFIED,item.modified/1000L);
                if(item.taken>0&&(item.mime.startsWith("image/")||item.mime.startsWith("video/")))values.put(MediaStore.Images.ImageColumns.DATE_TAKEN,item.taken);
                values.put(MediaStore.MediaColumns.IS_PENDING,1);uri=getContentResolver().insert(collection,values);
            }else uri=DocumentsContract.createDocument(getContentResolver(),legacy,"application/octet-stream",item.name+".partial");
            if(uri==null)throw new IOException("Storage unavailable");
        }
        void commit(String name)throws Exception{
            if(committed)return;
            if(Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.IS_PENDING,0);if(item.modified>0)values.put(MediaStore.MediaColumns.DATE_MODIFIED,item.modified/1000L);if(item.taken>0&&(item.mime.startsWith("image/")||item.mime.startsWith("video/")))values.put(MediaStore.Images.ImageColumns.DATE_TAKEN,item.taken);if(getContentResolver().update(uri,values,null,null)!=1)throw new IOException("Finalize failed");}
            else{Uri renamed=DocumentsContract.renameDocument(getContentResolver(),uri,name);if(renamed==null)throw new IOException("Finalize failed");uri=renamed;}
            committed=true;
        }
        void discard(){try{if(Build.VERSION.SDK_INT>=29)getContentResolver().delete(uri,null,null);else DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}
    }
    private boolean confirmResume()throws InterruptedException{
        CountDownLatch latch=new CountDownLatch(1);approval=latch;boolean[] yes={false};
        runOnUiThread(()->{
            if(isDestroyed()||cancelled){latch.countDown();return;}
            approvalDialog=new AlertDialog.Builder(UiText.context(this))
                .setTitle(receiveText("بەردەوام بە","Continue","متابعة"))
                .setMessage(receiveText("پەیوەندی گەڕایەوە. گواستنەوە لە شوێنی پچڕان بەردەوام بێتەوە؟","The connection is back. Continue from where the transfer stopped?","عاد الاتصال. هل تريد متابعة النقل من موضع الانقطاع؟"))
                .setPositiveButton(UiText.t(124),(d,w)->{yes[0]=true;latch.countDown();})
                .setNegativeButton(UiText.t(29),(d,w)->latch.countDown()).setCancelable(false).create();
            approvalDialog.show();
        });
        latch.await();approval=null;approvalDialog=null;return yes[0]&&!cancelled;
    }
    private boolean confirm(List<Item> items)throws InterruptedException{
        CountDownLatch latch=new CountDownLatch(1);approval=latch;boolean[] yes={false};
        runOnUiThread(()->{if(isDestroyed()||cancelled){latch.countDown();return;}
            Context themed=UiText.context(this);LinearLayout panel=new LinearLayout(themed);panel.setOrientation(LinearLayout.VERTICAL);panel.setGravity(Gravity.CENTER);panel.setPadding(dp(28),dp(30),dp(28),dp(24));panel.setLayoutDirection(UiText.direction());
            TextView icon=label("↓",54,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(box(BLUE,28));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(92),dp(92));ip.gravity=Gravity.CENTER_HORIZONTAL;panel.addView(icon,ip);
            TextView title=label("داتاکان دەنێردرێن",24,INK,true);title.setGravity(Gravity.CENTER);title.setPadding(0,dp(18),0,dp(22));panel.addView(title);
            Button receive=new Button(themed);receive.setText("↓  وەرگرتن");receive.setTextColor(Color.WHITE);receive.setTextSize(20);receive.setAllCaps(false);receive.setTypeface(null,Typeface.BOLD);receive.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),box(BLUE,20),null));panel.addView(receive,new LinearLayout.LayoutParams(-1,dp(72)));
            Space gap=new Space(themed);panel.addView(gap,new LinearLayout.LayoutParams(1,dp(12)));
            Button reject=new Button(themed);reject.setText("✕  ڕەتکردنەوە");reject.setTextColor(0xffc62828);reject.setTextSize(19);reject.setAllCaps(false);reject.setTypeface(null,Typeface.BOLD);reject.setBackground(new RippleDrawable(ColorStateList.valueOf(0x18c62828),box(0xffffeeee,20),null));panel.addView(reject,new LinearLayout.LayoutParams(-1,dp(72)));
            approvalDialog=new AlertDialog.Builder(themed).setView(panel).setCancelable(false).create();
            reject.setOnClickListener(v->{approvalDialog.dismiss();latch.countDown();});receive.setOnClickListener(v->{yes[0]=true;approvalDialog.dismiss();latch.countDown();});approvalDialog.show();
        });
        latch.await();approval=null;return yes[0]&&!cancelled;
    }

    private static String safeRelativePath(String path){
        if(path==null)return "";
        path=path.replace('\\','/').replaceAll("^/+","");
        StringBuilder out=new StringBuilder();
        for(String part:path.split("/")){
            part=safeName(part);
            if(part.isEmpty()||part.equals(".")||part.equals(".."))continue;
            if(out.length()>0)out.append('/');
            out.append(part);
        }
        return out.length()==0?"":out.append('/').toString();
    }
    private void enrichTransferMeta(Item item){
        if(item==null||item.uri==null)return;
        if("file".equals(item.uri.getScheme())){
            try{
                File file=new File(item.uri.getPath()).getCanonicalFile();
                if(file.isFile()){
                    item.modified=file.lastModified();if(item.size<0)item.size=file.length();
                    try{item.relativePath=safeRelativePath(StorageFiles.relativeDirectory(Environment.getExternalStorageDirectory(),file));}catch(IOException ignored){}
                }
            }catch(Exception ignored){}
            return;
        }
        String[] projection=Build.VERSION.SDK_INT>=29?
            new String[]{MediaStore.MediaColumns.RELATIVE_PATH,MediaStore.MediaColumns.DATE_MODIFIED}:
            new String[]{MediaStore.MediaColumns.DATA,MediaStore.MediaColumns.DATE_MODIFIED};
        try(Cursor c=getContentResolver().query(item.uri,projection,null,null,null)){
            if(c!=null&&c.moveToFirst()){
                String path=c.isNull(0)?"":c.getString(0);
                if(Build.VERSION.SDK_INT<29&&path!=null){
                    int slash=path.lastIndexOf('/');path=slash>0?path.substring(0,slash+1):"";
                    String root=Environment.getExternalStorageDirectory().getAbsolutePath()+"/";
                    if(path.startsWith(root))path=path.substring(root.length());
                }
                item.relativePath=safeRelativePath(path);
                if(!c.isNull(1))item.modified=c.getLong(1)*1000L;
            }
        }catch(Exception ignored){}
        if(item.mime!=null&&(item.mime.startsWith("image/")||item.mime.startsWith("video/"))){
            try(Cursor c=getContentResolver().query(item.uri,new String[]{MediaStore.Images.ImageColumns.DATE_TAKEN},null,null,null)){
                if(c!=null&&c.moveToFirst()&&!c.isNull(0))item.taken=c.getLong(0);
            }catch(Exception ignored){}
        }
    }
    private static String safeName(String name){if(name==null)name="file";name=name.replaceAll("[\\p{Cntrl}/\\\\]","_");if(name.isEmpty()||name.equals(".")||name.equals(".."))name="file";return name.length()>160?name.substring(0,160):name;}
    private static String validMime(String mime){return mime!=null&&mime.length()<128&&mime.matches("[a-zA-Z0-9.+_-]+/[a-zA-Z0-9.+_-]+")?mime:"application/octet-stream";}
    private Item inspect(Uri uri){Item item=new Item(uri,"file",validMime(getContentResolver().getType(uri)),-1);try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){if(c!=null&&c.moveToFirst()){item.name=safeName(c.getString(0));if(!c.isNull(1))item.size=c.getLong(1);}}enrichTransferMeta(item);return item;}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(NearbyClone.activityResult(this,request,result))return;
        if(request==SEND_FILES_SETTINGS){if(sendPicker!=null)sendPicker.reload();return;}
        if(request==UNINSTALL_APP){
            String done=uninstallCurrentPackage;uninstallCurrentPackage=null;
            if(done==null)return;
            boolean removed=false;
            try{getPackageManager().getApplicationInfo(done,0);}
            catch(PackageManager.NameNotFoundException missing){removed=true;}
            uninstallPickerFinished(done,removed);
            if(removed){main.post(this::launchNextUninstall);}
            else{
                uninstallQueue.clear();uninstallPicker=null;
                toast("سڕینەوە وەستاندرا؛ ئەپە دیاریکراوەکان هەر دیاریکراو دەمێننەوە");
            }
            return;
        }
        if(request==SETUP_SETTINGS){if(setupActive)permissionSummary();return;}
        if(request==WIFI_SETTINGS||request==LOCATION_SETTINGS){
            if(afterCloneLinkSettings!=null){Runnable next=afterCloneLinkSettings;afterCloneLinkSettings=null;
                android.net.wifi.WifiManager wm=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
                boolean enabled=request==WIFI_SETTINGS?wm!=null&&wm.isWifiEnabled():locationEnabled();
                if(enabled)next.run();else toast(UiText.t(185));return;}
            if(!phoneCloneController&&!"hotspot".equals(screen))return;
            android.net.wifi.WifiManager wm=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            boolean ready=(request==WIFI_SETTINGS&&wm!=null&&wm.isWifiEnabled())||(request==LOCATION_SETTINGS&&locationEnabled());
            if(ready){if(phoneCloneController)startCloneReceiverHost(cloneBand);else beginHotspot();}
            else{if(phoneCloneController){deviceRoles(false);note(UiText.t(185));}else{receiverSetup();note(UiText.t(185));}}return;
        }
        if(request==FOLDER&&result!=RESULT_OK){resumeFolder=false;if(resumeUsbFolder){resumeUsbFolder=false;usbReceiverSetup();}else if(phoneCloneController)deviceRoles(false);else receiverSetup();return;}
        if(result!=RESULT_OK||data==null)return;
        if(request==FOLDER&&data.getData()!=null){folder=data.getData();if(resumeUsbFolder){resumeUsbFolder=false;startUsb(true);}else if(resumeFolder){resumeFolder=false;if(phoneCloneController)startCloneReceiverHost(cloneBand);else beginHotspot();}else receiverSetup();}
        if(request==SCAN){usePair(data.getStringExtra("pairing"));}
        if(request==QR_IMAGE&&data.getData()!=null)decodeImage(data.getData());
        if(request==FILES){List<Uri> uris=new ArrayList<>();if(data.getClipData()!=null){for(int n=0;n<data.getClipData().getItemCount();n++)uris.add(data.getClipData().getItemAt(n).getUri());}else if(data.getData()!=null)uris.add(data.getData());
            busy=true;cancelled=false;loading(UiText.t(186));worker.execute(()->{try{List<Item> list=new ArrayList<>();for(Uri uri:uris){checkCancel();list.add(inspect(uri));}runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.put("files",list);openSendPicker();});}catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(187),friendly(e));});}});
        }
    }
    @Override public void onBackPressed(){if(setupActive){setupActive=false;setupWaiting=false;usbSourcePermissionFlow=false;home();return;}if(linking){stopLink();home();return;}if(busy){new AlertDialog.Builder(UiText.context(this)).setMessage(UiText.t(188)).setPositiveButton(UiText.t(189),(d,w)->cancel()).setNegativeButton(UiText.t(190),null).show();}else if(screen.equals("sendPicker")){if(sendPicker!=null&&sendPicker.back())return;closeGallery();home();}else if(screen.equals("home"))super.onBackPressed();else if(screen.equals("connect"))home();else home();}
    @Override protected void onDestroy(){uninstallQueue.clear();uninstallCurrentPackage=null;uninstallPicker=null;if(onlineUpdate!=null)onlineUpdate.destroy();closeGallery();NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null&&busy)manager.cancel(74);stopLink();cancel();usb.destroy();worker.shutdownNow();super.onDestroy();}
    private static class Phones extends View{
        Paint p=new Paint(3);Phones(Context c){super(c);setContentDescription(UiText.t(191));}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float scale=Math.min(getWidth()/340f,getHeight()/180f);c.save();c.translate((getWidth()-340*scale)/2,(getHeight()-180*scale)/2);c.scale(scale,scale);
            p.setColor(0xffe8efff);c.drawCircle(170,90,84,p);phone(c,55,23,0xffd6e5ff);phone(c,207,8,0xff2563eb);
            p.setColor(BLUE);p.setStrokeWidth(5);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(147,85,193,85,p);c.drawLine(185,77,193,85,p);c.drawLine(185,93,193,85,p);
            p.setColor(0xff99baf9);c.drawLine(147,104,193,104,p);c.drawLine(147,104,155,96,p);c.drawLine(147,104,155,112,p);c.restore();}
        void phone(Canvas c,float x,float y,int color){p.setColor(color);c.drawRoundRect(x,y,x+77,y+140,14,14,p);p.setColor(Color.WHITE);c.drawRoundRect(x+7,y+8,x+70,y+131,10,10,p);p.setColor(INK);c.drawRoundRect(x+28,y+10,x+49,y+15,3,3,p);p.setColor(0xffeaf1ff);c.drawRoundRect(x+14,y+32,x+63,y+75,8,8,p);p.setColor(0xff93b7f6);c.drawRoundRect(x+14,y+86,x+53,y+92,3,3,p);p.setColor(0xffdbe6f8);c.drawRoundRect(x+14,y+100,x+61,y+106,3,3,p);}
    }
}
