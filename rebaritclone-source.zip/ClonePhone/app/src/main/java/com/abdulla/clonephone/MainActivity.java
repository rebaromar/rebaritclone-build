package com.abdulla.clonephone;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.usb.UsbManager;
import android.net.*;
import android.provider.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.res.ColorStateList;
import android.view.*;
import android.widget.*;
import com.google.zxing.*;
import com.google.zxing.common.*;
import com.google.zxing.qrcode.QRCodeWriter;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int FILES=10,FOLDER=11,SCAN=12,QR_IMAGE=13,WIFI_SETTINGS=14,LOCATION_SETTINGS=15,UNINSTALL_APP=16,CAMERA_PERMISSION=20,DATA_PERMISSION=21,HOTSPOT_PERMISSION=22,SETUP_PERMISSION=23,SETUP_SETTINGS=24,FILE_BROWSER_PERMISSION=25,FILE_HUB_PERMISSION=26,PORT=39841,MAX_FILES=10000;
    private static final int BLUE=0xff4f46e5,INK=0xff152238,MUTED=0xff627089,BG=0xfff3f5fa;
    // A permanent catalogue URL: keep this QR unchanged and publish each new APK
    // (and its version notes) at this address.
    private static final String DOWNLOAD_CATALOG_URL="https://app.mediafire.com/folder/omye30rljf3px";
    // The public release manifest.  It contains only version metadata and the
    // direct, signed APK URL; a missing or unreachable manifest is ignored.
    private static final String UPDATE_MANIFEST_URL="https://rebaritclone-update-admin.rebar4qwrna.workers.dev/update.json";
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private boolean fileHubPermissionAsked=false;
    private final LinkedHashMap<String,List<Item>> groups=new LinkedHashMap<>();
    private final List<Item> selection=new ArrayList<>();
    private final Map<String,Set<String>> selectedRecords=new HashMap<>();
    private final Set<String> selectedApps=new HashSet<>();
    private final LinkedHashMap<String,Item> receivedFiles=new LinkedHashMap<>();
    private final LinkedHashMap<String,String> receivedApps=new LinkedHashMap<>();
    private void installReceivedApps(){if(receivedApps.isEmpty())return;Intent i=new Intent(this,AppInstallActivity.class);i.putStringArrayListExtra("uris",new ArrayList<>(receivedApps.keySet()));i.putStringArrayListExtra("names",new ArrayList<>(receivedApps.values()));startActivity(i);}
    private LinearLayout body,root;
    private FileGallery gallery;
    private boolean fileBrowserMode;
    private String browserMediaCategory;
    private void closeGallery(){if(gallery!=null){gallery.close();gallery=null;}}
    private TextView subtitle,status,percentage,details;
    private ProgressBar progress;
    private String screen="home",pendingCategory,pairText;
    private Uri folder,lastContact;
    private volatile Socket socket;
    private volatile ServerSocket listener;
    private volatile boolean busy,cancelled;
    private volatile CountDownLatch approval;
    private AlertDialog approvalDialog;
    private final ArrayDeque<String> uninstallQueue=new ArrayDeque<>();
    private String uninstallCurrentPackage;
    private LinkedHashSet<String> uninstallSelected;
    private List<ApplicationInfo> uninstallApps,uninstallShown;
    private BaseAdapter uninstallAdapter;
    private Runnable uninstallHeader;

    private void launchNextUninstall(){
        if(uninstallQueue.isEmpty()){uninstallCurrentPackage=null;toast("سڕینەوەی ئەپە هەڵبژێردراوەکان تەواو بوو");return;}
        uninstallCurrentPackage=uninstallQueue.removeFirst();
        try{
            Intent uninstall=new Intent(Intent.ACTION_UNINSTALL_PACKAGE);
            uninstall.setData(Uri.parse("package:"+uninstallCurrentPackage));
            uninstall.putExtra(Intent.EXTRA_RETURN_RESULT,true);
            uninstall.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivityForResult(uninstall,UNINSTALL_APP);
        }catch(Exception e){
            toast("نەتوانرا پەنجەرەی Android Uninstall بکرێتەوە");
            uninstallQueue.clear();uninstallCurrentPackage=null;
        }
    }
    private int completed;
    private long totalBytes,finishedBytes,lastUpdate,startTime;
    private boolean totalKnown;
    private TransferStats transferStats;
    private long resumedBytes,transferStarted;
    private String sendingId="",sendingManifest="",receivingId="",receivingManifest="",receivingBatch,usbApprovedManifest="";
    private Uri receivingLegacy;
    private final Map<Integer,ResumableFile.Entry> resumeEntries=new HashMap<>();
    private boolean restartAfterStop,receivedRecordBackup;
    private String manifest(List<Item> items,boolean source){StringBuilder b=new StringBuilder();for(Item i:items)b.append(source?i.uri.toString():"").append('\n').append(safeName(i.name)).append('\n').append(validMime(i.mime)).append('\n').append(i.size).append('\n');return b.toString();}
    private HotspotLink hotspot;
    private UsbLink usb;
    private boolean usbMode,fastMode,resumeFolder,resumeUsbFolder;
    private List<Item> usbRetryItems=new ArrayList<>();
    private final LinkedHashSet<String> usbControllerSelectionCache=new LinkedHashSet<>();
    private final LinkedHashSet<String> usbSourceConsentCache=new LinkedHashSet<>();
    private boolean usbAutoResume=false;
    private static final int USB_RETRY_LIMIT=12;
    private int usbReconnectAttempts=0;
    private String lastHotspotError="";
    // v12.1 automatic compatibility engine: fast 5 GHz/P2P first, then standard hotspot automatically.
    private boolean autoWifiFallback;
    private int autoWifiAttempt;
    private Network transferNetwork;
    private boolean linking;
    private String hotspotSsid="",hotspotPassword="";
    private Pairing pendingPeer;
    private boolean senderPaired;
    private SecureChannel selectedUsbChannel;
    private Runnable afterWifiPermission;
    private int linkGeneration;
    private List<String[]> setupSteps;
    private int setupIndex;
    private boolean setupReceiving,setupActive,setupWaiting,usbSourcePermissionFlow,usbControllerAuthorized;
    private final List<File> usbPreparedTemps=new ArrayList<>();
    private long lastNotification;
    private static final String TRANSFER_CHANNEL="transfer";
    private void startUsbSourcePermissions(){
        if(setupActive)return;
        usbSourcePermissionFlow=true;setupReceiving=false;setupActive=true;setupWaiting=false;setupIndex=0;
        setupSteps=PermissionPlan.forUsbSource(Build.VERSION.SDK_INT);
        page("permissions",UiText.t(246),"مۆبایلی کۆن: تەنها مۆڵەتە پێویستەکان بۆ خوێندنەوەی داتاکان",0);
        note("مۆبایلی تازە دیاری دەکات چی وەربگرێت. لەم مۆبایلە تەنها ڕەزامەندی دەدرێت.");
        nextPermission();
    }
    private void startPermissions(boolean receiving){
        if(setupActive)return;
        setupReceiving=receiving;setupActive=true;setupWaiting=false;setupIndex=0;
        setupSteps=PermissionPlan.forRole(Build.VERSION.SDK_INT,receiving);
        page("permissions",UiText.t(246),UiText.t(247),0);
        note(UiText.t(248));
        nextPermission();
    }
    private void nextPermission(){
        if(!setupActive||isDestroyed()||isFinishing()||setupWaiting)return;
        while(setupIndex<setupSteps.size()){
            String[] step=setupSteps.get(setupIndex++);
            boolean missing=false;for(String permission:step)missing|=checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED;
            if(!missing)continue;
            setupWaiting=true;
            try{requestPermissions(step,SETUP_PERMISSION);return;}
            catch(SecurityException e){setupWaiting=false;}
        }
        permissionSummary();
    }
    private void permissionSummary(){
        boolean missing=false;
        for(String[] step:setupSteps)for(String permission:step)if(!permission.equals(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)&&checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED)missing=true;
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(manager!=null&&!manager.areNotificationsEnabled())missing=true;
        if(!missing){finishPermissions();return;}
        page("permissions",UiText.t(246),UiText.t(249),0);
        note(UiText.t(248));
        button(UiText.t(250),false,()->{try{startActivityForResult(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())),SETUP_SETTINGS);}catch(ActivityNotFoundException e){toast(UiText.t(249));}});
        button(UiText.t(28),true,()->finishPermissions());
        button(UiText.t(29),false,()->{setupActive=false;usbSourcePermissionFlow=false;home();});
    }
    private void finishPermissions(){
        boolean receiving=setupReceiving;setupActive=false;setupWaiting=false;
        if(usbSourcePermissionFlow){usbSourcePermissionFlow=false;startUsb(false);return;}
        if(receiving){receiverSetup();String wifi=Build.VERSION.SDK_INT>=33?Manifest.permission.NEARBY_WIFI_DEVICES:Manifest.permission.ACCESS_FINE_LOCATION;
            if(checkSelfPermission(wifi)==PackageManager.PERMISSION_GRANTED)beginHotspot();else note(UiText.t(42));
        }else connectPage();
    }
    private void transferNotification(String message,int percent,boolean finished){
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(manager==null||!manager.areNotificationsEnabled())return;
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        long now=SystemClock.elapsedRealtime();if(!finished&&percent>=0&&now-lastNotification<1500)return;lastNotification=now;
        manager.createNotificationChannel(new NotificationChannel(TRANSFER_CHANNEL,UiText.t(251),NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder notification=new Notification.Builder(this,TRANSFER_CHANNEL).setSmallIcon(android.R.drawable.stat_sys_upload).setContentTitle("REBARIT CLONE").setContentText(message).setContentIntent(tap).setOnlyAlertOnce(true).setOngoing(!finished).setAutoCancel(finished).setVisibility(Notification.VISIBILITY_PRIVATE);
        if(!finished)notification.setProgress(1000,Math.max(0,percent),percent<0);
        try{manager.notify(74,notification.build());}catch(SecurityException ignored){}
    }
    private final Handler main=new Handler(Looper.getMainLooper());
    // v12.0 fast app browser caches: keep expensive icon/version/size work off the UI thread.
    private final ExecutorService appMetaWorker=Executors.newFixedThreadPool(2);
    private final android.util.LruCache<String,Drawable> appIconCache=new android.util.LruCache<>(96);
    private final ConcurrentHashMap<String,String> appMetaCache=new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String,String> appLabelCache=new ConcurrentHashMap<>();

    // VIP v11.9: smart clone / preflight / history / health / privacy state.
    private final ArrayList<String> transferHistory=new ArrayList<>();
    private boolean privacyMode=true;
    private long vipTransferStarted=0L;
    private String vipTransport="AUTO";
    private void vipHistory(String line){
        String stamp=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date());
        transferHistory.add(0,stamp+" • "+line);
        while(transferHistory.size()>30)transferHistory.remove(transferHistory.size()-1);
        try{getPreferences(0).edit().putString("vip_history",android.text.TextUtils.join("\n",transferHistory)).apply();}catch(Exception ignored){}
    }
    private void loadVipHistory(){
        if(!transferHistory.isEmpty())return;
        String raw=getPreferences(0).getString("vip_history","");
        if(!raw.isEmpty())transferHistory.addAll(Arrays.asList(raw.split("\n")));
    }
    private long freeStorage(){
        try{android.os.StatFs s=new android.os.StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());return s.getAvailableBytes();}catch(Exception e){return -1;}
    }
    private String preflightText(List<Item> items){
        long total=0;boolean unknown=false;for(Item i:items){if(i.size<0)unknown=true;else total+=i.size;}
        long free=freeStorage();String storage=free<0?"—":TransferStats.size(free);
        return "VIP Transfer Check\n"+items.size()+" files • "+TransferStats.size(total)+(unknown?" +":"")+"\nFree storage: "+storage+"\nBattery: "+batteryPercent()+"%\nPrivacy: Device-to-Device only";
    }
    private int batteryPercent(){
        try{android.os.BatteryManager b=(android.os.BatteryManager)getSystemService(BATTERY_SERVICE);return b.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);}catch(Exception e){return -1;}
    }
    private boolean enoughStorage(List<Item> items){
        long need=0;for(Item i:items)if(i.size>0)need+=i.size;long free=freeStorage();return free<0||need<=free;
    }
    private void showTransferHistory(){
        loadVipHistory();page("vipHistory","Transfer History","REBARIT CLONE VIP",0);
        if(transferHistory.isEmpty())summaryCard("No transfers yet");
        else for(String h:transferHistory)summaryCard(h);
        button(UiText.t(111),false,()->home());
    }


    static class Item {
        Uri uri;String name,mime,relativePath="";long size,modified=-1,taken=-1;
        Item(){}
        Item(Uri u,String n,String m,long s){uri=u;name=n;mime=m;size=s;}
    }
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);UiText.init(this);hotspot=new HotspotLink(this);usb=new UsbLink(this);fastMode=getPreferences(0).getBoolean("fast5",true);onlineUpdate=new OnlineUpdate(this,()->busy);restoreSenderCheckpoint();home();handleUsbLaunch(getIntent());}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handleUsbLaunch(intent);}
    private void handleUsbLaunch(Intent intent){
        try{
            if(intent==null)return;String a=intent.getAction();
            if(!UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)&&!UsbManager.ACTION_USB_ACCESSORY_ATTACHED.equals(a))return;
            main.postDelayed(()->{
                try{
                    if(isDestroyed()||busy||linking||"usb".equals(screen)||"usbWaiting".equals(screen))return;
                    // USB system intents must never crash the Activity. The user still chooses
                    // the logical new-phone/old-phone role inside REBARIT CLONE.
                    usbRoles();
                }catch(Throwable ignored){}
            },250);
        }catch(Throwable ignored){}
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable box(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private TextView label(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.START);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);t.setLineSpacing(dp(4),1);t.setFontFeatureSettings("kern");if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private void gap(int height){Space s=new Space(this);body.addView(s,new LinearLayout.LayoutParams(1,dp(height)));}
    private TextView text(String value,int size,int color,boolean bold){TextView t=label(value,size,color,bold);body.addView(t);return t;}
    private void page(String id,String title,String description,int step){
        closeGallery();
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        screen=id;root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setLayoutDirection(UiText.direction());
        root.setPadding(dp(24),dp(18),dp(24),dp(14));setContentView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);root.addView(top);
        TextView brand=label("REBARIT CLONE",19,INK,true);brand.setTextDirection(View.TEXT_DIRECTION_LTR);top.addView(brand,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView badge=label(UiText.t(295)+versionName(),11,BLUE,true);badge.setPadding(dp(10),dp(6),dp(10),dp(6));badge.setBackground(box(0xffe8e8ff,20));top.addView(badge);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(12),0,dp(24));scroll.addView(body);
        // The journey is always shown in the same order:
        // 1. Connect  →  2. Select  →  3. Transfer.
        if(step>0){steps(step);gap(24);}
        text(title,28,INK,true);gap(10);subtitle=text(description,15,MUTED,false);gap(24);
    }
    private void steps(int active){
        LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);body.addView(line,new LinearLayout.LayoutParams(-1,-2));
        for(int n=1;n<=3;n++){TextView chip=label((n<active?"✓":String.valueOf(n))+"  "+UiText.t(n==1?270:n==2?269:271),11,n==active?Color.WHITE:n<active?BLUE:MUTED,true);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(4),dp(10),dp(4),dp(10));chip.setBackground(box(n==active?BLUE:n<active?0xffe8e8ff:0xffe9edf5,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),0,dp(2),0);line.addView(chip,lp);}
    }
    private TextView summaryCard(String message){TextView v=text(message,16,INK,true);v.setPadding(dp(18),dp(18),dp(18),dp(18));v.setBackground(box(Color.WHITE,20));return v;}
    private Button button(String title,boolean primary,Runnable click){
        Button b=new Button(this);b.setText(title);b.setTextSize(16);b.setAllCaps(false);b.setTypeface(null,Typeface.BOLD);b.setTextColor(primary?Color.WHITE:BLUE);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x222563eb),box(primary?BLUE:0xffeaf0fd,18),null));
        b.setMinHeight(dp(56));b.setPadding(dp(16),dp(14),dp(16),dp(14));b.setElevation(primary?dp(2):0);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));body.addView(b,lp);b.setOnClickListener(v->click.run());return b;
    }
    private void note(String message){gap(12);TextView t=text(message,13,MUTED,false);t.setPadding(dp(14),dp(12),dp(14),dp(12));t.setBackground(box(0xffe9edf5,14));}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private void alert(String title,String message){new AlertDialog.Builder(UiText.context(this)).setTitle(title).setMessage(message).setPositiveButton(UiText.t(2),null).show();}
    private void chooseLanguage(){
        String[] codes={"ckb","en","ar"};String[] labels={"کوردی","English","العربية"};int selected=Arrays.asList(codes).indexOf(UiText.language());
        new AlertDialog.Builder(UiText.context(this)).setTitle("زمان / Language / اللغة").setSingleChoiceItems(labels,selected,(dialog,which)->{UiText.select(this,codes[which]);dialog.dismiss();home();}).setNegativeButton(UiText.t(61),null).show();
    }
    private static final int NIGHT=0xff050b12,LIGHT=0xfff4faff;
    private void darkScreen(String id,String title){
        closeGallery();
        screen=id;root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(NIGHT);root.setLayoutDirection(UiText.direction());root.setPadding(dp(22),dp(12),dp(22),dp(12));setContentView(root);
        getWindow().setStatusBarColor(NIGHT);getWindow().setNavigationBarColor(NIGHT);getWindow().getDecorView().setSystemUiVisibility(0);
        FrameLayout bar=new FrameLayout(this);root.addView(bar,new LinearLayout.LayoutParams(-1,dp(50)));
        if(!id.equals("home")){TextView back=label("‹",32,LIGHT,true);back.setGravity(Gravity.CENTER);back.setContentDescription(UiText.t(29));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(40),-1,Gravity.START|Gravity.CENTER_VERTICAL);bar.addView(back,bp);back.setOnClickListener(v->home());}
        LinearLayout brandBox=new LinearLayout(this);brandBox.setOrientation(LinearLayout.VERTICAL);brandBox.setGravity(Gravity.CENTER);
        TextView brand=label(id.equals("home")?"REBARIT CLONE":title,id.equals("home")?18:20,LIGHT,true);brand.setGravity(Gravity.CENTER);brand.setTextDirection(View.TEXT_DIRECTION_LTR);brandBox.addView(brand,new LinearLayout.LayoutParams(-2,-2));
        if(id.equals("home")){TextView version=label("v"+versionName(),10,0xff8ea6b8,false);version.setGravity(Gravity.CENTER);version.setTextDirection(View.TEXT_DIRECTION_LTR);brandBox.addView(version,new LinearLayout.LayoutParams(-2,-2));}
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER);bar.addView(brandBox,cp);
        TextView menu=label("⋮",28,LIGHT,true);menu.setGravity(Gravity.CENTER);menu.setContentDescription(UiText.t(262));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(40),-1,Gravity.END|Gravity.CENTER_VERTICAL);bar.addView(menu,mp);
        menu.setOnClickListener(v->{PopupMenu options=new PopupMenu(this,menu);options.getMenu().add("زمان / Language / اللغة").setOnMenuItemClickListener(i->{chooseLanguage();return true;});options.getMenu().add("↗  بەرنامەکە بنێرە").setOnMenuItemClickListener(i->{shareOwnApk();return true;});
            options.getMenu().add("▦  دابەزاندنی بەرنامە").setOnMenuItemClickListener(i->{showAppDownloadQr();return true;});options.getMenu().add(onlineUpdate.menuTitle()).setOnMenuItemClickListener(i->{onlineUpdate.checkManually();return true;});options.show();});
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(12),0,dp(16));scroll.addView(body);
    }
    private void appDownloadPage(){
        page("download",UiText.t(290),UiText.t(291),0);
        try{
            int side=620;BitMatrix matrix=new QRCodeWriter().encode(DOWNLOAD_CATALOG_URL,BarcodeFormat.QR_CODE,side,side);int[] pixels=new int[side*side];
            for(int y=0;y<side;y++)for(int x=0;x<side;x++)pixels[y*side+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
            ImageView qr=new ImageView(this);qr.setImageBitmap(Bitmap.createBitmap(pixels,side,side,Bitmap.Config.ARGB_8888));qr.setContentDescription(UiText.t(292));qr.setScaleType(ImageView.ScaleType.FIT_CENTER);qr.setBackground(box(Color.WHITE,24));qr.setPadding(dp(10),dp(10),dp(10),dp(10));
            int width=Math.min(dp(286),getResources().getDisplayMetrics().widthPixels-dp(48));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(width,width);lp.gravity=Gravity.CENTER;body.addView(qr,lp);
        }catch(Exception e){throw new IllegalStateException(e);}
        gap(18);TextView version=text(UiText.t(295)+versionName(),15,BLUE,true);version.setGravity(Gravity.CENTER);
        TextView url=text(DOWNLOAD_CATALOG_URL,13,MUTED,false);url.setTextDirection(View.TEXT_DIRECTION_LTR);url.setGravity(Gravity.CENTER);url.setTextIsSelectable(true);gap(12);
        button(UiText.t(293),true,this::openDownloadCatalog);
        button(UiText.t(294),false,()->{android.content.ClipboardManager c=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);c.setPrimaryClip(ClipData.newPlainText("rebaritclone download",DOWNLOAD_CATALOG_URL));toast(UiText.t(296));});
        button(UiText.t(29),false,this::home);
    }
    private String versionName(){try{return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception e){return "";}}
    private void showAppDownloadQr(){
        final String url="https://rebarit.store/app";
        LinearLayout panel=new LinearLayout(UiText.context(this));panel.setOrientation(LinearLayout.VERTICAL);panel.setGravity(Gravity.CENTER);panel.setPadding(dp(24),dp(24),dp(24),dp(20));
        TextView title=label("دابەزاندنی بەرنامە",22,INK,true);title.setGravity(Gravity.CENTER);panel.addView(title);
        TextView sub=label("QR ـەکە سکان بکە",13,MUTED,false);sub.setGravity(Gravity.CENTER);sub.setPadding(0,dp(6),0,dp(16));panel.addView(sub);
        ImageView qr=new ImageView(this);
        try{
            BitMatrix matrix=new QRCodeWriter().encode(url,BarcodeFormat.QR_CODE,720,720);
            int side=720;int[] pixels=new int[side*side];
            for(int y=0;y<side;y++)for(int x=0;x<side;x++)pixels[y*side+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
            qr.setImageBitmap(Bitmap.createBitmap(pixels,side,side,Bitmap.Config.ARGB_8888));
        }catch(Exception e){qr.setContentDescription("QR error");}
        panel.addView(qr,new LinearLayout.LayoutParams(dp(280),dp(280)));
        TextView address=label("rebarit.store/app",18,BLUE,true);address.setTextDirection(View.TEXT_DIRECTION_LTR);address.setGravity(Gravity.CENTER);address.setPadding(0,dp(14),0,dp(4));panel.addView(address);
        AlertDialog dialog=new AlertDialog.Builder(UiText.context(this)).setView(panel).setNegativeButton("داخستن",null).create();dialog.show();
    }

    private void shareOwnApk(){
        try{
            Uri apk=Uri.parse("content://"+getPackageName()+".share/apk");
            Intent send=new Intent(Intent.ACTION_SEND);
            send.setType("application/vnd.android.package-archive");
            send.putExtra(Intent.EXTRA_STREAM,apk);
            send.setClipData(ClipData.newRawUri(UiText.t(310),apk));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send,UiText.t(310)));
        }catch(ActivityNotFoundException|SecurityException e){toast(UiText.t(311));}
    }
    private void openDownloadCatalog(){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(DOWNLOAD_CATALOG_URL)));}catch(Exception e){toast(UiText.t(297));}}
    private OnlineUpdate onlineUpdate;
    @Override protected void onResume(){super.onResume();if(onlineUpdate!=null)onlineUpdate.resume();}
    @Override protected void onPause(){if(onlineUpdate!=null)onlineUpdate.pause();super.onPause();}
    private void home(){
        if(!busy){stopLink();senderPaired=false;selectedUsbChannel=null;}
        fileBrowserMode=false;
        darkScreen("home","REBAR IT CLONE");
        View art=new FlowArt(this);body.addView(art,new LinearLayout.LayoutParams(-1,dp(190)));
        text(UiText.t(258),12,0xff8ea6b8,false);gap(8);text(UiText.t(259),25,LIGHT,true);gap(20);
        landingCard(UiText.t(264),UiText.t(260),UiText.t(28),0xff006d67,0xff00a77f,()->deviceRoles(false));
        landingCard(UiText.t(261),UiText.t(263),UiText.t(28),0xff3f2f96,0xff694fe0,()->{fileBrowserMode=true;fileHub();});
        landingUsbCard("ناردن لە ڕێگەی کێبڵ","USB-C • خێرایی زۆر","کردنەوەی USB",0xff175fc9,0xff3197e8,this::usbRoles);

    }
    private void landingCard(String title,String description,String action,int first,int second,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(20),dp(20),dp(20),dp(16));
        GradientDrawable background=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{first,second});background.setCornerRadius(dp(20));card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff),background,null));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(14));body.addView(card,cp);
        TextView heading=label(title,23,LIGHT,true);card.addView(heading);
        TextView sub=label(description,13,Color.WHITE,false);card.addView(sub);
        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.END);footer.setPadding(0,dp(16),0,0);card.addView(footer);
        TextView pill=label(action+"  ›",14,Color.WHITE,true);pill.setGravity(Gravity.CENTER);pill.setPadding(dp(20),dp(5),dp(20),dp(5));GradientDrawable border=box(Color.TRANSPARENT,24);border.setStroke(dp(1),0xddffffff);pill.setBackground(border);footer.addView(pill);
        card.setFocusable(true);card.setOnClickListener(v->click.run());
    }
    private void landingUsbCard(String title,String description,String action,int first,int second,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(20),dp(18),dp(20),dp(16));
        GradientDrawable background=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{first,second});background.setCornerRadius(dp(20));card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff),background,null));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(14));body.addView(card,cp);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER);card.addView(top,new LinearLayout.LayoutParams(-1,-2));
        TextView usbBadge=label("USB",20,Color.WHITE,true);usbBadge.setGravity(Gravity.CENTER);usbBadge.setPadding(dp(16),dp(8),dp(16),dp(8));
        GradientDrawable badgeBg=box(0x26ffffff,16);badgeBg.setStroke(dp(1),0x90ffffff);usbBadge.setBackground(badgeBg);top.addView(usbBadge);top.setPadding(0,0,0,dp(12));
        TextView heading=label(title,23,LIGHT,true);heading.setGravity(Gravity.CENTER);card.addView(heading);
        TextView sub=label(description,13,Color.WHITE,false);sub.setGravity(Gravity.CENTER);card.addView(sub);
        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.CENTER);footer.setPadding(0,dp(16),0,0);card.addView(footer);
        TextView pill=label(action+"  ›",14,Color.WHITE,true);pill.setGravity(Gravity.CENTER);pill.setPadding(dp(20),dp(5),dp(20),dp(5));GradientDrawable border=box(Color.TRANSPARENT,24);border.setStroke(dp(1),0xddffffff);pill.setBackground(border);footer.addView(pill);
        card.setFocusable(true);card.setOnClickListener(v->click.run());
    }
    private void deviceRoles(boolean files){
        darkScreen(files?"fileRoles":"deviceRoles",files?UiText.t(261):UiText.t(264));
        gap(26);text(files?UiText.t(261):UiText.t(264),29,LIGHT,true).setGravity(Gravity.CENTER);gap(28);
        darkRole(UiText.t(7),UiText.t(8),"↓",0xff9690ff,()->startPermissions(true));
        darkRole(UiText.t(5),UiText.t(6),"↑",0xff35d8b4,()->startPermissions(false));
        gap(16);text(UiText.t(9),13,0xff8ea6b8,false).setGravity(Gravity.CENTER);
    }
    private void usbRoles(){
        if(busy)return;
        stopLink();usbMode=true;senderPaired=false;selectedUsbChannel=null;usbReconnectAttempts=0;selection.clear();usbApprovedManifest="";usbControllerAuthorized=false;receivingBatch=null;clearUsbResumeState();
        darkScreen("usbRoles",UiText.t(312));
        gap(18);
        text(UiText.t(315),27,LIGHT,true).setGravity(Gravity.CENTER);
        gap(8);
        text(UiText.t(316),13,0xff8ea6b8,false).setGravity(Gravity.CENTER);
        gap(24);
        darkRole(UiText.t(7),UiText.t(318),"↓",0xff9690ff,()->usbReceiverSetup());
        darkRole(UiText.t(5),"تەنها ڕەزامەندی بدە؛ مۆبایلی تازە هەڵدەبژێرێت","↑",0xff35d8b4,this::startUsbSourcePermissions);
        gap(12);
        text(UiText.t(319),12,0xff8ea6b8,false).setGravity(Gravity.CENTER);
    }
    private void darkRole(String title,String description,String glyph,int accent,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(18),dp(22),dp(18),dp(22));card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),box(0xff0d1822,20),null));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(16));body.addView(card,cp);
        TextView icon=label(glyph,30,NIGHT,true);icon.setGravity(Gravity.CENTER);icon.setBackground(box(accent,15));card.addView(icon,new LinearLayout.LayoutParams(dp(50),dp(54)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(dp(16),0,dp(10),0);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,21,LIGHT,true));words.addView(label(description,13,0xffa9bdca,false));card.setFocusable(true);card.setOnClickListener(v->click.run());
    }
    private static class FlowArt extends View{
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        FlowArt(Context context){super(context);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas canvas){
            float w=getWidth(),h=getHeight();
            paint.setShader(new RadialGradient(w*.85f,h*.7f,w*.7f,new int[]{0xff123448,0xff10182a,NIGHT},new float[]{0,.55f,1},Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h,paint);paint.setShader(null);
            float unit=Math.min(w/340f,h/160f);canvas.save();canvas.translate((w-340*unit)/2,(h-160*unit)/2);canvas.scale(unit,unit);
            for(int i=0;i<2;i++){float x=i==0?62:218;paint.setColor(i==0?0xff293951:0xff254b50);canvas.drawRoundRect(x,12,x+66,144,13,13,paint);paint.setColor(i==0?0xff92a6c4:0xff57dac2);canvas.drawRoundRect(x+7,20,x+59,132,8,8,paint);paint.setColor(0xff152338);canvas.drawRoundRect(x+22,24,x+44,29,3,3,paint);for(int row=0;row<3;row++){paint.setColor(i==0?0xff435a7c:0xff238c82);canvas.drawRoundRect(x+14,47+row*22,x+52,59+row*22,4,4,paint);}}
            paint.setColor(0xffb3a9ff);paint.setStrokeWidth(4);paint.setStrokeCap(Paint.Cap.ROUND);canvas.drawLine(150,68,190,68,paint);canvas.drawLine(182,60,190,68,paint);canvas.drawLine(182,76,190,68,paint);paint.setColor(0xff57dac2);canvas.drawLine(190,91,150,91,paint);canvas.drawLine(158,83,150,91,paint);canvas.drawLine(158,99,150,91,paint);canvas.restore();

        }
    }
    private void role(String title,String description,String icon,Runnable action){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(20),dp(22),dp(20),dp(22));card.setBackground(box(Color.WHITE,22));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(14));body.addView(card,cp);
        TextView glyph=label(icon,32,BLUE,true);glyph.setGravity(Gravity.CENTER);glyph.setBackground(box(0xffedf3ff,16));card.addView(glyph,new LinearLayout.LayoutParams(dp(58),dp(64)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(dp(16),0,dp(16),0);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,21,INK,true));words.addView(label(description,13,MUTED,false));card.setOnClickListener(v->action.run());
    }
    private void categories(){
        if(fileBrowserMode){fileHub();return;}
        page("categories",UiText.t(14),UiText.t(15),2);
        summaryCard("✦ REBARIT CLONE • FULL VIP");
        button("⚡ Smart Clone",true,()->connectPage());
        button("Transfer History",false,()->showTransferHistory());

        section(UiText.t(284));
        category("photos",UiText.t(16),UiText.t(17),"▧");
        category("videos",UiText.t(18),UiText.t(19),"▷");
        section(UiText.t(285));
        category("files",UiText.t(26),UiText.t(27),"＋");
        category("apps",UiText.t(22),UiText.t(23),"APK");
        category("audio",UiText.t(20),UiText.t(21),"♫");
        section(UiText.t(286));
        category("contacts",UiText.t(24),UiText.t(232),"☏");
        category("calls",UiText.t(229),UiText.t(233),"↔");
        category("sms",UiText.t(230),UiText.t(234),"✉");
        gap(14);summaryCard(selectionSummary(selectedItems()));
        button(UiText.t(28),true,()->prepareSelection());
        button(UiText.t(29),false,()->home());
        note(UiText.t(30));
    }
    /** File-manager style start page for the File transfer card. */
    private void fileHub(){
        closeGallery();fileBrowserMode=true;screen="fileHub";
        getWindow().setStatusBarColor(NIGHT);getWindow().setNavigationBarColor(NIGHT);
        getWindow().getDecorView().setSystemUiVisibility(0);
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(NIGHT);root.setLayoutDirection(UiText.direction());root.setPadding(dp(16),dp(8),dp(16),dp(12));setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);root.addView(header,new LinearLayout.LayoutParams(-1,dp(62)));
        TextView back=label("‹",44,LIGHT,false);back.setGravity(Gravity.CENTER);back.setContentDescription(UiText.t(29));header.addView(back,new LinearLayout.LayoutParams(dp(52),-1));back.setOnClickListener(v->home());
        TextView title=label(UiText.t(26),29,LIGHT,true);title.setGravity(Gravity.CENTER_VERTICAL);header.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        TextView refresh=label("↻",30,LIGHT,false);refresh.setGravity(Gravity.CENTER);refresh.setContentDescription(UiText.t(303));header.addView(refresh,new LinearLayout.LayoutParams(dp(52),-1));refresh.setOnClickListener(v->fileHub());
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(10),0,dp(18));scroll.addView(body);
        EditText search=new EditText(this);search.setSingleLine(true);search.setFocusable(false);search.setClickable(true);search.setTextColor(LIGHT);search.setHintTextColor(0xff8ea6b8);search.setHint(UiText.t(303));search.setTextSize(17);search.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search,0,0,0);search.setCompoundDrawablePadding(dp(10));search.setPadding(dp(16),0,dp(16),0);search.setBackground(box(0xff0d1822,18));body.addView(search,new LinearLayout.LayoutParams(-1,dp(46)));search.setOnClickListener(v->pickFiles());
        gap(18);TextView hint=text(UiText.t(263),14,MUTED,false);hint.setPadding(dp(4),0,dp(4),dp(8));
        Map<String,TextView> counters=new LinkedHashMap<>();
        LinearLayout first=fileHubRow();
        counters.put("audio",fileHubTile(first,UiText.t(20),"♪",0xffef5350,()->openFileBrowserMedia("audio")));
        counters.put("apps",fileHubTile(first,UiText.t(22),"APP",0xff2979ff,this::chooseApps));
        counters.put("videos",fileHubTile(first,UiText.t(18),"▶",0xff7c4dff,()->openFileBrowserMedia("videos")));
        counters.put("photos",fileHubTile(first,UiText.t(16),"▣",0xff00c853,()->openFileBrowserMedia("photos")));
        LinearLayout second=fileHubRow();
        counters.put("documents",fileHubTile(second,UiText.t(304),"≡",0xffffab00,this::pickDocuments));
        counters.put("other",fileHubTile(second,UiText.t(306),"•••",0xff40a4df,this::pickFiles));
        counters.put("downloads",fileHubTile(second,UiText.t(307),"↓",0xff536dfe,this::openDownloads));
        LinearLayout third=fileHubRow();
        fileHubSpacer(third); fileHubTile(third,"سڕینەوەی ئەپ","🗑",0xffff3d57,this::showUninstallApps); fileHubTile(third,UiText.t(24),"☏",0xff00a884,()->requestCategory("contacts")); fileHubSpacer(third);
        if(countSelected()>0){gap(18);TextView selected=text(UiText.t(308)+selectionSummary(selectedItems()),15,BLUE,true);selected.setGravity(Gravity.CENTER);button(UiText.t(309),true,this::prepareSelection);}
        addStorageSummary();
        loadFileHubCounts(counters);
        ensureFileHubPermissions();
    }
    private void ensureFileHubPermissions(){
        if(fileHubPermissionAsked)return;
        List<String> need=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=33){
            if(checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)!=PackageManager.PERMISSION_GRANTED)need.add(Manifest.permission.READ_MEDIA_IMAGES);
            if(checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO)!=PackageManager.PERMISSION_GRANTED)need.add(Manifest.permission.READ_MEDIA_VIDEO);
            if(checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)!=PackageManager.PERMISSION_GRANTED)need.add(Manifest.permission.READ_MEDIA_AUDIO);
        }else if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)need.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if(!need.isEmpty()){fileHubPermissionAsked=true;requestPermissions(need.toArray(new String[0]),FILE_HUB_PERMISSION);}
    }
    private void pickDocuments(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","text/plain","text/csv","application/rtf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-powerpoint","application/vnd.openxmlformats-officedocument.presentationml.presentation","application/vnd.oasis.opendocument.text","application/vnd.oasis.opendocument.spreadsheet","application/vnd.oasis.opendocument.presentation"});
        startActivityForResult(i,FILES);
    }
    private boolean isDocumentMime(String mime,String name){
        String m=mime==null?"":mime.toLowerCase(Locale.ROOT),n=name==null?"":name.toLowerCase(Locale.ROOT);
        if(m.equals("application/pdf")||m.startsWith("text/")||m.contains("word")||m.contains("excel")||m.contains("spreadsheet")||m.contains("powerpoint")||m.contains("presentation")||m.contains("opendocument")||m.equals("application/rtf"))return true;
        return n.matches(".*\\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv|rtf|odt|ods|odp)$");
    }
    private void addStorageSummary(){
        try{
            StatFs stat=new StatFs(Environment.getDataDirectory().getAbsolutePath());
            long total=stat.getTotalBytes(),free=stat.getAvailableBytes(),used=Math.max(0,total-free);
            gap(14);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(16),dp(14),dp(16),dp(14));card.setBackground(box(0xffffffff,18));body.addView(card,new LinearLayout.LayoutParams(-1,-2));
            TextView heading=label("Storage • بیرگە",15,INK,true);card.addView(heading);
            TextView values=label("بەکارهاتوو "+TransferStats.size(used)+" / "+TransferStats.size(total)+"   •   بەتاڵ "+TransferStats.size(free),13,MUTED,false);values.setPadding(0,dp(6),0,dp(8));card.addView(values);
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(1000);bar.setProgress(total>0?(int)Math.min(1000,(used*1000L)/total):0);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(8)));
        }catch(Exception ignored){}
    }
    private LinearLayout fileHubRow(){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.TOP);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(142));lp.setMargins(0,0,0,dp(8));body.addView(row,lp);return row;}
    private void fileHubSpacer(LinearLayout row){ View v=new View(this); row.addView(v,new LinearLayout.LayoutParams(0,-1,1)); }
    private TextView fileHubTile(LinearLayout row,String title,String glyph,int color,Runnable click){
        LinearLayout tile=new LinearLayout(this);tile.setOrientation(1);tile.setGravity(Gravity.CENTER_HORIZONTAL);tile.setPadding(dp(3),dp(8),dp(3),dp(6));tile.setBackground(new RippleDrawable(ColorStateList.valueOf(0x164f46e5),box(0xff0d1822,18),null));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(3),0,dp(3),0);row.addView(tile,lp);
        TextView icon=label(glyph,(glyph.equals("APK")||glyph.equals("APP"))?12:27,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setTextDirection(View.TEXT_DIRECTION_LTR);icon.setBackground(box(color,17));tile.addView(icon,new LinearLayout.LayoutParams(dp(58),dp(58)));
        TextView name=label(title,13,LIGHT,true);name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(38));np.setMargins(0,dp(7),0,0);tile.addView(name,np);
        TextView count=label("…",14,0xff8ea6b8,false);count.setGravity(Gravity.CENTER);tile.addView(count,new LinearLayout.LayoutParams(-1,dp(20)));
        tile.setContentDescription(title);tile.setOnClickListener(v->click.run());return count;
    }
    private void openFileBrowserMedia(String category){
        if(browserMediaAllowed(category)){showFileGallery(category);return;}
        browserMediaCategory=category;List<String> permissions=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=33){permissions.add(category.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:category.equals("videos")?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO);if(Build.VERSION.SDK_INT>=34&&!category.equals("audio"))permissions.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);}
        else permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        requestPermissions(permissions.toArray(new String[0]),FILE_BROWSER_PERMISSION);
    }
    private boolean browserMediaAllowed(String category){
        if(Build.VERSION.SDK_INT<33)return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
        String permission=category.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:category.equals("videos")?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO;
        return checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED;
    }
    private void loadFileHubCounts(Map<String,TextView> counters){worker.execute(()->{Map<String,Integer> values=new LinkedHashMap<>();for(String id:counters.keySet())values.put(id,fileHubCount(id));runOnUiThread(()->{if(!"fileHub".equals(screen))return;for(Map.Entry<String,TextView> entry:counters.entrySet()){Integer value=values.get(entry.getKey());entry.getValue().setText(value==null||value<0?"—":String.valueOf(value));}});});}
    private int fileHubCount(String id){
        try{
            if(id.equals("apps")){int count=0;for(ApplicationInfo app:getPackageManager().getInstalledApplications(0))if(!app.packageName.equals(getPackageName())&&(app.flags&ApplicationInfo.FLAG_SYSTEM)==0&&app.sourceDir!=null)count++;return count;}
            Uri collection;if(id.equals("photos"))collection=MediaStore.Images.Media.EXTERNAL_CONTENT_URI;else if(id.equals("videos"))collection=MediaStore.Video.Media.EXTERNAL_CONTENT_URI;else if(id.equals("audio"))collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;else collection=MediaStore.Files.getContentUri("external");
            String selection=null;String[] args=null;
            if(id.equals("apk")){selection=MediaStore.MediaColumns.DISPLAY_NAME+" LIKE ?";args=new String[]{"%.apk"};}
            else if(id.equals("documents")||id.equals("other")){
                int count=0;String[] projection={MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.MIME_TYPE};
                try(Cursor c=getContentResolver().query(collection,projection,null,null,null)){while(c!=null&&c.moveToNext()){String name=c.isNull(0)?"":c.getString(0),mime=c.isNull(1)?"":c.getString(1);boolean media=mime.startsWith("image/")||mime.startsWith("video/")||mime.startsWith("audio/");boolean apk=name.toLowerCase(Locale.ROOT).endsWith(".apk")||mime.equals("application/vnd.android.package-archive");boolean doc=isDocumentMime(mime,name);if(id.equals("documents")?doc:(!media&&!apk&&!doc))count++;}}return count;
            }
            else if(id.equals("downloads")){
                if(Build.VERSION.SDK_INT>=29) collection=MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                else { selection=MediaStore.MediaColumns.DATA+" LIKE ?"; args=new String[]{Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath()+"/%"}; }
            }
            try(Cursor cursor=getContentResolver().query(collection,new String[]{MediaStore.MediaColumns._ID},selection,args,null)){return cursor==null?0:cursor.getCount();}
        }catch(SecurityException e){return -1;}catch(Exception e){return 0;}
    }
    private void showFileGallery(String initialTab){
        darkScreen("gallery",UiText.t(14));
        root.removeViewAt(root.getChildCount()-1);
        List<FileGallery.Entry> initial=new ArrayList<>();
        for(Item item:groups.getOrDefault("gallery",Collections.emptyList())){FileGallery.Entry e=new FileGallery.Entry();e.uri=item.uri;e.name=item.name;e.mime=item.mime;e.size=item.size;initial.add(e);}
        gallery=new FileGallery(this,initial,selectionSummary(selectedItems()),new FileGallery.Actions(){
            public void changed(List<FileGallery.Entry> selected){List<Item> items=new ArrayList<>();for(FileGallery.Entry e:selected)items.add(new Item(e.uri,e.name,e.mime,e.size));if(items.isEmpty())groups.remove("gallery");else groups.put("gallery",items);if(gallery!=null)gallery.summary(selectionSummary(selectedItems()));}
            public void tab(String id){if(id.equals("files"))pickFiles();else if(id.equals("apps"))chooseApps();else requestCategory("contacts");}
            public void next(){prepareSelection();}
        },initialTab);root.addView(gallery,new LinearLayout.LayoutParams(-1,0,1));
    }
    private List<Item> selectedItems(){LinkedHashMap<String,Item> unique=new LinkedHashMap<>();for(List<Item> list:groups.values())for(Item item:list){String p=item.relativePath==null?"":item.relativePath.toLowerCase(Locale.ROOT);if(privacyMode&&(p.startsWith("android/data/")||p.startsWith("android/obb/")||p.contains("/.private/")))continue;unique.put(item.uri.toString(),item);}return new ArrayList<>(unique.values());}
    private TransferStats stats(List<Item> items){String[] names=new String[items.size()],mimes=new String[items.size()];long[] sizes=new long[items.size()];for(int n=0;n<items.size();n++){Item i=items.get(n);names[n]=i.name;mimes[n]=i.mime;sizes[n]=i.size;}return new TransferStats(names,mimes,sizes);}
    private String selectionSummary(List<Item> items){TransferStats s=stats(items);return items.size()+UiText.t(31)+TransferStats.size(s.totalBytes)+(s.totalKnown?"":UiText.t(32));}
    private int countSelected(){HashSet<String> unique=new HashSet<>();for(List<Item> list:groups.values())for(Item i:list)unique.add(i.uri.toString());return unique.size();}
    private void section(String name){TextView t=text(name,13,BLUE,true);t.setPadding(dp(4),dp(10),0,dp(8));}
    private void category(String id,String title,String desc,String glyph){
        boolean chosen=groups.containsKey(id);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(16),dp(16),dp(16),dp(16));GradientDrawable tile=box(chosen?0xffeeedff:Color.WHITE,20);tile.setStroke(dp(1),chosen?0xffb8b3fa:0xffe2e7f0);row.setBackground(new RippleDrawable(ColorStateList.valueOf(0x184f46e5),tile,null));row.setFocusable(true);row.setContentDescription(title+". "+(chosen?UiText.t(272):desc));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(10));body.addView(row,lp);
        int accent=id.equals("photos")?0xffd4517d:id.equals("videos")?0xff715bd5:id.equals("files")?0xff168477:id.equals("apps")?0xffd58026:BLUE;
        TextView icon=label(glyph,id.equals("apps")?13:24,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(box(accent,14));row.addView(icon,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(dp(12),0,dp(12),0);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,18,INK,true));words.addView(label(chosen?(isRecords(id)?selectedRecords.getOrDefault(id,Collections.emptySet()).size()+UiText.t(238)+" • ":"")+selectionSummary(groups.get(id)):desc,12,MUTED,false));
        TextView tick=label(chosen?"✓":"○",24,chosen?BLUE:0xffb5bfd0,true);row.addView(tick);
        row.setOnClickListener(v->{if(id.equals("apps")){chooseApps();return;}if((id.equals("sms")||id.equals("calls"))&&chosen){groups.remove(id);selectedRecords.remove(id);categories();return;}if(isRecords(id)){requestCategory(id);return;}if(chosen){groups.remove(id);categories();}else if(id.equals("files"))pickFiles();else requestCategory(id);});
    }
    private void showUninstallApps(){
        PackageManager pm=getPackageManager();
        final List<ApplicationInfo> userApps=new ArrayList<>(), systemApps=new ArrayList<>();
        try{for(ApplicationInfo a:pm.getInstalledApplications(0)){if(a.packageName.equals(getPackageName()))continue;if((a.flags&ApplicationInfo.FLAG_SYSTEM)!=0)systemApps.add(a);else userApps.add(a);}}catch(Exception ignored){}
        java.util.Comparator<ApplicationInfo> byName=(a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString());userApps.sort(byName);systemApps.sort(byName);
        final LinkedHashSet<String> selected=new LinkedHashSet<>();final List<ApplicationInfo> shown=new ArrayList<>();final boolean[] systemTab={false};final String[] query={""};
        final int WHITE=0xfff7fbff,DIM=0xff8fa6b8,PANEL=0xff101a22,LINE=0xff223440,CYAN=0xff00d9ff,PURPLE=0xff7c4dff,RED=0xffff334d;
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(10),dp(5),dp(10),dp(8));panel.setBackgroundColor(0xff071016);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);panel.addView(top,new LinearLayout.LayoutParams(-1,dp(44)));
        TextView close=label("‹",34,WHITE,false);close.setGravity(Gravity.CENTER);top.addView(close,new LinearLayout.LayoutParams(dp(40),-1));
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.setGravity(Gravity.CENTER);top.addView(titles,new LinearLayout.LayoutParams(0,-1,1));
        TextView title=label("سڕینەوەی ئەپ",17,WHITE,true);title.setGravity(Gravity.CENTER);titles.addView(title);TextView status=label("هیچ ئەپێک دیاری نەکراوە",10,DIM,false);status.setGravity(Gravity.CENTER);titles.addView(status);
        TextView menu=label("⋮",25,WHITE,true);menu.setGravity(Gravity.CENTER);top.addView(menu,new LinearLayout.LayoutParams(dp(40),-1));
        LinearLayout tabs=new LinearLayout(this);tabs.setPadding(dp(4),dp(4),dp(4),dp(4));tabs.setBackground(box(PANEL,18));panel.addView(tabs,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView userTab=label("User Apps\n"+userApps.size(),10,WHITE,true),sysTab=label("System Apps\n"+systemApps.size(),10,DIM,true);userTab.setGravity(Gravity.CENTER);sysTab.setGravity(Gravity.CENTER);tabs.addView(userTab,new LinearLayout.LayoutParams(0,-1,1));tabs.addView(sysTab,new LinearLayout.LayoutParams(0,-1,1));
        EditText find=new EditText(this);find.setSingleLine(true);find.setHint("گەڕان لە ناوی ئەپەکان...");find.setTextSize(13);find.setTextColor(WHITE);find.setHintTextColor(DIM);find.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search,0,0,0);find.setCompoundDrawablePadding(dp(8));find.setPadding(dp(14),0,dp(14),0);find.setBackground(box(PANEL,16));LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(38));fp.setMargins(0,dp(4),0,dp(3));panel.addView(find,fp);
        LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL);panel.addView(tools,new LinearLayout.LayoutParams(-1,dp(32)));TextView selectAll=label("☑  هەمووی",11,WHITE,true);selectAll.setGravity(Gravity.CENTER);selectAll.setBackground(box(0xff132832,12));tools.addView(selectAll,new LinearLayout.LayoutParams(0,dp(31),1));TextView sort=label("A–Z  ☷",11,WHITE,true);sort.setGravity(Gravity.CENTER);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(76),dp(31));sp.setMargins(dp(8),0,0,0);tools.addView(sort,sp);
        GridView grid=new GridView(this);grid.setNumColumns(3);grid.setHorizontalSpacing(dp(5));grid.setVerticalSpacing(dp(5));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setPadding(0,dp(4),0,dp(4));grid.setClipToPadding(false);panel.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        final BaseAdapter[] holder=new BaseAdapter[1];final Runnable[] updateHolder={null};
        BaseAdapter adapter=new BaseAdapter(){public int getCount(){return shown.size();}public Object getItem(int p){return shown.get(p);}public long getItemId(int p){return p;}public View getView(int p,View old,android.view.ViewGroup parent){ApplicationInfo a=shown.get(p);boolean on=selected.contains(a.packageName);
            LinearLayout card=new LinearLayout(MainActivity.this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(dp(4),dp(5),dp(4),dp(5));GradientDrawable bg=box(on?0xff102838:PANEL,15);bg.setStroke(dp(on?2:1),on?CYAN:LINE);card.setBackground(bg);
            FrameLayout iconWrap=new FrameLayout(MainActivity.this);card.addView(iconWrap,new LinearLayout.LayoutParams(dp(38),dp(38)));ImageView icon=new ImageView(MainActivity.this);Drawable cachedIcon=appIconCache.get(a.packageName);icon.setImageDrawable(cachedIcon!=null?cachedIcon:getPackageManager().getDefaultActivityIcon());icon.setScaleType(ImageView.ScaleType.FIT_CENTER);iconWrap.addView(icon,new FrameLayout.LayoutParams(-1,-1));CheckBox cb=new CheckBox(MainActivity.this);cb.setChecked(on);cb.setClickable(false);cb.setFocusable(false);if(Build.VERSION.SDK_INT>=21)cb.setButtonTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{CYAN,0xff78909c}));FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.TOP|Gravity.END);cp.setMargins(0,-dp(4),-dp(4),0);iconWrap.addView(cb,cp);
            TextView n=label(pm.getApplicationLabel(a).toString(),10,WHITE,true);n.setGravity(Gravity.CENTER);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);n.setPadding(0,dp(3),0,0);card.addView(n,new LinearLayout.LayoutParams(-1,-2));TextView meta=label("…",8,DIM,false);meta.setGravity(Gravity.CENTER);meta.setMaxLines(1);meta.setTag(a.packageName);card.addView(meta,new LinearLayout.LayoutParams(-1,-2));loadAppMetaAsync(a,meta,icon);
            card.setOnClickListener(v->{v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);if(!selected.add(a.packageName))selected.remove(a.packageName);holder[0].notifyDataSetChanged();if(updateHolder[0]!=null)updateHolder[0].run();});return card;}};holder[0]=adapter;grid.setAdapter(adapter);
        TextView trash=label("🗑  سڕینەوە",12,Color.WHITE,true);trash.setGravity(Gravity.CENTER);trash.setBackground(box(RED,18));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(40));tp.setMargins(dp(28),dp(3),dp(28),0);panel.addView(trash,tp);
        final Runnable[] refresh={null};final Runnable update=()->{int c=selected.size();status.setText(c==0?"هیچ ئەپێک دیاری نەکراوە":c+" ئەپ دیاریکراوە");trash.setText(c==0?"🗑  سڕینەوە":"🗑  سڕینەوە • "+c);trash.setAlpha(c==0?.48f:1f);};updateHolder[0]=update;
        refresh[0]=()->{shown.clear();List<ApplicationInfo> base=systemTab[0]?systemApps:userApps;String q=query[0].trim().toLowerCase(Locale.ROOT);for(ApplicationInfo a:base){String n=pm.getApplicationLabel(a).toString();if(q.isEmpty()||n.toLowerCase(Locale.ROOT).contains(q)||a.packageName.toLowerCase(Locale.ROOT).contains(q))shown.add(a);}userTab.setTextColor(systemTab[0]?DIM:WHITE);sysTab.setTextColor(systemTab[0]?WHITE:DIM);userTab.setBackground(box(systemTab[0]?Color.TRANSPARENT:PURPLE,14));sysTab.setBackground(box(systemTab[0]?PURPLE:Color.TRANSPARENT,14));adapter.notifyDataSetChanged();update.run();};
        userTab.setOnClickListener(v->{systemTab[0]=false;refresh[0].run();});sysTab.setOnClickListener(v->{systemTab[0]=true;refresh[0].run();});selectAll.setOnClickListener(v->{boolean all=!shown.isEmpty();for(ApplicationInfo a:shown)if(!selected.contains(a.packageName)){all=false;break;}for(ApplicationInfo a:shown){if(all)selected.remove(a.packageName);else selected.add(a.packageName);}adapter.notifyDataSetChanged();update.run();});find.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence x,int a,int b,int c){}public void afterTextChanged(android.text.Editable e){}public void onTextChanged(CharSequence x,int a,int b,int c){query[0]=x.toString();refresh[0].run();}});sort.setOnClickListener(v->{Collections.reverse(shown);adapter.notifyDataSetChanged();});
        AlertDialog dialog=new AlertDialog.Builder(UiText.context(this)).setView(panel).create();close.setOnClickListener(v->dialog.dismiss());trash.setOnClickListener(v->{if(selected.isEmpty()||uninstallCurrentPackage!=null)return;uninstallQueue.clear();for(String pkg:selected)try{pm.getApplicationInfo(pkg,0);uninstallQueue.addLast(pkg);}catch(Exception ignored){}if(uninstallQueue.isEmpty())return;uninstallSelected=selected;uninstallApps=userApps;uninstallShown=shown;uninstallAdapter=adapter;uninstallHeader=update;launchNextUninstall();});refresh[0].run();dialog.show();Window w=dialog.getWindow();if(w!=null){w.setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*.94f));w.setDimAmount(.65f);}
    }

    private void chooseApps(){
        if(busy)return;busy=true;cancelled=false;
        // Do not replace the current screen with a blocking Loading page.
        toast("ئەپەکان خێرا بار دەکرێن…");
        worker.execute(()->{try{
            PackageManager pm=getPackageManager();LinkedHashMap<String,ApplicationInfo> unique=new LinkedHashMap<>();
            for(ApplicationInfo app:pm.getInstalledApplications(0)){checkCancel();
                if(!app.packageName.equals(getPackageName())&&(app.flags&ApplicationInfo.FLAG_SYSTEM)==0&&app.sourceDir!=null)unique.put(app.packageName,app);
            }
            List<ApplicationInfo> all=new ArrayList<>(unique.values());
            all.sort((a,b)->quickAppLabel(a).compareToIgnoreCase(quickAppLabel(b)));
            runOnUiThread(()->{if(isDestroyed())return;busy=false;if(all.isEmpty()){toast(UiText.t(34));return;}showModernAppPicker(all,Collections.emptyList());});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;alert(UiText.t(37),friendly(e));});}});
    }
    private void showModernAppPicker(List<ApplicationInfo> all,List<ApplicationInfo> fresh){
        // 9.9: simpler two-tab picker. "New" was removed by request.
        // Installed = normal user apps. Not Installed = packages Android still knows about
        // but which are currently not installed (when the device/ROM exposes them).
        final int[] tab={0}; // 0 Installed, 1 Not Installed
        final String[] search={""};
        final Set<String> checkedPkgs=new LinkedHashSet<>(selectedApps);
        final List<ApplicationInfo> notInstalled=new ArrayList<>();
        // Historical/uninstalled package discovery is intentionally deferred; it must never block opening Apps.
        appMetaWorker.execute(()->{try{
            int flags=android.content.pm.PackageManager.MATCH_UNINSTALLED_PACKAGES;
            List<ApplicationInfo> found=new ArrayList<>();
            for(ApplicationInfo a:getPackageManager().getInstalledApplications(flags)){
                if(a.packageName.equals(getPackageName()))continue;
                boolean installed=(a.flags&ApplicationInfo.FLAG_INSTALLED)!=0,system=(a.flags&ApplicationInfo.FLAG_SYSTEM)!=0;
                if(!installed&&!system)found.add(a);
            }
            found.sort((a,b)->quickAppLabel(a).compareToIgnoreCase(quickAppLabel(b)));
            runOnUiThread(()->{notInstalled.clear();notInstalled.addAll(found);});
        }catch(Exception ignored){}});

        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(14),dp(12),dp(14),dp(8));panel.setBackgroundColor(0xfff7f9fc);
        TextView title=label("ئەپەکان",27,INK,true);title.setGravity(Gravity.CENTER);panel.addView(title);
        TextView sub=label("ئەپەکان هەڵبژێرە بۆ گواستنەوە",13,MUTED,false);sub.setGravity(Gravity.CENTER);sub.setPadding(0,0,0,dp(12));panel.addView(sub);

        LinearLayout tabs=new LinearLayout(this);tabs.setPadding(dp(4),dp(4),dp(4),dp(4));tabs.setBackground(box(0xffedf1f7,18));panel.addView(tabs,new LinearLayout.LayoutParams(-1,dp(46)));
        TextView installedTab=appTab("دامەزراو ("+all.size()+")",true);
        TextView notTab=appTab("دانەمەزراو ("+notInstalled.size()+")",false);
        tabs.addView(installedTab,new LinearLayout.LayoutParams(0,-1,1));
        tabs.addView(notTab,new LinearLayout.LayoutParams(0,-1,1));

        EditText find=new EditText(this);find.setSingleLine(true);find.setHint("گەڕان لە نێو ئەپەکان");find.setTextSize(13);find.setTextColor(INK);find.setHintTextColor(MUTED);find.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search,0,0,0);find.setCompoundDrawablePadding(dp(8));find.setPadding(dp(14),0,dp(14),0);find.setBackground(box(Color.WHITE,16));LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(38));fp.setMargins(0,dp(4),0,dp(3));panel.addView(find,fp);
        TextView selectAll=label("☐  هەمووی هەڵبژێرە",14,BLUE,true);selectAll.setGravity(Gravity.CENTER_VERTICAL);selectAll.setPadding(dp(8),0,dp(8),dp(6));panel.addView(selectAll);

        GridView grid=new GridView(this);grid.setNumColumns(3);grid.setHorizontalSpacing(dp(8));grid.setVerticalSpacing(dp(8));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);panel.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        TextView empty=label("",15,MUTED,false);empty.setGravity(Gravity.CENTER);grid.setEmptyView(empty);panel.addView(empty,new LinearLayout.LayoutParams(-1,0));
        final List<ApplicationInfo> shown=new ArrayList<>();
        final BaseAdapter[] adapterRef=new BaseAdapter[1];
        BaseAdapter adapter=new BaseAdapter(){
            public int getCount(){return shown.size();} public Object getItem(int p){return shown.get(p);} public long getItemId(int p){return p;}
            public View getView(int p,View old,android.view.ViewGroup parent){ApplicationInfo app=shown.get(p);LinearLayout card=new LinearLayout(MainActivity.this);card.setOrientation(1);card.setGravity(Gravity.CENTER);card.setPadding(dp(7),dp(9),dp(7),dp(9));card.setBackground(box(checkedPkgs.contains(app.packageName)?0xffe9efff:Color.WHITE,17));card.setClickable(true);card.setFocusable(true);
                FrameLayout top=new FrameLayout(MainActivity.this);card.addView(top,new LinearLayout.LayoutParams(dp(58),dp(58)));ImageView icon=new ImageView(MainActivity.this);icon.setTag(app.packageName);Drawable cachedIcon=appIconCache.get(app.packageName);icon.setImageDrawable(cachedIcon!=null?cachedIcon:getPackageManager().getDefaultActivityIcon());icon.setScaleType(ImageView.ScaleType.FIT_CENTER);top.addView(icon,new FrameLayout.LayoutParams(-1,-1));
                CheckBox cb=new CheckBox(MainActivity.this);cb.setChecked(checkedPkgs.contains(app.packageName));cb.setClickable(false);cb.setFocusable(false);cb.setFocusableInTouchMode(false);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(30),dp(30),Gravity.TOP|Gravity.END);cp.setMargins(0,-dp(4),-dp(4),0);top.addView(cb,cp);
                TextView n=label(quickAppLabel(app),13,INK,true);n.setGravity(Gravity.CENTER);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);n.setPadding(0,dp(5),0,0);card.addView(n,new LinearLayout.LayoutParams(-1,-2));
                TextView z=label(tab[0]==0?"…":"—",11,MUTED,false);z.setGravity(Gravity.CENTER);z.setTag(app.packageName);card.addView(z);if(tab[0]==0)loadAppMetaAsync(app,z,icon);else appMetaWorker.execute(()->{Drawable d=pmIcon(app);runOnUiThread(()->{if(!isDestroyed()&&app.packageName.equals(icon.getTag()))icon.setImageDrawable(d);});});
                card.setOnClickListener(v->{if(!checkedPkgs.add(app.packageName))checkedPkgs.remove(app.packageName);adapterRef[0].notifyDataSetChanged();});
                return card;}
        };adapterRef[0]=adapter;grid.setAdapter(adapter);
        Runnable refresh=()->{shown.clear();List<ApplicationInfo> base=tab[0]==0?all:notInstalled;String q=search[0].trim().toLowerCase(Locale.ROOT);for(ApplicationInfo a:base){String n=getPackageManager().getApplicationLabel(a).toString();if(q.isEmpty()||n.toLowerCase(Locale.ROOT).contains(q))shown.add(a);}empty.setText(tab[0]==1?"هیچ ئەپێکی دانەمەزراو نەدۆزرایەوە":"هیچ ئەپێک نەدۆزرایەوە");adapter.notifyDataSetChanged();};
        Runnable paintTabs=()->{installedTab.setBackground(box(tab[0]==0?BLUE:Color.TRANSPARENT,14));notTab.setBackground(box(tab[0]==1?BLUE:Color.TRANSPARENT,14));installedTab.setTextColor(tab[0]==0?Color.WHITE:INK);notTab.setTextColor(tab[0]==1?Color.WHITE:INK);refresh.run();};
        installedTab.setOnClickListener(v->{tab[0]=0;paintTabs.run();});notTab.setOnClickListener(v->{tab[0]=1;paintTabs.run();});
        grid.setOnItemClickListener((p,v,pos,id)->{ApplicationInfo a=shown.get(pos);if(!checkedPkgs.add(a.packageName))checkedPkgs.remove(a.packageName);adapter.notifyDataSetChanged();});
        selectAll.setOnClickListener(v->{boolean allOn=!shown.isEmpty();for(ApplicationInfo a:shown)if(!checkedPkgs.contains(a.packageName)){allOn=false;break;}for(ApplicationInfo a:shown){if(allOn)checkedPkgs.remove(a.packageName);else checkedPkgs.add(a.packageName);}adapter.notifyDataSetChanged();});
        find.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){search[0]=s.toString();refresh.run();}public void afterTextChanged(android.text.Editable e){}});
        paintTabs.run();
        AlertDialog dialog=new AlertDialog.Builder(UiText.context(this)).setView(panel).setNegativeButton(UiText.t(29),null).setPositiveButton("هەڵبژاردن",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{List<ApplicationInfo> chosen=new ArrayList<>();for(ApplicationInfo a:all)if(checkedPkgs.contains(a.packageName))chosen.add(a);dialog.dismiss();exportApps(chosen);});});dialog.show();
        Window w=dialog.getWindow();if(w!=null)w.setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*.88f));
    }
    private TextView appTab(String text,boolean active){TextView t=label(text,13,active?Color.WHITE:INK,true);t.setGravity(Gravity.CENTER);t.setBackground(box(active?BLUE:Color.TRANSPARENT,14));return t;}
    private Drawable pmIcon(ApplicationInfo app){
        Drawable cached=appIconCache.get(app.packageName);if(cached!=null)return cached;
        try{Drawable d=getPackageManager().getApplicationIcon(app);appIconCache.put(app.packageName,d);return d;}catch(Exception e){return getPackageManager().getDefaultActivityIcon();}
    }
    private String appInstalledSize(ApplicationInfo app){long total=0;try{if(app.sourceDir!=null)total+=new File(app.sourceDir).length();if(app.splitSourceDirs!=null)for(String s:app.splitSourceDirs)total+=new File(s).length();}catch(Exception ignored){}return TransferStats.size(total);}
    private String quickAppLabel(ApplicationInfo app){
        String v=appLabelCache.get(app.packageName);if(v!=null)return v;
        try{v=getPackageManager().getApplicationLabel(app).toString();}catch(Exception e){v=app.packageName;}
        appLabelCache.put(app.packageName,v);return v;
    }
    private void loadAppMetaAsync(ApplicationInfo app,TextView target,ImageView icon){
        String ready=appMetaCache.get(app.packageName);if(ready!=null){target.setText(ready);Drawable d=appIconCache.get(app.packageName);if(d!=null)icon.setImageDrawable(d);return;}
        target.setText("…");
        appMetaWorker.execute(()->{
            String ver="";try{PackageInfo pi=getPackageManager().getPackageInfo(app.packageName,0);ver=pi.versionName==null?"":("v"+pi.versionName+" • ");}catch(Exception ignored){}
            String meta=ver+appInstalledSize(app);Drawable d=pmIcon(app);appMetaCache.put(app.packageName,meta);
            runOnUiThread(()->{if(!isDestroyed()&&target.getTag()!=null&&target.getTag().equals(app.packageName)){target.setText(meta);icon.setImageDrawable(d);}});
        });
    }
    private void exportApps(List<ApplicationInfo> apps){
        if(apps.isEmpty()){groups.remove("apps");selectedApps.clear();categories();return;}
        busy=true;cancelled=false;loading(UiText.t(38));
        worker.execute(()->{List<Item> exported=new ArrayList<>();Set<String> successful=new HashSet<>();StringBuilder failed=new StringBuilder();
            for(ApplicationInfo old:apps){File bundle=null;try{
                checkCancel();PackageInfo before=getPackageManager().getPackageInfo(old.packageName,0);ApplicationInfo app=before.applicationInfo;
                List<File> parts=new ArrayList<>();parts.add(new File(app.sourceDir));if(app.splitSourceDirs!=null)for(String path:app.splitSourceDirs)parts.add(new File(path));
                bundle=File.createTempFile("app-",".rbapp",getCacheDir());AppBundle.write(parts,bundle);checkCancel();PackageInfo after=getPackageManager().getPackageInfo(app.packageName,0);
                if(before.lastUpdateTime!=after.lastUpdateTime||before.versionCode!=after.versionCode)throw new IOException("App updated during export");
                String label=safeName(getPackageManager().getApplicationLabel(app).toString());if(label.length()>100)label=label.substring(0,100);
                exported.add(new Item(Uri.fromFile(bundle),label+".rbapp",AppBundle.MIME,bundle.length()));successful.add(app.packageName);
            }catch(Exception e){if(bundle!=null)bundle.delete();failed.append(old.packageName).append("\n");if(cancelled)break;}}
            runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.remove("apps");if(!exported.isEmpty())groups.put("apps",exported);selectedApps.clear();selectedApps.addAll(successful);categories();
                if(failed.length()>0)alert(UiText.t(39),UiText.t(40)+failed.toString());});
        });
    }
    private void pickFiles(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);startActivityForResult(i,FILES);}
    private void openDownloads(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
        if(Build.VERSION.SDK_INT>=26)i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"));
        startActivityForResult(i,FILES);
    }
    private void requestCategory(String id){
        pendingCategory=id;List<String> permissions=new ArrayList<>();
        if(id.equals("contacts"))permissions.add(Manifest.permission.READ_CONTACTS);
        else if(id.equals("calls"))permissions.add(Manifest.permission.READ_CALL_LOG);
        else if(id.equals("sms"))permissions.add(Manifest.permission.READ_SMS);
        else if(Build.VERSION.SDK_INT>=33){permissions.add(id.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:id.equals("videos")?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO);
            if(Build.VERSION.SDK_INT>=34&&!id.equals("audio"))permissions.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);
        }else permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if(checkSelfPermission(permissions.get(0))==PackageManager.PERMISSION_GRANTED){loadCategory(id);return;}
        requestPermissions(permissions.toArray(new String[0]),DATA_PERMISSION);
    }
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] grants){
        super.onRequestPermissionsResult(code,perms,grants);
        if(code==SETUP_PERMISSION){setupWaiting=false;main.post(()->nextPermission());return;}
        if(code==FILE_HUB_PERMISSION){if("fileHub".equals(screen))fileHub();return;}
        if(code==FILE_BROWSER_PERMISSION){String category=browserMediaCategory;browserMediaCategory=null;if(category!=null&&browserMediaAllowed(category))showFileGallery(category);else toast(UiText.t(44));return;}
        if(code==HOTSPOT_PERMISSION){
            String needed=Build.VERSION.SDK_INT>=33?Manifest.permission.NEARBY_WIFI_DEVICES:Manifest.permission.ACCESS_FINE_LOCATION;
            Runnable next=afterWifiPermission;afterWifiPermission=null;
            if(checkSelfPermission(needed)==PackageManager.PERMISSION_GRANTED&&next!=null)next.run();else alert(UiText.t(41),UiText.t(42));
        }
        if(code==CAMERA_PERMISSION){if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)scan();else toast(UiText.t(43));}
        if(code==DATA_PERMISSION){boolean allowed=false;for(int g:grants)allowed|=g==PackageManager.PERMISSION_GRANTED;
            if(allowed)loadCategory(pendingCategory);else if(isRecords(pendingCategory))alert(UiText.t(41),UiText.t(235));else toast(UiText.t(44));}
    }
    private void loading(String message){page("loading",message,UiText.t(45),1);ProgressBar p=new ProgressBar(this);body.addView(p);}
    private void loadCategory(String id){
        if(isRecords(id)){loadRecords(id);return;}
        busy=true;cancelled=false;loading(UiText.t(46));
        worker.execute(()->{
            try{
                List<Item> found=media(id);
                checkCancel();runOnUiThread(()->{if(isDestroyed())return;busy=false;if(!found.isEmpty())groups.put(id,found);categories();if(found.isEmpty())toast(UiText.t(47));
                    else if(Build.VERSION.SDK_INT>=34&&(id.equals("photos")||id.equals("videos"))&&checkSelfPermission(id.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_MEDIA_VIDEO)!=PackageManager.PERMISSION_GRANTED)toast(UiText.t(48));});
            }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(49),friendly(e));});}
        });
    }
    private List<Item> media(String category)throws Exception{
        Uri collection=category.equals("photos")?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:category.equals("videos")?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        List<Item> out=new ArrayList<>();
        try(Cursor c=getContentResolver().query(collection,new String[]{"_id","_display_name","mime_type","_size",Build.VERSION.SDK_INT>=29?MediaStore.MediaColumns.RELATIVE_PATH:MediaStore.MediaColumns.DATA,MediaStore.MediaColumns.DATE_MODIFIED,MediaStore.Images.ImageColumns.DATE_TAKEN},null,null,"date_added DESC")){
            if(c!=null)while(c.moveToNext()){checkCancel();if(out.size()>=MAX_FILES)throw new IOException("TOO_MANY");
                Item item=new Item(ContentUris.withAppendedId(collection,c.getLong(0)),safeName(c.getString(1)),validMime(c.getString(2)),c.isNull(3)?-1:c.getLong(3));
                String path=c.isNull(4)?"":c.getString(4);
                if(Build.VERSION.SDK_INT<29&&path!=null){int slash=path.lastIndexOf('/');path=slash>0?path.substring(0,slash+1):"";String root=Environment.getExternalStorageDirectory().getAbsolutePath()+"/";if(path.startsWith(root))path=path.substring(root.length());}
                item.relativePath=safeRelativePath(path);if(!c.isNull(5))item.modified=c.getLong(5)*1000L;if(!c.isNull(6))item.taken=c.getLong(6);out.add(item);
            }
        }return out;
    }
    private boolean isRecords(String id){return "contacts".equals(id)||"calls".equals(id)||"sms".equals(id);}
    private void loadRecords(String kind){
        if(busy)return;busy=true;cancelled=false;loading(UiText.t(46));
        worker.execute(()->{try{PersonalRecords.Result result=PersonalRecords.load(this,kind,()->checkCancel());
            runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();if(result.rows.isEmpty())toast(UiText.t(47));else if(kind.equals("sms")||kind.equals("calls")){if(result.limited)toast(UiText.t(239));exportRecords(kind,result.rows);}else chooseRecords(kind,result);});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(49),e instanceof SecurityException?UiText.t(235):UiText.t(244));});}});
    }
    private void chooseRecords(String kind,PersonalRecords.Result result){
        Set<String> chosen=new HashSet<>(selectedRecords.getOrDefault(kind,Collections.emptySet()));List<PersonalRecords.Row> visible=new ArrayList<>();Set<String> available=new HashSet<>();for(PersonalRecords.Row row:result.rows)available.add(row.id);chosen.retainAll(available);if(!kind.equals("contacts")&&!selectedRecords.containsKey(kind))chosen.addAll(available);
        LinearLayout layout=new LinearLayout(UiText.context(this));layout.setOrientation(1);layout.setPadding(dp(16),dp(8),dp(16),0);layout.setLayoutDirection(UiText.direction());
        EditText search=new EditText(UiText.context(this));search.setSingleLine(true);search.setHint(UiText.t(236));layout.addView(search);
        TextView note=label(kind.equals("contacts")?UiText.t(232):UiText.t(231),13,MUTED,false);layout.addView(note);if(result.limited)layout.addView(label(UiText.t(239),13,MUTED,false));
        TextView count=label("",15,BLUE,true);layout.addView(count);
        LinearLayout actions=new LinearLayout(this);layout.addView(actions);Button all=new Button(this);all.setText(UiText.t(237));actions.addView(all,new LinearLayout.LayoutParams(0,-2,1));Button none=new Button(this);none.setText(UiText.t(245));actions.addView(none,new LinearLayout.LayoutParams(0,-2,1));
        ListView list=new ListView(UiText.context(this));list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);layout.addView(list,new LinearLayout.LayoutParams(-1,Math.min(dp(340),getResources().getDisplayMetrics().heightPixels/3)));
        Runnable refresh=()->{String term=search.getText().toString().toLowerCase(Locale.ROOT);visible.clear();List<String> labels=new ArrayList<>();for(PersonalRecords.Row row:result.rows)if(row.label.toLowerCase(Locale.ROOT).contains(term)){visible.add(row);labels.add(row.label);}
            list.setAdapter(new ArrayAdapter<>(UiText.context(this),android.R.layout.simple_list_item_multiple_choice,labels));list.clearChoices();for(int n=0;n<visible.size();n++)list.setItemChecked(n,chosen.contains(visible.get(n).id));count.setText(chosen.size()+UiText.t(238));};
        list.setOnItemClickListener((parent,view,pos,id)->{String key=visible.get(pos).id;if(list.isItemChecked(pos))chosen.add(key);else chosen.remove(key);count.setText(chosen.size()+UiText.t(238));});
        all.setOnClickListener(v->{for(PersonalRecords.Row row:visible)chosen.add(row.id);refresh.run();});none.setOnClickListener(v->{chosen.clear();refresh.run();});
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refresh.run();
        new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(kind.equals("contacts")?24:kind.equals("calls")?229:230)).setView(layout)
            .setPositiveButton(UiText.t(36),(d,w)->{List<PersonalRecords.Row> rows=new ArrayList<>();for(PersonalRecords.Row row:result.rows)if(chosen.contains(row.id))rows.add(row);exportRecords(kind,rows);})
            .setNegativeButton(UiText.t(61),null).show();
    }
    private void exportRecords(String kind,List<PersonalRecords.Row> rows){
        if(rows.isEmpty()){groups.remove(kind);selectedRecords.remove(kind);categories();return;}
        busy=true;cancelled=false;loading(UiText.t(186));
        worker.execute(()->{try{File file=PersonalRecords.export(this,kind,rows,()->checkCancel());
            String name=kind.equals("contacts")?"contacts-selected.vcf":kind+"-selected-backup.json";String mime=kind.equals("contacts")?"text/x-vcard":"application/json";
            Set<String> ids=new HashSet<>();for(PersonalRecords.Row row:rows)ids.add(row.id);
            runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.put(kind,new ArrayList<>(Collections.singletonList(new Item(Uri.fromFile(file),name,mime,file.length()))));selectedRecords.put(kind,ids);categories();});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(49),e instanceof SecurityException?UiText.t(235):UiText.t(244));});}});
    }
    private void prepareSelection(){
        if(countSelected()==0){toast(UiText.t(50));return;}
        if(countSelected()>MAX_FILES){toast(UiText.t(51));return;}
        selection.clear();Set<String> unique=new HashSet<>();for(List<Item> list:groups.values())for(Item i:list)if(unique.add(i.uri.toString()))selection.add(i);
        if(!senderPaired){connectPage();return;}
        if(selectedUsbChannel!=null){SecureChannel channel=selectedUsbChannel;selectedUsbChannel=null;usbMode=true;transferPage(true);List<Item> items=new ArrayList<>(selection);usbRetryItems=new ArrayList<>(items);usbReconnectAttempts=0;job(false,()->sendFiles(channel,items));}
        else if(pendingPeer!=null)send(pendingPeer);else connectPage();
    }
    private void connectPage(){
        senderPaired=false;if(selectedUsbChannel!=null){selectedUsbChannel=null;stopLink();}
        page("connect",UiText.t(52),UiText.t(278),1);
        body.addView(new Phones(this),new LinearLayout.LayoutParams(-1,dp(160)));gap(18);
        text(UiText.t(53),16,INK,false);gap(22);
        button(UiText.t(54),true,()->scan());
        button(UiText.t(55),false,()->startUsb(false));
        button(UiText.t(29),false,()->home());
        TextView manual=text(UiText.t(58),13,MUTED,false);manual.setPadding(0,dp(14),0,0);manual.setOnClickListener(v->manualPairing());
    }
    private void pairedWifi(Pairing peer){
        if(busy)return;busy=true;cancelled=false;page("pairVerify",UiText.t(64),UiText.t(278),1);
        int token=linkGeneration;
        worker.execute(()->{boolean ok=false;for(String host:peer.hosts){try{checkCancel();socket=transferNetwork.getSocketFactory().createSocket();socket.connect(new InetSocketAddress(host,PORT),4500);socket.setSoTimeout(10000);new SecureChannel(socket.getInputStream(),socket.getOutputStream(),peer.key,false);ok=true;break;}catch(Exception ignored){}finally{try{if(socket!=null)socket.close();}catch(Exception ignored){}}}
            final boolean ready=ok;runOnUiThread(()->{if(isDestroyed()||token!=linkGeneration)return;busy=false;if(ready&&!cancelled){pendingPeer=peer;senderPaired=true;usbMode=false;categories();}else{connectPage();alert(UiText.t(62),UiText.t(63));}});});
    }
    private void scan(){if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION);return;}startActivityForResult(new Intent(this,ScanActivity.class),SCAN);}
    private void manualPairing(){EditText e=new EditText(this);e.setHint("rebaritclone:v3:…");e.setTextDirection(View.TEXT_DIRECTION_LTR);new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(59)).setView(e).setPositiveButton(UiText.t(60),(d,w)->usePair(e.getText().toString())).setNegativeButton(UiText.t(61),null).show();}
    private void usePair(String value){
        try{Pairing peer=Pairing.parse(value);pendingPeer=peer;
            if(!peer.ssid.isEmpty()&&Build.VERSION.SDK_INT>=29)wifiPermission(()->connectHotspot(peer));
            else {transferNetwork=hotspot.currentWifi();if(transferNetwork==null)manualJoin(peer);else pairedWifi(peer);}
        }catch(Exception e){alert(UiText.t(62),UiText.t(63));}
    }
    private void wifiPermission(Runnable action){
        String permission=Build.VERSION.SDK_INT>=33?Manifest.permission.NEARBY_WIFI_DEVICES:Manifest.permission.ACCESS_FINE_LOCATION;
        if(checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED){action.run();return;}
        afterWifiPermission=action;
        requestPermissions(Build.VERSION.SDK_INT>=33?new String[]{permission}:new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,permission},HOTSPOT_PERMISSION);
    }
    private void connectHotspot(Pairing peer){
        linking=true;int token=++linkGeneration;
        page("link",UiText.t(64),UiText.t(65),1);
        text(peer.ssid,19,BLUE,true);button(UiText.t(66),false,()->{stopLink();manualJoin(peer);});button(UiText.t(29),false,()->{stopLink();connectPage();});
        hotspot.connect(peer,new HotspotLink.ClientCallback(){
            public void ready(Network network){if(isDestroyed()||token!=linkGeneration||busy)return;linking=false;transferNetwork=network;pairedWifi(peer);}
            public void failed(){if(isDestroyed()||token!=linkGeneration)return;if(busy){closeNetwork();return;}linking=false;manualJoin(peer);}
        });
    }
    private void manualJoin(Pairing peer){
        page("manual",UiText.t(67),UiText.t(68),1);
        if(!peer.ssid.isEmpty()){text(UiText.t(69)+peer.ssid,17,INK,true);gap(12);text(UiText.t(70)+peer.password,16,BLUE,false).setTextIsSelectable(true);}
        button(UiText.t(71),true,()->startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        button(UiText.t(72),true,()->{transferNetwork=hotspot.currentWifi();if(transferNetwork==null)toast(UiText.t(73));else pairedWifi(peer);});
        button(UiText.t(29),false,()->connectPage());
    }
    private void stopLink(){linkGeneration++;linking=false;hotspot.close();if(usb!=null)usb.close();transferNetwork=null;}
    private void beginHotspot(){
        if(busy||linking)return;
        if(!autoWifiFallback){autoWifiFallback=true;autoWifiAttempt=0;fastMode=true;}
        if(Build.VERSION.SDK_INT<29&&folder==null){resumeFolder=true;chooseFolder();return;}
        wifiPermission(()->{
            android.net.wifi.WifiManager wm=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if(!wm.isWifiEnabled()){startActivityForResult(new Intent(Build.VERSION.SDK_INT>=29?Settings.Panel.ACTION_WIFI:Settings.ACTION_WIFI_SETTINGS),WIFI_SETTINGS);return;}
            if(Build.VERSION.SDK_INT<33&&!locationEnabled()){startActivityForResult(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS),LOCATION_SETTINGS);return;}
            lastHotspotError="";linking=true;int token=++linkGeneration;
            main.postDelayed(()->{if(!isDestroyed()&&token==linkGeneration&&linking&&!busy){lastHotspotError="HOTSPOT_TIMEOUT";hotspotFailure();}},45000);
            page("hotspot",UiText.t(74),UiText.t(75),1);
            button(UiText.t(29),false,()->{stopLink();receiverSetup();});
            hotspot.start(fastMode,new HotspotLink.HostCallback(){
                public void ready(String ssid,String password){if(isDestroyed()||token!=linkGeneration)return;hotspotSsid=ssid;hotspotPassword=password;autoWifiFallback=false;autoWifiAttempt=0;waitForAddress(token,0);}
                public void failed(String reason){if(isDestroyed()||token!=linkGeneration)return;lastHotspotError=reason;linking=false;if(busy){closeNetwork();return;}hotspotFailure();}
            });
        });
    }
    private boolean locationEnabled(){
        android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
        return Build.VERSION.SDK_INT>=28?lm.isLocationEnabled():lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)||lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER);
    }
    private void hotspotFailure(){
        stopLink();hotspotSsid="";hotspotPassword="";
        String failed=lastHotspotError;
        // Attempt 1 was high-speed 5 GHz/P2P. Retry automatically in compatibility mode.
        if(autoWifiFallback&&autoWifiAttempt==0){
            autoWifiAttempt=1;fastMode=false;
            page("hotspot",UiText.t(74),"خۆکارانە باشترین پەیوەندی هەڵدەبژێردرێت…",1);
            summaryCard("5 GHz/P2P لەم ئامێرەدا بەردەست نەبوو");
            summaryCard("↻ گۆڕین بۆ Hotspot ـی گونجاو");
            main.postDelayed(()->{if(!isDestroyed()){linking=false;beginHotspot();}},700);
            return;
        }
        // Both managed modes failed. Only now expose manual recovery.
        autoWifiFallback=false;autoWifiAttempt=0;
        page("receiver",UiText.t(77),UiText.t(78),1);
        note(failed+" • "+Build.MANUFACTURER+" "+Build.MODEL+" • Android "+Build.VERSION.RELEASE);
        button("↻ هەڵبژاردنی خۆکاری دووبارە",true,()->{fastMode=true;beginHotspot();});
        button(UiText.t(81),false,()->manualHost());
        button(UiText.t(29),false,()->home());
    }
    private void waitForAddress(int token,int attempt){
        if(isDestroyed()||token!=linkGeneration)return;
        if(!wifiAddresses().isEmpty()){linking=false;receive();return;}
        if(attempt>=15){lastHotspotError="LOCAL_ADDRESS_NOT_FOUND";linking=false;hotspotFailure();return;}
        main.postDelayed(()->waitForAddress(token,attempt+1),1000);
    }
    private void manualHost(){
        autoWifiFallback=false;autoWifiAttempt=0;stopLink();hotspotSsid="";hotspotPassword="";
        page("manualhost",UiText.t(83),UiText.t(84),1);
        if(!lastHotspotError.isEmpty())note(UiText.t(85)+lastHotspotError+"\n"+Build.MANUFACTURER+" "+Build.MODEL+" • Android "+Build.VERSION.RELEASE);
        button(UiText.t(86),true,()->{try{startActivity(new Intent("android.settings.TETHER_SETTINGS"));}catch(Exception e){startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));}});
        button(UiText.t(87),true,()->{if(Build.VERSION.SDK_INT<29&&folder==null)chooseFolder();else receive();});
        note(UiText.t(88));
        button(UiText.t(29),false,()->receiverSetup());
    }
    private void decodeImage(Uri uri){
        busy=true;loading(UiText.t(89));worker.execute(()->{
            try{
                BitmapFactory.Options opt=new BitmapFactory.Options();opt.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,opt);}
                opt.inSampleSize=1;while(opt.outWidth/opt.inSampleSize>1600||opt.outHeight/opt.inSampleSize>1600)opt.inSampleSize*=2;opt.inJustDecodeBounds=false;
                Bitmap bitmap;try(InputStream in=getContentResolver().openInputStream(uri)){bitmap=BitmapFactory.decodeStream(in,null,opt);}if(bitmap==null)throw new IOException("QR");
                int w=bitmap.getWidth(),h=bitmap.getHeight();int[] pixels=new int[w*h];bitmap.getPixels(pixels,0,w,0,0,w,h);bitmap.recycle();
                Map<DecodeHintType,Object> hints=new EnumMap<>(DecodeHintType.class);hints.put(DecodeHintType.TRY_HARDER,true);hints.put(DecodeHintType.POSSIBLE_FORMATS,Collections.singletonList(BarcodeFormat.QR_CODE));
                String payload=new MultiFormatReader().decode(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(w,h,pixels))),hints).getText();Pairing.parse(payload);
                runOnUiThread(()->{if(isDestroyed())return;busy=false;usePair(payload);});
            }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;connectPage();alert(UiText.t(90),UiText.t(91));});}
        });
    }
    private void startUsb(boolean receiving){
        if(busy)return;
        if(receiving&&Build.VERSION.SDK_INT<29&&folder==null){resumeUsbFolder=true;chooseFolder();return;}
        stopLink();usbMode=true;linking=true;int token=++linkGeneration;
        page("usb",UiText.t(92),UiText.t(93),1);
        body.addView(new CableArt(this),new LinearLayout.LayoutParams(-1,dp(150)));gap(12);
        summaryCard(receiving?UiText.t(94):UiText.t(95));
        note(UiText.t(96));
        status=summaryCard(UiText.t(97));status.setTextColor(BLUE);
        button(UiText.t(29),false,()->{stopLink();if(receiving)usbReceiverSetup();else usbRoles();});
        try{usb.start(receiving,new UsbLink.Listener(){
            public void ready(InputStream in,OutputStream out){
                if(isDestroyed()||token!=linkGeneration)return;linking=false;
                if(!receiving){
                    page("usbWaiting","چاوەڕێی مۆبایلی تازە","مۆبایلی تازە دیاری دەکات چی وەربگرێت",1);button(UiText.t(111),false,()->cancel());
                    job(false,()->{SecureChannel channel=UsbSession.open(in,out,false);usbSourceSession(channel);});
                    return;
                }
                page("usbWaiting","کۆنترۆڵ لەم مۆبایلەیە","لیستی داتاکانی مۆبایلی کۆن وەردەگیرێت…",1);button(UiText.t(111),false,()->cancel());
                job(true,()->{SecureChannel channel=UsbSession.open(in,out,true);usbControllerSession(channel);});
            }
            public void status(String message){runOnUiThread(()->{if(!isDestroyed()&&token==linkGeneration&&status!=null)status.setText(message);});}
            public void failed(String reason){if(isDestroyed()||token!=linkGeneration)return;linking=false;
                clearUsbAttemptState();
                if(usbAutoResume&&!cancelled&&usbReconnectAttempts<USB_RETRY_LIMIT){
                    usbReconnectAttempts++;toast("USB پچڕا • خۆکارانە لە هەمان شوێن بەردەوام دەبێتەوە…");
                    main.postDelayed(()->startUsb(receiving),usbRetryDelay());return;
                }
                if(receiving){usbReceiverSetup();note("USB پەیوەندی نەکرا. کێبڵی Data بەکاربهێنە، USB permission = Allow.");}
                else{usbRoles();note("USB پەیوەندی نەکرا. کێبڵی Data بەکاربهێنە و USB permission ڕێگەپێبدە.");}
                toast(reason);
            }
        });}catch(Throwable e){
            linking=false;clearUsbAttemptState();
            if(receiving)usbReceiverSetup();else usbRoles();
            toast("USB نەتوانرا دەستپێبکات • دووبارە هەوڵ بدە");
        }
    }
    private void usbReceiverSetup(){
        if(busy)return;stopLink();usbMode=true;
        page("usbReceiver",UiText.t(102),UiText.t(273),1);
        body.addView(new CableArt(this),new LinearLayout.LayoutParams(-1,dp(180)));gap(18);
        summaryCard("1. کێبڵی USB-C پەیوەست بکە");gap(10);summaryCard("2. ئەم مۆبایلە لیستی داتاکانی مۆبایلی کۆن دەبینێت");gap(10);summaryCard("3. لێرە دیاری بکە چی وەربگریت؛ کۆنەکە تەنها ڕەزامەندی دەدات");gap(16);
        Button usbReceive=button("↓  وەرگرتن بە USB",true,()->startUsb(true));usbReceive.setTextSize(18);usbReceive.setMinHeight(dp(68));
        note("کێبڵی USB-C پەیوەست بکە؛ وەرگر خۆکارانە چاوەڕێ دەکات. ئەگەر Android داوای USB permission کرد، Allow هەڵبژێرە.");
        main.postDelayed(()->{if(!isDestroyed()&&!busy&&"usbReceiver".equals(screen))startUsb(true);},500);
        button(UiText.t(29),false,()->home());
    }
    private static class CableArt extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        CableArt(Context c){super(c);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
        protected void onDraw(Canvas c){float scale=Math.min(getWidth()/340f,getHeight()/175f);c.save();c.translate((getWidth()-340*scale)/2,(getHeight()-175*scale)/2);c.scale(scale,scale);
            p.setColor(0xffe9e8ff);c.drawRoundRect(0,0,340,175,24,24,p);
            for(int n=0;n<2;n++){float x=n==0?53:231;p.setColor(n==0?0xff627089:BLUE);c.drawRoundRect(x,18,x+56,126,10,10,p);p.setColor(Color.WHITE);c.drawRoundRect(x+5,24,x+51,117,6,6,p);p.setColor(0xffd5d9ed);c.drawRoundRect(x+18,28,x+38,32,2,2,p);p.setColor(n==0?0xff627089:BLUE);c.drawCircle(x+28,72,12,p);}
            p.setColor(BLUE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);Path cable=new Path();cable.moveTo(81,125);cable.lineTo(81,142);cable.cubicTo(81,165,259,165,259,142);cable.lineTo(259,125);c.drawPath(cable,p);p.setStyle(Paint.Style.FILL);c.drawRoundRect(73,121,89,132,3,3,p);c.drawRoundRect(251,121,267,132,3,3,p);p.setTextSize(16);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);c.drawText("USB-C",170,80,p);c.restore();}
    }
    private void receiverSetup(){
        page("receiver",UiText.t(99),UiText.t(100),1);
        body.addView(new Phones(this),new LinearLayout.LayoutParams(-1,dp(140)));gap(14);
        button(UiText.t(101),true,()->beginHotspot());
        button(UiText.t(103),false,()->manualHost());
        note(UiText.t(104));
        button(UiText.t(29),false,()->home());
    }
    private void chooseFolder(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);startActivityForResult(i,FOLDER);}
    private List<String> wifiAddresses(){
        LinkedHashSet<String> values=new LinkedHashSet<>();Set<String> clientInterfaces=new HashSet<>();
        if(hotspot!=null&&Pairing.local(hotspot.hostAddress()))values.add(hotspot.hostAddress());
        try{
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            for(Network n:cm.getAllNetworks()){NetworkCapabilities cap=cm.getNetworkCapabilities(n);LinkProperties lp=cm.getLinkProperties(n);
                if(cap!=null&&lp!=null&&cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)&&!cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN)){
                    clientInterfaces.add(lp.getInterfaceName());
                    if(hotspotSsid.isEmpty())for(LinkAddress la:lp.getLinkAddresses())if(la.getAddress() instanceof Inet4Address&&Pairing.local(la.getAddress().getHostAddress()))values.add(la.getAddress().getHostAddress());
                }
            }
            for(NetworkInterface ni:Collections.list(NetworkInterface.getNetworkInterfaces())){
                String name=ni.getName().toLowerCase(Locale.ROOT);
                if(!hotspotSsid.isEmpty()&&clientInterfaces.contains(ni.getName()))continue;
                if(!ni.isUp()||!(name.startsWith("wlan")||name.startsWith("swlan")||name.startsWith("ap")||name.startsWith("wlp")||name.startsWith("p2p")||name.startsWith("br")))continue;
                for(InetAddress a:Collections.list(ni.getInetAddresses()))if(a instanceof Inet4Address&&Pairing.local(a.getHostAddress()))values.add(a.getHostAddress());
            }
        }catch(Exception ignored){}List<String> result=new ArrayList<>(values);return result.subList(0,Math.min(result.size(),8));
    }
    private String usbCategoryName(String id){
        if("photos".equals(id))return UiText.t(16);if("videos".equals(id))return UiText.t(18);if("audio".equals(id))return UiText.t(20);
        if("files".equals(id))return UiText.t(26);if("apps".equals(id))return UiText.t(22);if("contacts".equals(id))return UiText.t(24);
        if("calls".equals(id))return UiText.t(229);if("sms".equals(id))return UiText.t(230);return id;
    }
    private long[] usbMediaStat(String id)throws Exception{
        Uri uri="photos".equals(id)?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:"videos".equals(id)?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        long count=0,bytes=0;try(Cursor c=getContentResolver().query(uri,new String[]{MediaStore.MediaColumns.SIZE},null,null,null)){while(c!=null&&c.moveToNext()){checkCancel();count++;if(!c.isNull(0)&&c.getLong(0)>0)bytes+=c.getLong(0);}}
        return new long[]{count,bytes};
    }
    private boolean usbSharedFileCandidate(String name,String mime,String path){
        name=name==null?"":name.toLowerCase(Locale.ROOT);mime=mime==null?"":mime.toLowerCase(Locale.ROOT);path=safeRelativePath(path).toLowerCase(Locale.ROOT);
        if(path.startsWith("android/data/")||path.startsWith("android/obb/"))return false;
        if(mime.startsWith("image/")||mime.startsWith("video/")||mime.startsWith("audio/"))return false;
        if(name.endsWith(".apk")||mime.equals("application/vnd.android.package-archive"))return false;
        return !name.isEmpty();
    }
    private long[] usbFilesStat()throws Exception{
        Uri uri=MediaStore.Files.getContentUri("external");long count=0,bytes=0;
        String pathColumn=Build.VERSION.SDK_INT>=29?MediaStore.MediaColumns.RELATIVE_PATH:MediaStore.MediaColumns.DATA;
        try(Cursor c=getContentResolver().query(uri,new String[]{MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.MIME_TYPE,MediaStore.MediaColumns.SIZE,pathColumn},null,null,null)){
            while(c!=null&&c.moveToNext()){checkCancel();String name=c.isNull(0)?"":c.getString(0),mime=c.isNull(1)?"":c.getString(1),path=c.isNull(3)?"":c.getString(3);if(!usbSharedFileCandidate(name,mime,path))continue;count++;if(!c.isNull(2)&&c.getLong(2)>0)bytes+=c.getLong(2);if(count>=MAX_FILES)break;}
        }return new long[]{count,bytes};
    }
    private long[] usbAppsStat(){long count=0,bytes=0;try{for(ApplicationInfo a:getPackageManager().getInstalledApplications(0)){if(a.packageName.equals(getPackageName())||(a.flags&ApplicationInfo.FLAG_SYSTEM)!=0)continue;count++;if(a.sourceDir!=null)bytes+=Math.max(0,new File(a.sourceDir).length());if(a.splitSourceDirs!=null)for(String s:a.splitSourceDirs)bytes+=Math.max(0,new File(s).length());}}catch(Exception ignored){}return new long[]{count,bytes};}
    private List<UsbCloneProtocol.Category> usbInventory()throws Exception{
        List<UsbCloneProtocol.Category> out=new ArrayList<>();String[] ids={"photos","videos","audio","files","apps","contacts","calls","sms"};
        for(String id:ids){checkCancel();try{long[] stat;if("photos".equals(id)||"videos".equals(id)||"audio".equals(id))stat=usbMediaStat(id);else if("files".equals(id))stat=usbFilesStat();else if("apps".equals(id))stat=usbAppsStat();else{PersonalRecords.Result r=PersonalRecords.load(this,id,()->checkCancel());stat=new long[]{r.rows.size(),-1};}out.add(new UsbCloneProtocol.Category(id,(int)Math.min(Integer.MAX_VALUE,stat[0]),stat[1]));}catch(SecurityException e){out.add(new UsbCloneProtocol.Category(id,0,-1));}}
        return out;
    }
    private List<Item> usbSharedFiles()throws Exception{
        List<Item> out=new ArrayList<>();Uri collection=MediaStore.Files.getContentUri("external");String pathColumn=Build.VERSION.SDK_INT>=29?MediaStore.MediaColumns.RELATIVE_PATH:MediaStore.MediaColumns.DATA;
        try(Cursor c=getContentResolver().query(collection,new String[]{MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.MIME_TYPE,MediaStore.MediaColumns.SIZE,pathColumn,MediaStore.MediaColumns.DATE_MODIFIED},null,null,MediaStore.MediaColumns.DATE_MODIFIED+" DESC")){
            while(c!=null&&c.moveToNext()){checkCancel();String name=c.isNull(1)?"":c.getString(1),mime=c.isNull(2)?"application/octet-stream":c.getString(2),path=c.isNull(4)?"":c.getString(4);if(!usbSharedFileCandidate(name,mime,path))continue;
                Item i=new Item(ContentUris.withAppendedId(collection,c.getLong(0)),safeName(name),validMime(mime),c.isNull(3)?-1:c.getLong(3));
                if(Build.VERSION.SDK_INT<29&&path!=null){int slash=path.lastIndexOf('/');path=slash>0?path.substring(0,slash+1):"";String ext=Environment.getExternalStorageDirectory().getAbsolutePath()+"/";if(path.startsWith(ext))path=path.substring(ext.length());}
                i.relativePath=safeRelativePath(path);if(!c.isNull(5))i.modified=c.getLong(5)*1000L;out.add(i);if(out.size()>=MAX_FILES)break;
            }
        }return out;
    }
    private List<Item> usbExportApps()throws Exception{
        List<Item> out=new ArrayList<>();for(ApplicationInfo old:getPackageManager().getInstalledApplications(0)){checkCancel();if(old.packageName.equals(getPackageName())||(old.flags&ApplicationInfo.FLAG_SYSTEM)!=0)continue;File bundle=null;
            try{PackageInfo before=getPackageManager().getPackageInfo(old.packageName,0);ApplicationInfo app=before.applicationInfo;List<File> parts=new ArrayList<>();parts.add(new File(app.sourceDir));if(app.splitSourceDirs!=null)for(String p:app.splitSourceDirs)parts.add(new File(p));bundle=File.createTempFile("usb-app-",".rbapp",getCacheDir());AppBundle.write(parts,bundle);PackageInfo after=getPackageManager().getPackageInfo(app.packageName,0);if(before.lastUpdateTime!=after.lastUpdateTime||before.versionCode!=after.versionCode)throw new IOException("App updated during export");usbPreparedTemps.add(bundle);String label=safeName(getPackageManager().getApplicationLabel(app).toString());out.add(new Item(Uri.fromFile(bundle),label+".rbapp",AppBundle.MIME,bundle.length()));}
            catch(Exception e){if(bundle!=null&&!usbPreparedTemps.contains(bundle))bundle.delete();}
        }return out;
    }
    private Item usbExportRecords(String kind)throws Exception{
        PersonalRecords.Result r=PersonalRecords.load(this,kind,()->checkCancel());if(r.rows.isEmpty())return null;File file=PersonalRecords.export(this,kind,r.rows,()->checkCancel());usbPreparedTemps.add(file);String name="contacts".equals(kind)?"contacts-all.vcf":kind+"-all-backup.json";String mime="contacts".equals(kind)?"text/x-vcard":"application/json";return new Item(Uri.fromFile(file),name,mime,file.length());
    }
    private List<Item> usbPrepareItems(Set<String> selected)throws Exception{
        usbCleanupPrepared();List<Item> items=new ArrayList<>();
        for(String id:selected){checkCancel();tell("ئامادەکردنی "+usbCategoryName(id)+"…");if("photos".equals(id)||"videos".equals(id)||"audio".equals(id))items.addAll(media(id));else if("files".equals(id))items.addAll(usbSharedFiles());else if("apps".equals(id))items.addAll(usbExportApps());else if(isRecords(id)){Item x=usbExportRecords(id);if(x!=null)items.add(x);}if(items.size()>MAX_FILES)throw new IOException("TOO_MANY");}
        return items;
    }
    private void usbCleanupPrepared(){for(File f:new ArrayList<>(usbPreparedTemps))try{f.delete();}catch(Exception ignored){}usbPreparedTemps.clear();}
    private Set<String> chooseUsbControllerCategories(List<UsbCloneProtocol.Category> categories)throws Exception{
        CountDownLatch latch=new CountDownLatch(1);approval=latch;LinkedHashSet<String> chosen=new LinkedHashSet<>();boolean[] accepted={false};
        runOnUiThread(()->{if(isDestroyed()||cancelled){latch.countDown();return;}List<UsbCloneProtocol.Category> visible=new ArrayList<>();for(UsbCloneProtocol.Category c:categories)if(c.count>0)visible.add(c);if(visible.isEmpty()){latch.countDown();return;}String[] labels=new String[visible.size()];boolean[] checks=new boolean[visible.size()];
            for(int n=0;n<visible.size();n++){UsbCloneProtocol.Category c=visible.get(n);checks[n]=true;chosen.add(c.id);labels[n]=usbCategoryName(c.id)+"   •   "+c.count+"   •   "+(c.bytes<0?"—":TransferStats.size(c.bytes));}
            AlertDialog dialog=new AlertDialog.Builder(UiText.context(this)).setTitle("لە مۆبایلی کۆن چی وەربگریت؟").setMultiChoiceItems(labels,checks,(d,w,on)->{String id=visible.get(w).id;if(on)chosen.add(id);else chosen.remove(id);}).setPositiveButton("وەرگرتن",null).setNegativeButton(UiText.t(29),(d,w)->latch.countDown()).setCancelable(false).create();approvalDialog=dialog;
            dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(chosen.isEmpty()){toast("لانیکەم یەک بەش هەڵبژێرە");return;}accepted[0]=true;dialog.dismiss();latch.countDown();}));dialog.show();
        });
        latch.await();approval=null;approvalDialog=null;if(cancelled)throw new IOException("Cancelled");if(!accepted[0])return Collections.emptySet();return new LinkedHashSet<>(chosen);
    }
    private boolean confirmUsbSourceRequest(Set<String> selected,List<UsbCloneProtocol.Category> inventory)throws InterruptedException{
        CountDownLatch latch=new CountDownLatch(1);approval=latch;boolean[] yes={false};StringBuilder list=new StringBuilder();long bytes=0;int count=0;boolean unknown=false;
        for(UsbCloneProtocol.Category c:inventory)if(selected.contains(c.id)){list.append("• ").append(usbCategoryName(c.id)).append(" — ").append(c.count).append("\n");count+=c.count;if(c.bytes<0)unknown=true;else bytes+=c.bytes;}
        final String message=list+"\n"+count+" فایل/تۆمار • "+TransferStats.size(bytes)+(unknown?" +":"")+"\n\nمۆبایلی تازە داوای ئەم داتایانە دەکات.";
        runOnUiThread(()->{if(isDestroyed()||cancelled){latch.countDown();return;}approvalDialog=new AlertDialog.Builder(UiText.context(this)).setTitle("ڕەزامەندی بۆ ناردن").setMessage(message).setPositiveButton("ڕێگە دەدەم",(d,w)->{yes[0]=true;latch.countDown();}).setNegativeButton("ڕەتکردنەوە",(d,w)->latch.countDown()).setCancelable(false).create();approvalDialog.show();});
        latch.await();approval=null;approvalDialog=null;return yes[0]&&!cancelled;
    }
    private void usbControllerSession(SecureChannel channel)throws Exception{
        usbControllerAuthorized=false;channel.write(UsbCloneProtocol.command(UsbCloneProtocol.INVENTORY_REQUEST));List<UsbCloneProtocol.Category> inventory=UsbCloneProtocol.decodeInventory(channel.read());
        LinkedHashSet<String> selected=new LinkedHashSet<>();
        if(usbAutoResume&&!usbControllerSelectionCache.isEmpty()){
            HashSet<String> available=new HashSet<>();for(UsbCloneProtocol.Category c:inventory)if(c.count>0)available.add(c.id);
            for(String id:usbControllerSelectionCache)if(available.contains(id))selected.add(id);
            if(selected.isEmpty())throw new IOException("USB_SOURCE_CHANGED");
        }else{selected.addAll(chooseUsbControllerCategories(inventory));usbControllerSelectionCache.clear();usbControllerSelectionCache.addAll(selected);}
        channel.write(UsbCloneProtocol.encodeSelection(selected));if(selected.isEmpty())throw new IOException("DECLINED");
        runOnUiThread(()->{if(!isDestroyed()&&!cancelled){page("selectionWaiting","چاوەڕێی ڕەزامەندی","لە مۆبایلی کۆن «ڕێگە دەدەم» هەڵبژێرە",2);button(UiText.t(111),false,()->cancel());}});
        for(;;){byte[] reply=channel.read();if(UsbCloneProtocol.is(reply,UsbCloneProtocol.PREPARING)){tell("مۆبایلی کۆن داتاکان ئامادە دەکات…");continue;}if(UsbCloneProtocol.is(reply,UsbCloneProtocol.DECLINED))throw new IOException("DECLINED");if(UsbCloneProtocol.is(reply,UsbCloneProtocol.ERROR))throw new IOException("USB_SOURCE_PREPARE");if(!UsbCloneProtocol.is(reply,UsbCloneProtocol.ACCEPTED))throw new IOException("USB_PROTOCOL");break;}
        usbControllerAuthorized=true;try{receiveFiles(channel);}finally{usbControllerAuthorized=false;}
    }
    private void usbSourceSession(SecureChannel channel)throws Exception{
        byte[] request=channel.read();if(!UsbCloneProtocol.is(request,UsbCloneProtocol.INVENTORY_REQUEST))throw new IOException("USB_PROTOCOL");tell("لیستی داتاکان دەنێردرێت…");List<UsbCloneProtocol.Category> inventory=usbInventory();channel.write(UsbCloneProtocol.encodeInventory(inventory));LinkedHashSet<String> selected=UsbCloneProtocol.decodeSelection(channel.read());if(selected.isEmpty()){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.DECLINED));throw new IOException("DECLINED");}
        Set<String> allowed=new HashSet<>();for(UsbCloneProtocol.Category c:inventory)allowed.add(c.id);selected.retainAll(allowed);if(selected.isEmpty()){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.DECLINED));throw new IOException("DECLINED");}
        boolean rememberedConsent=usbAutoResume&&!usbSourceConsentCache.isEmpty()&&usbSourceConsentCache.equals(selected);
        if(!rememberedConsent&&!confirmUsbSourceRequest(selected,inventory)){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.DECLINED));throw new IOException("DECLINED");}
        if(!rememberedConsent){usbSourceConsentCache.clear();usbSourceConsentCache.addAll(selected);}
        runOnUiThread(()->{if(!isDestroyed()&&!cancelled){page("usbPreparing",usbAutoResume?"گواستنەوە خۆکارانە بەردەوام دەبێتەوە":"ئامادەکردنی داتا",usbAutoResume?"لە هەمان شوێنی پچڕان دەست پێدەکاتەوە":"ڕەزامەندی درا • داتاکان بۆ مۆبایلی تازە ئامادە دەکرێن",2);ProgressBar p=new ProgressBar(this);body.addView(p);}});
        channel.write(UsbCloneProtocol.command(UsbCloneProtocol.PREPARING));List<Item> items;
        if(usbAutoResume&&!usbRetryItems.isEmpty())items=new ArrayList<>(usbRetryItems);
        else try{items=usbPrepareItems(selected);usbRetryItems=new ArrayList<>(items);}catch(Exception e){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.ERROR));throw e;}
        if(items.isEmpty()){channel.write(UsbCloneProtocol.command(UsbCloneProtocol.ERROR));throw new IOException("USB_SOURCE_PREPARE");}
        channel.write(UsbCloneProtocol.command(UsbCloneProtocol.ACCEPTED));runOnUiThread(()->{if(!isDestroyed()&&!cancelled)transferPage(true);});sendFiles(channel,items);
    }
    private void qrPage(String payload){
        page("qr",UiText.t(105),UiText.t(106),1);
        try{
            int side=660;BitMatrix matrix=new QRCodeWriter().encode(payload,BarcodeFormat.QR_CODE,side,side);int[] pixels=new int[side*side];for(int y=0;y<side;y++)for(int x=0;x<side;x++)pixels[y*side+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
            Bitmap bitmap=Bitmap.createBitmap(pixels,side,side,Bitmap.Config.ARGB_8888);ImageView qr=new ImageView(this);qr.setImageBitmap(bitmap);qr.setContentDescription(UiText.t(107));qr.setScaleType(ImageView.ScaleType.FIT_CENTER);qr.setBackground(box(Color.WHITE,24));qr.setPadding(dp(8),dp(8),dp(8),dp(8));
            int width=Math.min(dp(280),getResources().getDisplayMetrics().widthPixels-dp(48));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(width,width);lp.gravity=Gravity.CENTER;body.addView(qr,lp);
        }catch(Exception e){throw new IllegalStateException(e);}
        gap(22);status=text(UiText.t(108),17,BLUE,true);status.setGravity(Gravity.CENTER);
        Switch mode=new Switch(this);mode.setText(UiText.t(109));mode.setChecked(fastMode);body.addView(mode);
        mode.setOnCheckedChangeListener((v,on)->{fastMode=on;getPreferences(0).edit().putBoolean("fast5",on).apply();restartAfterStop=true;cancel();});
        note(hotspot.hostInfo()+UiText.t(110));
        button(UiText.t(111),false,()->cancel());
        TextView copy=text(UiText.t(112),13,MUTED,false);copy.setGravity(Gravity.CENTER);copy.setPadding(0,dp(16),0,0);
        copy.setOnClickListener(v->{android.content.ClipboardManager c=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);ClipData clip=ClipData.newPlainText("rebaritclone pairing",payload);if(Build.VERSION.SDK_INT>=33){PersistableBundle extras=new PersistableBundle();extras.putBoolean("android.content.extra.IS_SENSITIVE",true);clip.getDescription().setExtras(extras);}c.setPrimaryClip(clip);toast(UiText.t(113));});
    }
    private void transferPage(boolean sending){
        lastNotification=0;transferNotification(sending?UiText.t(114):UiText.t(115),-1,false);
        page("transfer",sending?UiText.t(114):UiText.t(115),UiText.t(116),3);

        gap(16);percentage=text(UiText.t(118),64,BLUE,true);percentage.setGravity(Gravity.CENTER);gap(20);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);progress.setProgressBackgroundTintList(ColorStateList.valueOf(0xffe0e4f1));progress.setProgressTintList(ColorStateList.valueOf(BLUE));body.addView(progress,new LinearLayout.LayoutParams(-1,dp(14)));gap(26);
        status=text(UiText.t(119),17,INK,true);status.setVisibility(View.GONE);details=summaryCard(UiText.t(120));details.setLineSpacing(dp(10),1);gap(24);
        button(UiText.t(121),false,()->new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(122)).setMessage(UiText.t(123)).setPositiveButton(UiText.t(111),(d,w)->cancel()).setNegativeButton(UiText.t(124),null).show());
    }
    private void resultPage(boolean success,String message,boolean receiving){
        transferNotification(success?UiText.t(125):UiText.t(126),0,true);
        page("result",success?UiText.t(125):UiText.t(126),message,0);gap(24);
        TextView icon=text(success?"✓":"!",80,success?0xff12a875:0xffd68122,true);icon.setGravity(Gravity.CENTER);gap(20);
        text(completed+UiText.t(127),22,INK,true).setGravity(Gravity.CENTER);note(UiText.t(128));
        if(transferStats!=null){
            summaryCard(UiText.t(253)+(transferStats.total(0)-transferStats.remaining(0,completed)));gap(8);
            summaryCard(UiText.t(254)+(transferStats.total(1)-transferStats.remaining(1,completed)));gap(8);
            long seconds=transferStarted==0?0:Math.max(0,(SystemClock.elapsedRealtime()-transferStarted)/1000);
            text(UiText.t(255)+String.format(Locale.US,"%02d:%02d:%02d",seconds/3600,(seconds/60)%60,seconds%60),20,INK,true);
        }
        if(receiving&&!receivedFiles.isEmpty())button(UiText.t(256),true,()->showReceivedFiles());
        if(receiving&&receivedRecordBackup)note(UiText.t(231));
        if(receiving&&!receivedApps.isEmpty())button(UiText.t(129),true,()->installReceivedApps());
        if(receiving&&completed>0){note(Build.VERSION.SDK_INT>=29?UiText.t(130):UiText.t(131));
            if(lastContact!=null)button(UiText.t(132),true,()->importContacts());
        }
        button(UiText.t(133),false,()->home());
        if(!success&&!usbMode)button(UiText.t(134),false,()->{if(receiving)beginHotspot();else connectPage();});
        if(!success&&!usbMode)note(UiText.t(135));
    }
    private void showReceivedFiles(){
        List<Item> files=new ArrayList<>(receivedFiles.values());String[] names=new String[files.size()];
        for(int n=0;n<files.size();n++)names[n]=files.get(n).name;
        new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(256)).setItems(names,(dialog,index)->{
            Item item=files.get(index);
            if(item.name.toLowerCase(Locale.ROOT).endsWith(".rbapp")||item.name.toLowerCase(Locale.ROOT).endsWith(".apk")){
                Intent install=new Intent(this,AppInstallActivity.class);install.putStringArrayListExtra("uris",new ArrayList<>(Collections.singletonList(item.uri.toString())));install.putStringArrayListExtra("names",new ArrayList<>(Collections.singletonList(item.name)));startActivity(install);return;
            }
            try{Intent view=new Intent(Intent.ACTION_VIEW).setDataAndType(item.uri,item.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);view.setClipData(ClipData.newRawUri("received file",item.uri));startActivity(view);}
            catch(ActivityNotFoundException|SecurityException e){alert(UiText.t(256),UiText.t(257));}
        }).setNegativeButton(UiText.t(29),null).show();
    }
    private void importContacts(){
        try{Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(lastContact,"text/x-vcard").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("contacts",lastContact));startActivity(i);}
        catch(Exception e){alert(UiText.t(132),UiText.t(136));}
    }
    private void tell(String value){runOnUiThread(()->{if(!isDestroyed()&&status!=null)status.setText(value);});}
    private void resetTotals(List<Item> items){if(transferStarted==0)transferStarted=SystemClock.elapsedRealtime();transferStats=stats(items);totalBytes=transferStats.totalBytes;finishedBytes=0;resumedBytes=0;totalKnown=transferStats.totalKnown;lastUpdate=0;startTime=SystemClock.elapsedRealtime();}
    private String eta(long remaining,double rate,long elapsed){
        if(remaining==0)return UiText.t(137);if(remaining<0||rate<=0||elapsed<3000)return UiText.t(138);
        long seconds=(long)Math.ceil(remaining/rate);return seconds>=3600?(seconds/3600)+UiText.t(139)+(seconds%3600/60)+UiText.t(140):seconds>=60?(seconds/60)+UiText.t(141)+(seconds%60)+UiText.t(142):seconds+UiText.t(142);
    }
    private void updateProgress(int index,int count,Item item,long bytes,boolean force){
        long now=SystemClock.elapsedRealtime();if(!force&&now-lastUpdate<200)return;lastUpdate=now;long moved=finishedBytes+bytes;
        int done=Math.min(count,index-1+(force?1:0));
        int percent=totalKnown&&totalBytes>0?(int)Math.min(done==count?1000:999,moved*1000.0/totalBytes):(int)(done*1000.0/Math.max(1,count));
        long remaining=transferStats.remainingBytes(moved),elapsed=now-startTime;
        double rate=Math.max(0,moved-resumedBytes)/Math.max(1,elapsed/1000.0);
        String all=TransferStats.size(totalBytes)+(totalKnown?"":UiText.t(143));
        String info=UiText.t(144)+all+UiText.t(145)+TransferStats.size(moved)+
            UiText.t(155)+String.format(Locale.US,"%.1f MB/s",rate/1000000.0)+UiText.t(156)+(remaining==0&&done<count?UiText.t(157):eta(remaining,rate,elapsed));
        final String display=info;
        runOnUiThread(()->{if(!screen.equals("transfer")||isDestroyed())return;transferNotification((percent/10)+"% • "+done+" / "+count,percent,false);progress.setProgress(percent);percentage.setText((percent/10)+UiText.t(158));status.setText(index+" / "+count+"  •  "+item.name);details.setText(display);});
    }
    interface Work{void run()throws Exception;}
    private void job(boolean receiving,Work work){
        if(busy)return;busy=true;cancelled=false;completed=0;lastContact=null;transferStats=null;transferStarted=0;hotspot.performance(!usbMode);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);startTransferService();
        markInterrupted(true);
        worker.execute(()->{boolean ok=false;String message;Exception failure=null;
            try{checkCancel();work.run();ok=true;message=UiText.t(159);}
            catch(Exception e){failure=e;message=cancelled?UiText.t(160):friendly(e);}
            finally{closeNetwork();stopTransferService();if(ok)markInterrupted(false);}
            final boolean success=ok;final String result=message;final Exception error=failure;
            runOnUiThread(()->{
                if(isDestroyed())return;stopLink();busy=false;
                if(success){
                    usbReconnectAttempts=0;if(usbMode){usbCleanupPrepared();clearUsbResumeState();}else clearUsbAttemptState();resultPage(true,result,receiving);if(receiving&&!receivedApps.isEmpty())installReceivedApps();
                }else if(usbMode&&!cancelled&&error!=null&&recoverableUsb(error)&&usbReconnectAttempts<USB_RETRY_LIMIT){
                    usbAutoResume=true;usbReconnectAttempts++;clearUsbAttemptState();toast("USB پچڕا • خۆکارانە لە هەمان شوێن بەردەوام دەبێتەوە…");main.postDelayed(()->startUsb(receiving),usbRetryDelay());
                }else if(restartAfterStop){restartAfterStop=false;beginHotspot();}
                else{if(usbMode){usbCleanupPrepared();clearUsbResumeState();}resultPage(false,result,receiving);}
            });
        });
    }
    private long usbRetryDelay(){return usbReconnectAttempts<=1?700L:usbReconnectAttempts==2?1500L:3000L;}
    private void clearUsbRecoveryPrefs(){getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().remove("sender_items").remove("receive").remove("interrupted").apply();}
    private void clearUsbAttemptState(){
        if(!usbMode)return;
        usbControllerAuthorized=false;
    }
    private void clearUsbResumeState(){
        usbCleanupPrepared();usbAutoResume=false;usbControllerAuthorized=false;usbReconnectAttempts=0;usbControllerSelectionCache.clear();usbSourceConsentCache.clear();usbRetryItems.clear();
        sendingId="";sendingManifest="";receivingId="";receivingManifest="";usbApprovedManifest="";
        for(ResumableFile.Entry e:resumeEntries.values())try{e.partial.delete();}catch(Exception ignored){}
        resumeEntries.clear();clearUsbRecoveryPrefs();
    }
    private void startTransferService(){try{Intent i=new Intent(this,TransferService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}catch(Exception ignored){}}
    private void stopTransferService(){try{stopService(new Intent(this,TransferService.class));}catch(Exception ignored){}}
    private void markInterrupted(boolean active){getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().putBoolean("interrupted",active).putLong("time",System.currentTimeMillis()).apply();}
    private boolean hadInterruptedTransfer(){return getSharedPreferences("transfer_recovery",MODE_PRIVATE).getBoolean("interrupted",false);}
    private void saveReceiveCheckpoint(){
        try{JSONObject j=new JSONObject();j.put("session",receivingId);j.put("manifest",receivingManifest);j.put("batch",receivingBatch==null?"":receivingBatch);JSONObject e=new JSONObject();for(Map.Entry<Integer,ResumableFile.Entry> x:resumeEntries.entrySet())e.put(String.valueOf(x.getKey()),x.getValue().partial.getAbsolutePath());j.put("entries",e);getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().putString("receive",j.toString()).apply();}catch(Exception ignored){}
    }
    private void restoreReceiveCheckpoint(String session,String sig){
        if(!resumeEntries.isEmpty())return;String raw=getSharedPreferences("transfer_recovery",MODE_PRIVATE).getString("receive","");if(raw.isEmpty())return;
        try{JSONObject j=new JSONObject(raw);if(!session.equals(j.optString("session"))||!sig.equals(j.optString("manifest")))return;receivingId=session;receivingManifest=sig;receivingBatch=j.optString("batch",Long.toString(System.currentTimeMillis()));JSONObject e=j.optJSONObject("entries");if(e!=null){Iterator<String> keys=e.keys();while(keys.hasNext()){String k=keys.next();File f=new File(e.optString(k));if(f.isFile())resumeEntries.put(Integer.parseInt(k),new ResumableFile.Entry(f));}}}catch(Exception ignored){}
    }
    private void saveSenderCheckpoint(List<Item> items){
        try{org.json.JSONArray a=new org.json.JSONArray();for(Item i:items){JSONObject o=new JSONObject();o.put("uri",i.uri==null?"":i.uri.toString());o.put("name",i.name);o.put("mime",i.mime);o.put("size",i.size);o.put("path",i.relativePath);o.put("modified",i.modified);o.put("taken",i.taken);a.put(o);}getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().putString("sender_items",a.toString()).apply();}catch(Exception ignored){}
    }
    private void restoreSenderCheckpoint(){
        if(!hadInterruptedTransfer()||!selection.isEmpty())return;String raw=getSharedPreferences("transfer_recovery",MODE_PRIVATE).getString("sender_items","");if(raw.isEmpty())return;
        try{org.json.JSONArray a=new org.json.JSONArray(raw);for(int n=0;n<a.length();n++){JSONObject o=a.getJSONObject(n);String u=o.optString("uri");if(u.isEmpty())continue;Item i=new Item(Uri.parse(u),o.optString("name"),o.optString("mime"),o.optLong("size",-1));i.relativePath=o.optString("path","");i.modified=o.optLong("modified",-1);i.taken=o.optLong("taken",-1);selection.add(i);}if(!selection.isEmpty())toast("گواستنەوەی پێشوو دۆزرایەوە • دەتوانیت بەردەوام بیت");}catch(Exception ignored){}
    }
    private void clearSenderCheckpoint(){getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().remove("sender_items").apply();}
    private void clearReceiveCheckpoint(){getSharedPreferences("transfer_recovery",MODE_PRIVATE).edit().remove("receive").apply();}
    private String friendly(Exception e){
        if("SOURCE_CHANGED".equals(e.getMessage())||"USB_SOURCE_CHANGED".equals(e.getMessage()))return UiText.t(161);
        if(e instanceof SecurityException)return UiText.t(162);
        if("TOO_MANY".equals(e.getMessage()))return UiText.t(163);
        if("DECLINED".equals(e.getMessage()))return UiText.t(164);
        if(usbMode)return UiText.t(165);
        if(e instanceof java.net.SocketTimeoutException)return UiText.t(166);
        if(e instanceof java.net.ConnectException||"CONNECT".equals(e.getMessage()))return UiText.t(167);
        if("PAIR".equals(e.getMessage()))return UiText.t(168);
        if(e instanceof EOFException||e instanceof java.net.SocketException)return UiText.t(169);
        return UiText.t(170);
    }
    private void cancel(){cancelled=true;closeNetwork();CountDownLatch a=approval;if(a!=null)a.countDown();if(approvalDialog!=null)approvalDialog.dismiss();tell(UiText.t(171));}
    private void closeNetwork(){if(usb!=null)usb.closeStreams();try{if(socket!=null)socket.close();}catch(Exception ignored){}try{if(listener!=null)listener.close();}catch(Exception ignored){}}
    private void checkCancel()throws IOException{if(cancelled||Thread.currentThread().isInterrupted())throw new IOException("Cancelled");}
    private void expect(SecureChannel c,int expected)throws Exception{byte[] p=c.read();if(p.length!=1||p[0]!=expected)throw new IOException("DECLINED");}
    private void tuneTransferSocket(Socket s)throws SocketException{
        s.setKeepAlive(true);s.setTcpNoDelay(true);s.setSendBufferSize(4194304);s.setReceiveBufferSize(4194304);s.setSoTimeout(300000);
    }
    private static boolean recoverableNetwork(Exception e){return e instanceof EOFException||e instanceof SocketException||e instanceof SocketTimeoutException||e instanceof ConnectException||"CONNECT".equals(e.getMessage());}
    private static boolean recoverableUsb(Exception e){
        String m=e.getMessage();
        if("DECLINED".equals(m)||"TOO_MANY".equals(m)||"Not enough storage".equals(m)||"USB_SOURCE_PREPARE".equals(m)||"USB_PROTOCOL".equals(m)||"USB_ROLE".equals(m))return false;
        return e instanceof IOException;
    }
    private void reconnectPause(int attempt)throws Exception{tell("پەیوەندی پچڕا • خۆکارانە بەردەوام دەبێتەوە…");long ms=Math.min(6000,800L*(attempt+1));for(long n=0;n<ms;n+=100){checkCancel();Thread.sleep(100);}}
    private void send(Pairing peer){
        if(busy)return;usbMode=false;
        transferPage(true);List<Item> items=new ArrayList<>(selection);saveSenderCheckpoint(items);
        job(false,()->{
            for(int attempt=0;;attempt++)try{
            if(items.isEmpty()||items.size()>MAX_FILES)throw new IOException("TOO_MANY");SecureChannel channel=null;
            for(String host:peer.hosts){
                checkCancel();try{socket=transferNetwork.getSocketFactory().createSocket();tuneTransferSocket(socket);socket.setSoTimeout(15000);socket.connect(new InetSocketAddress(host,PORT),8000);checkCancel();channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),peer.key,false);socket.setSoTimeout(300000);break;}
                catch(Exception e){try{socket.close();}catch(Exception ignored){}if(cancelled)throw e;}
            }
            if(channel==null)throw new IOException("CONNECT");
            sendFiles(channel,items);break;
            }catch(IOException e){if(cancelled||attempt>=6||!recoverableNetwork(e))throw e;
                try{if(socket!=null)socket.close();}catch(Exception ignored){}reconnectPause(attempt);
            }
        });
    }
    private void sendFiles(SecureChannel channel,List<Item> items)throws Exception{
            if(!usbMode)saveSenderCheckpoint(items);vipTransferStarted=SystemClock.elapsedRealtime();
            if(items.isEmpty()||items.size()>MAX_FILES)throw new IOException("TOO_MANY");
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(buffer);String sig=manifest(items,true);if(sendingId.isEmpty()||!sig.equals(sendingManifest)){sendingId=UUID.randomUUID().toString();sendingManifest=sig;}
            out.writeUTF(sendingId);out.writeInt(items.size());channel.write(buffer.toByteArray());
            for(Item item:items){checkCancel();enrichTransferMeta(item);buffer.reset();out.writeUTF(safeName(item.name));out.writeUTF(validMime(item.mime));out.writeLong(item.size);out.writeUTF(safeRelativePath(item.relativePath));out.writeLong(item.modified);out.writeLong(item.taken);channel.write(buffer.toByteArray());}
            tell(UiText.t(173));expect(channel,1);resetTotals(items);completed=0;int index=0;
            for(Item item:items){checkCancel();index++;final int position=index;final boolean[] first={true};long bytes;
                try(InputStream in=new BufferedInputStream(openSource(item.uri),1048576)){
                    if(in==null)throw new IOException("Source unavailable");
                    bytes=ResumableFile.send(channel,in,item.size,usbMode?524288:262144,n->{checkCancel();if(n<0)return;if(first[0]){resumedBytes+=n;first[0]=false;}updateProgress(position,items.size(),item,n,false);});
                }
                completed++;updateProgress(index,items.size(),item,bytes,true);finishedBytes+=bytes;
             }expect(channel,3);channel.write(new byte[]{4});if(!usbMode){clearSenderCheckpoint();markInterrupted(false);}vipHistory("Sent • "+items.size()+" files • "+TransferStats.size(finishedBytes));sendingId="";sendingManifest="";
    }

    private InputStream openSource(Uri uri)throws Exception{return "file".equals(uri.getScheme())?new FileInputStream(new File(uri.getPath())):getContentResolver().openInputStream(uri);}
    private void receive(){
        if(busy)return;usbMode=false;
        List<String> hosts=wifiAddresses();if(hosts.isEmpty()){alert(UiText.t(174),UiText.t(175));return;}
        String code=SecureChannel.newCode();pairText=hotspotSsid.isEmpty()?Pairing.encode(hosts,code):Pairing.encodeHotspot(hosts,code,hotspotSsid,hotspotPassword);byte[] key=SecureChannel.parseCode(code);
        page("waiting",UiText.t(176),UiText.t(45),1);
        job(true,()->{
            listener=new ServerSocket();checkCancel();listener.setReuseAddress(true);listener.bind(new InetSocketAddress(PORT));listener.setSoTimeout(1000);
            runOnUiThread(()->{if(!isDestroyed()&&!cancelled)qrPage(pairText);});
            for(;;){
            SecureChannel channel=null;long deadline=SystemClock.elapsedRealtime()+600000;
            while(channel==null){checkCancel();if(SystemClock.elapsedRealtime()>deadline)throw new SocketTimeoutException();
                try{socket=listener.accept();tuneTransferSocket(socket);socket.setSoTimeout(15000);channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,true);}
                catch(SocketTimeoutException e){if(socket!=null)try{socket.close();}catch(Exception ignored){}}
                catch(Exception e){checkCancel();if(socket!=null)try{socket.close();}catch(Exception ignored){}}
            }
            socket.setSoTimeout(300000);checkCancel();
            runOnUiThread(()->{if(!isDestroyed()&&!cancelled){page("selectionWaiting",UiText.t(279),UiText.t(280),2);button(UiText.t(111),false,()->cancel());}});
            try{receiveFiles(channel);break;}
            catch(IOException e){if(cancelled||listener.isClosed()||!(e instanceof EOFException||e instanceof SocketException||e instanceof SocketTimeoutException))throw e;
                try{socket.close();}catch(Exception ignored){}tell("پەیوەندی پچڕا • چاوەڕێی پەیوەندیی دووبارە…");Thread.sleep(700);
            }
            }
        });
    }
    private void receiveFiles(SecureChannel channel)throws Exception{
            DataInputStream header=new DataInputStream(new ByteArrayInputStream(channel.read()));String session=header.readUTF();if(!session.matches("[a-f0-9-]{36}"))throw new IOException("Invalid session");int count=header.readInt();if(count<1||count>MAX_FILES||header.available()!=0)throw new IOException("TOO_MANY");
            List<Item> items=new ArrayList<>();
            for(int n=0;n<count;n++){checkCancel();DataInputStream meta=new DataInputStream(new ByteArrayInputStream(channel.read()));Item i=new Item();i.name=safeName(meta.readUTF());i.mime=validMime(meta.readUTF());i.size=meta.readLong();i.relativePath=safeRelativePath(meta.readUTF());i.modified=meta.readLong();i.taken=meta.readLong();if(i.size< -1||meta.available()!=0)throw new IOException("Invalid metadata");items.add(i);}
            if(!enoughStorage(items)){channel.write(new byte[]{0});throw new IOException("Not enough storage");}
            String sig=manifest(items,false);
            restoreReceiveCheckpoint(session,sig);
            boolean alreadyApproved=usbMode?(usbControllerAuthorized||sig.equals(usbApprovedManifest)):(session.equals(receivingId)&&sig.equals(receivingManifest));
            if(!alreadyApproved&&!confirm(items)){channel.write(new byte[]{0});throw new IOException("DECLINED");}
            boolean usbRetrySame=usbMode&&alreadyApproved;
            if(usbMode)usbApprovedManifest=sig;
            checkCancel();
            if(!session.equals(receivingId)||!sig.equals(receivingManifest)){
                if(usbMode&&usbAutoResume&&!receivingId.isEmpty())throw new IOException("USB_SOURCE_CHANGED");
                for(ResumableFile.Entry e:resumeEntries.values())try{e.partial.delete();}catch(Exception ignored){}resumeEntries.clear();clearReceiveCheckpoint();
                if(!usbRetrySame){receivedFiles.clear();receivedApps.clear();receivedRecordBackup=false;receivingBatch=Long.toString(System.currentTimeMillis());receivingLegacy=null;}
                receivingId=session;receivingManifest=sig;if(receivingBatch==null||receivingBatch.isEmpty())receivingBatch=Long.toString(System.currentTimeMillis());
            }
            if(Build.VERSION.SDK_INT<29&&receivingLegacy==null){Uri parent=DocumentsContract.buildDocumentUriUsingTree(folder,DocumentsContract.getTreeDocumentId(folder));receivingLegacy=DocumentsContract.createDocument(getContentResolver(),parent,DocumentsContract.Document.MIME_TYPE_DIR,"rebaritclone-"+receivingBatch);if(receivingLegacy==null)throw new IOException("Folder unavailable");}
            channel.write(new byte[]{1});resetTotals(items);completed=0;runOnUiThread(()->{if(!isDestroyed())transferPage(false);});int index=0;
            for(Item item:items){
                checkCancel();index++;final int position=index;long bytes;
                final boolean[] first={true};ResumableFile.Entry entry=resumeEntries.get(index);
                if(entry==null){File cacheRoot=getExternalCacheDir()!=null?getExternalCacheDir():getCacheDir();entry=new ResumableFile.Entry(File.createTempFile("resume-",".part",cacheRoot));resumeEntries.put(index,entry);saveReceiveCheckpoint();}
                bytes=ResumableFile.receive(channel,entry,item.size,n->{checkCancel();if(n<0)return;if(first[0]){resumedBytes+=n;first[0]=false;}updateProgress(position,count,item,n,false);},partial->{
                    SavedFile file=new SavedFile(item,receivingBatch,receivingLegacy);
                    try{
                        if(file.duplicate){rememberReceived(file,item);return;}
                        try(InputStream in=new BufferedInputStream(new FileInputStream(partial));OutputStream out=new BufferedOutputStream(getContentResolver().openOutputStream(file.uri,"w"),1048576)){
                            if(out==null)throw new IOException("Storage unavailable");byte[] data=new byte[1048576];int n;while((n=in.read(data))!=-1){checkCancel();out.write(data,0,n);}
                        }
                        file.commit(item.name);rememberReceived(file,item);
                    }finally{if(!file.committed)file.discard();}
                });
                completed++;updateProgress(index,count,item,bytes,true);finishedBytes+=bytes;
            }
            channel.write(new byte[]{3});expect(channel,4);clearReceiveCheckpoint();markInterrupted(false);vipHistory("Received • "+items.size()+" files • "+TransferStats.size(finishedBytes));
    }

    private void rememberReceived(SavedFile file,Item item){
        Item saved=new Item(file.uri,item.name,item.mime,item.size);saved.relativePath=item.relativePath;saved.modified=item.modified;saved.taken=item.taken;receivedFiles.put(file.uri.toString(),saved);
        if(item.name.equals("calls-selected-backup.json")||item.name.equals("sms-selected-backup.json"))receivedRecordBackup=true;
        String lower=item.name.toLowerCase(Locale.ROOT);if(lower.endsWith(".rbapp")||lower.endsWith(".apk"))receivedApps.put(file.uri.toString(),item.name);if(lower.endsWith(".vcf"))lastContact=file.uri;
    }

    private Uri findSessionDuplicate(Item item){
        for(Map.Entry<String,Item> e:receivedFiles.entrySet()){Item old=e.getValue();if(old!=null&&Objects.equals(old.name,item.name)&&old.size==item.size&&Objects.equals(safeRelativePath(old.relativePath),safeRelativePath(item.relativePath)))try{return Uri.parse(e.getKey());}catch(Exception ignored){}}
        return null;
    }
    private Uri findDuplicate(Item item){
        Uri session=findSessionDuplicate(item);if(session!=null)return session;
        if(Build.VERSION.SDK_INT<29)return null;
        try{
            Uri collection=item.mime.startsWith("image/")?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:item.mime.startsWith("video/")?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:item.mime.startsWith("audio/")?MediaStore.Audio.Media.EXTERNAL_CONTENT_URI:MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String path=safeRelativePath(item.relativePath);
            try(Cursor c=getContentResolver().query(collection,new String[]{MediaStore.MediaColumns._ID},MediaStore.MediaColumns.DISPLAY_NAME+"=? AND "+MediaStore.MediaColumns.SIZE+"=? AND "+MediaStore.MediaColumns.RELATIVE_PATH+"=?",new String[]{item.name,String.valueOf(item.size),path},null)){
                if(c!=null&&c.moveToFirst())return ContentUris.withAppendedId(collection,c.getLong(0));
            }
        }catch(Exception ignored){}
        return null;
    }
    private class SavedFile{
        Uri uri;boolean committed,duplicate;final Item item;
        SavedFile(Item item,String batch,Uri legacy)throws Exception{this.item=item;Uri existing=findDuplicate(item);if(existing!=null){uri=existing;duplicate=true;committed=true;return;}
            if(Build.VERSION.SDK_INT>=29){Uri collection;String directory;
                if(item.mime.startsWith("image/")){collection=MediaStore.Images.Media.EXTERNAL_CONTENT_URI;directory=Environment.DIRECTORY_PICTURES;}
                else if(item.mime.startsWith("video/")){collection=MediaStore.Video.Media.EXTERNAL_CONTENT_URI;directory=Environment.DIRECTORY_MOVIES;}
                else if(item.mime.startsWith("audio/")){collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;directory=Environment.DIRECTORY_MUSIC;}
                else{collection=MediaStore.Downloads.EXTERNAL_CONTENT_URI;directory=Environment.DIRECTORY_DOWNLOADS;}
                ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,item.name);values.put(MediaStore.MediaColumns.MIME_TYPE,item.mime);
                String original=safeRelativePath(item.relativePath);values.put(MediaStore.MediaColumns.RELATIVE_PATH,original.isEmpty()?directory+"/":original);
                if(item.modified>0)values.put(MediaStore.MediaColumns.DATE_MODIFIED,item.modified/1000L);
                if(item.taken>0&&(item.mime.startsWith("image/")||item.mime.startsWith("video/")))values.put(MediaStore.Images.ImageColumns.DATE_TAKEN,item.taken);
                values.put(MediaStore.MediaColumns.IS_PENDING,1);uri=getContentResolver().insert(collection,values);
            }else uri=DocumentsContract.createDocument(getContentResolver(),legacy,"application/octet-stream",item.name+".partial");
            if(uri==null)throw new IOException("Storage unavailable");
        }
        void commit(String name)throws Exception{
            if(Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.IS_PENDING,0);if(item.modified>0)values.put(MediaStore.MediaColumns.DATE_MODIFIED,item.modified/1000L);if(item.taken>0&&(item.mime.startsWith("image/")||item.mime.startsWith("video/")))values.put(MediaStore.Images.ImageColumns.DATE_TAKEN,item.taken);if(getContentResolver().update(uri,values,null,null)!=1)throw new IOException("Finalize failed");}
            else{Uri renamed=DocumentsContract.renameDocument(getContentResolver(),uri,name);if(renamed==null)throw new IOException("Finalize failed");uri=renamed;}
            committed=true;
        }
        void discard(){try{if(Build.VERSION.SDK_INT>=29)getContentResolver().delete(uri,null,null);else DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}
    }
    private boolean confirm(List<Item> items)throws InterruptedException{
        CountDownLatch latch=new CountDownLatch(1);approval=latch;boolean[] yes={false};
        runOnUiThread(()->{if(isDestroyed()||cancelled){latch.countDown();return;}
            Context themed=UiText.context(this);LinearLayout panel=new LinearLayout(themed);panel.setOrientation(LinearLayout.VERTICAL);panel.setGravity(Gravity.CENTER);panel.setPadding(dp(28),dp(30),dp(28),dp(24));panel.setLayoutDirection(UiText.direction());
            TextView icon=label("↓",54,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(box(BLUE,28));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(92),dp(92));ip.gravity=Gravity.CENTER_HORIZONTAL;panel.addView(icon,ip);
            TextView title=label("داتاکان دەنێردرێن",24,INK,true);title.setGravity(Gravity.CENTER);title.setPadding(0,dp(18),0,dp(22));panel.addView(title);
            Button receive=new Button(themed);receive.setText("↓  وەرگرتن");receive.setTextColor(Color.WHITE);receive.setTextSize(20);receive.setAllCaps(false);receive.setTypeface(null,Typeface.BOLD);receive.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),box(BLUE,20),null));panel.addView(receive,new LinearLayout.LayoutParams(-1,dp(72)));
            Space gap=new Space(themed);panel.addView(gap,new LinearLayout.LayoutParams(1,dp(12)));
            Button reject=new Button(themed);reject.setText("✕  ڕەتکردنەوە");reject.setTextColor(0xffc62828);reject.setTextSize(19);reject.setAllCaps(false);reject.setTypeface(null,Typeface.BOLD);reject.setBackground(new RippleDrawable(ColorStateList.valueOf(0x18c62828),box(0xffffeeee,20),null));panel.addView(reject,new LinearLayout.LayoutParams(-1,dp(72)));
            approvalDialog=new AlertDialog.Builder(themed).setView(panel).setCancelable(false).create();
            reject.setOnClickListener(v->{approvalDialog.dismiss();latch.countDown();});receive.setOnClickListener(v->{yes[0]=true;approvalDialog.dismiss();latch.countDown();});approvalDialog.show();
        });
        latch.await();approval=null;return yes[0]&&!cancelled;
    }

    private static String safeRelativePath(String path){
        if(path==null)return "";
        path=path.replace('\\','/').replaceAll("^/+","");
        StringBuilder out=new StringBuilder();
        for(String part:path.split("/")){
            part=safeName(part);
            if(part.isEmpty()||part.equals(".")||part.equals(".."))continue;
            if(out.length()>0)out.append('/');
            out.append(part);
        }
        return out.length()==0?"":out.append('/').toString();
    }
    private void enrichTransferMeta(Item item){
        if(item==null||item.uri==null)return;
        String[] projection=Build.VERSION.SDK_INT>=29?
            new String[]{MediaStore.MediaColumns.RELATIVE_PATH,MediaStore.MediaColumns.DATE_MODIFIED}:
            new String[]{MediaStore.MediaColumns.DATA,MediaStore.MediaColumns.DATE_MODIFIED};
        try(Cursor c=getContentResolver().query(item.uri,projection,null,null,null)){
            if(c!=null&&c.moveToFirst()){
                String path=c.isNull(0)?"":c.getString(0);
                if(Build.VERSION.SDK_INT<29&&path!=null){
                    int slash=path.lastIndexOf('/');path=slash>0?path.substring(0,slash+1):"";
                    String root=Environment.getExternalStorageDirectory().getAbsolutePath()+"/";
                    if(path.startsWith(root))path=path.substring(root.length());
                }
                item.relativePath=safeRelativePath(path);
                if(!c.isNull(1))item.modified=c.getLong(1)*1000L;
            }
        }catch(Exception ignored){}
        if(item.mime!=null&&(item.mime.startsWith("image/")||item.mime.startsWith("video/"))){
            try(Cursor c=getContentResolver().query(item.uri,new String[]{MediaStore.Images.ImageColumns.DATE_TAKEN},null,null,null)){
                if(c!=null&&c.moveToFirst()&&!c.isNull(0))item.taken=c.getLong(0);
            }catch(Exception ignored){}
        }
    }
    private static String safeName(String name){if(name==null)name="file";name=name.replaceAll("[\\p{Cntrl}/\\\\]","_");if(name.isEmpty()||name.equals(".")||name.equals(".."))name="file";return name.length()>160?name.substring(0,160):name;}
    private static String validMime(String mime){return mime!=null&&mime.length()<128&&mime.matches("[a-zA-Z0-9.+_-]+/[a-zA-Z0-9.+_-]+")?mime:"application/octet-stream";}
    private Item inspect(Uri uri){Item item=new Item(uri,"file",validMime(getContentResolver().getType(uri)),-1);try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){if(c!=null&&c.moveToFirst()){item.name=safeName(c.getString(0));if(!c.isNull(1))item.size=c.getLong(1);}}enrichTransferMeta(item);return item;}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==UNINSTALL_APP){
            String done=uninstallCurrentPackage;uninstallCurrentPackage=null;
            if(result==RESULT_OK&&done!=null){
                if(uninstallSelected!=null)uninstallSelected.remove(done);
                if(uninstallApps!=null)uninstallApps.removeIf(a->a.packageName.equals(done));
                if(uninstallShown!=null)uninstallShown.removeIf(a->a.packageName.equals(done));
                if(uninstallAdapter!=null)uninstallAdapter.notifyDataSetChanged();
                if(uninstallHeader!=null)uninstallHeader.run();
                launchNextUninstall();
            }else{
                uninstallQueue.clear();
                toast("سڕینەوە وەستاندرا؛ ئەپە دیاریکراوەکان هەر دیاریکراو دەمێننەوە");
            }
            return;
        }
        if(request==SETUP_SETTINGS){if(setupActive)permissionSummary();return;}
        if(request==WIFI_SETTINGS||request==LOCATION_SETTINGS){
            android.net.wifi.WifiManager wm=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if((request==WIFI_SETTINGS&&wm.isWifiEnabled())||(request==LOCATION_SETTINGS&&locationEnabled()))beginHotspot();else{receiverSetup();note(UiText.t(185));}return;
        }
        if(request==FOLDER&&result!=RESULT_OK){resumeFolder=false;if(resumeUsbFolder){resumeUsbFolder=false;usbReceiverSetup();}else receiverSetup();return;}
        if(result!=RESULT_OK||data==null)return;
        if(request==FOLDER&&data.getData()!=null){folder=data.getData();if(resumeUsbFolder){resumeUsbFolder=false;startUsb(true);}else if(resumeFolder){resumeFolder=false;beginHotspot();}else receiverSetup();}
        if(request==SCAN){usePair(data.getStringExtra("pairing"));}
        if(request==QR_IMAGE&&data.getData()!=null)decodeImage(data.getData());
        if(request==FILES){List<Uri> uris=new ArrayList<>();if(data.getClipData()!=null){for(int n=0;n<data.getClipData().getItemCount();n++)uris.add(data.getClipData().getItemAt(n).getUri());}else if(data.getData()!=null)uris.add(data.getData());
            busy=true;cancelled=false;loading(UiText.t(186));worker.execute(()->{try{List<Item> list=new ArrayList<>();for(Uri uri:uris){checkCancel();list.add(inspect(uri));}runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.put("files",list);categories();});}catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(187),friendly(e));});}});
        }
    }
    @Override public void onBackPressed(){if(setupActive){setupActive=false;setupWaiting=false;usbSourcePermissionFlow=false;home();return;}if(linking){stopLink();home();return;}if(busy){new AlertDialog.Builder(UiText.context(this)).setMessage(UiText.t(188)).setPositiveButton(UiText.t(189),(d,w)->cancel()).setNegativeButton(UiText.t(190),null).show();}else if(screen.equals("home"))super.onBackPressed();else if(screen.equals("connect"))home();else if(screen.equals("gallery")){closeGallery();fileHub();}else if(screen.equals("fileHub"))categories();else home();}
    @Override protected void onDestroy(){if(onlineUpdate!=null)onlineUpdate.destroy();closeGallery();NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null&&busy)manager.cancel(74);stopLink();cancel();usb.destroy();worker.shutdownNow();appMetaWorker.shutdownNow();super.onDestroy();}
    private static class Phones extends View{
        Paint p=new Paint(3);Phones(Context c){super(c);setContentDescription(UiText.t(191));}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float scale=Math.min(getWidth()/340f,getHeight()/180f);c.save();c.translate((getWidth()-340*scale)/2,(getHeight()-180*scale)/2);c.scale(scale,scale);
            p.setColor(0xffe8efff);c.drawCircle(170,90,84,p);phone(c,55,23,0xffd6e5ff);phone(c,207,8,0xff2563eb);
            p.setColor(BLUE);p.setStrokeWidth(5);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(147,85,193,85,p);c.drawLine(185,77,193,85,p);c.drawLine(185,93,193,85,p);
            p.setColor(0xff99baf9);c.drawLine(147,104,193,104,p);c.drawLine(147,104,155,96,p);c.drawLine(147,104,155,112,p);c.restore();}
        void phone(Canvas c,float x,float y,int color){p.setColor(color);c.drawRoundRect(x,y,x+77,y+140,14,14,p);p.setColor(Color.WHITE);c.drawRoundRect(x+7,y+8,x+70,y+131,10,10,p);p.setColor(INK);c.drawRoundRect(x+28,y+10,x+49,y+15,3,3,p);p.setColor(0xffeaf1ff);c.drawRoundRect(x+14,y+32,x+63,y+75,8,8,p);p.setColor(0xff93b7f6);c.drawRoundRect(x+14,y+86,x+53,y+92,3,3,p);p.setColor(0xffdbe6f8);c.drawRoundRect(x+14,y+100,x+61,y+106,3,3,p);}
    }
}
