package com.abdulla.clonephone;

import android.os.Bundle;
import java.lang.reflect.*;
import java.util.*;

/** Emulator-only visual fixtures. This source set is excluded from release APKs. */
public final class DesignPreviewActivity extends MainActivity {
    @Override public void onCreate(Bundle state){
        getSharedPreferences("permission_onboarding",0).edit().putBoolean("completed",true).commit();
        String language=getIntent().getStringExtra("language");UiText.select(this,language==null?"ckb":language);
        super.onCreate(state);
        try{
            String screen=getIntent().getStringExtra("screen");
            if("picker".equals(screen))invoke("openSendPicker",new Class<?>[]{});
            else if("scan".equals(screen))startActivity(new android.content.Intent(this,ScanActivity.class));
            else if("installer".equals(screen))startActivity(new android.content.Intent(this,InstallPreviewActivity.class));
            else if("roles".equals(screen))invoke("deviceRoles",new Class<?>[]{boolean.class},false);
            else if("usb".equals(screen))invoke("usbRoles",new Class<?>[]{});
            else if("selection".equals(screen)){
                List<UsbCloneProtocol.Category> categories=Arrays.asList(
                    new UsbCloneProtocol.Category("photos",1249,2400000000L),new UsbCloneProtocol.Category("videos",48,6800000000L),
                    new UsbCloneProtocol.Category("apps",3,320000000L),new UsbCloneProtocol.Category("audio",126,670000000L),
                    new UsbCloneProtocol.Category("documents",57,94000000L),new UsbCloneProtocol.Category("contacts",840,44000L));
                List<CloneAppPicker.App> apps=Arrays.asList(new CloneAppPicker.App("preview.one","Notes",80000000L),new CloneAppPicker.App("preview.two","Maps",120000000L),new CloneAppPicker.App("preview.three","Reader",120000000L));
                setContentView(new CloneSelectionView(this,categories,apps,new CloneSelectionView.Actions(){public void send(Set<String> c,Set<String> p){}public void back(){finish();}}));
            }else if("transfer".equals(screen)){
                invoke("transferPage",new Class<?>[]{boolean.class},true);
                Field field=MainActivity.class.getDeclaredField("transferDashboard");field.setAccessible(true);
                ((TransferDashboard)field.get(this)).update(624,"62.4%","218 / 1249  ·  IMG_2048.jpg","24.8 MB/s","02:14","6.4 GB","10.3 GB");
            }
        }catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    private void invoke(String name,Class<?>[] types,Object... args)throws ReflectiveOperationException{Method method=MainActivity.class.getDeclaredMethod(name,types);method.setAccessible(true);method.invoke(this,args);}
}
