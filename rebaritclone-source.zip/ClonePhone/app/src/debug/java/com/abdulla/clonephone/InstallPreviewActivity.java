package com.abdulla.clonephone;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.Arrays;

/** An idle installer fixture: no install session starts automatically. Debug builds only. */
public final class InstallPreviewActivity extends AppInstallActivity {
    @Override public void onCreate(Bundle state){
        getIntent().putStringArrayListExtra("uris",new ArrayList<>(Arrays.asList("content://preview/app")));
        getIntent().putStringArrayListExtra("names",new ArrayList<>(Arrays.asList("Reader.apk")));
        Bundle idle=new Bundle();idle.putInt("session",-1);super.onCreate(idle);
    }
}
