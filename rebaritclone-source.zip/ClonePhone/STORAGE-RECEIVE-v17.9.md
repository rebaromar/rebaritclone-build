# REBAR IT Clone 17.9 — receiving files from shared-storage folders

VersionCode 119 / versionName 17.9. Includes all five picker changes described in [17.8](PICKER-STORAGE-v17.8.md), with the same application ID and signing key.

Direct Storage browsing can select files beneath arbitrary phone folders. Android's scoped-storage MediaStore collections reject incompatible primary directories: an image from `Xom/Album/` cannot be inserted into the Images collection at that exact root. Receiver destination paths now retain supported public roots and map unsupported roots under the file type's public directory while preserving nested folders. For example, `Xom/Album/photo.jpg` is saved under `Pictures/Xom/Album/`, and a document from `Backups/Work/` under `Download/Backups/Work/`. WhatsApp shared media paths receive the same compatible mapping. Existing compatible roots such as DCIM, Pictures, Movies, Music, Download and Documents are retained as appropriate for the collection. Audio directory compatibility follows the Android version.

Duplicate lookup and file insertion use the same destination policy. Modification dates continue to accompany direct files. Android 9 and earlier retain their existing chosen-folder receive flow.

Validation: pure JVM destination policy tests cover arbitrary image and document roots, WhatsApp media, valid public roots, casing, empty paths, nested hierarchy, and version-specific audio directories. Android debug APK compilation and signing/version verification are performed before publication. Physical phone transfer and uninstall dialog verification remain to be completed on devices.
