# REBARIT Turbo Wi-Fi — v11.7
- Prefer existing 5 GHz Wi-Fi Direct path where supported; preserve automatic fallback.
- High-performance Wi-Fi lock for every non-USB transfer.
- Request 4 MiB TCP send/receive buffers.
- Use maximum 1 MiB authenticated transfer frames on Wi-Fi.
- SecureChannel keeps 512 KiB buffered streams.
- Existing direct streaming, resume, retry, AES-GCM, SHA-256 and MB/s/ETA remain.
- KEEP_SCREEN_ON is active while REBARIT CLONE is foreground, on sender and receiver.
- Android's permanent screen timeout setting is not modified.
