# v12.0
- Apps discovery runs off the UI thread and no blocking Loading page is opened.
- App labels are cached.
- App icons use an LRU cache and load asynchronously.
- Version + APK/split APK byte size load asynchronously.
- APK size uses sourceDir/splitSourceDirs file lengths, not APK content scans.
- Uninstalled-package discovery is deferred to background.
- Delete Apps grid also uses asynchronous icon/version/size metadata.
- New-phone USB page always shows a large explicit `↓ وەرگرتن بە USB` button.
- Existing USB/Wi-Fi, resume, VIP, original folder/date preservation remain.
