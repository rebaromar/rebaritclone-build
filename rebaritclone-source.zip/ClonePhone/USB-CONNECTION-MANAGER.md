# REBARIT CLONE USB Connection Manager

Flow: New phone = USB Host/Receiver; old phone = AOA Accessory/Sender.

The USB link owns permission, attach/detach observation, AOA negotiation, bulk endpoint discovery, and connection lifetime. The app UI starts transfer only after Listener.ready().

Design rules:
- one active USB session at a time
- react immediately to cable attach/detach
- tolerate slow AOA re-enumeration
- never treat unrelated storage/hub devices as transfer peers
- Android/OEM permission dialogs remain system-controlled
