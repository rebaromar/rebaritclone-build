# USB role flow — v11.6
1. Open USB High Speed from Home.
2. On receiver choose “New phone”.
3. On sender choose “Old phone”.
4. Connect with a USB-C data cable and approve Android USB permission.
5. After secure USB pairing, the old phone automatically opens the existing data/category screen.
6. Photos, videos, files, apps, audio, contacts, SMS/call backups and their available counts/sizes are scanned by the existing category engine.
7. Select desired data or Select All, then tap Send.
8. The new phone waits and receives using the v11.5 High-Speed USB engine.
