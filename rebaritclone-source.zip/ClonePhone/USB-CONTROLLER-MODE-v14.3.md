# REBARIT CLONE v14.3 — USB Controller Mode

- New phone is the logical Controller/Receiver.
- Old phone is Source/Sender and only grants or rejects one consent request.
- New phone receives a category inventory before transfer and selects what to request.
- USB protocol: INVENTORY_REQUEST → INVENTORY → SELECTION → consent → PREPARING → ACCEPTED → normal verified file transfer.
- USB transfer remains fresh/non-resumable; SHA-256 verification is preserved.
- Source asks for media/contacts/calls/SMS permissions before entering USB source mode.
- Generic shared files are limited to what normal Android MediaStore access allows; private app data remains outside normal app privileges.
