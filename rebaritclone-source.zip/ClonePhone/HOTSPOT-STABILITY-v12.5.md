# v12.5 Hotspot transfer stability
- TCP keep-alive + TCP_NODELAY enabled.
- Socket read timeout increased to 5 minutes after secure handshake.
- Connect timeout increased to 8 seconds.
- Wi-Fi transfer frame reduced to 256 KiB for better OEM hotspot stability; USB retains 1 MiB frames.
- Sender retries transient disconnects up to 6 times with bounded backoff.
- Receiver keeps its server/resume state alive and waits for reconnection.
- Existing ResumableFile protocol resumes from the authenticated partial byte offset, so completed bytes are not restarted.
- Hotspot NetworkCallback no longer destroys transfer state immediately on transient onLost; reconnect/resume is handled by the transfer engine.
- High-performance Wi-Fi lock and screen-on behavior remain active during the job.
