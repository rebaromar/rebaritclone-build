# Not Installed loading — 17.7

The previous Not Installed view walked and sorted every shared-storage file before filtering app packages. It also parsed APK archives on the UI thread whenever grid cells were rebuilt.

The view now queries Android's file index for package filenames, then discovers unindexed packages using a separate package-only scan. Results appear progressively, with Download and Bluetooth directories scanned first. Other files no longer undergo the package scan's expensive file/read/canonical-path/timestamp work. Package sort timestamps are cached. All-file discovery retains its separate cache and behavior.

The first discovered results can appear while the remaining scan runs; progress updates are throttled. Completed package results are cached within the picker. Tapping the selected segment no longer restarts the scan. Old loads and provider queries are canceled when switching tabs. Incomplete loads retain discovered results with a visible retry action.

APK icons load in a separate, bounded background pool and bitmap cache. Pending requests are deduplicated and view tags include file identity, size and modification time. Bundle files use a generic package icon rather than being parsed as APKs.

Validation: package-only scanning tests cover early batches, directory priority, all package extensions, cached metadata costs, cancellation and symlink confinement; Android debug APK build and signing verification. Physical phone timings have not been measured, so large storage collections can still take time to finish scanning.

VersionCode 117 / versionName 17.7; application ID and signing certificate are unchanged.
