# REBAR IT Clone 17.8 — Music, folders, storage and uninstall

VersionCode 118 / versionName 17.8. Application ID and signing key are unchanged.

Music uses a readable list with title, artist, duration, file size and album art when available. Photos, Videos, Music and document category results offer individual folder selection and Select All folders, while individual file selection remains available. Selecting a folder in a document category selects that category's matching documents.

Files document categories query indexed documents and then scan readable shared storage for the selected type. Matching supports Office extensions, templates/macros and indexed MIME types. Results appear progressively and completed categories are cached within the picker; partial results do not enable selecting an entire folder until discovery completes. Refresh reloads the category. The Files hub adds Storage for immediate folder browsing and recursive selection. Whole storage-folder selection commits only after a successful traversal; cancellation, read failures or exceeding the existing 10,000-item transfer limit leave the existing selection unchanged. Overlapping folders and aliases are deduplicated. Direct files preserve their shared-storage directory and modification date during transfer.

The My Files home card and standalone gallery implementation are removed. The sender's Files section now provides document and storage browsing.

Selecting eligible installed apps shows a trash icon in the picker header. It opens Android's uninstall confirmation for each selected app in sequence. Android approval is required for each app. Cancel stops the remaining queue and preserves unremoved selections. Successful removals update both the visible app list and the pending transfer selection. System apps and this app cannot be removed through this action.

Storage browsing requires Android file access. Android/data and Android/obb remain inaccessible; contacts and media use their existing permissions. Empty folders carry no file contents to transfer. Receive QR/band selection, phone cloning and USB transfer remain available.

Validation: JVM tests cover document/MIME matching, progressive discovery, cancellation, directory priority, canonical confinement, recursive and overlapping selection, denied nested traversal, and direct-file transfer directory metadata. Debug APK compilation and signing/version verification are performed before publication. Actual phone UI, media providers and Android uninstall dialogs still need device verification.
