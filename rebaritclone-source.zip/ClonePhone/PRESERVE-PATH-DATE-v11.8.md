# Preserve original path and dates — v11.8
For both Wi‑Fi and USB transfer:
- Sender includes the original public-storage relative folder path.
- Sender includes original DATE_MODIFIED and media DATE_TAKEN.
- Receiver sanitizes the relative path to prevent traversal and recreates the same public folder structure through MediaStore RELATIVE_PATH.
- Receiver writes DATE_MODIFIED and DATE_TAKEN before/finalizing the media item.
- Example: DCIM/Camera/a.jpg -> DCIM/Camera/a.jpg; Pictures/Screenshots/x.png -> Pictures/Screenshots/x.png.
- If a source does not expose a usable path (some SAF/cloud providers), receiver safely falls back to the normal public media category folder.
- Android protected/private directories remain subject to platform restrictions.
