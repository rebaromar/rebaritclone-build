# USB stability fixes – v14.2

- Fixed Android 10+ SecurityException caused by reading UsbAccessory.getSerial() before USB permission.
- USB permission PendingIntent is immutable, matching current Android USB host guidance.
- AOA accessory filter version now matches the emitted AOA identity (2.0).
- OEM permission failures are recovered without exposing raw SecurityException in the UI.
- Logical sender/receiver roles remain independent of the physical Type-C host/accessory role.
