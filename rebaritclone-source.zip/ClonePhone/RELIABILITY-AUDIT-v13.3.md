# REBARIT CLONE v13.3 reliability cleanup
- Removed stale duplicate Bluetooth/Share button from download page.
- Kept Send App only in the three-dot menu.
- QR generation optimized to one bitmap allocation.
- app metadata worker now shuts down with MainActivity.
- Removed privileged UPDATE_PACKAGES_WITHOUT_USER_ACTION permission.
- Existing USB/hotspot reconnect, keep-screen-on, app scan cache, file metadata preservation and update flow retained.
