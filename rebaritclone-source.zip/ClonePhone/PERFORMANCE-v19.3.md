# REBAR IT Clone 19.3 performance changes

- App selection now records package and APK metadata instead of building every `.rbapp` file into the sender cache. APK bytes are read once, directly from the installed base and split APK files, as they are sent.
- `.rbapp` version 1 is a bounded, uncompressed stream container with a computable exact size. This removes the large pre-transfer disk copy and ZIP deflate/inflate work. The receiver still verifies the complete encrypted transfer with SHA-256 before committing it, and Android still verifies package signatures at install time.
- The reader continues to accept the previous ZIP-based `.rbapp` files.
- The encrypted channel identifies itself as protocol 6. Both phones must run 19.3 or newer so an older receiver cannot accept an unreadable app container.
- Source-file sizes and package version timestamps are checked when the stream opens. A changed or truncated APK aborts the file and keeps existing resume validation in place.

The sender no longer needs cache space equal to the complete selected-app set. The receiver still needs room for the selected app packages. Network throughput still depends on the Wi-Fi Direct band, both devices, and their radio conditions; no speed claim is made without a real two-phone measurement.
