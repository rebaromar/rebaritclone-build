# Receive Files QR — 17.6

The purple Receive Files card now starts preparing the receiver immediately. Android may still request Nearby Wi-Fi/location permission, Wi-Fi activation, or a save folder on Android 6–9. The QR appears after a real hotspot/group address is available and the transfer listener has bound successfully.

The QR page shows Auto, 2.4 GHz, 5 GHz and 6 GHz below the code. Unsupported or unavailable choices stay visible and disabled. Auto selects a supported connection with fallback. An explicit band must be confirmed by the actual group frequency; a failed request offers Auto or retry instead of showing an incorrect QR.

Changing band hides the previous QR, cancels the old receiver listener, closes the old hotspot and creates a fresh pairing session. Band changes stop being available after the sender authenticates. Phone Clone and USB keep their separate protocols.

6 GHz hosting requires Android's permitted Wi-Fi Direct group-owner channels and a radio that supports them. Radio support alone does not guarantee that Android permits an app to create a 6 GHz group. Older Android versions can use Auto without calling the Android 8 local-only-hotspot API.

VersionCode 116 / versionName 17.6. Device-specific hotspot behavior still needs confirmation on the user's phones; no physical Android phone was connected to the build environment.
