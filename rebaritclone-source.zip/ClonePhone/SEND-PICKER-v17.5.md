# Send Files fixes — 17.5

- Not Installed discovers saved APK, APKS, XAPK, APKM and RBAPP files in readable shared storage. File access opens Android all-files settings on Android 11+, or the runtime storage permission on Android 6–10. Individual document picking remains available.
- Photos and Videos have Recent/Folders views. Recent photos use three-column thumbnails grouped by day; Folders uses actual storage directories with item counts and folder navigation.
- Files shows WhatsApp Status/Media, ALL/PDF/EXCEL/PPT/TXT/DOC/WPS documents, Zip archives and files larger than 50MB. Categories open actual file selections.
- Contacts lists names and numbers, alphabetical headings, individual and group selection, and exports the selection through the existing VCF transfer flow.
- Discovery is cancellable, skips Android/data and Android/obb, and confines symlinks to shared storage.

Validation: PickerFilesTest passed for actual temporary-file discovery, package/document/archive types, the 50MB boundary, WhatsApp paths, restricted directory exclusion, symlink escapes/loops and cancellation. Gradle assembleDebug passed; APK signature verification passed. Real-phone visual checks, permission prompts and contact provider export require device testing.

VersionCode 115 / versionName 17.5; minSdk 23; ClonePhone/gradlew preserved for GitHub Actions.
