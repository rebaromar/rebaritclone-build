# REBAR IT Clone 17.4 — Send Files picker

The green Send Files card opens a full-screen light Select Files page matching the supplied reference layout:
- FILES, VIDEOS, APPS, PHOTOS, MUSIC tabs with a blue active indicator.
- Installed apps and local APK packages under Not Installed.
- Recently installed user apps (last seven days) grouped under New, remaining apps under Apps.
- Four-column app grid with actual icons, app names and APK/split-package sizes.
- Collapsible groups, group selection, search, selected item count and fixed NEXT button.
- Selection retained across tabs and search. NEXT uses the existing app bundle export and connection flow.
- Media uses Android MediaStore and thumbnails. Android's document picker supplies files outside MediaStore access.

Compatibility repair: TransferService uses the API 23 notification builder on Android 6/7 and does not restart an idle foreground service after process death.

Validation: encrypted loopback resume, corrupt-prefix rejection, lost acknowledgement deduplication, SHA-256 integrity, 64 MiB buffered transfer, protocol and 2000-file manifest tests passed. Real-device visual, permission and phone-to-phone tests remain necessary.

Build validation: Gradle assembleDebug completed successfully (34 tasks). APK signature verification passed; versionName 17.4 / versionCode 114, minSdk 23. Maven Central returned HTTP 429 in this environment; a local Gradle init script used Google's Maven Central mirror for build verification. The source repository settings remain unchanged.
