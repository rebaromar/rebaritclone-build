# REBARIT CLONE v14.1 — USB stability rebuild

- Logical sender/receiver role is decoupled from the physical USB-C host/accessory role.
- Either phone may be the Type-C host; the host automatically negotiates Android Open Accessory mode.
- USB uses a fresh-transfer protocol: partial files never resume. A failed current file restarts from byte 0.
- Fully completed duplicate files may be skipped after reconnect, so a retry does not create duplicates.
- USB receive streams directly into pending destination storage instead of staging multi-GB files in app cache.
- SHA-256 verification is completed before a received file is finalized.
- Attach/detach is watched while connected; detaching closes the active link immediately.
- Bulk I/O uses conservative 64 KiB requests (16 KiB on older Android) with bounded transient retries.
- Transfer foreground service now holds a partial CPU wake lock while a transfer is active.
- Automatic USB recovery is limited to 3 full restart attempts with backoff.
- Wi-Fi/Hotspot resume behavior remains unchanged.

Android/OEM USB role negotiation is controlled by the OS/hardware; no normal third-party app can guarantee Samsung-only privileged behavior on every device.
