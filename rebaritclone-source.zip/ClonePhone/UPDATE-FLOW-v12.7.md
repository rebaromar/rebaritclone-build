# REBARIT CLONE v12.7 update flow
Online self-update:
1. Download APK inside REBARIT CLONE with progress.
2. Validate package/version/signature.
3. DO NOT open AppInstallActivity / bulk-app installation screen.
4. Open Android's native package installer directly with ACTION_VIEW.
5. Android shows only its required Update/Cancel confirmation.

Note: Android does not allow an ordinary third-party app to silently press the system Update button.
AppInstallActivity remains only for apps received/transferred by REBARIT CLONE.
