# REBARIT CLONE 19.2 performance changes

- Automatic Phone Clone Wi-Fi Direct hosting now uses the automatic band policy instead of forcing 2.4 GHz. The policy tries supported 6 GHz and 5 GHz before 2.4 GHz, with the existing fallback behavior retained.
- Clone-mode media and document manifests no longer request a date sort. Normal gallery views still sort newest first. This avoids unnecessary MediaStore ordering work while preparing a large selection.
- When Phone Clone exports applications, it resolves only the packages selected by the user instead of enumerating every installed application again.
- The authenticated transfer, SHA-256 verification, checkpointing, resume behavior, and per-file durable commit are unchanged.

No throughput number is claimed until the same large selection is measured on both phones and the Wi-Fi band is recorded.
