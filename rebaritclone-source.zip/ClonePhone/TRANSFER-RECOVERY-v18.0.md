# REBARIT CLONE 18.0 — reconnect consent and large files

When a cable or Wi-Fi connection interrupts an active transfer, reconnecting
negotiates the same transfer and byte offset. The receiving phone asks only
**Continue**. Phone Clone and USB reuse the original category selection and
source consent; prepared app/record exports remain available throughout retries.

QR pages offer **Back to home**, and failed transfers no longer show a manual
“Resume interrupted transfer” button. Going home cancels scheduled reconnects
and discards incomplete pending destinations while keeping completed files.

Wi-Fi clients retry with a current network; hosted connection failure rebuilds
the group and updates the QR while retaining the listener, pairing key and
transfer state. If Android changes the hosted network credentials, scan the new
QR to reconnect; the transfer resumes after Continue. USB reattach intents do
not reset an interrupted automatic transfer.

Authenticated CP05 heartbeat records keep connections alive while consent,
source preparation, SHA-256 prefix verification or destination sync takes time.
Both phones must run 18.0 or later; CP04 peers are rejected with update guidance.
Transport errors retry. Permission, storage, source-change, authentication and
protocol errors stop safely. A disconnected prefix check preserves valid bytes.

Files stream directly into a seekable pending MediaStore/SAF destination. There
is no complete cache file followed by a second complete copy. Remaining capacity
uses 64-bit lengths and excludes retained bytes and completed files. Checkpoints
persist destination URI, completed length and SHA-256 before the file ACK.
Completed destinations are never reopened as writable duplicates by name/size.
Final batch receipt loss does not undo files already durably acknowledged.

Validation: APK 18.0/code 120 builds and verifies with the existing signing key;
21 JVM tests cover encrypted streaming, mid-file and prefix-check interruption,
restored/lost-ACK recovery, direct storage and partial-write rollback, actual
heartbeat socket deadlines, transport classification, final batch receipt loss,
QR round trips, USB bootstrap, and 220 GB sparse offsets/capacity/accounting.

The 220 GB checks validate 64-bit behavior; they do not transfer 220 GB between
physical phones. Device/provider behavior, filesystem file-size limits, actual
capacity, cable/radio failure and Android/OEM termination remain practical limits.
Keep both apps open during an interrupted transfer. Generic Wi-Fi journals can
restore byte state after relaunch; equivalent automatic Phone Clone/USB recovery
after process death is not claimed. Nonseekable/cloud document providers are
rejected with guidance to use device storage.
