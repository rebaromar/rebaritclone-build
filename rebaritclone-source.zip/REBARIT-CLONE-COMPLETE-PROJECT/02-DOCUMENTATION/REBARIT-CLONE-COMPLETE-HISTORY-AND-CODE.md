# REBARIT CLONE --- Complete Project History + Source Code

## Current build

-   App name: REBARIT CLONE
-   Version: 11.4
-   Version Code: 57
-   Android namespace/applicationId: com.abdulla.clonephone
-   Minimum Android: API 26 (Android 8)
-   Target SDK: 34
-   Compile SDK: 35
-   Languages in source: Java + Kotlin
-   Build: Gradle / Java 17
-   QR library: ZXing core 3.5.3

## Main development path

1.  Started as Android-to-Android phone cloning / transfer app.
2.  Added old-phone / new-phone roles and step flow: Start → Connection
    → Selection → Transfer.
3.  Added Wi‑Fi Direct / local hotspot connection and QR pairing,
    including 5 GHz preference/fallback.
4.  Added encrypted/authenticated local transfer and retry/resume
    helpers.
5.  Added photos, videos, audio, files/documents, contacts, SMS, recent
    calls and APK app transfer.
6.  Added USB-C receive/send route using Android USB host/accessory
    support.
7.  Added app bundle transfer (.rbapp) with base APK + split APKs.
8.  Added sequential Android package installation flow and install
    result handling.
9.  Added file gallery, media browsing, search/filter, selection and
    file-size formatting.
10. Added User Apps / System Apps views, multi-select and app uninstall
    flow.
11. Redesigned UI toward dark/VIP style and compact app cards.
12. Renamed visible app label to REBARIT CLONE.
13. Added Java + Kotlin coexistence; new VIP design helper is Kotlin.
14. Added online update support.
15. Version 11.4 fixed the receiver-side app installation screen so dark
    theme does not render it black/unclear; added VIP dark install UI,
    progress, current item count and installed/skipped state.

## Important Android limitations preserved

-   Normal apps cannot silently uninstall arbitrary apps without Android
    confirmation.
-   Normal apps cannot silently approve package installation dialogs.
-   Some permissions are controlled by Android and must be approved by
    the user.
-   System apps may not be removable by a normal app.
-   App-private data from third-party apps is not generally transferable
    without privileged/root/device-owner capabilities.

## Source layout

The sections below contain the actual source/code from the current 11.4
project, separated file by file.

------------------------------------------------------------------------

# Project document: `README-ckb.md`

# rebaritclone --- وەشانی 7.9.1 بۆ تاقیکردنەوە

ئەم وەشانە ڕووکارێکی هەنگاو بە هەنگاو هەیە: مۆبایلی کۆن / مۆبایلی نوێ،
هەڵبژاردنی جۆری داتا، پەیوەستبوون بە QR، شاشەی گواستنەوە و هەڵبژاردنی
ئەپ بۆ دامەزراندن. ناوەڕۆکی فایلەکان لە تۆڕی ناوخۆ بە نهێنیکراوی
نێردرێت؛ بۆ سێرڤەرێکی ئینتەرنێت نانێردرێت.

## دەستپێکردن --- بەبێ سیمکارت و ئینتەرنێت

1.  APKی **8.4 لە هەردوو مۆبایلەکە** دابمەزرێنە. ئەندرۆید 8 یان نوێتر
    پێویستە.
2.  لە مۆبایلی نوێ **مۆبایلی نوێ** دابگرە. ڕێگەی Nearby Wi-Fi بدە؛ لە
    ئەندرۆید 12 و کۆنتر، ڕێگەی Location و چالاکبوونی Location ڕەنگە
    پێویست بێت. ئەپەکە شوێنی جوگرافی تۆ ناخوێنێتەوە.
3.  لە مۆبایلی کۆن داتا هەڵبژێرە، **بەردەوام بە ← سکانی QR** دابگرە و
    QRی مۆبایلی نوێ سکان بکە.
4.  لە ئەندرۆید 10 و نوێتر داواکاری پەیوەستبوونی سیستەم قبووڵ بکە. ئەگەر
    نووسی «ئینتەرنێتی نییە»، هەر پەیوەست بمێنەوە؛ ئەم تۆڕە بۆ ناردنی
    فایلە، نە ئینتەرنێت.
5.  لە مۆبایلی نوێ **وەرگرتن** دابگرە. هەردوو ئەپەکە کراوە بهێڵەوە تا
    تەواو دەبێت.

**ڕێگای دەستی:** ئەگەر هۆتسپۆتی بەخۆکار لە مۆبایلەکەت کار نەکرد، بەشی
«هۆتسپۆت بە دەستی خۆم چالاک دەکەم» هەڵبژێرە. لە نوێکە هۆتسپۆت چالاک بکە،
لە کۆنەکە بە وایفای پێوە ببەستە، پاشان QR سکان بکە. لە ئەندرۆید 8 و 9
پەیوەستبوون بە وایفای بە دەستییە؛ ناو و وشەی نهێنی هۆتسپۆت لە ئەپەکە
نیشان دەدرێن. هەندێک سازەری مۆبایل لە هۆتسپۆتی دەستیدا سنووری تایبەت
هەیە.

داتای سیمکارت و ئینتەرنێت پێویست نین. هۆتسپۆتی ناوخۆی ئەپەکە پەیوەندی
ئینتەرنێت دروست ناکات. لە ئەندرۆید 8 و 9 فۆڵدەری وەرگرتن یەکەم جار
هەڵبژێرە.

## خێرایی بەرز / High performance

دۆخی **خێرایی بەرز / 5 GHz** بە بنەڕەت چالاکە و هەڵبژاردەکە تەنها لە ژێر
QR هەیە. گۆڕینی هەڵبژاردەکە تۆڕ و QR نوێ دەکاتەوە؛ لە مۆبایلی کۆن QRی
نوێ سکان بکە. بە کرتە لە «مۆبایلی نوێ» داواکاری ڕێگەی ئەندرۆید
دەردەکەوێت، پاش Allow هەوڵی دروستکردنی تۆڕی 5 GHz و پیشاندانی QR بەخۆکار
دەدرێت. ئەگەر وایفای کوژاوە بێت، پانێڵی سیستەم دەکرێتەوە؛ چالاکی بکە و
بگەڕێوە. لە ئەندرۆیدی کۆندا ڕەنگە Location و هەڵبژاردنی فۆڵدەر پێویست
بێت. ئەپ ناتوانێت لە جیاتی تۆ Allow دابگرێت.

ئەگەر 5 GHz ئامادە نەبوو، هۆکارەکە نیشان دەدرێت. هەڵبژاردەی هەوڵدانەوە،
هۆتسپۆتی ئاسایی، ڕێکخستنی دەستی و USB هەن. لە هەڵەی سەرقاڵبوونی Wi-Fi
Direct، پاش سێ هەوڵدانەوە هۆتسپۆتی ئاسایی بەخۆکار تاقی دەکرێتەوە و
گۆڕانەکە لە ژێر QR ڕوون دەکرێتەوە؛ 5 GHz مسۆگەر نییە. دۆخی خێرا بافەری 1
MiB و داواکاری کارایی بەرزی وایفای بەکاردەهێنێت.

لە شاشەی QR و وەرگرتن، 5 GHz تەنها کاتێک نیشان دەدرێت کە فرێکوێنسی گروپی
Wi-Fi Direct پشتڕاست کرابێتەوە. باندی وایفای تری مۆبایل وەک باندی
هۆتسپۆت نیشان نادرێت. **Link بە Mbps خێرایی ڕاستەقینەی گواستنەوە بە MB/s
نییە.** 5 GHz واتە باندی وایفای، نە 5Gی سیمکارت.

ئەم هەڵبژاردەیە «Ultra Fast» ی مسۆگەر نییە. خێرایی بە مۆبایل، باند،
دووری، قەبارەی فایل، بیرگە و گەرمی بەستراوە. ڕەنگە وزەی زیاتر
بەکاربهێنێت. ئەگەر جیاوازی نەبوو یان ئامێر گەرم بوو، دۆخی ئاسایی
بەکاربهێنە.

## گواستنەوە بە کەیبڵی USB-C --- تاقیکردنەوەیی

1.  کەیبڵێک بەکاربهێنە کە **داتا** بگوازێتەوە، نە تەنها شەحن.
2.  لە مۆبایلی نوێ **وەرگرتن بە USB-C / ڕێگاکانی تر ← وەرگرتن بە کەیبڵی
    USB-C** هەڵبژێرە.
3.  لە مۆبایلی کۆن داتا هەڵبژێرە، بەردەوام بە و **ناردن بە کەیبڵی
    USB-C** هەڵبژێرە.
4.  هەردوو مۆبایلەکە بە کەیبڵ ببەستە. لە نوێکە USB controlled by → This
    device هەڵبژێرە، یان OTG چالاک بکە ئەگەر هەڵبژاردەکە هەیە.
5.  داواکارییەکانی ڕێگەی USB لە هەردوو مۆبایلەکە قبووڵ بکە. ڕەنگە دوای
    گۆڕینی دۆخی USB دووبارە داوا بکرێت.
6.  لە مۆبایلی نوێ لیستەکە پشکنە و وەرگرتن قبووڵ بکە. USB debugging
    پێویست نییە.

ئەگەر مۆبایل نەدۆزرایەوە، لە کۆنەکە USB / File transfer هەڵبژێرە و هەوڵ
بدەوە. ئەپەکە پاشان دۆخی USB دەگۆڕێت بۆ Android Open Accessory. پێویستە
مۆبایلی نوێ USB Host/OTG و کۆنەکە USB Accessory پشتگیری بکەن. هەموو
جووتە مۆبایلێک پێکەوە کار ناکەن. خێرایی بە کەیبڵ خۆکارانە لە وایفای
زیاتر نییە؛ کەیبڵ، پۆرت و پشتگیری سیستەم گرنگن.

بۆ ئەم ڕێگایە وایفای، هۆتسپۆت، سیمکارت و ئینتەرنێت بەکارناهێنرێن. USB لە
کۆددا زیاد کراوە و stream ـەکان تاقی کراونەتەوە، **بەڵام لەسەر دوو
مۆبایل بە کەیبڵی ڕاستەقینە هێشتا تاقی نەکراوەتەوە**. سەرەتا تەنها یەک
فایلێکی بچووک تاقی بکەرەوە.

سەرەتا بە یەک وێنە و ڤیدیۆیەکی بچووک تاقی بکەرەوە. بۆ هەڵبژاردنی چەند
فایلێکی دیاریکراو، بەشی **فایلەکان** بەکاربهێنە. کلیککردن لە بەشێکی
هەڵبژێردراو ئەو بەشە لە لیست لادەبات.

## ناردن و دامەزراندنی ئەپەکان

1.  **7.6 لە هەردوو مۆبایل دابمەزرێنە.** لە کۆنەکە «مۆبایلی کۆن ←
    ئەپەکان» دابگرە.
2.  لە لیستەکە ئەپەکان تیک بکە و «زیادکردن» دابگرە. دووبارە کرتە لە
    «ئەپەکان» دەستکاری هەڵبژاردن دەکات. لابردنی هەموو تیکەکان و
    زیادکردن، ئەو بەشە بەتاڵ دەکات.
3.  «بەردەوام بە» دابگرە و بە QR یان USB بینێرە. ئەپی سیستەم و ئەپی بێ
    ئایکۆنی دەستپێکردن لە لیستەکەدا نین.
4.  دوای وەرگرتنی تەواوی لیستەکە، لە مۆبایلی نوێ دامەزراندنی ئەپەکان بە
    ڕیز دەست پێ دەکات.
5.  یەکەم جار ئەگەر داوا کرا، **Allow from this source** بۆ rebaritclone
    چالاک بکە و بگەڕێوە. لە پەنجەرەی ئەندرۆید بۆ هەر ئەپ **Install /
    Update** قبووڵ بکە. ئەپ ناتوانێت لە جیاتی تۆ ئەو قبووڵکردنە بکات.
6.  ئەگەر ئەپێک ڕەتکرایەوە یان دامەزراندنی سەرنەکەوت، هۆکارەکە لە
    لیستەکە تۆمار دەکرێت و خۆکارانە دەچێتە ئەپی دواتر. لە کۆتایی ژمارەی
    ئەپە دامەزراو و جێهێڵراوەکان دەردەکەوێت. هیچ ئەپی دامەزراو بۆ
    چارەسەری کێشە خۆکارانە ناسڕێتەوە.

ئەپە هەڵبژێردراوەکان بە فایلێکی `.rbapp` نێردرێن کە **base APK و هەموو
split APKی دامەزراوی ئەو مۆبایلە** لەخۆ دەگرێت. واژۆ و ناوەڕۆکی APK
دەستکاری ناکرێن. فایلە وەرگیراوەکان لە Downloads / rebaritclone
دەمێننەوە؛ لە ئەندرۆیدی کۆندا لە فۆڵدەری هەڵبژێردراو. APKی تاکیش
دەتوانیت لە «فایلەکان» هەڵبژێریت و بینێریت.

**ئەمە داتای ناوخۆی ئەپ ناگوازێتەوە:** هەژمار، چوونەژوورەوە، نامەکان،
داتای WhatsApp، ڕێکخستن و داتای زیادەی یارییەکان تێدا نین. هەندێک ئەپ
بەهۆی جۆری پرۆسێسەر، ئەندرۆید، واژۆ، وەشان یان سنووری خۆی لە مۆبایلی نوێ
دانەمەزرێت یان کار نەکات. هەڵگرتنی splitەکانی مۆبایلی کۆن مسۆگەری گونجان
لەگەڵ مۆبایلی نوێ نییە.

ئامادەکردنی فایلەکانی ئەپ بۆشایی کاتی لە کۆنەکە دەوێت؛ وەرگرتن و
دامەزراندنیش بۆشایی زیادە لە نوێکە دەوێت. سەرەتا یەک ئەپی بچووک تاقی
بکەرەوە. هەردوو ئەپەکە کراوە بهێڵەوە؛ لیستی دامەزراندن دوای داخستنی
تەواوی ئەپ مسۆگەر نییە.

## بەردەوامبوون دوای پچڕان

-   هەردوو مۆبایلەکە دەبێت **7.6** بن؛ گواستنەوە لەگەڵ وەشانە کۆنەکان
    ناگونجێت.
-   ئەگەر تەنها پەیوەندی ناردن پچڕا و تۆڕ هەر مابوو، نێرەر تا دوو جار
    بەخۆکار هەوڵ دەداتەوە. وەرگر تا ١٠ خولەک چاوەڕێ دەکات.
-   ئەگەر هۆتسپۆتیش پچڕا، لە نوێکە «بەردەوامبوون لە شوێنی پچڕان» دابگرە؛
    لە کۆنەکە هەمان فایلەکان هەڵبژێردراو بهێڵەوە و QRی نوێ سکان بکە. لە
    USB، کەیبڵ پەیوەست بکەرەوە و هەمان ڕێگای USB دووبارە هەڵبژێرە.
-   فایلە تەواوکراوەکان دووبارە نانێردرێن. فایلە ناتەواوەکە لە دوا
    پارچەی بە تەواوی وەرگیراوەوە بەردەوام دەبێت. پێش بەردەوامبوون بەشە
    پاشەکەوتکراوەکە دەپشکنرێت، بۆیە ڕەنگە کەمێک چاوەڕێ بکەیت.
-   **هەردوو ئەپەکە کراوە بهێڵەوە.** داخستن، Force stop، کوژاندنەوەی
    مۆبایل یان لەناوچوونی پرۆسەی ئەپ زانیاری بەردەوامبوون لەناو دەبات.
    ئەم وەشانە بەردەوامبوون دوای دووبارەکردنەوەی ئەپ مسۆگەر ناکات.
-   وەرگر فایلێکی کاتی هەڵدەگرێت، پاش پشکنین بۆ گەلەری/Downloads کۆپی
    دەکات و کاتییەکە دەسڕێتەوە. بۆ گەورەترین فایلەکە بۆشایی زیادە
    پێویستە؛ ئەم هەنگاوەش کات دەبات.
-   گۆڕینی لیستی فایلەکان گواستنەوەی نوێ دەست پێ دەکات. فایلە سەرچاوەکان
    لە کاتی گواستنەوە دەستکاری مەکە.

## شوێنی داتا

لە ئەندرۆید 10 و نوێتر:

-   وێنەکان: Pictures / rebaritclone / فۆڵدەری هەر گواستنەوەیەک؛ لە
    گەلەریش بەردەستن.
-   ڤیدیۆکان: Movies / rebaritclone.
-   دەنگەکان: Music / rebaritclone.
-   فایلەکانی تر و VCF: Download / rebaritclone.

لە ئەندرۆید 8 و 9 فایلەکان لە فۆڵدەری هەڵبژێردراو کۆدەکرێنەوە. ئەپەکە
کۆپی دەکات؛ فایلە سەرەکییەکان ناسڕێتەوە.

ژمارەکان لە Contacts بە VCF هەناردە دەکرێن. دوای وەرگرتن **هاوردەکردنی
ژمارەکان** دابگرە و ڕێنمایی ئەپی Contacts تەواو بکە. ئەگەر ئەپی Contacts
ئەو دوگمەیەی نەکردەوە، لە Contacts بەشی Import بەکاربهێنە و contacts.vcf
هەڵبژێرە. دووبارە هاوردەکردن ڕەنگە ژمارەی دووبارە دروست بکات.

## سنوورە ڕاستەقینەکان

-   ئەمە هێشتا وەشانی تاقیکردنەوەیە و جێگرەوەی تەواوی Samsung Smart
    Switch نییە؛ هیچ پەیوەندییەکی بە سامسۆنگەوە نییە.
-   داتای ناوخۆی ئەپەکان، WhatsApp، هەژمارەکان، وشەی نهێنی و
    ڕێکخستنەکانی سیستەم ناگوازرێنەوە. SMS و مێژووی پەیوەندی تەنها بە
    فایلێکی پاشەکەوت دەنێردرێن؛ خۆکار ناچنە ناو Phone و Messages.
-   USB تاقیکردنەوەییە. دروستکردنی گروپی Wi-Fi Direct و هۆتسپۆتی بەخۆکار
    بە پشتگیری سیستەم و ڕێگەکان بەستراون؛ ڕێگای هۆتسپۆتی دەستی ماوەتەوە.
-   ئەندرۆید 14 و نوێتر ئەگەر تەنها ڕێگە بە هەندێک وێنە بدەیت، تەنها
    ئەوان زیاد دەکرێن؛ هەموو گەلەری ناگوازرێتەوە.
-   سنوور ١٠ هەزار فایلە لە هەر جارێکدا. بۆ لیستە گەورەترەکان بەش بەش
    بنێرە. داتای MediaStore تەنها فایلە بەردەست و ڕێگەپێدراوەکان
    دەگرێتەوە، نە هەموو فۆڵدەرە شاراوەکان.
-   لە هەندێک ئەندرۆید زانیاری شوێنی وێنەکان لە لایەن سیستەمەوە لە
    کۆپییە خوێندراوەکە لادەبرێت؛ ئەرشیفکردنی تەواوی مێتاداتا مسۆگەر
    نییە.
-   گواستنەوە لە پاشبنەما مسۆگەر نییە؛ هەردوو ئەپەکە کراوە بهێڵەوە.
-   لەم وەشانەدا دوای پچڕانی پەیوەندی دەتوانرێت هەمان گواستنەوە لە دوا
    پارچەی وەرگیراو بەردەوام بێت، بە مەرجێک هەردوو ئەپەکە نەخرابنەوە و
    هەمان لیستی فایلەکان مابێتەوە.
-   هەندێک تۆڕی میوان پەیوەندی نێوان مۆبایلەکان قەدەغە دەکات؛ لەو دۆخەدا
    هۆتسپۆت تاقی بکەرەوە.
-   QR و کۆدی پەیوەندی تەنها لەگەڵ مۆبایلی خۆت بەکاربهێنە؛ کلیلی ئەو
    پەیوەندییەیە.

## پشکنین

APK دروست کراوە و واژۆکەی پشکنراوە. گواستنەوەی نهێنی، کۆدی هەڵە، داتای
دەستکاریکراو، QR لە چوار ئاراستە و لیستی ٢٠٠٠ فایل تاقی کراونەتەوە.
هێشتا دامەزراندن، کامێرا، ڕووکار و گواستنەوەی ڕاستەقینە لەسەر دوو مۆبایل
پشکنین نەکراون؛ ئەو تاقیکردنەوەیە پێویستە.

## کۆد و دروستکردن

پڕۆژەکە لە Android Studio بکەرەوە؛ JDK 17، SDK 35 و Gradle 8.9
بەکاربهێنە. یان لە Linux/macOS بە JAVA_HOME و ANDROID_HOME ڕێکخراو،
`bash build-local.sh` بەکاربهێنە. وەشانی 9.1 (ژمارەی 34) لە سەرەتا و
پەڕەی دابەزاندنەوە «بەرنامەکە بنێرە بە Bluetooth یان Share» پیشان دەدات
و APKی دامەزراو بە ناوی `REBAR-IT-Clone-9.1.apk` بۆ Android Sharesheet
دەدات؛ ناردن پێویستی بە قبووڵکردن لە مۆبایلی وەرگر هەیە. کلیلی
تاقیکردنەوە بۆ نوێکردنەوەی APK لە پڕۆژەکە هەیە؛ بۆ بڵاوکردنەوەی بەرهەمی
کۆتایی نییە.

تاقیکردنەوەی زیاتر: 64 MiB + 37 بایت لە تۆڕی ناوخۆی ژینگەی دروستکردن
گوازرایەوە و SHA-256 یەکسان بوو. ئەمە تاقیکردنەوەی خێرایی مۆبایل نییە.
هۆتسپۆتی ڕاستەقینە و داواکاری پەیوەستبوونی ئەندرۆید هێشتا لە دوو مۆبایل
تاقی نەکراونەتەوە.

سەرچاوەی Android:
https://developer.android.com/develop/connectivity/wifi/localonlyhotspot
https://developer.android.com/develop/connectivity/wifi/wifi-bootstrap

## هەڵەی هۆتسپۆت

وەشانی 7.4.1 هۆکاری شکستی هۆتسپۆت/گروپی وایفای و مۆدێل و ئەندرۆیدی
مۆبایل نیشان دەدات. ئەگەر بەخۆکار کار نەکرد، وێنەی ئەو هەڵەیە بنێرە.
ئەمە هۆکاری کێشەکە دیاری دەکات؛ لە وێنەی خێرایی گواستنەوە بە تەنها
ناتوانرێت هۆکاری هۆتسپۆت بزانرێت.

سەرچاوەکانی USB و Wi-Fi Direct:
https://source.android.com/docs/core/interaction/accessories/aoa
https://developer.android.com/develop/connectivity/usb/accessory
https://developer.android.com/develop/connectivity/wifi/wifip2p

وەشانی 7.4.1: پشکنینی پێکهێنان و خوێندنەوەی پاکێجی ئەپ سەرکەوتوو بوو.
پەنجەرەی Install و دامەزراندنی ڕاستەقینە لەسەر مۆبایل هێشتا پێویستی بە
تاقیکردنەوە هەیە.

## دامەزراندنی بێ پرسیار لە 7.1

لە ئەندرۆید 12 و نوێتر ئەپ داوای دامەزراندنی بێ پرسیار دەکات، بەڵام
تەنها کاتێک ئەندرۆید خۆی ڕێگە دەدات جێبەجێ دەبێت؛ بۆ نموونە هەندێک
نوێکردنەوەی ئەپێک کە پێشتر rebaritclone دایمەزراندووە، بە مەرجەکانی
سیستەم. **بۆ ئەپی تازە لە مۆبایلی نوێ، هەر پەنجەرەی Install پێویستە.**
هەبوونی ئەپ لە Play Store ئەو مەرجە ناگۆڕێت. ئەپەکە پشکنینی Play Store
ناکات و بانگەشەی ڕێگەپێدراوی Google بۆ فایلە نێردراوەکان ناکات.

## ژمارە و قەبارە --- 7.2

لە هەڵبژاردنی وێنە، ڤیدیۆ و بەشەکانی تر ژمارەی فایل و قەبارەیان بە GB
نیشان دەدرێت. کۆی هەڵبژاردن و شاشەی پەیوەستبوونیش قەبارەی گشتی پیشان
دەدەن؛ فایلێکی هەمان URI دووبارە لە کۆی هەڵبژاردن ناژمێردرێت.

لە شاشەی گواستنەوەی هەردوو مۆبایل: قەبارەی گشتی، GBی گوازراوە و ماوە،
ژمارەی فایلە تەواو و ماوەکان، ژمارەی وێنە و ڤیدیۆی ماوە لە کۆی گشتی، ئەپ
و فایلەکانی تر، خێرایی ناوەند بە MB/s و کاتی خەمڵێنراوی ماوە هەن. فایلە
ئێستاکە تا تەواوبوونی پشکنین و پشتڕاستکردنەوە لە ژمارەی ماوەدا
دەژمێردرێت.

GB = 1,000,000,000 بایت و MB = 1,000,000 بایت. قەبارەی کەمتر لە 0.001 GB
بە \<0.001 GB نیشان دەدرێت. ئەگەر ئەندرۆید قەبارەی فایلێک نەدات، قەبارەی
گشتی/ماوە و کاتی ماوە بە تەواوی نادیار دەبن و بە ڕوونی نیشان دەدرێن.
کاتی ماوە خەمڵاندنە، نە کاتێکی مسۆگەر؛ پشکنین، بیرگە و خێرایی تۆڕ
دەیگۆڕن.

## زمان --- 7.4.1

لە شاشەی سەرەتادا **زمان / Language / اللغة** دابگرە و یەکێک هەڵبژێرە:

-   کوردی
-   English
-   العربية

گۆڕانەکە ڕاستەوخۆ جێبەجێ دەبێت و بۆ جارەکانی دواتر پاشەکەوت دەکرێت. هەر
مۆبایلێک دەتوانێت زمانێکی جیاواز هەڵبژێرێت. کوردی زمانی بنەڕەتە. گۆڕینی
زمان لە شاشەی سەرەتا هەڵبژاردنی فایلەکان ناسڕێتەوە.

شاشەکانی هەڵبژاردن، QR، ناردن و وەرگرتن، زانیاری گواستنەوە، دامەزراندن،
USB و پەیامەکانی ئەپ وەرگێڕدراون. ئینگلیزی لە چەپ بۆ ڕاست و عەرەبی/کوردی
لە ڕاست بۆ چەپ پیشان دەدرێن. ناوی فایل، ناوی ئەپ، کۆدی هەڵەی سیستەم و
زانیاری QR دەستکاری ناکرێن.

پەنجەرەکانی ڕێگەدان و Installی خودی ئەندرۆید بە زمانی سیستەمی مۆبایل
دەردەکەون. ئەم هەڵبژاردەیە زمانی هەموو مۆبایلەکە ناگۆڕێت.

## هەڵبژاردنی ژمارەکان، مێژووی پەیوەندی و SMS --- 7.4.1

لە مۆبایلی کۆن، هەر بەشێک بە جیا بکەرەوە و ڕێگەی خوێندنەوەی بدە. تەنها
ئەو تۆمارانە هەڵبژێرە کە دەتەوێت بینێریت. گەڕان، هەڵبژاردنی هەموو
ئەوانەی نیشان دراون و پاککردنەوەی هەڵبژاردن هەن. پاشان دوگمەی جێبەجێکردن
دابگرە.

-   **ژمارەکان:** تۆمارە هەڵبژێردراوەکان بە contacts-selected.vcf
    دەنێردرێن. لە مۆبایلی نوێ هەڵبژاردەی هاوردەکردنی ژمارەکان
    بەکاربهێنە؛ هاوردەکردنی دووبارە ڕەنگە ژمارەی دووبارە دروست بکات.
-   **مێژووی پەیوەندی:** تۆمارە هەڵبژێردراوەکان بە
    calls-selected-backup.json دەنێردرێن.
-   **SMS:** نامە هەڵبژێردراوەکان بە sms-selected-backup.json دەنێردرێن.
    دەقی تەواوی نامە هەڵدەگیرێت، هەرچەند پێشبینینی لیست کورتە.

**فایلەکانی JSON پاشەکەوتن؛ لەم وەشانەدا گەڕاندنەوە بۆ ناو Phone و
Messages نییە.** گونجانیان لەگەڵ ئەپی گەڕاندنەوەی تر مسۆگەر نییە. MMS،
RCS و WhatsApp تێدا نین. فایلەکان لە شوێنی وەرگرتنی هەمان فایلەکانی تر
هەڵدەگیرێن.

ئەندرۆید یان دامەزرێنەری APK ڕەنگە ڕێگەی خوێندنەوەی SMS و مێژووی
پەیوەندی نەدات، تەنانەت ئەگەر بەکارهێنەر ڕازی بێت. لەو دۆخەدا بەشی
فایلەکان بۆ ناردنی پاشەکەوتێکی ئامادە بەکاربهێنە.

هەر لیستێک زۆرترین 5000 تۆمار نیشان دەدات؛ بۆ SMS و پەیوەندی
نوێترینەکانن. گەڕان لە دەقی نیشاندراوی لیستەکەدایە. لە هەڵبژاردندا
ژمارەی تۆمارەکان نیشان دەدرێت؛ لە گواستنەوەدا هەر بەشێک یەک فایلە.

پێکهێنانی APK، واژۆ و پشکنینی JSON و هەر سێ زمان سەرکەوتوو بوون.
هەڵبژاردن، ڕێگەپێدان و خوێندنەوەی تۆمارەکان لە مۆبایلی ڕاستەقینە هێشتا
تاقی نەکراونەتەوە.

## چاککردنی کرێش --- 7.4.1

پەنجەرەی زمان، هەڵبژاردنی تۆمارەکان و پەیامی ڕێگەپێدان ئێستا پەیوەندییان
بە شاشەی چالاکی ئەپەکەوە دەپارێزرێت. کێشەی دروستکردنی پەنجەرە لە کۆدی
پێشوو چاک کرا؛ وێنەی کرێش بە تەنها هۆکاری ڕاستەقینە پشتڕاست ناکاتەوە و
logcat بەردەست نەبوو.

وەک Update لەسەر وەشانی پێشوو دایبمەزرێنە؛ پێویست بە سڕینەوەی ئەپ نییە.
پاشان زمانەکان یەک بە یەک هەڵبژێرە و مێژووی پەیوەندی بکەرەوە. پێکهێنان و
واژۆ پشکنران؛ تاقیکردنەوەی ئەم چاککردنە لەسەر مۆبایل هێشتا ماوە.

## ڕێگەپێدان بە نۆرە --- 7.5

دوای کرتە لە مۆبایلی کۆن یان نوێ، داواکارییە پێویستەکانی ئەندرۆید یەک بە
یەک دەردەکەون. ئەو ڕێگانەی پێشتر دراون دووبارە داوا ناکرێن. ئەپ ناتوانێت
لە جیاتی تۆ Allow دابگرێت.

-   لە کۆنەکە: Notifications (ئەندرۆید 13+)، Nearby Wi-Fi یان Location
    بەپێی وەشان، وێنە/ڤیدیۆ، دەنگ، کامێرا، ژمارەکان، مێژووی پەیوەندی و
    SMS.
-   لە نوێکە: Notifications و Nearby Wi-Fi یان Location. پاش تەواوبوون،
    ئەگەر ڕێگەی وایفای درابێت هەوڵی دروستکردنی هۆتسپۆت و QR دەدرێت.
    پێویست بە خوێندنەوەی هەموو وێنە و نامەکانی وەرگر نییە.
-   بۆ هەموو وێنەکان **Allow all** هەڵبژێرە. ئەگەر تەنها هەندێک وێنە
    هەڵبژێریت، ئەپ تەنها ئەوانە دەبینێت.
-   ئەگەر ڕێگەیەک نەدرابێت، هەڵبژاردەی کردنەوەی ڕێکخستنی ئەپ و
    بەردەوامبوون هەیە. ئەندرۆید ڕەنگە دوای ڕەتکردنەوەی دووبارە پەنجەرە
    نیشان نەدات؛ لە ڕێکخستنەکان بگۆڕە. سنووری SMS و مێژووی پەیوەندی
    بەردەوامە.

ئاگادارکردنەوەی گواستنەوە ڕێژە و ژمارەی فایلە تەواوبووەکان نیشان دەدات.
ئەمە خزمەتگوزاری گواستنەوەی بەردەوام لە پشتەوە نییە؛ هەردوو ئەپەکە تا
کۆتایی کراوە بهێڵەوە. ئاگادارکردنەوە بە دەنگ و پەنجەرەی ناچاری نییە؛
ڕێکخستنی سیستەم نیشاندانی دیاری دەکات.

«System files» ڕێگەیەکی گشتیی Allow نییە؛ بەشی فایلەکان هەڵبژێری سیستەم
دەکاتەوە. فایلە پارێزراوەکانی سیستەم و داتای تایبەتی ئەپەکانی تر بەردەست
نین. «Display over other apps» بۆ پەنجەرەی Allow پێویست نییە و داوا
ناکرێت. ڕێگەی دامەزراندنی ئەپ هەر لە کاتی Install داوا دەکرێت.

پشکنینی لیستی ڕێگەکان بۆ هەردوو ڕۆڵ و وەشانەکانی SDK 26--36، 252 دەقی
هەر سێ زمان، پێکهێنان و واژۆ سەرکەوتوو بوون. ڕەوتی پەنجەرەکان و
ئاگادارکردنەوە لەسەر مۆبایلی ڕاستەقینە هێشتا تاقی نەکراونەتەوە.

## چارەسەری P2P_ERROR_2 --- 7.5.1

ئەم هەڵەیە واتە خزمەتگوزاری Wi-Fi Direct سەرقاڵە، نە بەڵگەی نەبوونی
پشتگیری 5 GHz. ئەپ سێ جار بە ماوەی 0.75، 1.5 و 3 چرکە هەوڵ دەداتەوە.
ئەگەر داواکاری 5 GHz هەر سەرقاڵ بوو، بەخۆکار هۆتسپۆتی ناوخۆی ئاسایی تاقی
دەکاتەوە. QR تەنها پاش بەردەستبوونی تۆڕ و ناونیشانی ناوخۆیی دروست دەبێت.

لە ژێر QR ڕوون دەکرێتەوە کە ڕێگای ئاسایی تاقی کراوەتەوە؛ باندی ئەو
هۆتسپۆتە مسۆگەر نییە. هەڵبژاردەی پێشخستنی 5 GHz بۆ جارێکی دواتر
دەمێنێتەوە. هەڵەکانی تر وەک نەبوونی ڕێگە یان پشتگیری بە هەمان شێوەی
پێشوو نیشان دەدرێن. ئەگەر خودی ئەندرۆید هەردوو ڕێگا ڕەت بکاتەوە، QR بە
زۆر دروست ناکرێت و ڕێگاکانی دەستی هەر بەردەستن.

پێکهێنان، واژۆ، سنووری هەوڵدانەوە و 253 دەقی سێ زمان پشکنران؛
تاقیکردنەوە لەسەر Samsung SM-A566B / Android 16 هێشتا ماوە.

## شاشەی سادە و لیستی ئەپەکان --- 7.6

لە شاشەی گواستنەوەدا تەنها ڕێژە و شریتی پێشکەوتن، قەبارەی گشتی، قەبارەی
گوازراوە، خێرایی ناوەند و کاتی خەمڵێنراوی ماوە دەردەکەون. ناوی فایل و
ژمارە وردەکان و قەبارەی ماوە و زانیاری باند لەم شاشەیە لابران. زانیاری
تۆڕ لە شاشەی QR هەر هەیە.

لە یەکەم کردنەوەی SMS یان مێژووی پەیوەندی، هەموو تۆمارە بارکراوەکان
خۆکار هەڵبژێردراون؛ دەتوانیت تۆمار لاببەیت و پاشان جێبەجێ بکەیت.
هەڵبژاردنی پاشەکەوتکراو لە هەمان دانیشتن دەپارێزرێت. سنووری 5000 تۆماری
نوێتر هەر ماوە؛ ئەمە بە مانای هەڵبژاردنی تۆمارەکانی دەرەوەی لیست نییە.
SMS و مێژووی پەیوەندی هەر پاشەکەوتی JSONن و ناچنە ناو Phone/Messages.

لیستی ئەپەکان ئایکۆن، ناوی ئەپ و خانەی هەڵبژاردن هەیە و بە ناو ڕیز
کراوە؛ کۆدی پەکەج لە لیست نیشان نادرێت. هەمان ئەپە ناسیسـتەمییەکانی
دارای ئایکۆنی کردنەوە کە ئەندرۆید بەردەستی دەکات نیشان دەدرێن. پاکێجی
rbapp و ڕەوتی دامەزراندن نەگۆڕاون.

لە کۆتایی ژمارەی وێنە و ڤیدیۆی تەواوگوازراو و ماوەی گواستنەوە بە
کاتژمێر:خولەک:چرکە نیشان دەدرێت. ماوە لە دەستپێکی ناردنی فایلەکان بۆ ئەم
هەوڵەی گواستنەوە هەژمار دەکرێت، هەوڵدانەوەی خۆکار تێدایە؛ کاتی
هەڵبژاردن، ئامادەکردن و دامەزراندنی ئەپ تێدا نییە.

پێکهێنان، واژۆ، هەژمارکردنی فایلە تەواوبووەکان و 256 دەقی سێ زمان
پشکنران. شێوە و کارکردنی ڕووکار لە مۆبایلی ڕاستەقینە هێشتا تاقی
نەکراونەتەوە. ئەم بەشە جێگرەوەی وەسفی شاشەی وردی وەشانە کۆنەکانە.

## پیشاندانی فایلەکان و SMS بە یەک کرتە --- 7.6.1

لە شاشەی کۆتایی مۆبایلی وەرگر «پیشاندانی فایلەکان» دابگرە. لیستی فایلە
تەواووەرگیراوەکانی ئەم بەشەی گواستنەوە دەردەکەوێت؛ کرتە لە فایلێک بۆ
کردنەوەی بە ئەپی گونجاو. کرتە لە پاکێجی ئەپ ڕەوتی دامەزراندنی ئەو ئەپە
دەکاتەوە. فایلە ناتەواوەکان نیشان نادرێن. ئەگەر ئەپی گونجاو بۆ JSON یان
جۆرێکی تر نەبێت، پەیام دەردەکەوێت؛ فایلەکە هەر پاشەکەوتە. لیستەکە لە
دانیشتنی ئێستای ئەپەکەدایە، دوای داخستنی ئەپ لە Files/Gallery فایلەکان
بدۆزەرەوە.

لە مۆبایلی کۆن، یەک کرتە لە SMS هەموو نامە بەردەستە بارکراوەکان
هەڵدەبژێرێت و پاشەکەوتەکە ئامادە دەکات، بەبێ پەنجەرەی هەڵبژاردنی نامە.
کرتەی دووەم SMS لە هەڵبژاردن لادەبات. ئەگەر ڕێگەی ئەندرۆید نەدرابێت داوا
دەکرێت. سنووری نوێترین 5000 تۆمار و ناردن بە JSON هەر ماون؛ گەڕاندنەوەی
خۆکار بۆ Messages نییە. مێژووی پەیوەندی هەمان لیستی هەڵبژاردنی پێشووی
هەیە.

پێکهێنان، واژۆ و 258 دەقی سێ زمان پشکنران؛ کردنەوەی فایل و SMS بە یەک
کرتە لەسەر مۆبایل هێشتا تاقی نەکراونەتەوە.

## ڕووکاری نموونەی ڤیدیۆ --- 7.7

شاشەی سەرەتا بەپێی ڤیدیۆی IMG_7251.mp4 گۆڕا: پاشبنەمای تاریک و شەپۆلی
مۆر، کارتی سەوزی Mobile bo Mobile لە شوێنی Device clone و کارتی مۆری
گواستنەوەی فایل. ناوی ئەپ هەر rebaritclone ـە.

کارتی Mobile bo Mobile بکەرەوە؛ «مۆبایلی کۆن» بۆ ناردن و «مۆبایلی نوێ»
بۆ وەرگرتن دیارن. هەڵبژاردنی هەر یەک ڕەوتی ڕێگەپێدان و گواستنەوەی پێشوو
دەست پێدەکات. کارتی فایلەکانیش هەمان هەڵبژاردنی نێرەر و وەرگر دەکاتەوە.
شاشەکانی هەڵبژاردنی داتا، QR و گواستنەوە هەمان کارکردنی پێشوویان
پاراستووە.

لە مینیوی ⋮ی سەرەوە زمان، یارمەتی و ڕێگاکانی USB/وەرگرتن بەردەستن.
کوردی، ئینگلیزی و عەرەبی هەر ماون. ناوی Mobile bo Mobile لە هەموو
زمانەکاندا بە هەمان شێوە دەردەکەوێت.

ئەم گۆڕانکارییە ڕووکار و ڕیزبەندی شاشە دیارەکانی ڤیدیۆکە دەگرێتەوە؛ بە
مانای زیادکردنی هەموو تایبەتمەندییە نادیارەکانی EasyShare نییە.
پێکهێنان، واژۆ و 264 دەقی سێ زمان پشکنران؛ ڕووکار لە مۆبایلی ڕاستەقینە
هێشتا تاقی نەکراوەتەوە.

## مۆبایل بۆ مۆبایل و گریدی فایلەکان --- 7.9.1

ناوی کارتە سەوزەکە لە زمانی کوردی بوو بە «مۆبایل بۆ مۆبایل». لە ئینگلیزی
Phone to phone و لە عەرەبی من هاتف إلى هاتف دەردەکەوێت.

کارتی مۆری «گواستنەوەی فایل» ئێستا دوای ڕێگەپێدان شاشەی هەڵبژاردنی فایل
دەکاتەوە. پاشبنەما تاریکە، وێنە/ڤیدیۆ بە گریدی چوارستوونی و ڕێکەوت نیشان
دەدرێن. کرتەی کورت بۆ هەڵبژاردن و کرتەی درێژ بۆ پیشاندان بە ئەپی
گونجاوە. ماوەی ڤیدیۆ لەسەر وێنە بچووکەکە دەردەکەوێت. خانەی هەر ڕۆژێک
تۆمارە دیارەکانی ئەو ڕۆژە هەڵدەبژێرێت؛ خانەی سەرەوە هەموو ئەوانەی لە
ئەنجامی گەڕان/پاڵاوتن دیارن هەڵدەبژێرێت.

تابی دەنگ لیستی دەنگەکان دەکاتەوە. تابی فایل هەڵبژێری خودی ئەندرۆید
دەکاتەوە؛ ئەپ و ژمارەکانیش هەمان هەڵبژێرە کاراکانی ناو ئەپ دەکەنەوە.
هەڵبژاردنی وێنە و دەنگ لە گۆڕینی تابەکاندا دەپارێزرێت. کۆی ژمارە/قەبارە
لە خوارەوە و دوگمەی بەردەوامبوون هەن. کارتی سەوز هەر ڕێگای مۆبایلی
کۆن/نوێی پاراستووە.

تەنها فایلەکانی ڕێگەپێدراو لەلایەن ئەندرۆیدەوە دەبینرێن؛ هەڵبژاردنی چەند
وێنەیەک لە پەنجەرەی سیستەم هەمان سنوور لەم گریدەش دروست دەکات. سنووری
بارکردن 10000 فایلە و کاتێک پڕ بوو پەیام دەردەکەوێت. لیستەکان لەسەر
فایلە ناوخۆییەکانن؛ مێژووی گواستنەوەی دایمی زیاد نەکراوە.

پێکهێنان، واژۆ و 268 دەقی سێ زمان پشکنران. وێنە بچووکەکان، دەست‌لێدان و
ڕێگەپێدانی بەشێک لە وێنەکان لە مۆبایلی ڕاستەقینە هێشتا تاقی
نەکراونەتەوە.

## نوێکاری 7.9.1

قەبارەی APK بە فایلێکی پڕکەرەوەی 1 MiB گەورە کراوە؛ ئەمە هیچ خێرایی یان
تایبەتمەندییەک زیاد ناکات. پیشاندانی قەبارەکان وەک پێش 7.9 بە GB
گەڕێنراوەتەوە؛ هیچ دەستکارییەک لە ناوەڕۆک یان قەبارەی ڕاستەقینەی وێنە و
ڤیدیۆ ناکرێت. مێژووی پەیوەندی وەک SMS بە یەک کرتە تۆمارە بەردەستەکان
هەڵدەبژێرێت، تا سنووری 5000 تۆمار؛ کرتەی دووەم هەڵبژاردنەکە لادەبات.

## ڕووکار و ناوەڕۆکی 8.0

سەرەتای نوێ بە وێنەی دوو مۆبایل، کارتی سەوز و مۆر بە دەقی ڕوونتر،
نیشاندەری سێ هەنگاو، کارتی هەڵبژاردن و کورتەی زانیاری گواستنەوە.
دەقەکانی SMS و مێژووی پەیوەندی لە هەرسێ زمان ڕاست کراونەتەوە. قەبارەی
ڕاستەقینەی فایلەکان ناگۆڕدرێت. ئەم وەشانە پێکهاتووە و دەقەکان پشکنراون؛
پشکنینی ڕووکار لەسەر مۆبایل هێشتا ماوە.

## وەرگرتن بە USB --- 8.1

لە مێنیوی سەرەکی «وەرگرتن بە USB-C» شاشەی تایبەت بە کەیبڵ دەکاتەوە.
کەیبڵی داتا پەیوەست بکە، لە کۆنەکە فایلەکان هەڵبژێرە و ناردن بە USB
دابگرە؛ لە نوێکە دەستپێکردنی وەرگرتن دابگرە. ڕێگەدانی USB قبووڵ بکە. ئەم
بەشە هۆتسپۆت ناکاتەوە. پەیوەندی بە کەیبڵ هێشتا لەسەر دوو مۆبایلی
ڕاستەقینە تاقی نەکراوەتەوە.

## 8.1.1

لە شاشەی مۆبایل بۆ مۆبایل: یەکەم «من مۆبایلە تازەکەم» بۆ وەرگرتن؛ دووەم
«من مۆبایلە کۆنەکەم» بۆ ناردن.

## 8.2 --- پەیوەندی، هەڵبژاردن، گواستنەوە

لە مۆبایلە کۆنەکە سەرەتا QR سکان بکە یان USB پەیوەست بکە، دوای پەیوەندی
داتا هەڵبژێرە و بەردەوام بە. نوێکە چاوەڕوانی هەڵبژاردن دەکات. بۆ هەردوو
مۆبایل ئەم وەشانە دابمەزرێنە.

## 8.3 --- پەنجەرەی وەرگرتن

کاتێک مۆبایلی کۆن داتا دەنێرێت، لە مۆبایلی نوێ کارتی پشتڕاستکردنەوە
دەردەکەوێت. ژمارەی فایل، قەبارەی تەواو و تا 3 ناوی فایل نیشان دەدات.
«وەرگرتن» یان «ڕەتکردنەوە» بە دوگمەی گەورە هەڵبژێرە.

## 8.4 --- هەڵبژاردن و خێرایی

بەشەکان بە جیا: وێنە، ڤیدیۆ، فایل، APK، دەنگ، ژمارە و نامە. دوای
هەڵبژاردن بەردەوام بە تا پەیوەندی و گواستنەوە دەست پێ بکات. دۆخی Ultra
Fast پشتیوانی Wi-Fi 6/6E ی مۆبایل دەناسێنێت؛ باندی کۆتایی لەلایەن
Android و پشتیوانی هەردوو مۆبایل دیاری دەکرێت.

------------------------------------------------------------------------

# Project document: `TECHNICAL.md`

# rebaritclone 7.8 test

Native Android application (Java, minSdk 26, compileSdk 35, targetSdk
34). Original interface with separate role, category, pairing, transfer
and result screens. Local TCP on port 39841. Existing app ID and
development signing key retained for in-place upgrade; versionCode 19.

## Pairing and transport

Receiver enumerates IPv4 Wi-Fi link addresses and hotspot interfaces,
excluding cellular/VPN interfaces. A local-only QR contains a version
tag, up to eight RFC1918 addresses and a fresh 128-bit secret. The
camera scanner and image picker decode QR using embedded ZXing core
3.5.3 (Apache-2.0; license in third-party). No external scanner, Play
Services or online QR generation is used. Clipboard pairing is a
fallback; mark the clipboard payload sensitive on Android 13+.

HotspotLink requests a LocalOnlyHotspot on the receiver. Its v3 QR
carries SSID and WPA2 credentials plus private addresses and the
transfer secret. Android 10+ senders use WifiNetworkSpecifier without
NET_CAPABILITY_INTERNET, with system user consent, then bind transfer
sockets to the returned Network. No default cellular socket fallback is
used. Older senders and OEM failures use a manual hotspot/Wi-Fi flow.
The app never fetches an online service. Nearby Wi-Fi permission is
requested on Android 13+; fine/coarse location permissions on older
systems are required by Wi-Fi APIs, not used to read geographic
location. QR credentials are secrets: share only between owned phones.

The local hotspot's band is chosen by Android. The normal
local-only-hotspot path does not force 5 GHz. Performance mode first
tries a 5 GHz Wi-Fi Direct group where Android reports support, showing
an explicit failure and user-selected fallback when creation fails. Its
manual flow suggests 5 GHz only where both devices support it. Network
request and hotspot reservation are released on
completion/cancellation/destruction. Sender confirms receipt of the
final batch ACK before receiver tears down its hotspot. OEM interface
names, hotspot availability and physical network behavior remain
untested on devices. Wi-Fi Direct group-owner creation and an
experimental AOA USB transport are now implemented, as detailed below.

Wire v4 uses CP04 magic, a random 256-bit receiver session challenge,
HMAC-SHA256-derived independent AES-256-GCM directional keys and
monotonic 96-bit nonces. Each file has an authenticated EOF, SHA-256
digest and acknowledgement. Metadata is sent as separate bounded
records, avoiding the original single-frame manifest limit. Count limit:
10000 files; frame limit: 1 MiB; file chunks: 256 KiB. The receiver
rejects old wire versions and unauthenticated attempts and waits for
another client until timeout. Both phones must upgrade. No forward
secrecy or third-party security audit is claimed.

## Selection and storage

Category requests use just-in-time READ_MEDIA\_\* / legacy
READ_EXTERNAL_STORAGE permissions. Android 14 selected-visual-access is
supported and explicitly reported as partial access. MediaStore lists
only accessible indexed media. Manual file selection uses SAF without
broad storage permission. Duplicate source URIs are removed before
transfer. Contacts require READ_CONTACTS and are exported by the
platform vCard provider to an app-private cache file; receiver offers
ACTION_VIEW for the user to import through Contacts, not silent database
restoration.

Android 10+: received images, videos and audio use the corresponding
MediaStore collection and rebaritclone/batch directory, with IS_PENDING
until verification and output close. Other files use
MediaStore.Downloads. No WRITE_EXTERNAL_STORAGE permission is needed.
API 26-28 uses a user-selected SAF directory with .partial then rename.
All copying is streamed, source files are never deleted. Each batch uses
a new directory. Failed transfers attempt to delete the incomplete
destination; process death may leave pending/partial entries. A lost
acknowledgement after commit may leave a completed file despite sender
reporting failure.

MediaStore metadata/permissions can redact location data; original EXIF,
timestamps, albums and filesystem layout are not guaranteed preserved.
There is no automatic private app data, WhatsApp, settings or account
migration. Selected SMS and call records can be exported as JSON
backups, but are not restored to the native Phone/Messages databases.
Contacts must be explicitly imported and may duplicate existing entries.
Version 6 supports in-Activity session resume; there is no deduplication
across independent batches or recovery after process death.

## Lifecycle and build

The Activity keeps the screen awake during a session; a foreground
transfer service is not implemented. Keep both apps open. Stop closes
sockets and releases pending approval. Process death and OEM
battery/network behavior remain device-test requirements. QR scanner
releases the camera on pause. Read timeout is 180 seconds, user
acceptance 150 seconds, listener lifetime ten minutes. No
application-level socket write deadline exists; Stop closes the socket.

APK built using the included SDK-only build-local.sh (javac, aapt2, d8,
zipalign, apksigner); Gradle project also supplied. Bundled ZXing core
is included in both build paths. Public development keystore password:
android, alias: androiddebugkey. Use a separate private release signing
setup for production. No Play Store publication performed.

## Verification and limits

-   Full Java compilation, resources, DEX and APK signature
    verification.
-   Encrypted 2 MiB duplex payload, empty/end records, wrong key,
    invalid code and tampering rejection.
-   Pairing local-address validation and invalid payload rejection.
-   QR encode/decode through both bitmap and NV21 luminance paths, at
    280/660 pixels and four rotations.
-   2000-file Unicode metadata stream exceeding old 128 KiB manifest
    cap; disconnect handling.
-   NOT RUN: physical-device installation, native UI screenshots, camera
    focus/preview, MediaStore/SAF behavior, Contacts import, two-device
    Wi-Fi/hotspot transfer and OEM lifecycle tests. Camera QR tests use
    synthetic frames and do not establish physical camera performance.

Primary references:
https://developer.android.com/training/data-storage/shared/media
https://developer.android.com/training/data-storage/shared/documents-files
https://github.com/zxing/zxing

## Buffered transport update

Network input/output use 512 KiB buffers, file I/O uses 256 KiB buffers,
socket buffers request 1 MiB (actual size controlled by OS). Data frames
use a writeBuffered method to avoid per-chunk flush and Arrays.copyOf;
EOF/control writes flush explicitly. AES-GCM Cipher instances are reused
but initialized with unique monotonic nonces. Peak buffers stay bounded
independent of file size. SHA-256 remains enabled. Wire v4 is
intentionally incompatible with earlier APKs; upgrade both phones.

FastStreamTest verifies 64 MiB plus a short 37-byte tail, digest, EOF
flush and acknowledgement. Host loopback timing is a diagnostic, not
evidence of real-phone throughput or an Ultra Fast guarantee. Actual
two-phone hotspot/system-consent testing has not been performed.

## Version 4 changes

Version 5 defaults the new fast5 preference to true, including upgrades
from v4. New-phone role immediately starts permission → Wi-Fi settings
if disabled → location settings on API \<33 if disabled → host creation
→ QR. System permissions remain user-granted. Settings return checks
prerequisites instead of repeatedly opening a cancelled panel; API26--28
folder selection resumes setup. USB/manual setup remains accessible from
home.

Performance mode requests only a 5 GHz P2P group (API29+), verifies
WifiP2pGroup.getFrequency before showing QR and does not silently fall
back to 2.4 GHz. Unsupported/failed/unknown-band cases show explicit
retry, normal-hotspot, manual or USB choices. Normal mode retains
LocalOnlyHotspot → auto-band P2P fallback. A 45-second setup deadline
reports failure instead of indefinite waiting. Receiver diagnostics use
only the created group frequency; unknown hotspot band is explicitly
unknown. Sender diagnostics use only WifiInfo from its bound Network,
never unrelated infrastructure getConnectionInfo. These changes do not
establish measured throughput improvement.

High performance uses 1 MiB file chunks and file buffers instead of 256
KiB, within the same 1 MiB wire frame bound, and requests
WIFI_MODE_FULL_HIGH_PERF only during Wi-Fi transfer. This is a tuning
option, not a measured improvement or Ultra Fast guarantee; Android/OEMs
may ignore/deprecate the lock. The option may increase memory/power
usage. The user supplied a v3 screenshot showing approximately 7.7 MB/s
on actual phones; that confirms a v3 transfer was in progress, not its
completion or the bottleneck. No controlled before/after speed test on
their devices was possible.

## USB AOA prototype

New phone is USB host; old phone is Android Open Accessory. UsbLink
obtains explicit Android USB permissions, probes AOA version with vendor
request 51, supplies all identifying strings including version with
request 52, starts accessory mode with request 53, then handles
re-enumeration and fresh permission. Accessory attach metadata matches
rebaritclone / Phone Transfer / 1.0. Host selects only AOA bulk
interfaces, excluding ADB. Old phone opens its accessory
ParcelFileDescriptor. USB debugging is not used. Data cable,
host/accessory capabilities and correct USB roles are required; not all
Android phone pairs support this.

UsbSession bootstraps a fresh key over the physically connected cable,
then uses SecureChannel and exactly the same shared
sendFiles/receiveFiles routines as Wi-Fi (manifest, acceptance, digests
and acknowledgements). Physical cable and user USB permissions are the
trust boundary: the key bootstrap is not authenticated against a
malicious physical USB interposer. No claim of protection from such an
interposer is made. USB input preserves byte-stream semantics across
bulk reads, and host bulk requests are capped at 16 KiB for
compatibility with older Android APIs. AOA is not MTP and cannot
concurrently expose the same Android device as MTP.

USB setup polls for up to two minutes; host bulk I/O has 180-second
timeouts. The accessory FileDescriptor side has no application-level
read deadline; Cancel closes descriptors, and unplug normally surfaces
an I/O failure. Activity/foreground-only lifecycle limitations remain.
AOA and physical USB-C throughput have not been measured. A USB-C
connector does not establish a guaranteed data rate.

UsbSessionTest uses fragmented simulated streams, full 1 MiB encrypted
records, a short tail, SHA-256, final acknowledgement and invalid-header
rejection. It verifies only the transport-independent session/record
layer, not UsbManager, AOA switching, permissions, USB roles, host bulk
I/O or physical performance. Real two-phone hotspot/P2P/USB/UI tests
remain outstanding.

Version 5 verification: Android build and signing checked. Physical
permissions/settings return, 5 GHz P2P creation and before/after
throughput remain untested. Official band API:
https://developer.android.com/reference/android/net/wifi/p2p/WifiP2pConfig.Builder#setGroupOperatingBand(int)

## Version 6: interrupted-transfer resume and QR speed control

High-performance control is removed from home/receiver setup and placed
below the QR. Switching it cancels the waiting listener, releases the
current host, and starts a new host/QR with the selected preference.
Both phones must use v6: CP04 and v4 key-derivation context reject
earlier wire formats.

Sender retains a random batch UUID while a transfer is incomplete, tied
to ordered source URI/name/MIME/size metadata. Receiver retains UUID,
manifest, publication directory and file entries in Activity memory.
Unknown/changed batches require acceptance and replace the previous
partial session. Socket-only errors get two automatic sender retries
while the network is still available; receiver keeps its listener for
reconnection for up to ten minutes. Lost Wi-Fi network/hotspot requires
new pairing via Resume; USB requires reconnecting and selecting USB
again. Original file selections must remain unchanged. Reconnecting an
already accepted UUID+manifest does not prompt again.

ResumableFile stages only fully authenticated decrypted records in an
app-cache file. Each retry negotiates byte offset, completion flag and
SHA-256 prefix digest. Sender reads/hash-checks the retained prefix
before transmitting remaining bytes. Mismatched partial prefix is
cleared and the session stops with SOURCE_CHANGED; completed entries are
not overwritten. Full digest and declared size are verified before
publication to MediaStore/SAF. Entry is marked done before ACK, allowing
a lost per-file ACK to skip re-publication. Completed prefix checks
require local reads but no retransmission of file contents. Resumed
bytes are excluded from reported speed. Empty files and unknown sizes
are supported.

A staged file plus its final destination temporarily require up to twice
that file's space. Publication copies add I/O and are not a throughput
optimization. Partial cache files may be evicted by Android; a missing
partial starts at zero. UUID/commit ledger is not durable: Activity
destruction, process death or device restart loses resume state. No
crash-safe exactly-once publication is claimed. Orphan cache files are
subject to Android cache cleanup. User cancellation preserves this
Activity's checkpoint for an explicit retry. Source changes are
rejected, and source files are never modified.

ResumeTest exercises the production ResumableFile and SecureChannel over
local sockets: interruption after 1 MiB, retained byte offset,
reconnect/tail/digest, lost publication ACK without duplicate publish,
corrupt prefix rejection/reset, subsequent retry, and empty-file
deduplication. Android UI lifecycle, settings, Wi-Fi/USB reconnect and
performance still require physical device testing. User screenshot
confirms v5 created a 5765 MHz Wi-Fi Direct group on their phone; it
does not establish throughput.

## Version 7: selected application transfer and consent-based installation

Apps category queries visible MAIN/LAUNCHER activities through an
explicit manifest `<queries>`{=html} intent, deduplicates packages, and
excludes system apps and rebaritclone itself. No QUERY_ALL_PACKAGES
permission is used. A multiple-choice list exports only selected apps.
Each .rbapp is a bounded ZIP containing byte-identical
ApplicationInfo.sourceDir (base.apk) and splitSourceDirs (split-N.apk).
Export checks lastUpdateTime/version before/after to reject concurrent
package updates. No private app data, OBB, asset packs, accounts or
credentials are read. Export snapshots consume sender cache space.

Verified publication of .rbapp/.apk received files adds their URI to the
current batch's install queue. After successful batch transfer,
AppInstallActivity opens automatically. On partial-transfer failure the
result page allows installation of already verified received apps.
Installation uses PackageInstaller MODE_FULL_INSTALL sessions, streams
base and all splits together, fsyncs and closes all outputs before
commit, and requests USER_ACTION_NOT_REQUIRED on API31+ subject to
Android enforcing eligibility. REQUEST_INSTALL_PACKAGES is declared;
canRequestPackageInstalls gates the user-controlled unknown-sources
settings screen. No silent install, root, accessibility automation or
device-owner bypass is used.

Installer callbacks use a mutable app-scoped PendingIntent with a
per-Activity random action and a non-exported dynamic receiver on
API33+. Session IDs are checked. Pending user action opens Android's
provided confirmation intent only while this Activity is resumed.
Success proceeds to the next app; terminal install failures/denial and
staging failures are recorded as skipped and advance automatically.
Unknown-source permission denial pauses the queue. Existing apps are
never uninstalled to resolve a conflict. Installer Activity is not
exported. Cancel/destruction abandons its active session. A restored
Activity does not automatically replay the queue; the user must resume
explicitly. Process-death recovery of the transfer/install queue is not
guaranteed.

AppBundle accepts only base.apk and numbered split APK entries, rejects
duplicates/path traversal/extra entries/missing base, bounds entry count
to 256 and cumulative decompressed bytes to 16 GiB, and never extracts
ZIP paths to the filesystem. Validation must complete before a
PackageInstaller session commits; Android validates actual APK
structure, package/split consistency, signatures, ABI and compatibility.
Standalone APKs selected through Files use a single session entry.
Copied device-specific splits can be incompatible with a different
device; no installability guarantee is made.

AppBundleTest: actual signed test APK + synthetic split byte-for-byte
roundtrip, base-only archive, malformed/truncated container,
duplicate/path traversal/extra entry/missing base/count overflow and
incomplete sink staging rejection. Full Android compile/signature
verification passes. Physical app list, unknown-source settings, Android
install/update confirmation, split compatibility, cancel/status
delivery, and low-storage/OEM lifecycle behavior have NOT been
device-tested.

Official references:
https://developer.android.com/reference/android/content/pm/PackageInstaller.Session
https://developer.android.com/reference/android/content/pm/PackageInstaller.SessionParams#setRequireUserAction(int)
https://developer.android.com/training/package-visibility/declaring

## Version 7.1 installation queue

Terminal success/skip outcomes and counts are visible in the Activity
and saved in its instance state. Rejected/incompatible/staging-failed
apps do not block subsequent entries.
UPDATE_PACKAGES_WITHOUT_USER_ACTION plus USER_ACTION_NOT_REQUIRED
requests the documented Android12+ automatic-update path, but Android
determines eligibility (installer/update ownership and installed app
target SDK conditions). It does not enable unattended first-time app
migration. Pending user-action callbacks are still handled normally. No
Play Store approval status is inferred from an APK or app listing, and
no installer identity is forged. System install restrictions, user
denial and signature checks are honored. Build/signing verified; real
system approval/skip/automatic update behavior is not device-tested.

## Version 7.2 selection and live statistics

TransferStats computes manifest byte totals, unknown-size state and
completion-prefix counts for photos/videos/apps/other. MIME
classification includes common media-extension fallback. Category cards
and deduplicated selection/connection summaries show decimal GB. During
transfer, both roles show total/moved/remaining bytes, acknowledged file
totals, remaining per-type counts, average decimal MB/s excluding
resumed bytes, and estimated time remaining. An in-flight file remains
pending until final completion; percentage is capped below 100% before
all files finish. Unknown total size disables a fabricated remaining
byte count or ETA; tiny positive sizes display \<0.001 GB. ETA has a
three-second warmup and indicates verification/publication when all
known bytes have arrived but files are not completed. This does not
change wire format or copying semantics.

TransferStatsTest passes mixed-type totals, completion boundaries,
partial/resumed byte remaining, unknown sizes, empty input and decimal
unit formatting. Full Android compilation and APK signing pass. Native
layout on physical devices has not been visually tested.

## Version 7.3: Kurdish, English and Arabic

Home has a permanently multilingual language selector (native language
names). UiText stores the selection in private language/selected
SharedPreferences, defaults to Kurdish, and updates the home screen
without recreating MainActivity or dropping file selection.
MainActivity, scanner and installer initialize their UI language from
that preference. Root layout direction and in-app dialog configuration
follow the choice: English LTR, Kurdish/Arabic RTL. Each device selects
independently.

229 unique app-owned strings across MainActivity, AppInstallActivity,
ScanActivity, UsbLink and HotspotLink are localized via stable IDs.
Dynamic text fragments are translated before concatenation; file/app
names, credentials, protocol fields and diagnostic codes are not passed
through string replacement. Translations.java is generated by
localization/generate.py from ckb.json and translations.tsv; both are
included in source. The existing SDK-only builder does not need
generated Android R.java for these catalogs. Android-owned
permission/install/settings UI keeps its system-selected language.

TranslationsTest verifies all 229 entries in all three languages, no
Kurdish/Arabic script in English strings, fallback, direction, line
breaks and spacing of dynamic fragments. Source audit confirms no
unlocalized Kurdish UI literals except intentional native language
labels. Full APK build/signature verification passes. No physical UI
screenshots or runtime language persistence test on an Android device
was available; these remain device-test items. Transfer protocol and
app-install policy are unchanged.

## Version 7.4: selected personal records

Contacts, recent calls and SMS each have a separate multi-choice picker
with search, select-all-visible and clear. Selection persists during the
current Activity session. Contacts export selected provider-generated
VCF records; SMS/calls export version-1 rebaritclone-records UTF-8 JSON
with IDs, timestamps and original fields. One immutable cache snapshot
per selected category enters the existing transfer pipeline. The
category shows record count; transfer counts snapshot files. Failed
export preserves the previous selection and discards the partial
snapshot. Receiver shows backup-only guidance; existing explicit VCF
import remains available.

READ_CONTACTS, READ_CALL_LOG and READ_SMS are requested on demand.
READ_SMS/READ_CALL_LOG are hard-restricted Android permissions and may
be blocked by the OS/installer; denial is explained. No default-SMS
role, native write, SMS send or permission bypass is implemented. JSON
is not claimed compatible with third-party restoration tools.
MMS/RCS/WhatsApp excluded. Pickers cap at 5000 contacts / newest 5000
calls or SMS and show a limit notice. Search operates on displayed
previews, not the full SMS body. Deleted/unreadable rows fail export
rather than silently omit chosen data.

246 translated strings now cover Kurdish, English and Arabic. Synthetic
RecordJson output independently parsed with Python verifies Unicode,
control escaping, string phone numbers, nulls, long timestamps, selected
fixture exclusion, counts and empty backups. This tests serialization,
not Android provider or picker behavior. Full APK builds and signs.
Physical permission, provider compatibility, picker and two-device tests
remain unrun.

## Version 7.4.1: Activity-backed localized dialogs

UiText.context previously returned Activity.createConfigurationContext,
a standalone resource context without the Activity WindowManager/window
token. Every localized AlertDialog used it, including language selection
and both the calls picker and permission-denial alert. This is a
concrete BadTokenException risk consistent with the reported exits, but
no device stack trace was available to confirm the observed exception.
It now requires an Activity and returns ContextThemeWrapper with that
Activity as its base, its existing theme and an override containing only
locale/layout direction. This preserves Activity window services while
localizing dialog resources. All callers compile against the
Activity-only signature. No broad catch hides dialog failures; record
permission/export behavior is unchanged.

Build/signing, certificate continuity and translation checks pass. No
emulator/system image or attached Android device is available. Required
device regression: open/dismiss language picker, switch all three
languages and restart; open recent calls with permission allowed/denied;
open SMS/contacts pickers, search/select/cancel/apply; confirm denial
alerts and other localized dialogs remain visible without app exit.

## Version 7.5: role-entry permission queue and transfer notifications

Role cards start a sequential, SDK-aware runtime permission queue.
Granted groups are skipped. Denial/swipe advances once, with a final
optional app-settings/continue screen; it never loops until consent.
Receiver requests notification and Wi-Fi discovery permissions only.
Sender also requests media, camera and read-only contacts/calls/SMS.
Android 12 and earlier request coarse+fine location together; 13+
requests Nearby Wi-Fi, media types and POST_NOTIFICATIONS; 14+ includes
selected-visual-media support. No broad system-file, overlay or SMS-send
permission. SAF remains the documents route, legacy receiver folder
selection stays in hotspot setup, and package-install access stays at
installation. Restricted call/SMS permissions may remain unavailable.

Notification channel `transfer` has LOW importance and PRIVATE
lockscreen visibility. Transfer updates are throttled to 1.5 seconds,
with immutable content PendingIntent and no filenames/message bodies.
Final notification reports success/failure; progress notice is removed
when an active Activity is destroyed. No foreground service or
process-death resume was added; keeping the app open remains required.
Permission prompts and notification display are ultimately controlled by
Android, including suppressed repeated denials/channel blocking.

PermissionPlanTest covers role/SDK boundaries
26,28,29,31,32,33,34,35,36, duplicates and forbidden unrelated grants.
All 252 translations compile and validate. APK signing and upgrade
certificate continuity pass. Runtime permission callbacks,
denied/restricted/selected-photo branches, settings return, notification
delivery and physical hotspot flow remain device-test requirements.

## Version 7.5.1: transient Wi-Fi Direct BUSY recovery

Screenshot on Samsung SM-A566B Android 16 shows P2P_ERROR_2. Android
defines 2 as BUSY, not lack of 5 GHz support. createGroup now retries
BUSY with 750/1500/3000 ms backoff; each delayed attempt checks the
session generation. Other errors are not retried. After forced-5GHz BUSY
exhaustion, one automatic local-only-hotspot attempt is made with
require5 cleared. If local hotspot fails, the existing AUTO-band P2P
fallback may run with the same bounded retries, then reports failure; no
loop back to local hotspot. Successful fallback is explicitly labeled on
QR/receiver diagnostics and never asserts a 5 GHz local hotspot.
Existing fast-mode preference remains selected for future attempts.
Stale createGroup success no longer removes a potentially newer group.
Cancelling remains generation-guarded; late success cleanup and actual
OEM lifecycle behavior require physical tests.

P2pRetryTest verifies bounded BUSY budget and immediate permanent-error
termination. Full APK build, signing, upgrade identity, and 253
localized strings pass. No device or emulator was available for
asynchronous Wi-Fi manager callbacks, successful local-hotspot fallback,
cancellation races or QR pairing. Existing 45s outer timeout remains.
Reference:
https://developer.android.com/reference/android/net/wifi/p2p/WifiP2pManager#BUSY

## Version 7.6: concise transfer screen and recognizable app selection

Transfer details now show only total GB, moved GB, average MB/s and
estimated remaining time; retain percentage/progress, hide current
filename/count status and remove transfer-screen band and
remaining/category detail rows. QR band diagnostics are retained. Result
page uses acknowledged prefix counts from TransferStats for completed
photos/videos and a separate monotonic transferStarted timestamp set at
first resetTotals per job. Automatic retries preserve that timestamp;
manual restarted jobs reset it. Preparation, pairing and installation
time are excluded. Stats/timer are cleared at job start to avoid
old-batch result data.

SMS/calls first picker opening defaults all loaded records selected;
existing saved selections are retained. The 5000-record cap remains
disclosed. App picker replaces package-code strings with sorted human
labels, provider icons and checkboxes. Icons load off UI thread with
default-icon fallback. Only existing visible non-system launchable apps
remain eligible; bundle format and install semantics are unchanged.

Build/signature and upgrade certificate pass. Existing TransferStatsTest
covers acknowledged boundaries, mixed categories, empty and
partial/resumed data. All 256 translations pass. Actual list
rendering/taps, default check marks and final duration presentation
still require device validation.

## Version 7.6.1: received file browser and direct SMS category toggle

Track successfully published receiving URIs with original display
names/MIME in insertion order. Show files opens a session-local list on
the receiver result screen, including committed files from interrupted
transfers; new incoming batch clears it and resumed acknowledgements do
not add duplicates. ACTION_VIEW grants read-only URI access via
flags/ClipData; rbapp/APK entries go through the existing installer with
just the selected package. Missing viewer/denied access shows an
explanation. No broad storage access added. Activity state is not
persisted; external Files/Gallery remain the access path after process
death.

SMS category now directly exports loaded rows and selects its snapshot
without a picker. Second tap clears selection. Existing Android
permission gating, background export and failure preservation remain. A
toast discloses the 5000-row cap when reached. Contacts/calls selection
is unchanged. Build/signatures, upgrade certificate and 258 translations
pass; no real-device picker/open-file/one-tap-SMS test was available.

## Version 7.7: reference-video landing and role screens

Inspected the 30.5s attached EasyShare demonstration via frames.
Implemented a dark landing page with original Canvas purple ribbon, teal
Mobile bo Mobile card (replaces Device clone wording) and purple File
transfer card. Both lead to dark role screens with explicit old/new
phone choices connected to existing permission queue and sender/receiver
paths. Overflow offers actual language/help/alternate receiving
functions; no dummy history or PC/iPhone migration options were added.
Header retains rebaritclone. Only landing/role screens adopt the dark
theme; existing functional screens retain their established layout and
reset system-bar colors. Scrolling accommodates smaller displays and
wrapping. No proprietary artwork or source was copied.

Full Android compile/signatures, upgrade certificate and 264
translations pass. No Android emulator or device was available for pixel
comparison, navigation taps or native rendering; the reference video was
visually inspected, not used as proof of generated app appearance.

## Version 7.8: dark file selection gallery

Localized phone-to-phone title. Purple file card enters sender
permission setup then FileGallery; green card retains old/new device
flow. Native ListView virtualizes date headers and four-column thumbnail
rows, with per-item, per-day and select-visible controls, filename
search, photo/video filter, duration overlays and long-press
ACTION_VIEW. Audio tab loads audio rows. Files opens SAF; Apps/Contacts
route to existing selectors and return to gallery. MainActivity keeps
selected gallery URIs in its existing groups, deduplicating at transfer
preparation. Footer reports all groups and continues to existing
pairing.

MediaStore reads on a dedicated single worker; thumbnail pool has two
workers and a bounded 64-task queue, 12MiB bitmap LRU and
generation/closed guards. Every main page navigation shuts gallery
workers down; provider results check generation before touching UI.
Queries respect platform grants and show errors/empty/cap notices; max
10,000 loaded entries per current media/audio view. No extra storage
grants, database mutations, or persistent transfer-history feature
added. Date grouping uses date_added and local calendar date. Media
query cap may omit additional records; this is disclosed.

APK build/signatures, upgrade identity and 268 strings verified. No
real/emulated Android UI, thumbnails, per-day taps, partial-media
grants, SAF returns, large-gallery performance or video duration overlay
rendering was tested; these remain physical validation tasks. Tabs
invoking existing app/contact dialogs and system document UI are
functional routes rather than copies of the reference app's internal
implementations.

7.9: decimal MB below 1 GB across selection, transfer and approval
sizes; GB retained for larger amounts. Calls now directly export all
loaded rows as SMS does, with the same 5000-row cap and permission/error
handling. Second tap clears selection.

7.9.1: reverted MB display change to prior GB formatter; kept call
select-all toggle. User requested APK size over 1 MB: included
deterministic inert 1 MiB package-padding.bin asset, with no runtime use
or performance benefit. Manual and Gradle builds include assets. Signed
APK build passed; not device tested.

8.0: refreshed native home illustration and contrast, three-step
active/completed indicators, category selection borders/ripples,
responsive-height buttons, transfer/result information cards, gallery
search field. Corrected one-tap call/SMS guidance in all locales. Signed
build and translation/TransferStats tests passed. No emulator or
physical-device visual verification; system pickers/install dialogs
retain OS UI. Transport and media byte counts unchanged.

8.1: dedicated USB receiving entry from home menu, cable illustration
and localized steps. USB wait page has retry; back returns USB setup.
Android 8/9 folder success resumes USB and cancellation returns USB
setup. Signed build, 278 translations and static USB-only route checks
passed; physical USB transport/UI not tested.

8.2: Connect \> Select \> Transfer. Sender permissions route to
connection page. Wi-Fi verifies encrypted peer handshake then closes
preflight TCP while retaining network; receiver accepts subsequent
transfer connection (10-minute accept window). USB retains authenticated
channel while sender selects. Receiver selection waiting screen.
Connection page clears stale sender state. Signed build, 281
translations and simulated UsbSessionTest passed. Physical-device
connection-first flow not tested.

8.3: replaced incoming-transfer AlertDialog message with a custom
RTL/LTR-aware confirmation card. It shows receive icon, file count,
known byte total and unknown-size marker, up to three ellipsized file
names, a remainder label, and two 58dp action buttons. Confirmation
latch/timeout/cancel behavior is preserved. Signed build and 284
translation test passed; no device UI test.

8.4: selection page has grouped headings and visual cards for photos,
videos, files, APK apps, audio, contacts, calls and SMS. Hotspot status
includes an Android capability message for 6/6E, 5 GHz or fallback.
Wi-Fi Direct configuration can request only 5 GHz or AUTO in Android's
public API, so the app reports/detects support but cannot force 6/6E.
Signed build and 290 translation test passed; device radio behavior
remains untested.

------------------------------------------------------------------------

# Project document: `VALIDATION.txt`

rebaritclone 7.8-test / versionCode 19 PASS: full Android Java
compilation, resources, DEX, APK v2/v3 signatures PASS: 2 MiB encrypted
duplex transfer, EOF records, invalid code, wrong key, ciphertext
tampering rejection PASS: private-address-only pairing validation PASS:
QR decoding via image and camera luminance paths, 2 sizes, 4 rotations
PASS: 2000-file Unicode manifest larger than old frame limit; disconnect
detection NOT RUN: real Android installation, native UI rendering,
physical camera, two-device Wi-Fi/hotspot, MediaStore/SAF, Contacts
import and OEM lifecycle behavior PASS: 64 MiB + 37-byte buffered
encrypted stream, complete length and digest verified PASS: hotspot QR
SSID/password Unicode roundtrip and invalid credential rejection NOT
RUN: physical local-only hotspot, system Wi-Fi consent, no-SIM
two-device transfer or real-phone throughput PASS: simulated USB
bootstrap, 1 MiB encrypted records, fragmented reads, tail/digest/final
ACK and invalid-header rejection NOT RUN: physical USB-C/AOA,
permission/re-enumeration, Wi-Fi Direct group creation, 5 GHz selection
or before/after phone throughput

Version 5: permission-to-hotspot flow and authoritative band reporting
implemented; no measured speed increase claimed. Existing protocol tests
above describe unchanged transport coverage. New physical Android flow
and 5 GHz device tests NOT RUN.

Version 6 PASS: production encrypted mid-file resume at 1 MiB, SHA-256
prefix/full validation, 37-byte tail, lost ACK deduplication,
corrupted-prefix reset/retry and zero-byte file. Version 6 PASS:
ProtocolTest and UsbSessionTest with CP04 transport. Version 6 NOT RUN:
physical Android automatic reconnect, QR mode switch lifecycle,
low-storage and Activity/process death behavior. Resume state is
Activity-scoped, not persistent across app restarts.

Version 7 PASS: AppBundle real signed APK and split byte preservation,
base-only, invalid/missing/duplicate/traversal/extra/count/truncated
inputs and incomplete sink rejection. Version 7 PASS: full Android
compile, resources, DEX and APK signature verification. Version 7 NOT
RUN: real phone app selection, PackageInstaller consent/status flow,
unknown-source settings, split install compatibility or two-device app
migration.

Version 7.1: automatic advance on install rejection/failure and outcome
counts; OS-eligible automatic updates requested. Full build/signature
verified; real-device callback/skip/auto-update tests NOT RUN.

Version 7.2 PASS: TransferStats mixed types, pending/complete boundary,
partial/resumed sizes, unknown/empty data and decimal GB. Full Android
build and signing PASS. Physical UI visual test NOT RUN.

Version 7.3 PASS: 229 strings in all three languages, English script
isolation, RTL/LTR mapping, fallback, multiline and dynamic-fragment
spacing; source coverage audit. Full APK build/signature PASS. Physical
language switching/persistence and layout tests NOT RUN.

Version 7.4 PASS: full APK build/signing; all 246 translation entries;
synthetic RecordJson independently parsed for Unicode/control escaping,
string numbers, long timestamps, nulls, counts, selected fixture
exclusion and empty records. Version 7.4 NOT RUN: Android
contacts/SMS/call providers, runtime/hard-restricted permissions, picker
interaction, receiver backup guidance and two-device transfer. Calls/SMS
are JSON backups only; no native restoration implemented.

Version 7.4.1 PASS: full Android build/signature; Activity-only
localized-context call sites compile. Translation catalog tests pass;
signing certificate retained. Version 7.4.1 NOT RUN: physical/emulated
dialog open/language switch/calls permission paths. No device crash
stack trace supplied; BadTokenException is a code-derived diagnosis, not
a captured exception.

Version 7.5 PASS: PermissionPlanTest sender/receiver and SDK boundaries
26--36, permission group uniqueness, absence of
overlay/protected-file/SMS-send access. 252 localized strings. Full APK
build/signature and upgrade certificate continuity. Version 7.5 NOT RUN:
Android runtime request queue/callbacks, denied or selected-only access,
settings return, real notification visibility and post-permission
hotspot startup. Activity-scoped transfers still require app kept open.

Version 7.5.1 PASS: bounded BUSY retry policy, permanent-error no-retry,
full APK build/signature, upgrade certificate, 253 translations. NOT
RUN: real Wi-Fi Direct recovery/local hotspot fallback, cancellation
races, QR pairing on Samsung Android 16.

Version 7.6 PASS: full APK build/signature, upgrade certificate, mixed
media acknowledged count tests, 256 translations. NOT RUN: physical app
icon picker/check states, default SMS/calls selection, concise progress
and final summary display.

Version 7.6.1 PASS: full APK build/signature, upgrade certificate, 258
translations. NOT RUN: committed-file list/viewer intents, selected
package installer launch, direct SMS export/toggle on Android.

Version 7.7 PASS: full APK build/signature, upgrade certificate, 264
translations; reference-video frames inspected. NOT RUN: native dark
screen rendering/scrolling, menu/role taps, visual comparison on device.

Version 7.8 PASS: full APK build/signature, upgrade identity, 268
translations. NOT RUN: Android gallery/date selection/thumbnail loading,
tabs, search/filter interactions, partial media permissions, large-media
performance.

7.9: signed APK build passed; TransferStatsTest covers MB/GB boundary,
zero and sub-KB display. Calls share SMS direct export-all path and
toggle off; contacts picker unchanged. No physical-device validation.

7.9.1: reverted MB display change to prior GB formatter; kept call
select-all toggle. User requested APK size over 1 MB: included
deterministic inert 1 MiB package-padding.bin asset, with no runtime use
or performance benefit. Manual and Gradle builds include assets. Signed
APK build passed; not device tested.

8.0: refreshed native home illustration and contrast, three-step
active/completed indicators, category selection borders/ripples,
responsive-height buttons, transfer/result information cards, gallery
search field. Corrected one-tap call/SMS guidance in all locales. Signed
build and translation/TransferStats tests passed. No emulator or
physical-device visual verification; system pickers/install dialogs
retain OS UI. Transport and media byte counts unchanged.

8.1: dedicated USB receiving entry from home menu, cable illustration
and localized steps. USB wait page has retry; back returns USB setup.
Android 8/9 folder success resumes USB and cancellation returns USB
setup. Signed build, 278 translations and static USB-only route checks
passed; physical USB transport/UI not tested.

8.1.1: Sorani role labels updated and new-phone receiver placed first;
old-phone sender second. Signed APK build passed. No device UI test.

8.2: Connect \> Select \> Transfer. Sender permissions route to
connection page. Wi-Fi verifies encrypted peer handshake then closes
preflight TCP while retaining network; receiver accepts subsequent
transfer connection (10-minute accept window). USB retains authenticated
channel while sender selects. Receiver selection waiting screen.
Connection page clears stale sender state. Signed build, 281
translations and simulated UsbSessionTest passed. Physical-device
connection-first flow not tested.

8.3: replaced incoming-transfer AlertDialog message with a custom
RTL/LTR-aware confirmation card. It shows receive icon, file count,
known byte total and unknown-size marker, up to three ellipsized file
names, a remainder label, and two 58dp action buttons. Confirmation
latch/timeout/cancel behavior is preserved. Signed build and 284
translation test passed; no device UI test.

8.4: selection page has grouped headings and visual cards for photos,
videos, files, APK apps, audio, contacts, calls and SMS. Hotspot status
includes an Android capability message for 6/6E, 5 GHz or fallback.
Wi-Fi Direct configuration can request only 5 GHz or AUTO in Android's
public API, so the app reports/detects support but cannot force 6/6E.
Signed build and 290 translation test passed; device radio behavior
remains untested.

------------------------------------------------------------------------

## `.gitignore`

``` text
.gradle/
local.properties
**/build/
*.jks
```

------------------------------------------------------------------------

## `app/build.gradle`

``` groovy
plugins { id 'com.android.application'; id 'org.jetbrains.kotlin.android' }
android {
    namespace 'com.abdulla.clonephone'
    compileSdk 35
    defaultConfig {
        applicationId 'com.abdulla.clonephone'
        minSdk 26
        targetSdk 34
        versionCode 57
        versionName '11.4'
    }
    compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = '17' }
    signingConfigs {
        debug {
            storeFile rootProject.file('test-signing/debug.keystore')
            storePassword 'android'
            keyAlias 'androiddebugkey'
            keyPassword 'android'
        }
    }
}

dependencies { implementation files('libs/zxing-core-3.5.3.jar') }
```

------------------------------------------------------------------------

## `app/src/main/AndroidManifest.xml`

``` xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />
    <uses-permission android:name="android.permission.NEARBY_WIFI_DEVICES" android:usesPermissionFlags="neverForLocation" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
    <uses-permission android:name="android.permission.READ_MEDIA_VISUAL_USER_SELECTED" />
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.READ_CALL_LOG" />
    <uses-permission android:name="android.permission.READ_SMS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-feature android:name="android.hardware.usb.host" android:required="false" />
    <uses-feature android:name="android.hardware.usb.accessory" android:required="false" />
    <uses-feature android:name="android.hardware.wifi.direct" android:required="false" />
    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />
    <uses-permission android:name="android.permission.REQUEST_DELETE_PACKAGES" />
    <uses-permission android:name="android.permission.UPDATE_PACKAGES_WITHOUT_USER_ACTION" />
    <queries><intent><action android:name="android.intent.action.MAIN" /><category android:name="android.intent.category.LAUNCHER" /></intent></queries>
    <application android:icon="@drawable/app_icon" android:label="REBARIT CLONE" android:theme="@style/AppTheme" android:allowBackup="false" android:supportsRtl="true">
        <provider android:name=".OwnApkProvider" android:authorities="com.abdulla.clonephone.share" android:exported="false" android:grantUriPermissions="true" />
        <activity android:name=".AppInstallActivity" android:exported="false" android:configChanges="orientation|screenSize|keyboardHidden" />
        <activity android:name=".ScanActivity" android:exported="false" android:screenOrientation="portrait" />
        <activity android:name=".MainActivity" android:launchMode="singleTop" android:exported="true" android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            <intent-filter><action android:name="android.hardware.usb.action.USB_ACCESSORY_ATTACHED" /></intent-filter>
            <meta-data android:name="android.hardware.usb.action.USB_ACCESSORY_ATTACHED" android:resource="@xml/usb_accessory" />
        </activity>
    </application>
</manifest>
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/AppBundle.java`

``` java
package com.abdulla.clonephone;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Private transfer container: unmodified base APK plus all installed split APKs. */
public final class AppBundle {
    public static final String MIME="application/x-rebaritclone-app";
    public static final long MAX_BYTES=16L*1024*1024*1024;
    public static final int MAX_PARTS=256;
    public interface Sink {void part(String name,InputStream input)throws Exception;}
    public static void write(List<File> apks,File destination)throws Exception{
        if(apks.isEmpty()||apks.size()>MAX_PARTS)throw new IOException("Invalid APK count");
        boolean success=false;long total=0;
        try(ZipOutputStream out=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(destination),1048576))){
            out.setLevel(0);byte[] data=new byte[1048576];int index=0;
            for(File apk:apks){if(!apk.isFile()||!apk.canRead())throw new IOException("APK unavailable");
                out.putNextEntry(new ZipEntry(index++==0?"base.apk":"split-"+(index-1)+".apk"));
                try(InputStream in=new BufferedInputStream(new FileInputStream(apk))){int n;while((n=in.read(data))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();total+=n;if(total>MAX_BYTES)throw new IOException("App too large");out.write(data,0,n);}}
                out.closeEntry();
            }success=true;
        }finally{if(!success)destination.delete();}
    }
    public static void read(InputStream source,Sink sink)throws Exception{
        Set<String> names=new HashSet<>();final long[] total={0};
        try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(source,1048576))){ZipEntry entry;
            while((entry=zip.getNextEntry())!=null){String name=entry.getName();
                if(entry.isDirectory()||!name.matches("base\\.apk|split-[0-9]{1,3}\\.apk")||!names.add(name)||names.size()>MAX_PARTS)throw new IOException("Invalid app bundle");
                InputStream bounded=new FilterInputStream(zip){
                    public int read()throws IOException{byte[] b=new byte[1];return read(b,0,1)==-1?-1:b[0]&255;}
                    public int read(byte[] b,int o,int l)throws IOException{if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();int n=in.read(b,o,l);if(n>0){total[0]+=n;if(total[0]>MAX_BYTES)throw new IOException("App too large");}return n;}
                    public void close(){} // Session sink must not close the outer archive.
                };
                sink.part(name,bounded);if(bounded.read()!=-1)throw new IOException("Incomplete APK staging");zip.closeEntry();
            }
        }
        if(!names.contains("base.apk"))throw new IOException("Missing base APK");
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/AppInstallActivity.java`

``` java
package com.abdulla.clonephone;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Foreground sequential installer. Android owns every install/update approval. */
@SuppressWarnings("deprecation")
public class AppInstallActivity extends Activity {
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private ArrayList<String> uris,names;
    private int index;
    private volatile int sessionId=-1;
    private volatile boolean destroyed;
    private boolean working,resumed,permissionPending,startPending;
    private Intent approvalIntent;
    private PendingIntent callback;
    private TextView state,position,history,summary;
    private ProgressBar progress;
    private int installed,skipped;
    private final StringBuilder results=new StringBuilder();
    private Button retry,next;
    private String action;
    private final BroadcastReceiver receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent intent){
        if(!action.equals(intent.getAction())||sessionId<0||intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID,-2)!=sessionId)return;
        int status=intent.getIntExtra(PackageInstaller.EXTRA_STATUS,PackageInstaller.STATUS_FAILURE);
        if(status==PackageInstaller.STATUS_PENDING_USER_ACTION){
            approvalIntent=intent.getParcelableExtra(Intent.EXTRA_INTENT);state.setText(UiText.t(197));
            if(approvalIntent==null){fail(UiText.t(198));return;}launchApproval();return;
        }
        sessionId=-1;working=false;if(callback!=null){callback.cancel();callback=null;}
        finishItem(status==PackageInstaller.STATUS_SUCCESS,status==PackageInstaller.STATUS_SUCCESS?UiText.t(199):reason(status));
    }};
    @Override public void onCreate(Bundle saved){super.onCreate(saved);UiText.init(this);
        uris=getIntent().getStringArrayListExtra("uris");names=getIntent().getStringArrayListExtra("names");
        if(uris==null||names==null||uris.size()!=names.size()||uris.isEmpty()){finish();return;}
        action=getPackageName()+".INSTALL."+UUID.randomUUID();
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,new IntentFilter(action),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,new IntentFilter(action));
        getWindow().setStatusBarColor(Color.rgb(5,11,18));getWindow().setNavigationBarColor(Color.rgb(5,11,18));
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(28),dp(22),dp(28));box.setLayoutDirection(UiText.direction());box.setBackground(makeBg());
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(5,11,18));scroll.addView(box);setContentView(scroll);
        TextView brand=label("REBARIT CLONE",13,0xff7f8da3);brand.setLetterSpacing(.16f);box.addView(brand);
        TextView title=label(UiText.t(129),28,Color.WHITE);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setPadding(0,dp(8),0,dp(6));box.addView(title);
        summary=label("",13,0xff8ea0b8);summary.setPadding(0,0,0,dp(18));box.addView(summary);
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(18),dp(18),dp(18));card.setBackground(cardBg());box.addView(card,new LinearLayout.LayoutParams(-1,-2));
        position=label("",20,Color.WHITE);position.setTypeface(Typeface.DEFAULT,Typeface.BOLD);card.addView(position);
        state=label("",15,0xffb8c5d8);state.setPadding(0,dp(12),0,dp(12));card.addView(state);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(0xff00d9ff));progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff263447));card.addView(progress,new LinearLayout.LayoutParams(-1,dp(6)));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setPadding(0,dp(18),0,0);card.addView(actions);
        retry=vipButton(UiText.t(200),0xff0b86ff);actions.addView(retry,new LinearLayout.LayoutParams(0,dp(48),1));retry.setOnClickListener(v->startCurrent());
        next=vipButton(UiText.t(201),0xff27364a);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(48),1);np.setMarginStart(dp(10));actions.addView(next,np);next.setOnClickListener(v->finishItem(false,UiText.t(202)));
        Button stop=vipButton(UiText.t(29),0xff7b1f2c);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(48));sp.setMargins(0,dp(12),0,0);box.addView(stop,sp);stop.setOnClickListener(v->onBackPressed());
        TextView note=label(UiText.t(203),13,0xff8392a8);note.setPadding(0,dp(18),0,dp(8));box.addView(note);
        history=label("",14,0xffd2dbea);history.setLineSpacing(0,1.18f);box.addView(history);
        if(saved!=null){installed=saved.getInt("installed",0);skipped=saved.getInt("skipped",0);results.append(saved.getString("results",""));history.setText(results.toString());index=saved.getInt("index",0);int old=saved.getInt("session",-1);if(old>=0)try{getPackageManager().getPackageInstaller().abandonSession(old);}catch(Exception ignored){}state.setText(UiText.t(204));}
        else startPending=true;
        showPosition();
    }
    private void finishItem(boolean success,String message){
        if(destroyed||index>=uris.size())return;
        abandon();working=false;approvalIntent=null;
        if(success)installed++;else skipped++;
        results.append(success?"✓ ":"— ").append(names.get(index)).append(": ").append(message).append("\n\n");history.setText(results.toString());
        index++;showPosition();startPending=index<uris.size();advance();
    }
    private void showPosition(){
        int total=uris.size();summary.setText("✓ "+installed+"   •   — "+skipped+"   •   "+Math.min(index+1,total)+" / "+total);
        progress.setProgress(total==0?0:(int)(100f*index/total));
        if(index>=total){state.setText(UiText.t(205));position.setText(installed+UiText.t(206)+skipped+UiText.t(207));progress.setProgress(100);retry.setEnabled(false);next.setEnabled(false);startPending=false;return;}
        position.setText(names.get(index)+"\n"+(index+1)+" / "+total);retry.setEnabled(!working);next.setEnabled(!working);
    }
    @Override protected void onResume(){super.onResume();resumed=true;launchApproval();advance();}
    @Override protected void onPause(){resumed=false;super.onPause();}
    private void advance(){if(resumed&&startPending&&!working){startPending=false;startCurrent();}}
    private void launchApproval(){if(resumed&&approvalIntent!=null){Intent i=approvalIntent;approvalIntent=null;try{startActivity(i);}catch(Exception e){fail(UiText.t(208));}}}
    private void startCurrent(){
        if(working||index>=uris.size()||destroyed)return;
        if(!getPackageManager().canRequestPackageInstalls()){
            state.setText(UiText.t(209));
            permissionPending=true;try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())),42);}catch(Exception e){permissionPending=false;fail(UiText.t(210));}return;
        }
        working=true;showPosition();state.setText(UiText.t(211));
        final String value=uris.get(index),name=names.get(index);
        worker.execute(()->{int created=-1;boolean committed=false;
            try{
                PackageInstaller installer=getPackageManager().getPackageInstaller();PackageInstaller.SessionParams params=new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
                if(Build.VERSION.SDK_INT>=31)params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
                created=installer.createSession(params);sessionId=created;if(destroyed)throw new InterruptedIOException();
                try(PackageInstaller.Session session=installer.openSession(created);InputStream source=getContentResolver().openInputStream(Uri.parse(value))){
                    if(source==null)throw new IOException("File unavailable");
                    if(name.toLowerCase(Locale.ROOT).endsWith(".rbapp"))AppBundle.read(source,(part,in)->stage(session,part,in));else stage(session,"base.apk",source);
                    if(destroyed||Thread.currentThread().isInterrupted())throw new InterruptedIOException();
                    Intent result=new Intent(action).setPackage(getPackageName());int flags=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=31)flags|=PendingIntent.FLAG_MUTABLE;
                    callback=PendingIntent.getBroadcast(this,created,result,flags);session.commit(callback.getIntentSender());committed=true;
                }
            }catch(Exception e){if(created>=0)try{getPackageManager().getPackageInstaller().abandonSession(created);}catch(Exception ignored){}sessionId=-1;
                runOnUiThread(()->{if(!destroyed)finishItem(false,UiText.t(212)+e.getMessage());});
            }finally{if(!committed&&callback!=null){callback.cancel();callback=null;}}
        });
    }
    private void stage(PackageInstaller.Session session,String name,InputStream in)throws Exception{
        try(OutputStream out=session.openWrite(name,0,-1)){byte[] data=new byte[1048576];int n;long total=0;
            while((n=in.read(data))!=-1){if(destroyed||Thread.currentThread().isInterrupted())throw new InterruptedIOException();total+=n;if(total>AppBundle.MAX_BYTES)throw new IOException("App too large");out.write(data,0,n);}session.fsync(out);
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==42&&permissionPending){permissionPending=false;if(getPackageManager().canRequestPackageInstalls()){startPending=true;advance();}else fail(UiText.t(213));}}
    private void fail(String message){abandon();working=false;state.setText(message);retry.setEnabled(index<uris.size());next.setEnabled(index<uris.size());}
    private String reason(int status){switch(status){case PackageInstaller.STATUS_FAILURE_ABORTED:return UiText.t(214);case PackageInstaller.STATUS_FAILURE_STORAGE:return UiText.t(215);case PackageInstaller.STATUS_FAILURE_CONFLICT:return UiText.t(216);case PackageInstaller.STATUS_FAILURE_INCOMPATIBLE:return UiText.t(217);case PackageInstaller.STATUS_FAILURE_BLOCKED:return UiText.t(218);default:return UiText.t(219);}}
    private void abandon(){int id=sessionId;sessionId=-1;if(id>=0)try{getPackageManager().getPackageInstaller().abandonSession(id);}catch(Exception ignored){}if(callback!=null){callback.cancel();callback=null;}}
    @Override public void onBackPressed(){new AlertDialog.Builder(UiText.context(this)).setMessage(UiText.t(220)).setPositiveButton(UiText.t(29),(d,w)->{destroyed=true;abandon();finish();}).setNegativeButton(UiText.t(124),null).show();}
    @Override protected void onSaveInstanceState(Bundle state){state.putInt("installed",installed);state.putInt("skipped",skipped);state.putString("results",results.toString());state.putInt("index",index);state.putInt("session",sessionId);super.onSaveInstanceState(state);}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String text,int size,int color){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(color);v.setGravity(UiText.direction()==View.LAYOUT_DIRECTION_RTL?Gravity.RIGHT:Gravity.LEFT);return v;}
    private GradientDrawable makeBg(){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff050b12,0xff091321,0xff0b1020});return g;}
    private GradientDrawable cardBg(){GradientDrawable g=new GradientDrawable();g.setColor(0xff101a28);g.setCornerRadius(dp(22));g.setStroke(dp(1),0xff26364d);return g;}
    private Button vipButton(String text,int color){Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(16));b.setBackground(g);return b;}

    @Override protected void onDestroy(){destroyed=true;worker.shutdownNow();abandon();try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onDestroy();}
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/FileGallery.java`

``` java
package com.abdulla.clonephone;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;
import java.text.SimpleDateFormat;

/** Session-local media picker; real MediaStore thumbnails and URI selection. */
final class FileGallery extends LinearLayout {
    static final class Entry {Uri uri;String name,mime,folder;long size,date,duration;}
    interface Actions {void changed(List<Entry> selected);void tab(String name);void next();}
    private final Activity activity;private final Actions actions;
    private final ExecutorService loader=Executors.newSingleThreadExecutor();
    private final ThreadPoolExecutor thumbs=new ThreadPoolExecutor(2,2,10,TimeUnit.SECONDS,new ArrayBlockingQueue<>(64),new ThreadPoolExecutor.DiscardOldestPolicy());
    private final LruCache<String,Bitmap> cache=new LruCache<String,Bitmap>(12*1024*1024){protected int sizeOf(String k,Bitmap v){return v.getByteCount();}};
    private final List<Entry> entries=new ArrayList<>();private final List<Object> rows=new ArrayList<>();
    private final LinkedHashMap<String,Entry> chosen=new LinkedHashMap<>();
    private final ListView list;private final TextView count;private final EditText search;private final CheckBox all;
    private final BaseAdapter adapter;private boolean closed,audio;private final String mediaType;private int filter,loadVersion;private String query="";
    private final int white=0xfff5f5fa,muted=0xffb4b4c2;private String warning="";
    FileGallery(Activity a,List<Entry> initial,String summary,Actions callback,String initialTab){
        super(a);activity=a;actions=callback;for(Entry e:initial)chosen.put(e.uri.toString(),e);
        mediaType=initialTab;audio="audio".equals(initialTab);filter="photos".equals(initialTab)?1:"videos".equals(initialTab)?2:0;
        setOrientation(VERTICAL);setLayoutDirection(UiText.direction());setBackgroundColor(0xff101827);
        HorizontalScrollView tabs=new HorizontalScrollView(a);LinearLayout tabRow=new LinearLayout(a);tabs.addView(tabRow);tabs.setHorizontalScrollBarEnabled(false);addView(tabs);
        String[] ids={"media","audio","files","apps","contacts"};int[] labels={265,20,26,22,24};
        List<TextView> tabViews=new ArrayList<>();
        for(int i=0;i<ids.length;i++){final String id=ids[i];TextView tab=text(UiText.t(labels[i]),16);tab.setPadding(dp(12),dp(16),dp(12),dp(16));tabRow.addView(tab);tabViews.add(tab);tab.setOnClickListener(v->{if(id.equals("media")||id.equals("audio")){if(mediaType.equals("photos")||mediaType.equals("videos"))return;audio=id.equals("audio");for(TextView t:tabViews)t.setTextColor(muted);tab.setTextColor(white);load();}else actions.tab(id);});}
        tabViews.get(audio?1:0).setTextColor(white);
        search=new EditText(a);search.setSingleLine(true);search.setTextColor(white);search.setHintTextColor(muted);search.setHint(UiText.t(236));search.setPadding(dp(14),0,dp(14),0);android.graphics.drawable.GradientDrawable searchBg=new android.graphics.drawable.GradientDrawable();searchBg.setColor(0xff202d43);searchBg.setCornerRadius(dp(14));search.setBackground(searchBg);addView(search,new LayoutParams(-1,dp(48)));
        LinearLayout tools=new LinearLayout(a);tools.setGravity(Gravity.CENTER_VERTICAL);addView(tools);
        TextView filterButton=text(mediaType.equals("photos")?UiText.t(16):mediaType.equals("videos")?UiText.t(18):UiText.t(266)+" ▾",16);tools.addView(filterButton,new LayoutParams(0,dp(52),1));if(mediaType.equals("photos")||mediaType.equals("videos"))filterButton.setEnabled(false);
        filterButton.setOnClickListener(v->new AlertDialog.Builder(UiText.context(a)).setItems(new String[]{UiText.t(266),UiText.t(16),UiText.t(18)},(d,n)->{filter=n;filterButton.setText(UiText.t(n==0?266:n==1?16:18)+" ▾");rebuild();}).show());
        all=new CheckBox(a);all.setButtonTintList(android.content.res.ColorStateList.valueOf(0xffaaa4ff));all.setContentDescription(UiText.t(237));tools.addView(all);all.setOnClickListener(v->{boolean checked=all.isChecked();for(Entry e:visible())if(checked)chosen.put(e.uri.toString(),e);else chosen.remove(e.uri.toString());changed();});
        list=new ListView(a);list.setDivider(null);addView(list,new LayoutParams(-1,0,1));
        adapter=new BaseAdapter(){public int getCount(){return rows.size();}public Object getItem(int i){return rows.get(i);}public long getItemId(int i){return i;}public boolean isEnabled(int p){return false;}
            public View getView(int position,View reuse,ViewGroup parent){Object row=rows.get(position);
                if(row instanceof String){String day=(String)row;CheckBox header=new CheckBox(a);header.setTextColor(white);header.setTextSize(17);header.setPadding(dp(6),dp(14),0,dp(8));List<Entry> members=new ArrayList<>();for(Entry e:visible())if(day(e).equals(day))members.add(e);boolean selected=!members.isEmpty();for(Entry e:members)selected&=chosen.containsKey(e.uri.toString());header.setText(day+" ("+members.size()+")");header.setChecked(selected);header.setOnClickListener(v->{for(Entry e:members)if(header.isChecked())chosen.put(e.uri.toString(),e);else chosen.remove(e.uri.toString());changed();});return header;}
                @SuppressWarnings("unchecked") List<Entry> cells=(List<Entry>)row;
                LinearLayout line=new LinearLayout(a);line.setLayoutDirection(LAYOUT_DIRECTION_LTR);
                for(Entry e:cells){if(audio){CheckBox item=new CheckBox(a);item.setTextColor(white);item.setText(e.name+"\n"+TransferStats.size(e.size));item.setChecked(chosen.containsKey(e.uri.toString()));item.setPadding(dp(8),dp(12),dp(8),dp(12));item.setOnClickListener(v->toggle(e));line.addView(item,new LayoutParams(-1,-2));}
                    else{FrameLayout cell=new FrameLayout(a);int side=Math.max(dp(64),(getResources().getDisplayMetrics().widthPixels-dp(44))/4);LayoutParams cp=new LayoutParams(0,side,1);cp.setMargins(1,1,1,1);line.addView(cell,cp);cell.setBackgroundColor(0xff252633);
                        ImageView image=new ImageView(a);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setContentDescription(e.name);cell.addView(image,new FrameLayout.LayoutParams(-1,-1));thumbnail(e,image);
                        CheckBox check=new CheckBox(a);check.setChecked(chosen.containsKey(e.uri.toString()));check.setButtonTintList(android.content.res.ColorStateList.valueOf(0xffc1baff));check.setClickable(false);check.setFocusable(false);FrameLayout.LayoutParams ck=new FrameLayout.LayoutParams(dp(38),dp(38),Gravity.TOP|Gravity.RIGHT);cell.addView(check,ck);
                        if(e.mime.startsWith("video/")){TextView length=text(String.format(Locale.US,"%02d:%02d",e.duration/60000,e.duration/1000%60),12);length.setBackgroundColor(0x99000000);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.LEFT);cell.addView(length,lp);}TextView fileSize=text(TransferStats.size(e.size),11);fileSize.setBackgroundColor(0x99000000);fileSize.setPadding(dp(4),dp(2),dp(4),dp(2));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.RIGHT);cell.addView(fileSize,sp);
                        cell.setOnClickListener(v->toggle(e));cell.setOnLongClickListener(v->{try{activity.startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(e.uri,e.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));}catch(Exception ignored){Toast.makeText(a,UiText.t(257),Toast.LENGTH_SHORT).show();}return true;});
                    }}
                if(!audio)for(int n=cells.size();n<4;n++)line.addView(new View(a),new LayoutParams(0,1,1));return line;
            }};list.setAdapter(adapter);
        count=text(summary,13);count.setPadding(0,dp(10),0,dp(6));addView(count);
        Button next=new Button(a);next.setText(UiText.t(28));next.setTextColor(white);next.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff7166dc));addView(next,new LayoutParams(-1,dp(52)));next.setOnClickListener(v->actions.next());
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int af){}public void afterTextChanged(android.text.Editable e){}public void onTextChanged(CharSequence s,int st,int b,int c){query=s.toString().toLowerCase(Locale.ROOT);rebuild();}});load();
    }
    private int dp(int x){return (int)(getResources().getDisplayMetrics().density*x);}
    private TextView text(String s,int size){TextView t=new TextView(activity);t.setText(s);t.setTextColor(white);t.setTextSize(size);return t;}
    private String day(Entry e){if(mediaType.equals("photos")||mediaType.equals("videos"))return e.folder==null||e.folder.trim().isEmpty()?"Camera":e.folder;return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date(e.date*1000));}
    private List<Entry> visible(){List<Entry> out=new ArrayList<>();for(Entry e:entries)if(e.name.toLowerCase(Locale.ROOT).contains(query)&&(audio||filter==0||(filter==1&&e.mime.startsWith("image/"))||(filter==2&&e.mime.startsWith("video/"))))out.add(e);return out;}
    private void rebuild(){if(closed)return;rows.clear();String previous=null;List<Entry> cells=null;List<Entry> shown=visible();for(Entry e:shown){String d=day(e);if(!d.equals(previous)){rows.add(d);previous=d;cells=null;}if(cells==null||cells.size()==(audio?1:4)){cells=new ArrayList<>();rows.add(cells);}cells.add(e);}boolean checked=!shown.isEmpty();for(Entry e:shown)checked&=chosen.containsKey(e.uri.toString());all.setChecked(checked);adapter.notifyDataSetChanged();}
    private void toggle(Entry e){if(chosen.containsKey(e.uri.toString()))chosen.remove(e.uri.toString());else chosen.put(e.uri.toString(),e);changed();}
    private void changed(){actions.changed(new ArrayList<>(chosen.values()));rebuild();}
    void summary(String value){count.setText(warning.isEmpty()?value:warning+"\n"+value);}
    private void load(){int version=++loadVersion;boolean sound=audio;entries.clear();rebuild();warning="";loader.execute(()->{List<Entry> found=new ArrayList<>();boolean denied=false;for(int kind:sound?new int[]{2}:mediaType.equals("photos")?new int[]{0}:mediaType.equals("videos")?new int[]{1}:new int[]{0,1}){try{Uri uri=kind==0?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:kind==1?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                String[] projection=kind==0?new String[]{"_id","_display_name","mime_type","_size","date_added","bucket_display_name"}:kind==1?new String[]{"_id","_display_name","mime_type","_size","date_added","duration","bucket_display_name"}:new String[]{"_id","_display_name","mime_type","_size","date_added","duration"};
                try(Cursor c=activity.getContentResolver().query(uri,projection,null,null,"date_added DESC")){while(c!=null&&c.moveToNext()&&found.size()<10000&&!closed){Entry e=new Entry();e.uri=ContentUris.withAppendedId(uri,c.getLong(0));e.name=c.isNull(1)?"file":c.getString(1);e.mime=c.isNull(2)?(kind==0?"image/jpeg":kind==1?"video/mp4":"audio/mpeg"):c.getString(2);e.size=c.isNull(3)?-1:c.getLong(3);e.date=c.getLong(4);e.duration=kind==0?0:c.getLong(5);e.folder=kind==0?(c.isNull(5)?"Camera":c.getString(5)):kind==1?(c.isNull(6)?"Camera":c.getString(6)):"";found.add(e);}}
            }catch(Exception e){denied=true;}}
            found.sort((x,y)->Long.compare(y.date,x.date));final boolean restricted=denied;activity.runOnUiThread(()->{if(closed||version!=loadVersion)return;entries.addAll(found);warning=restricted?UiText.t(249):found.size()>=10000?UiText.t(267):found.isEmpty()?UiText.t(47):"";rebuild();actions.changed(new ArrayList<>(chosen.values()));});});}
    private void thumbnail(Entry e,ImageView target){String key=e.uri.toString();target.setTag(key);Bitmap saved=cache.get(key);if(saved!=null){target.setImageBitmap(saved);return;}
        if(closed)return;thumbs.execute(()->{Bitmap b=null;try{if(Build.VERSION.SDK_INT>=29)b=activity.getContentResolver().loadThumbnail(e.uri,new Size(180,180),null);else if(e.mime.startsWith("video/"))b=MediaStore.Video.Thumbnails.getThumbnail(activity.getContentResolver(),ContentUris.parseId(e.uri),MediaStore.Video.Thumbnails.MINI_KIND,null);else b=MediaStore.Images.Thumbnails.getThumbnail(activity.getContentResolver(),ContentUris.parseId(e.uri),MediaStore.Images.Thumbnails.MINI_KIND,null);}catch(Exception ignored){}if(b!=null&&!closed){cache.put(key,b);final Bitmap bitmap=b;activity.runOnUiThread(()->{if(!closed&&key.equals(target.getTag()))target.setImageBitmap(bitmap);});}});}
    void close(){closed=true;loader.shutdownNow();thumbs.shutdownNow();cache.evictAll();}
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/HotspotLink.java`

``` java
package com.abdulla.clonephone;

import android.content.Context;
import android.net.*;
import android.net.wifi.*;
import android.net.wifi.p2p.*;
import android.os.*;

/** Local-only Android APIs. All public methods and callbacks run on the main thread. */
@SuppressWarnings("deprecation")
final class HotspotLink {
    interface HostCallback {void ready(String ssid,String password);void failed(String reason);}
    interface ClientCallback {void ready(Network network);void failed();}
    private final WifiManager wifi;
    private final ConnectivityManager connectivity;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WifiManager.LocalOnlyHotspotReservation reservation;
    private ConnectivityManager.NetworkCallback callback;
    private int generation,groupFrequency;
    private boolean require5,automaticFallback;
    private final WifiP2pManager p2p;
    private WifiP2pManager.Channel p2pChannel;
    private boolean ownsGroup;
    private String failure="",groupAddress="";
    String hostAddress(){return groupAddress;}
    private WifiManager.WifiLock performanceLock;
    HotspotLink(Context context){wifi=(WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);connectivity=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);p2p=(WifiP2pManager)context.getSystemService(Context.WIFI_P2P_SERVICE);if(p2p!=null)p2pChannel=p2p.initialize(context,Looper.getMainLooper(),()->p2pChannel=null);}
    void start(boolean fast,HostCallback listener){
        close();failure="";automaticFallback=false;final int token=generation;
        require5=fast;
        if(fast){if(Build.VERSION.SDK_INT>=29&&wifi.is5GHzBandSupported())startP2p(listener,token,true,false);else listener.failed("5GHZ_UNAVAILABLE");return;}
        startLocal(listener,token);
    }
    private void startLocal(HostCallback listener,int token){
        try{wifi.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback(){
            @Override public void onStarted(WifiManager.LocalOnlyHotspotReservation value){
                if(token!=generation){value.close();return;}reservation=value;
                String ssid,password;
                if(Build.VERSION.SDK_INT>=30){SoftApConfiguration c=value.getSoftApConfiguration();ssid=c.getSsid();password=c.getPassphrase();}
                else{WifiConfiguration c=value.getWifiConfiguration();ssid=c.SSID;password=c.preSharedKey;}
                if(ssid==null||password==null){failure="HOTSPOT_NO_CONFIG";startP2p(listener,token,false,false);return;}listener.ready(ssid,password);
            }
            @Override public void onFailed(int reason){if(token==generation){failure="HOTSPOT_ERROR_"+reason;startP2p(listener,token,false,false);}}
            @Override public void onStopped(){if(token==generation){close();listener.failed("HOTSPOT_STOPPED");}}
        },main);}catch(SecurityException e){close();listener.failed("WIFI_PERMISSION_OR_LOCATION");}catch(Exception e){failure=e.getClass().getSimpleName();startP2p(listener,token,false,false);}
    }
    private void startP2p(HostCallback listener,int token,boolean band5,boolean localFallback){
        startP2p(listener,token,band5,localFallback,0);
    }
    private void startP2p(HostCallback listener,int token,boolean band5,boolean localFallback,int attempt){
        if(token!=generation)return;
        if(p2p==null||p2pChannel==null){if(localFallback)startLocal(listener,token);else{close();listener.failed(failure+" / P2P_UNAVAILABLE");}return;}
        WifiP2pManager.ActionListener action=new WifiP2pManager.ActionListener(){
            public void onSuccess(){if(token!=generation)return;ownsGroup=true;readGroup(listener,token,0);}
            public void onFailure(int reason){if(token!=generation)return;
                long delay=P2pRetry.delay(reason,attempt);
                if(delay>=0){main.postDelayed(()->startP2p(listener,token,band5,localFallback,attempt+1),delay);return;}
                failure+=" / P2P_ERROR_"+reason;
                if(reason==WifiP2pManager.BUSY&&band5&&!automaticFallback){
                    automaticFallback=true;require5=false;
                    // The service stayed busy: try Android's local hotspot once.
                    // Its actual band is unknown and must not be advertised as 5 GHz.
                    startLocal(listener,token);return;
                }
                if(localFallback)startLocal(listener,token);else{close();listener.failed(failure);}}
        };
        try{
            if(Build.VERSION.SDK_INT>=29){
                String suffix=SecureChannel.newCode().substring(0,6);
                WifiP2pConfig config=new WifiP2pConfig.Builder().setNetworkName("DIRECT-rb-"+suffix).setPassphrase(SecureChannel.newCode().substring(0,16)).setGroupOperatingBand(band5?WifiP2pConfig.GROUP_OWNER_BAND_5GHZ:WifiP2pConfig.GROUP_OWNER_BAND_AUTO).build();
                p2p.createGroup(p2pChannel,config,action);
            }else p2p.createGroup(p2pChannel,action);
        }catch(Exception e){action.onFailure(-1);}
    }
    private void readGroup(HostCallback listener,int token,int tries){
        if(token!=generation)return;
        try{p2p.requestGroupInfo(p2pChannel,group->{
            if(token!=generation)return;
            if(group!=null&&group.isGroupOwner()&&group.getPassphrase()!=null){
                p2p.requestConnectionInfo(p2pChannel,info->{
                    if(token!=generation)return;
                    if(info!=null&&info.groupFormed&&info.isGroupOwner&&info.groupOwnerAddress!=null){groupFrequency=Build.VERSION.SDK_INT>=29?group.getFrequency():0;if(require5&&(groupFrequency<4900||groupFrequency>=5925)){close();listener.failed("5GHZ_NOT_CONFIRMED");return;}groupAddress=info.groupOwnerAddress.getHostAddress();listener.ready(group.getNetworkName(),group.getPassphrase());}
                    else if(tries<20)main.postDelayed(()->readGroup(listener,token,tries+1),500);
                    else{close();listener.failed("P2P_NO_GROUP_ADDRESS");}
                });return;
            }
            if(tries>=20){close();listener.failed("P2P_NO_GROUP_ADDRESS");return;}
            main.postDelayed(()->readGroup(listener,token,tries+1),500);
        });}catch(Exception e){close();listener.failed("P2P_PERMISSION_OR_LOCATION");}
    }
    void performance(boolean enabled){
        if(performanceLock!=null){try{if(performanceLock.isHeld())performanceLock.release();}catch(Exception ignored){}performanceLock=null;}
        if(enabled)try{performanceLock=wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF,"rebaritclone-transfer");performanceLock.setReferenceCounted(false);performanceLock.acquire();}catch(Exception ignored){}
    }
    String hostInfo(){String band=groupFrequency>=5925?"6 GHz • Wi-Fi Direct • "+groupFrequency+" MHz":groupFrequency>=4900&&groupFrequency<5925?"5 GHz • Wi-Fi Direct • "+groupFrequency+" MHz":UiText.t(224);return (automaticFallback?UiText.t(252)+"\n":"")+band+"\n"+capabilityInfo();}
    private String capabilityInfo(){try{if(Build.VERSION.SDK_INT>=31&&wifi.is6GHzBandSupported())return UiText.t(287);if(wifi.is5GHzBandSupported())return UiText.t(288);return UiText.t(289);}catch(Exception e){return UiText.t(289);}}
    String linkInfo(Network network){
        try{
            WifiInfo info=null;
            if(Build.VERSION.SDK_INT>=29&&network!=null){NetworkCapabilities cap=connectivity.getNetworkCapabilities(network);if(cap!=null&&cap.getTransportInfo() instanceof WifiInfo)info=(WifiInfo)cap.getTransportInfo();}
            if(info==null)return UiText.t(225);
            int f=info.getFrequency(),rate=info.getLinkSpeed();
            String band=f>=5925?"6 GHz":f>=4900?"5 GHz":f>=2400?"2.4 GHz":"Wi-Fi";
            return band+(rate>0?" • Link "+rate+" Mbps":"")+"\n"+(f>=2400&&f<2500?UiText.t(226):UiText.t(227));
        }catch(Exception e){return UiText.t(228);}
    }
    void connect(Pairing peer,ClientCallback listener){
        close();final int token=generation;
        if(Build.VERSION.SDK_INT<29){listener.failed();return;}
        try{
            WifiNetworkSpecifier spec=new WifiNetworkSpecifier.Builder().setSsid(peer.ssid).setWpa2Passphrase(peer.password).build();
            NetworkRequest request=new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build();
            callback=new ConnectivityManager.NetworkCallback(){
                @Override public void onAvailable(Network n){main.post(()->{if(token==generation)listener.ready(n);});}
                @Override public void onUnavailable(){main.post(()->{if(token==generation){close();listener.failed();}});}
                @Override public void onLost(Network n){main.post(()->{if(token==generation){close();listener.failed();}});}
            };
            connectivity.requestNetwork(request,callback,60000);
        }catch(Exception e){close();listener.failed();}
    }
    Network currentWifi(){
        for(Network n:connectivity.getAllNetworks()){
            NetworkCapabilities c=connectivity.getNetworkCapabilities(n);
            if(c!=null&&c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)&&!c.hasTransport(NetworkCapabilities.TRANSPORT_VPN))return n;
        }return null;
    }
    void close(){
        generation++;groupAddress="";groupFrequency=0;
        performance(false);
        if(ownsGroup&&p2p!=null&&p2pChannel!=null){try{p2p.removeGroup(p2pChannel,null);}catch(Exception ignored){}ownsGroup=false;}
        if(callback!=null){try{connectivity.unregisterNetworkCallback(callback);}catch(Exception ignored){}callback=null;}
        if(reservation!=null){try{reservation.close();}catch(Exception ignored){}reservation=null;}
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/MainActivity.java`

``` java
package com.abdulla.clonephone;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.*;
import android.provider.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.res.ColorStateList;
import android.view.*;
import android.widget.*;
import com.google.zxing.*;
import com.google.zxing.common.*;
import com.google.zxing.qrcode.QRCodeWriter;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int FILES=10,FOLDER=11,SCAN=12,QR_IMAGE=13,WIFI_SETTINGS=14,LOCATION_SETTINGS=15,UNINSTALL_APP=16,CAMERA_PERMISSION=20,DATA_PERMISSION=21,HOTSPOT_PERMISSION=22,SETUP_PERMISSION=23,SETUP_SETTINGS=24,FILE_BROWSER_PERMISSION=25,FILE_HUB_PERMISSION=26,PORT=39841,MAX_FILES=10000;
    private static final int BLUE=0xff4f46e5,INK=0xff152238,MUTED=0xff627089,BG=0xfff3f5fa;
    // A permanent catalogue URL: keep this QR unchanged and publish each new APK
    // (and its version notes) at this address.
    private static final String DOWNLOAD_CATALOG_URL="https://app.mediafire.com/folder/omye30rljf3px";
    // The public release manifest.  It contains only version metadata and the
    // direct, signed APK URL; a missing or unreachable manifest is ignored.
    private static final String UPDATE_MANIFEST_URL="https://rebaritclone-update-admin.rebar4qwrna.workers.dev/update.json";
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private boolean fileHubPermissionAsked=false;
    private final LinkedHashMap<String,List<Item>> groups=new LinkedHashMap<>();
    private final List<Item> selection=new ArrayList<>();
    private final Map<String,Set<String>> selectedRecords=new HashMap<>();
    private final Set<String> selectedApps=new HashSet<>();
    private final LinkedHashMap<String,Item> receivedFiles=new LinkedHashMap<>();
    private final LinkedHashMap<String,String> receivedApps=new LinkedHashMap<>();
    private void installReceivedApps(){if(receivedApps.isEmpty())return;Intent i=new Intent(this,AppInstallActivity.class);i.putStringArrayListExtra("uris",new ArrayList<>(receivedApps.keySet()));i.putStringArrayListExtra("names",new ArrayList<>(receivedApps.values()));startActivity(i);}
    private LinearLayout body,root;
    private FileGallery gallery;
    private boolean fileBrowserMode;
    private String browserMediaCategory;
    private void closeGallery(){if(gallery!=null){gallery.close();gallery=null;}}
    private TextView subtitle,status,percentage,details;
    private ProgressBar progress;
    private String screen="home",pendingCategory,pairText;
    private Uri folder,lastContact;
    private volatile Socket socket;
    private volatile ServerSocket listener;
    private volatile boolean busy,cancelled;
    private volatile CountDownLatch approval;
    private AlertDialog approvalDialog;
    private final ArrayDeque<String> uninstallQueue=new ArrayDeque<>();
    private String uninstallCurrentPackage;
    private LinkedHashSet<String> uninstallSelected;
    private List<ApplicationInfo> uninstallApps,uninstallShown;
    private BaseAdapter uninstallAdapter;
    private Runnable uninstallHeader;

    private void launchNextUninstall(){
        if(uninstallQueue.isEmpty()){uninstallCurrentPackage=null;toast("سڕینەوەی ئەپە هەڵبژێردراوەکان تەواو بوو");return;}
        uninstallCurrentPackage=uninstallQueue.removeFirst();
        try{
            Intent uninstall=new Intent(Intent.ACTION_UNINSTALL_PACKAGE);
            uninstall.setData(Uri.parse("package:"+uninstallCurrentPackage));
            uninstall.putExtra(Intent.EXTRA_RETURN_RESULT,true);
            uninstall.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivityForResult(uninstall,UNINSTALL_APP);
        }catch(Exception e){
            toast("نەتوانرا پەنجەرەی Android Uninstall بکرێتەوە");
            uninstallQueue.clear();uninstallCurrentPackage=null;
        }
    }
    private int completed;
    private long totalBytes,finishedBytes,lastUpdate,startTime;
    private boolean totalKnown;
    private TransferStats transferStats;
    private long resumedBytes,transferStarted;
    private String sendingId="",sendingManifest="",receivingId="",receivingManifest="",receivingBatch;
    private Uri receivingLegacy;
    private final Map<Integer,ResumableFile.Entry> resumeEntries=new HashMap<>();
    private boolean restartAfterStop,receivedRecordBackup;
    private String manifest(List<Item> items,boolean source){StringBuilder b=new StringBuilder();for(Item i:items)b.append(source?i.uri.toString():"").append('\n').append(safeName(i.name)).append('\n').append(validMime(i.mime)).append('\n').append(i.size).append('\n');return b.toString();}
    private HotspotLink hotspot;
    private UsbLink usb;
    private boolean usbMode,fastMode,resumeFolder,resumeUsbFolder;
    private String lastHotspotError="";
    private Network transferNetwork;
    private boolean linking;
    private String hotspotSsid="",hotspotPassword="";
    private Pairing pendingPeer;
    private boolean senderPaired;
    private SecureChannel selectedUsbChannel;
    private Runnable afterWifiPermission;
    private int linkGeneration;
    private List<String[]> setupSteps;
    private int setupIndex;
    private boolean setupReceiving,setupActive,setupWaiting;
    private long lastNotification;
    private static final String TRANSFER_CHANNEL="transfer";
    private void startPermissions(boolean receiving){
        if(setupActive)return;
        setupReceiving=receiving;setupActive=true;setupWaiting=false;setupIndex=0;
        setupSteps=PermissionPlan.forRole(Build.VERSION.SDK_INT,receiving);
        page("permissions",UiText.t(246),UiText.t(247),0);
        note(UiText.t(248));
        nextPermission();
    }
    private void nextPermission(){
        if(!setupActive||isDestroyed()||isFinishing()||setupWaiting)return;
        while(setupIndex<setupSteps.size()){
            String[] step=setupSteps.get(setupIndex++);
            boolean missing=false;for(String permission:step)missing|=checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED;
            if(!missing)continue;
            setupWaiting=true;
            try{requestPermissions(step,SETUP_PERMISSION);return;}
            catch(SecurityException e){setupWaiting=false;}
        }
        permissionSummary();
    }
    private void permissionSummary(){
        boolean missing=false;
        for(String[] step:setupSteps)for(String permission:step)if(!permission.equals(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)&&checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED)missing=true;
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(manager!=null&&!manager.areNotificationsEnabled())missing=true;
        if(!missing){finishPermissions();return;}
        page("permissions",UiText.t(246),UiText.t(249),0);
        note(UiText.t(248));
        button(UiText.t(250),false,()->{try{startActivityForResult(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())),SETUP_SETTINGS);}catch(ActivityNotFoundException e){toast(UiText.t(249));}});
        button(UiText.t(28),true,()->finishPermissions());
        button(UiText.t(29),false,()->{setupActive=false;home();});
    }
    private void finishPermissions(){
        boolean receiving=setupReceiving;setupActive=false;setupWaiting=false;
        if(receiving){receiverSetup();String wifi=Build.VERSION.SDK_INT>=33?Manifest.permission.NEARBY_WIFI_DEVICES:Manifest.permission.ACCESS_FINE_LOCATION;
            if(checkSelfPermission(wifi)==PackageManager.PERMISSION_GRANTED)beginHotspot();else note(UiText.t(42));
        }else connectPage();
    }
    private void transferNotification(String message,int percent,boolean finished){
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(manager==null||!manager.areNotificationsEnabled())return;
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        long now=SystemClock.elapsedRealtime();if(!finished&&percent>=0&&now-lastNotification<1500)return;lastNotification=now;
        manager.createNotificationChannel(new NotificationChannel(TRANSFER_CHANNEL,UiText.t(251),NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder notification=new Notification.Builder(this,TRANSFER_CHANNEL).setSmallIcon(android.R.drawable.stat_sys_upload).setContentTitle("REBARIT CLONE").setContentText(message).setContentIntent(tap).setOnlyAlertOnce(true).setOngoing(!finished).setAutoCancel(finished).setVisibility(Notification.VISIBILITY_PRIVATE);
        if(!finished)notification.setProgress(1000,Math.max(0,percent),percent<0);
        try{manager.notify(74,notification.build());}catch(SecurityException ignored){}
    }
    private final Handler main=new Handler(Looper.getMainLooper());

    static class Item {Uri uri;String name,mime;long size;Item(){}Item(Uri u,String n,String m,long s){uri=u;name=n;mime=m;size=s;}}
    @Override public void onCreate(Bundle state){super.onCreate(state);UiText.init(this);hotspot=new HotspotLink(this);usb=new UsbLink(this);fastMode=getPreferences(0).getBoolean("fast5",true);onlineUpdate=new OnlineUpdate(this,()->busy);home();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable box(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private TextView label(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.START);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);t.setLineSpacing(dp(4),1);t.setFontFeatureSettings("kern");if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private void gap(int height){Space s=new Space(this);body.addView(s,new LinearLayout.LayoutParams(1,dp(height)));}
    private TextView text(String value,int size,int color,boolean bold){TextView t=label(value,size,color,bold);body.addView(t);return t;}
    private void page(String id,String title,String description,int step){
        closeGallery();
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        screen=id;root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setLayoutDirection(UiText.direction());
        root.setPadding(dp(24),dp(18),dp(24),dp(14));setContentView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);root.addView(top);
        TextView brand=label("REBARIT CLONE",19,INK,true);brand.setTextDirection(View.TEXT_DIRECTION_LTR);top.addView(brand,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView badge=label(UiText.t(295)+versionName(),11,BLUE,true);badge.setPadding(dp(10),dp(6),dp(10),dp(6));badge.setBackground(box(0xffe8e8ff,20));top.addView(badge);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(12),0,dp(24));scroll.addView(body);
        // The journey is always shown in the same order:
        // 1. Connect  →  2. Select  →  3. Transfer.
        if(step>0){steps(step);gap(24);}
        text(title,28,INK,true);gap(10);subtitle=text(description,15,MUTED,false);gap(24);
    }
    private void steps(int active){
        LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);body.addView(line,new LinearLayout.LayoutParams(-1,-2));
        for(int n=1;n<=3;n++){TextView chip=label((n<active?"✓":String.valueOf(n))+"  "+UiText.t(n==1?270:n==2?269:271),11,n==active?Color.WHITE:n<active?BLUE:MUTED,true);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(4),dp(10),dp(4),dp(10));chip.setBackground(box(n==active?BLUE:n<active?0xffe8e8ff:0xffe9edf5,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),0,dp(2),0);line.addView(chip,lp);}
    }
    private TextView summaryCard(String message){TextView v=text(message,16,INK,true);v.setPadding(dp(18),dp(18),dp(18),dp(18));v.setBackground(box(Color.WHITE,20));return v;}
    private Button button(String title,boolean primary,Runnable click){
        Button b=new Button(this);b.setText(title);b.setTextSize(16);b.setAllCaps(false);b.setTypeface(null,Typeface.BOLD);b.setTextColor(primary?Color.WHITE:BLUE);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x222563eb),box(primary?BLUE:0xffeaf0fd,18),null));
        b.setMinHeight(dp(56));b.setPadding(dp(16),dp(14),dp(16),dp(14));b.setElevation(primary?dp(2):0);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));body.addView(b,lp);b.setOnClickListener(v->click.run());return b;
    }
    private void note(String message){gap(12);TextView t=text(message,13,MUTED,false);t.setPadding(dp(14),dp(12),dp(14),dp(12));t.setBackground(box(0xffe9edf5,14));}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private void alert(String title,String message){new AlertDialog.Builder(UiText.context(this)).setTitle(title).setMessage(message).setPositiveButton(UiText.t(2),null).show();}
    private void chooseLanguage(){
        String[] codes={"ckb","en","ar"};String[] labels={"کوردی","English","العربية"};int selected=Arrays.asList(codes).indexOf(UiText.language());
        new AlertDialog.Builder(UiText.context(this)).setTitle("زمان / Language / اللغة").setSingleChoiceItems(labels,selected,(dialog,which)->{UiText.select(this,codes[which]);dialog.dismiss();home();}).setNegativeButton(UiText.t(61),null).show();
    }
    private static final int NIGHT=0xff050b12,LIGHT=0xfff4faff;
    private void darkScreen(String id,String title){
        closeGallery();
        screen=id;root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(NIGHT);root.setLayoutDirection(UiText.direction());root.setPadding(dp(22),dp(12),dp(22),dp(12));setContentView(root);
        getWindow().setStatusBarColor(NIGHT);getWindow().setNavigationBarColor(NIGHT);getWindow().getDecorView().setSystemUiVisibility(0);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);root.addView(bar,new LinearLayout.LayoutParams(-1,dp(42)));
        if(!id.equals("home")){TextView back=label("‹",32,LIGHT,true);back.setGravity(Gravity.CENTER);back.setContentDescription(UiText.t(29));bar.addView(back,new LinearLayout.LayoutParams(dp(40),-1));back.setOnClickListener(v->home());}
        TextView brand=label(title,20,LIGHT,true);brand.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);bar.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView installedVersion=label("",12,0xff8ea6b8,false);
        installedVersion.setMaxWidth(dp(155));installedVersion.setPadding(dp(8),0,dp(8),0);bar.addView(installedVersion);
        if(onlineUpdate!=null&&id.equals("home"))onlineUpdate.bind(installedVersion);
        else installedVersion.setText("");
        TextView menu=label("⋮",28,LIGHT,true);menu.setGravity(Gravity.CENTER);menu.setContentDescription(UiText.t(262));bar.addView(menu,new LinearLayout.LayoutParams(dp(40),-1));
        menu.setOnClickListener(v->{PopupMenu options=new PopupMenu(this,menu);options.getMenu().add("زمان / Language / اللغة").setOnMenuItemClickListener(i->{chooseLanguage();return true;});options.getMenu().add(onlineUpdate.menuTitle()).setOnMenuItemClickListener(i->{onlineUpdate.checkManually();return true;});options.getMenu().add(UiText.t(310)).setOnMenuItemClickListener(i->{shareOwnApk();return true;});options.show();});
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(12),0,dp(16));scroll.addView(body);
    }
    private void appDownloadPage(){
        page("download",UiText.t(290),UiText.t(291),0);
        try{
            int side=620;BitMatrix matrix=new QRCodeWriter().encode(DOWNLOAD_CATALOG_URL,BarcodeFormat.QR_CODE,side,side);int[] pixels=new int[side*side];
            for(int y=0;y<side;y++)for(int x=0;x<side;x++)pixels[y*side+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
            ImageView qr=new ImageView(this);qr.setImageBitmap(Bitmap.createBitmap(pixels,side,side,Bitmap.Config.ARGB_8888));qr.setContentDescription(UiText.t(292));qr.setScaleType(ImageView.ScaleType.FIT_CENTER);qr.setBackground(box(Color.WHITE,24));qr.setPadding(dp(10),dp(10),dp(10),dp(10));
            int width=Math.min(dp(286),getResources().getDisplayMetrics().widthPixels-dp(48));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(width,width);lp.gravity=Gravity.CENTER;body.addView(qr,lp);
        }catch(Exception e){throw new IllegalStateException(e);}
        gap(18);TextView version=text(UiText.t(295)+versionName(),15,BLUE,true);version.setGravity(Gravity.CENTER);
        TextView url=text(DOWNLOAD_CATALOG_URL,13,MUTED,false);url.setTextDirection(View.TEXT_DIRECTION_LTR);url.setGravity(Gravity.CENTER);url.setTextIsSelectable(true);gap(12);
        button(UiText.t(293),true,this::openDownloadCatalog);
        button(UiText.t(310),false,this::shareOwnApk);
        button(UiText.t(294),false,()->{android.content.ClipboardManager c=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);c.setPrimaryClip(ClipData.newPlainText("rebaritclone download",DOWNLOAD_CATALOG_URL));toast(UiText.t(296));});
        button(UiText.t(29),false,this::home);
    }
    private String versionName(){try{return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception e){return "";}}
    private void shareOwnApk(){
        try{
            Uri apk=Uri.parse("content://"+getPackageName()+".share/apk");
            Intent send=new Intent(Intent.ACTION_SEND);
            send.setType("application/vnd.android.package-archive");
            send.putExtra(Intent.EXTRA_STREAM,apk);
            send.setClipData(ClipData.newRawUri(UiText.t(310),apk));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send,UiText.t(310)));
        }catch(ActivityNotFoundException|SecurityException e){toast(UiText.t(311));}
    }
    private void openDownloadCatalog(){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(DOWNLOAD_CATALOG_URL)));}catch(Exception e){toast(UiText.t(297));}}
    private OnlineUpdate onlineUpdate;
    @Override protected void onResume(){super.onResume();if(onlineUpdate!=null)onlineUpdate.resume();}
    @Override protected void onPause(){if(onlineUpdate!=null)onlineUpdate.pause();super.onPause();}
    private void home(){
        if(!busy){stopLink();senderPaired=false;selectedUsbChannel=null;}
        fileBrowserMode=false;
        darkScreen("home","REBAR IT CLONE");
        View art=new FlowArt(this);body.addView(art,new LinearLayout.LayoutParams(-1,dp(190)));
        text("REBARIT CLONE • VIP",11,0xff57dac2,true).setGravity(Gravity.CENTER);gap(6);text(UiText.t(258),12,0xff8ea6b8,false);gap(8);text(UiText.t(259),25,LIGHT,true);gap(20);
        landingCard(UiText.t(264),UiText.t(260),UiText.t(28),0xff006d67,0xff00a77f,()->deviceRoles(false));
        landingCard(UiText.t(261),UiText.t(263),UiText.t(28),0xff3f2f96,0xff694fe0,()->{fileBrowserMode=true;fileHub();});
        gap(8);button(UiText.t(310),false,this::shareOwnApk);
    }
    private void landingCard(String title,String description,String action,int first,int second,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(20),dp(20),dp(20),dp(16));
        GradientDrawable background=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{first,second});background.setCornerRadius(dp(20));card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff),background,null));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(14));body.addView(card,cp);
        TextView heading=label(title,23,LIGHT,true);card.addView(heading);
        TextView sub=label(description,13,Color.WHITE,false);card.addView(sub);
        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.END);footer.setPadding(0,dp(16),0,0);card.addView(footer);
        TextView pill=label(action+"  ›",14,Color.WHITE,true);pill.setGravity(Gravity.CENTER);pill.setPadding(dp(20),dp(5),dp(20),dp(5));GradientDrawable border=box(Color.TRANSPARENT,24);border.setStroke(dp(1),0xddffffff);pill.setBackground(border);footer.addView(pill);
        card.setFocusable(true);card.setOnClickListener(v->click.run());
    }
    private void deviceRoles(boolean files){
        darkScreen(files?"fileRoles":"deviceRoles",files?UiText.t(261):UiText.t(264));
        gap(26);text(files?UiText.t(261):UiText.t(264),29,LIGHT,true).setGravity(Gravity.CENTER);gap(28);
        darkRole(UiText.t(7),UiText.t(8),"↓",0xff9690ff,()->startPermissions(true));
        darkRole(UiText.t(5),UiText.t(6),"↑",0xff35d8b4,()->startPermissions(false));
        gap(16);text(UiText.t(9),13,0xff8ea6b8,false).setGravity(Gravity.CENTER);
    }
    private void darkRole(String title,String description,String glyph,int accent,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(18),dp(22),dp(18),dp(22));card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),box(0xff0d1822,20),null));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(16));body.addView(card,cp);
        TextView icon=label(glyph,30,NIGHT,true);icon.setGravity(Gravity.CENTER);icon.setBackground(box(accent,15));card.addView(icon,new LinearLayout.LayoutParams(dp(50),dp(54)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(dp(16),0,dp(10),0);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,21,LIGHT,true));words.addView(label(description,13,0xffa9bdca,false));card.setFocusable(true);card.setOnClickListener(v->click.run());
    }
    private static class FlowArt extends View{
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        FlowArt(Context context){super(context);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas canvas){
            float w=getWidth(),h=getHeight();
            paint.setShader(new RadialGradient(w*.85f,h*.7f,w*.7f,new int[]{0xff123448,0xff10182a,NIGHT},new float[]{0,.55f,1},Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h,paint);paint.setShader(null);
            float unit=Math.min(w/340f,h/160f);canvas.save();canvas.translate((w-340*unit)/2,(h-160*unit)/2);canvas.scale(unit,unit);
            for(int i=0;i<2;i++){float x=i==0?62:218;paint.setColor(i==0?0xff293951:0xff254b50);canvas.drawRoundRect(x,12,x+66,144,13,13,paint);paint.setColor(i==0?0xff92a6c4:0xff57dac2);canvas.drawRoundRect(x+7,20,x+59,132,8,8,paint);paint.setColor(0xff152338);canvas.drawRoundRect(x+22,24,x+44,29,3,3,paint);for(int row=0;row<3;row++){paint.setColor(i==0?0xff435a7c:0xff238c82);canvas.drawRoundRect(x+14,47+row*22,x+52,59+row*22,4,4,paint);}}
            paint.setColor(0xffb3a9ff);paint.setStrokeWidth(4);paint.setStrokeCap(Paint.Cap.ROUND);canvas.drawLine(150,68,190,68,paint);canvas.drawLine(182,60,190,68,paint);canvas.drawLine(182,76,190,68,paint);paint.setColor(0xff57dac2);canvas.drawLine(190,91,150,91,paint);canvas.drawLine(158,83,150,91,paint);canvas.drawLine(158,99,150,91,paint);canvas.restore();

        }
    }
    private void role(String title,String description,String icon,Runnable action){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(20),dp(22),dp(20),dp(22));card.setBackground(box(Color.WHITE,22));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(14));body.addView(card,cp);
        TextView glyph=label(icon,32,BLUE,true);glyph.setGravity(Gravity.CENTER);glyph.setBackground(box(0xffedf3ff,16));card.addView(glyph,new LinearLayout.LayoutParams(dp(58),dp(64)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(dp(16),0,dp(16),0);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,21,INK,true));words.addView(label(description,13,MUTED,false));card.setOnClickListener(v->action.run());
    }
    private void categories(){
        if(fileBrowserMode){fileHub();return;}
        page("categories",UiText.t(14),UiText.t(15),2);
        section(UiText.t(284));
        category("photos",UiText.t(16),UiText.t(17),"▧");
        category("videos",UiText.t(18),UiText.t(19),"▷");
        section(UiText.t(285));
        category("files",UiText.t(26),UiText.t(27),"＋");
        category("apps",UiText.t(22),UiText.t(23),"APK");
        category("audio",UiText.t(20),UiText.t(21),"♫");
        section(UiText.t(286));
        category("contacts",UiText.t(24),UiText.t(232),"☏");
        category("calls",UiText.t(229),UiText.t(233),"↔");
        category("sms",UiText.t(230),UiText.t(234),"✉");
        gap(14);summaryCard(selectionSummary(selectedItems()));
        button(UiText.t(28),true,()->prepareSelection());
        button(UiText.t(29),false,()->home());
        note(UiText.t(30));
    }
    /** File-manager style start page for the File transfer card. */
    private void fileHub(){
        closeGallery();fileBrowserMode=true;screen="fileHub";
        getWindow().setStatusBarColor(NIGHT);getWindow().setNavigationBarColor(NIGHT);
        getWindow().getDecorView().setSystemUiVisibility(0);
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(NIGHT);root.setLayoutDirection(UiText.direction());root.setPadding(dp(16),dp(8),dp(16),dp(12));setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);root.addView(header,new LinearLayout.LayoutParams(-1,dp(62)));
        TextView back=label("‹",44,LIGHT,false);back.setGravity(Gravity.CENTER);back.setContentDescription(UiText.t(29));header.addView(back,new LinearLayout.LayoutParams(dp(52),-1));back.setOnClickListener(v->home());
        TextView title=label(UiText.t(26),29,LIGHT,true);title.setGravity(Gravity.CENTER_VERTICAL);header.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        TextView refresh=label("↻",30,LIGHT,false);refresh.setGravity(Gravity.CENTER);refresh.setContentDescription(UiText.t(303));header.addView(refresh,new LinearLayout.LayoutParams(dp(52),-1));refresh.setOnClickListener(v->fileHub());
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(10),0,dp(18));scroll.addView(body);
        EditText search=new EditText(this);search.setSingleLine(true);search.setFocusable(false);search.setClickable(true);search.setTextColor(LIGHT);search.setHintTextColor(0xff8ea6b8);search.setHint(UiText.t(303));search.setTextSize(17);search.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search,0,0,0);search.setCompoundDrawablePadding(dp(10));search.setPadding(dp(16),0,dp(16),0);search.setBackground(box(0xff0d1822,18));body.addView(search,new LinearLayout.LayoutParams(-1,dp(46)));search.setOnClickListener(v->pickFiles());
        gap(18);TextView hint=text(UiText.t(263),14,MUTED,false);hint.setPadding(dp(4),0,dp(4),dp(8));
        Map<String,TextView> counters=new LinkedHashMap<>();
        LinearLayout first=fileHubRow();
        counters.put("audio",fileHubTile(first,UiText.t(20),"♪",0xffef5350,()->openFileBrowserMedia("audio")));
        counters.put("apps",fileHubTile(first,UiText.t(22),"APP",0xff2979ff,this::chooseApps));
        counters.put("videos",fileHubTile(first,UiText.t(18),"▶",0xff7c4dff,()->openFileBrowserMedia("videos")));
        counters.put("photos",fileHubTile(first,UiText.t(16),"▣",0xff00c853,()->openFileBrowserMedia("photos")));
        LinearLayout second=fileHubRow();
        counters.put("documents",fileHubTile(second,UiText.t(304),"≡",0xffffab00,this::pickDocuments));
        counters.put("other",fileHubTile(second,UiText.t(306),"•••",0xff40a4df,this::pickFiles));
        counters.put("downloads",fileHubTile(second,UiText.t(307),"↓",0xff536dfe,this::openDownloads));
        LinearLayout third=fileHubRow();
        fileHubSpacer(third); fileHubTile(third,"سڕینەوەی ئەپ","🗑",0xffff3d57,this::showUninstallApps); fileHubTile(third,UiText.t(24),"☏",0xff00a884,()->requestCategory("contacts")); fileHubSpacer(third);
        if(countSelected()>0){gap(18);TextView selected=text(UiText.t(308)+selectionSummary(selectedItems()),15,BLUE,true);selected.setGravity(Gravity.CENTER);button(UiText.t(309),true,this::prepareSelection);}
        addStorageSummary();
        loadFileHubCounts(counters);
        ensureFileHubPermissions();
    }
    private void ensureFileHubPermissions(){
        if(fileHubPermissionAsked)return;
        List<String> need=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=33){
            if(checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)!=PackageManager.PERMISSION_GRANTED)need.add(Manifest.permission.READ_MEDIA_IMAGES);
            if(checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO)!=PackageManager.PERMISSION_GRANTED)need.add(Manifest.permission.READ_MEDIA_VIDEO);
            if(checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)!=PackageManager.PERMISSION_GRANTED)need.add(Manifest.permission.READ_MEDIA_AUDIO);
        }else if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)need.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if(!need.isEmpty()){fileHubPermissionAsked=true;requestPermissions(need.toArray(new String[0]),FILE_HUB_PERMISSION);}
    }
    private void pickDocuments(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","text/plain","text/csv","application/rtf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-powerpoint","application/vnd.openxmlformats-officedocument.presentationml.presentation","application/vnd.oasis.opendocument.text","application/vnd.oasis.opendocument.spreadsheet","application/vnd.oasis.opendocument.presentation"});
        startActivityForResult(i,FILES);
    }
    private boolean isDocumentMime(String mime,String name){
        String m=mime==null?"":mime.toLowerCase(Locale.ROOT),n=name==null?"":name.toLowerCase(Locale.ROOT);
        if(m.equals("application/pdf")||m.startsWith("text/")||m.contains("word")||m.contains("excel")||m.contains("spreadsheet")||m.contains("powerpoint")||m.contains("presentation")||m.contains("opendocument")||m.equals("application/rtf"))return true;
        return n.matches(".*\\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv|rtf|odt|ods|odp)$");
    }
    private void addStorageSummary(){
        try{
            StatFs stat=new StatFs(Environment.getDataDirectory().getAbsolutePath());
            long total=stat.getTotalBytes(),free=stat.getAvailableBytes(),used=Math.max(0,total-free);
            gap(14);
            LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(16),dp(14),dp(16),dp(14));card.setBackground(box(0xffffffff,18));body.addView(card,new LinearLayout.LayoutParams(-1,-2));
            TextView heading=label("Storage • بیرگە",15,INK,true);card.addView(heading);
            TextView values=label("بەکارهاتوو "+TransferStats.size(used)+" / "+TransferStats.size(total)+"   •   بەتاڵ "+TransferStats.size(free),13,MUTED,false);values.setPadding(0,dp(6),0,dp(8));card.addView(values);
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(1000);bar.setProgress(total>0?(int)Math.min(1000,(used*1000L)/total):0);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(8)));
        }catch(Exception ignored){}
    }
    private LinearLayout fileHubRow(){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.TOP);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(142));lp.setMargins(0,0,0,dp(8));body.addView(row,lp);return row;}
    private void fileHubSpacer(LinearLayout row){ View v=new View(this); row.addView(v,new LinearLayout.LayoutParams(0,-1,1)); }
    private TextView fileHubTile(LinearLayout row,String title,String glyph,int color,Runnable click){
        LinearLayout tile=new LinearLayout(this);tile.setOrientation(1);tile.setGravity(Gravity.CENTER_HORIZONTAL);tile.setPadding(dp(3),dp(8),dp(3),dp(6));tile.setBackground(new RippleDrawable(ColorStateList.valueOf(0x164f46e5),box(0xff0d1822,18),null));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(3),0,dp(3),0);row.addView(tile,lp);
        TextView icon=label(glyph,(glyph.equals("APK")||glyph.equals("APP"))?12:27,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setTextDirection(View.TEXT_DIRECTION_LTR);icon.setBackground(box(color,17));tile.addView(icon,new LinearLayout.LayoutParams(dp(58),dp(58)));
        TextView name=label(title,13,LIGHT,true);name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(38));np.setMargins(0,dp(7),0,0);tile.addView(name,np);
        TextView count=label("…",14,0xff8ea6b8,false);count.setGravity(Gravity.CENTER);tile.addView(count,new LinearLayout.LayoutParams(-1,dp(20)));
        tile.setContentDescription(title);tile.setOnClickListener(v->click.run());return count;
    }
    private void openFileBrowserMedia(String category){
        if(browserMediaAllowed(category)){showFileGallery(category);return;}
        browserMediaCategory=category;List<String> permissions=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=33){permissions.add(category.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:category.equals("videos")?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO);if(Build.VERSION.SDK_INT>=34&&!category.equals("audio"))permissions.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);}
        else permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        requestPermissions(permissions.toArray(new String[0]),FILE_BROWSER_PERMISSION);
    }
    private boolean browserMediaAllowed(String category){
        if(Build.VERSION.SDK_INT<33)return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
        String permission=category.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:category.equals("videos")?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO;
        return checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED;
    }
    private void loadFileHubCounts(Map<String,TextView> counters){worker.execute(()->{Map<String,Integer> values=new LinkedHashMap<>();for(String id:counters.keySet())values.put(id,fileHubCount(id));runOnUiThread(()->{if(!"fileHub".equals(screen))return;for(Map.Entry<String,TextView> entry:counters.entrySet()){Integer value=values.get(entry.getKey());entry.getValue().setText(value==null||value<0?"—":String.valueOf(value));}});});}
    private int fileHubCount(String id){
        try{
            if(id.equals("apps")){int count=0;for(ApplicationInfo app:getPackageManager().getInstalledApplications(0))if(!app.packageName.equals(getPackageName())&&(app.flags&ApplicationInfo.FLAG_SYSTEM)==0&&app.sourceDir!=null)count++;return count;}
            Uri collection;if(id.equals("photos"))collection=MediaStore.Images.Media.EXTERNAL_CONTENT_URI;else if(id.equals("videos"))collection=MediaStore.Video.Media.EXTERNAL_CONTENT_URI;else if(id.equals("audio"))collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;else collection=MediaStore.Files.getContentUri("external");
            String selection=null;String[] args=null;
            if(id.equals("apk")){selection=MediaStore.MediaColumns.DISPLAY_NAME+" LIKE ?";args=new String[]{"%.apk"};}
            else if(id.equals("documents")||id.equals("other")){
                int count=0;String[] projection={MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.MIME_TYPE};
                try(Cursor c=getContentResolver().query(collection,projection,null,null,null)){while(c!=null&&c.moveToNext()){String name=c.isNull(0)?"":c.getString(0),mime=c.isNull(1)?"":c.getString(1);boolean media=mime.startsWith("image/")||mime.startsWith("video/")||mime.startsWith("audio/");boolean apk=name.toLowerCase(Locale.ROOT).endsWith(".apk")||mime.equals("application/vnd.android.package-archive");boolean doc=isDocumentMime(mime,name);if(id.equals("documents")?doc:(!media&&!apk&&!doc))count++;}}return count;
            }
            else if(id.equals("downloads")){
                if(Build.VERSION.SDK_INT>=29) collection=MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                else { selection=MediaStore.MediaColumns.DATA+" LIKE ?"; args=new String[]{Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath()+"/%"}; }
            }
            try(Cursor cursor=getContentResolver().query(collection,new String[]{MediaStore.MediaColumns._ID},selection,args,null)){return cursor==null?0:cursor.getCount();}
        }catch(SecurityException e){return -1;}catch(Exception e){return 0;}
    }
    private void showFileGallery(String initialTab){
        darkScreen("gallery",UiText.t(14));
        root.removeViewAt(root.getChildCount()-1);
        List<FileGallery.Entry> initial=new ArrayList<>();
        for(Item item:groups.getOrDefault("gallery",Collections.emptyList())){FileGallery.Entry e=new FileGallery.Entry();e.uri=item.uri;e.name=item.name;e.mime=item.mime;e.size=item.size;initial.add(e);}
        gallery=new FileGallery(this,initial,selectionSummary(selectedItems()),new FileGallery.Actions(){
            public void changed(List<FileGallery.Entry> selected){List<Item> items=new ArrayList<>();for(FileGallery.Entry e:selected)items.add(new Item(e.uri,e.name,e.mime,e.size));if(items.isEmpty())groups.remove("gallery");else groups.put("gallery",items);if(gallery!=null)gallery.summary(selectionSummary(selectedItems()));}
            public void tab(String id){if(id.equals("files"))pickFiles();else if(id.equals("apps"))chooseApps();else requestCategory("contacts");}
            public void next(){prepareSelection();}
        },initialTab);root.addView(gallery,new LinearLayout.LayoutParams(-1,0,1));
    }
    private List<Item> selectedItems(){LinkedHashMap<String,Item> unique=new LinkedHashMap<>();for(List<Item> list:groups.values())for(Item item:list)unique.put(item.uri.toString(),item);return new ArrayList<>(unique.values());}
    private TransferStats stats(List<Item> items){String[] names=new String[items.size()],mimes=new String[items.size()];long[] sizes=new long[items.size()];for(int n=0;n<items.size();n++){Item i=items.get(n);names[n]=i.name;mimes[n]=i.mime;sizes[n]=i.size;}return new TransferStats(names,mimes,sizes);}
    private String selectionSummary(List<Item> items){TransferStats s=stats(items);return items.size()+UiText.t(31)+TransferStats.size(s.totalBytes)+(s.totalKnown?"":UiText.t(32));}
    private int countSelected(){HashSet<String> unique=new HashSet<>();for(List<Item> list:groups.values())for(Item i:list)unique.add(i.uri.toString());return unique.size();}
    private void section(String name){TextView t=text(name,13,BLUE,true);t.setPadding(dp(4),dp(10),0,dp(8));}
    private void category(String id,String title,String desc,String glyph){
        boolean chosen=groups.containsKey(id);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(16),dp(16),dp(16),dp(16));GradientDrawable tile=box(chosen?0xffeeedff:Color.WHITE,20);tile.setStroke(dp(1),chosen?0xffb8b3fa:0xffe2e7f0);row.setBackground(new RippleDrawable(ColorStateList.valueOf(0x184f46e5),tile,null));row.setFocusable(true);row.setContentDescription(title+". "+(chosen?UiText.t(272):desc));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(10));body.addView(row,lp);
        int accent=id.equals("photos")?0xffd4517d:id.equals("videos")?0xff715bd5:id.equals("files")?0xff168477:id.equals("apps")?0xffd58026:BLUE;
        TextView icon=label(glyph,id.equals("apps")?13:24,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(box(accent,14));row.addView(icon,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(dp(12),0,dp(12),0);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(label(title,18,INK,true));words.addView(label(chosen?(isRecords(id)?selectedRecords.getOrDefault(id,Collections.emptySet()).size()+UiText.t(238)+" • ":"")+selectionSummary(groups.get(id)):desc,12,MUTED,false));
        TextView tick=label(chosen?"✓":"○",24,chosen?BLUE:0xffb5bfd0,true);row.addView(tick);
        row.setOnClickListener(v->{if(id.equals("apps")){chooseApps();return;}if((id.equals("sms")||id.equals("calls"))&&chosen){groups.remove(id);selectedRecords.remove(id);categories();return;}if(isRecords(id)){requestCategory(id);return;}if(chosen){groups.remove(id);categories();}else if(id.equals("files"))pickFiles();else requestCategory(id);});
    }
    private void showUninstallApps(){
        PackageManager pm=getPackageManager();
        final List<ApplicationInfo> userApps=new ArrayList<>(), systemApps=new ArrayList<>();
        try{for(ApplicationInfo a:pm.getInstalledApplications(0)){if(a.packageName.equals(getPackageName()))continue;if((a.flags&ApplicationInfo.FLAG_SYSTEM)!=0)systemApps.add(a);else userApps.add(a);}}catch(Exception ignored){}
        java.util.Comparator<ApplicationInfo> byName=(a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString());userApps.sort(byName);systemApps.sort(byName);
        final LinkedHashSet<String> selected=new LinkedHashSet<>();final List<ApplicationInfo> shown=new ArrayList<>();final boolean[] systemTab={false};final String[] query={""};
        final int WHITE=0xfff7fbff,DIM=0xff8fa6b8,PANEL=0xff101a22,LINE=0xff223440,CYAN=0xff00d9ff,PURPLE=0xff7c4dff,RED=0xffff334d;
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(10),dp(5),dp(10),dp(8));panel.setBackgroundColor(0xff071016);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);panel.addView(top,new LinearLayout.LayoutParams(-1,dp(44)));
        TextView close=label("‹",34,WHITE,false);close.setGravity(Gravity.CENTER);top.addView(close,new LinearLayout.LayoutParams(dp(40),-1));
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.setGravity(Gravity.CENTER);top.addView(titles,new LinearLayout.LayoutParams(0,-1,1));
        TextView title=label("سڕینەوەی ئەپ",17,WHITE,true);title.setGravity(Gravity.CENTER);titles.addView(title);TextView status=label("هیچ ئەپێک دیاری نەکراوە",10,DIM,false);status.setGravity(Gravity.CENTER);titles.addView(status);
        TextView menu=label("⋮",25,WHITE,true);menu.setGravity(Gravity.CENTER);top.addView(menu,new LinearLayout.LayoutParams(dp(40),-1));
        LinearLayout tabs=new LinearLayout(this);tabs.setPadding(dp(4),dp(4),dp(4),dp(4));tabs.setBackground(box(PANEL,18));panel.addView(tabs,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView userTab=label("User Apps\n"+userApps.size(),10,WHITE,true),sysTab=label("System Apps\n"+systemApps.size(),10,DIM,true);userTab.setGravity(Gravity.CENTER);sysTab.setGravity(Gravity.CENTER);tabs.addView(userTab,new LinearLayout.LayoutParams(0,-1,1));tabs.addView(sysTab,new LinearLayout.LayoutParams(0,-1,1));
        EditText find=new EditText(this);find.setSingleLine(true);find.setHint("گەڕان لە ناوی ئەپەکان...");find.setTextSize(13);find.setTextColor(WHITE);find.setHintTextColor(DIM);find.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search,0,0,0);find.setCompoundDrawablePadding(dp(8));find.setPadding(dp(14),0,dp(14),0);find.setBackground(box(PANEL,16));LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(38));fp.setMargins(0,dp(4),0,dp(3));panel.addView(find,fp);
        LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL);panel.addView(tools,new LinearLayout.LayoutParams(-1,dp(32)));TextView selectAll=label("☑  هەمووی",11,WHITE,true);selectAll.setGravity(Gravity.CENTER);selectAll.setBackground(box(0xff132832,12));tools.addView(selectAll,new LinearLayout.LayoutParams(0,dp(31),1));TextView sort=label("A–Z  ☷",11,WHITE,true);sort.setGravity(Gravity.CENTER);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(76),dp(31));sp.setMargins(dp(8),0,0,0);tools.addView(sort,sp);
        GridView grid=new GridView(this);grid.setNumColumns(3);grid.setHorizontalSpacing(dp(5));grid.setVerticalSpacing(dp(5));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setPadding(0,dp(4),0,dp(4));grid.setClipToPadding(false);panel.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        final BaseAdapter[] holder=new BaseAdapter[1];final Runnable[] updateHolder={null};
        BaseAdapter adapter=new BaseAdapter(){public int getCount(){return shown.size();}public Object getItem(int p){return shown.get(p);}public long getItemId(int p){return p;}public View getView(int p,View old,android.view.ViewGroup parent){ApplicationInfo a=shown.get(p);boolean on=selected.contains(a.packageName);
            LinearLayout card=new LinearLayout(MainActivity.this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(dp(4),dp(5),dp(4),dp(5));GradientDrawable bg=box(on?0xff102838:PANEL,15);bg.setStroke(dp(on?2:1),on?CYAN:LINE);card.setBackground(bg);
            FrameLayout iconWrap=new FrameLayout(MainActivity.this);card.addView(iconWrap,new LinearLayout.LayoutParams(dp(38),dp(38)));ImageView icon=new ImageView(MainActivity.this);icon.setImageDrawable(pmIcon(a));icon.setScaleType(ImageView.ScaleType.FIT_CENTER);iconWrap.addView(icon,new FrameLayout.LayoutParams(-1,-1));CheckBox cb=new CheckBox(MainActivity.this);cb.setChecked(on);cb.setClickable(false);cb.setFocusable(false);if(Build.VERSION.SDK_INT>=21)cb.setButtonTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{CYAN,0xff78909c}));FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.TOP|Gravity.END);cp.setMargins(0,-dp(4),-dp(4),0);iconWrap.addView(cb,cp);
            TextView n=label(pm.getApplicationLabel(a).toString(),10,WHITE,true);n.setGravity(Gravity.CENTER);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);n.setPadding(0,dp(3),0,0);card.addView(n,new LinearLayout.LayoutParams(-1,-2));String ver="";try{PackageInfo pi=pm.getPackageInfo(a.packageName,0);ver=pi.versionName==null?"":("v"+pi.versionName+"  •  ");}catch(Exception ignored){}TextView meta=label(ver+appInstalledSize(a),8,DIM,false);meta.setGravity(Gravity.CENTER);meta.setMaxLines(1);card.addView(meta,new LinearLayout.LayoutParams(-1,-2));
            card.setOnClickListener(v->{v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);if(!selected.add(a.packageName))selected.remove(a.packageName);holder[0].notifyDataSetChanged();if(updateHolder[0]!=null)updateHolder[0].run();});return card;}};holder[0]=adapter;grid.setAdapter(adapter);
        TextView trash=label("🗑  سڕینەوە",12,Color.WHITE,true);trash.setGravity(Gravity.CENTER);trash.setBackground(box(RED,18));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(40));tp.setMargins(dp(28),dp(3),dp(28),0);panel.addView(trash,tp);
        final Runnable[] refresh={null};final Runnable update=()->{int c=selected.size();status.setText(c==0?"هیچ ئەپێک دیاری نەکراوە":c+" ئەپ دیاریکراوە");trash.setText(c==0?"🗑  سڕینەوە":"🗑  سڕینەوە • "+c);trash.setAlpha(c==0?.48f:1f);};updateHolder[0]=update;
        refresh[0]=()->{shown.clear();List<ApplicationInfo> base=systemTab[0]?systemApps:userApps;String q=query[0].trim().toLowerCase(Locale.ROOT);for(ApplicationInfo a:base){String n=pm.getApplicationLabel(a).toString();if(q.isEmpty()||n.toLowerCase(Locale.ROOT).contains(q)||a.packageName.toLowerCase(Locale.ROOT).contains(q))shown.add(a);}userTab.setTextColor(systemTab[0]?DIM:WHITE);sysTab.setTextColor(systemTab[0]?WHITE:DIM);userTab.setBackground(box(systemTab[0]?Color.TRANSPARENT:PURPLE,14));sysTab.setBackground(box(systemTab[0]?PURPLE:Color.TRANSPARENT,14));adapter.notifyDataSetChanged();update.run();};
        userTab.setOnClickListener(v->{systemTab[0]=false;refresh[0].run();});sysTab.setOnClickListener(v->{systemTab[0]=true;refresh[0].run();});selectAll.setOnClickListener(v->{boolean all=!shown.isEmpty();for(ApplicationInfo a:shown)if(!selected.contains(a.packageName)){all=false;break;}for(ApplicationInfo a:shown){if(all)selected.remove(a.packageName);else selected.add(a.packageName);}adapter.notifyDataSetChanged();update.run();});find.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence x,int a,int b,int c){}public void afterTextChanged(android.text.Editable e){}public void onTextChanged(CharSequence x,int a,int b,int c){query[0]=x.toString();refresh[0].run();}});sort.setOnClickListener(v->{Collections.reverse(shown);adapter.notifyDataSetChanged();});
        AlertDialog dialog=new AlertDialog.Builder(UiText.context(this)).setView(panel).create();close.setOnClickListener(v->dialog.dismiss());trash.setOnClickListener(v->{if(selected.isEmpty()||uninstallCurrentPackage!=null)return;uninstallQueue.clear();for(String pkg:selected)try{pm.getApplicationInfo(pkg,0);uninstallQueue.addLast(pkg);}catch(Exception ignored){}if(uninstallQueue.isEmpty())return;uninstallSelected=selected;uninstallApps=userApps;uninstallShown=shown;uninstallAdapter=adapter;uninstallHeader=update;launchNextUninstall();});refresh[0].run();dialog.show();Window w=dialog.getWindow();if(w!=null){w.setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*.94f));w.setDimAmount(.65f);}
    }

    private void chooseApps(){
        if(busy)return;busy=true;cancelled=false;loading(UiText.t(33));
        worker.execute(()->{try{
            PackageManager pm=getPackageManager();LinkedHashMap<String,ApplicationInfo> unique=new LinkedHashMap<>();
            Intent query=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            for(ResolveInfo r:pm.queryIntentActivities(query,0)){checkCancel();ApplicationInfo app=r.activityInfo.applicationInfo;
                if(!app.packageName.equals(getPackageName())&&(app.flags&ApplicationInfo.FLAG_SYSTEM)==0&&app.sourceDir!=null)unique.put(app.packageName,app);
            }
            List<ApplicationInfo> all=new ArrayList<>(unique.values());all.sort((a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
            long recentCutoff=System.currentTimeMillis()-30L*24*60*60*1000;
            List<ApplicationInfo> fresh=new ArrayList<>();
            for(ApplicationInfo app:all){try{PackageInfo pi=pm.getPackageInfo(app.packageName,0);if(Math.max(pi.firstInstallTime,pi.lastUpdateTime)>=recentCutoff)fresh.add(app);}catch(Exception ignored){}}
            runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();if(all.isEmpty()){toast(UiText.t(34));return;}showModernAppPicker(all,fresh);});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(37),friendly(e));});}});
    }
    private void showModernAppPicker(List<ApplicationInfo> all,List<ApplicationInfo> fresh){
        // 9.9: simpler two-tab picker. "New" was removed by request.
        // Installed = normal user apps. Not Installed = packages Android still knows about
        // but which are currently not installed (when the device/ROM exposes them).
        final int[] tab={0}; // 0 Installed, 1 Not Installed
        final String[] search={""};
        final Set<String> checkedPkgs=new LinkedHashSet<>(selectedApps);
        final List<ApplicationInfo> notInstalled=new ArrayList<>();
        try{
            int flags=android.content.pm.PackageManager.MATCH_UNINSTALLED_PACKAGES;
            for(ApplicationInfo a:getPackageManager().getInstalledApplications(flags)){
                if(a.packageName.equals(getPackageName()))continue;
                boolean installed=(a.flags&ApplicationInfo.FLAG_INSTALLED)!=0;
                boolean system=(a.flags&ApplicationInfo.FLAG_SYSTEM)!=0;
                if(!installed&&!system)notInstalled.add(a);
            }
            notInstalled.sort((a,b)->getPackageManager().getApplicationLabel(a).toString().compareToIgnoreCase(getPackageManager().getApplicationLabel(b).toString()));
        }catch(Exception ignored){}

        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(14),dp(12),dp(14),dp(8));panel.setBackgroundColor(0xfff7f9fc);
        TextView title=label("ئەپەکان",27,INK,true);title.setGravity(Gravity.CENTER);panel.addView(title);
        TextView sub=label("ئەپەکان هەڵبژێرە بۆ گواستنەوە",13,MUTED,false);sub.setGravity(Gravity.CENTER);sub.setPadding(0,0,0,dp(12));panel.addView(sub);

        LinearLayout tabs=new LinearLayout(this);tabs.setPadding(dp(4),dp(4),dp(4),dp(4));tabs.setBackground(box(0xffedf1f7,18));panel.addView(tabs,new LinearLayout.LayoutParams(-1,dp(46)));
        TextView installedTab=appTab("دامەزراو ("+all.size()+")",true);
        TextView notTab=appTab("دانەمەزراو ("+notInstalled.size()+")",false);
        tabs.addView(installedTab,new LinearLayout.LayoutParams(0,-1,1));
        tabs.addView(notTab,new LinearLayout.LayoutParams(0,-1,1));

        EditText find=new EditText(this);find.setSingleLine(true);find.setHint("گەڕان لە نێو ئەپەکان");find.setTextSize(13);find.setTextColor(INK);find.setHintTextColor(MUTED);find.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search,0,0,0);find.setCompoundDrawablePadding(dp(8));find.setPadding(dp(14),0,dp(14),0);find.setBackground(box(Color.WHITE,16));LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(38));fp.setMargins(0,dp(4),0,dp(3));panel.addView(find,fp);
        TextView selectAll=label("☐  هەمووی هەڵبژێرە",14,BLUE,true);selectAll.setGravity(Gravity.CENTER_VERTICAL);selectAll.setPadding(dp(8),0,dp(8),dp(6));panel.addView(selectAll);

        GridView grid=new GridView(this);grid.setNumColumns(3);grid.setHorizontalSpacing(dp(8));grid.setVerticalSpacing(dp(8));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);panel.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        TextView empty=label("",15,MUTED,false);empty.setGravity(Gravity.CENTER);grid.setEmptyView(empty);panel.addView(empty,new LinearLayout.LayoutParams(-1,0));
        final List<ApplicationInfo> shown=new ArrayList<>();
        final BaseAdapter[] adapterRef=new BaseAdapter[1];
        BaseAdapter adapter=new BaseAdapter(){
            public int getCount(){return shown.size();} public Object getItem(int p){return shown.get(p);} public long getItemId(int p){return p;}
            public View getView(int p,View old,android.view.ViewGroup parent){ApplicationInfo app=shown.get(p);LinearLayout card=new LinearLayout(MainActivity.this);card.setOrientation(1);card.setGravity(Gravity.CENTER);card.setPadding(dp(7),dp(9),dp(7),dp(9));card.setBackground(box(checkedPkgs.contains(app.packageName)?0xffe9efff:Color.WHITE,17));card.setClickable(true);card.setFocusable(true);
                FrameLayout top=new FrameLayout(MainActivity.this);card.addView(top,new LinearLayout.LayoutParams(dp(58),dp(58)));ImageView icon=new ImageView(MainActivity.this);try{icon.setImageDrawable(pmIcon(app));}catch(Exception ignored){}top.addView(icon,new FrameLayout.LayoutParams(-1,-1));
                CheckBox cb=new CheckBox(MainActivity.this);cb.setChecked(checkedPkgs.contains(app.packageName));cb.setClickable(false);cb.setFocusable(false);cb.setFocusableInTouchMode(false);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(30),dp(30),Gravity.TOP|Gravity.END);cp.setMargins(0,-dp(4),-dp(4),0);top.addView(cb,cp);
                TextView n=label(getPackageManager().getApplicationLabel(app).toString(),13,INK,true);n.setGravity(Gravity.CENTER);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);n.setPadding(0,dp(5),0,0);card.addView(n,new LinearLayout.LayoutParams(-1,-2));
                TextView z=label(tab[0]==0?appInstalledSize(app):"—",11,MUTED,false);z.setGravity(Gravity.CENTER);card.addView(z);
                card.setOnClickListener(v->{if(!checkedPkgs.add(app.packageName))checkedPkgs.remove(app.packageName);adapterRef[0].notifyDataSetChanged();});
                return card;}
        };adapterRef[0]=adapter;grid.setAdapter(adapter);
        Runnable refresh=()->{shown.clear();List<ApplicationInfo> base=tab[0]==0?all:notInstalled;String q=search[0].trim().toLowerCase(Locale.ROOT);for(ApplicationInfo a:base){String n=getPackageManager().getApplicationLabel(a).toString();if(q.isEmpty()||n.toLowerCase(Locale.ROOT).contains(q))shown.add(a);}empty.setText(tab[0]==1?"هیچ ئەپێکی دانەمەزراو نەدۆزرایەوە":"هیچ ئەپێک نەدۆزرایەوە");adapter.notifyDataSetChanged();};
        Runnable paintTabs=()->{installedTab.setBackground(box(tab[0]==0?BLUE:Color.TRANSPARENT,14));notTab.setBackground(box(tab[0]==1?BLUE:Color.TRANSPARENT,14));installedTab.setTextColor(tab[0]==0?Color.WHITE:INK);notTab.setTextColor(tab[0]==1?Color.WHITE:INK);refresh.run();};
        installedTab.setOnClickListener(v->{tab[0]=0;paintTabs.run();});notTab.setOnClickListener(v->{tab[0]=1;paintTabs.run();});
        grid.setOnItemClickListener((p,v,pos,id)->{ApplicationInfo a=shown.get(pos);if(!checkedPkgs.add(a.packageName))checkedPkgs.remove(a.packageName);adapter.notifyDataSetChanged();});
        selectAll.setOnClickListener(v->{boolean allOn=!shown.isEmpty();for(ApplicationInfo a:shown)if(!checkedPkgs.contains(a.packageName)){allOn=false;break;}for(ApplicationInfo a:shown){if(allOn)checkedPkgs.remove(a.packageName);else checkedPkgs.add(a.packageName);}adapter.notifyDataSetChanged();});
        find.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){search[0]=s.toString();refresh.run();}public void afterTextChanged(android.text.Editable e){}});
        paintTabs.run();
        AlertDialog dialog=new AlertDialog.Builder(UiText.context(this)).setView(panel).setNegativeButton(UiText.t(29),null).setPositiveButton("هەڵبژاردن",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{List<ApplicationInfo> chosen=new ArrayList<>();for(ApplicationInfo a:all)if(checkedPkgs.contains(a.packageName))chosen.add(a);dialog.dismiss();exportApps(chosen);});});dialog.show();
        Window w=dialog.getWindow();if(w!=null)w.setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*.88f));
    }
    private TextView appTab(String text,boolean active){TextView t=label(text,13,active?Color.WHITE:INK,true);t.setGravity(Gravity.CENTER);t.setBackground(box(active?BLUE:Color.TRANSPARENT,14));return t;}
    private Drawable pmIcon(ApplicationInfo app){try{return getPackageManager().getApplicationIcon(app);}catch(Exception e){return getPackageManager().getDefaultActivityIcon();}}
    private String appInstalledSize(ApplicationInfo app){long total=0;try{if(app.sourceDir!=null)total+=new File(app.sourceDir).length();if(app.splitSourceDirs!=null)for(String s:app.splitSourceDirs)total+=new File(s).length();}catch(Exception ignored){}return TransferStats.size(total);}
    private void exportApps(List<ApplicationInfo> apps){
        if(apps.isEmpty()){groups.remove("apps");selectedApps.clear();categories();return;}
        busy=true;cancelled=false;loading(UiText.t(38));
        worker.execute(()->{List<Item> exported=new ArrayList<>();Set<String> successful=new HashSet<>();StringBuilder failed=new StringBuilder();
            for(ApplicationInfo old:apps){File bundle=null;try{
                checkCancel();PackageInfo before=getPackageManager().getPackageInfo(old.packageName,0);ApplicationInfo app=before.applicationInfo;
                List<File> parts=new ArrayList<>();parts.add(new File(app.sourceDir));if(app.splitSourceDirs!=null)for(String path:app.splitSourceDirs)parts.add(new File(path));
                bundle=File.createTempFile("app-",".rbapp",getCacheDir());AppBundle.write(parts,bundle);checkCancel();PackageInfo after=getPackageManager().getPackageInfo(app.packageName,0);
                if(before.lastUpdateTime!=after.lastUpdateTime||before.versionCode!=after.versionCode)throw new IOException("App updated during export");
                String label=safeName(getPackageManager().getApplicationLabel(app).toString());if(label.length()>100)label=label.substring(0,100);
                exported.add(new Item(Uri.fromFile(bundle),label+".rbapp",AppBundle.MIME,bundle.length()));successful.add(app.packageName);
            }catch(Exception e){if(bundle!=null)bundle.delete();failed.append(old.packageName).append("\n");if(cancelled)break;}}
            runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.remove("apps");if(!exported.isEmpty())groups.put("apps",exported);selectedApps.clear();selectedApps.addAll(successful);categories();
                if(failed.length()>0)alert(UiText.t(39),UiText.t(40)+failed.toString());});
        });
    }
    private void pickFiles(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);startActivityForResult(i,FILES);}
    private void openDownloads(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
        if(Build.VERSION.SDK_INT>=26)i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"));
        startActivityForResult(i,FILES);
    }
    private void requestCategory(String id){
        pendingCategory=id;List<String> permissions=new ArrayList<>();
        if(id.equals("contacts"))permissions.add(Manifest.permission.READ_CONTACTS);
        else if(id.equals("calls"))permissions.add(Manifest.permission.READ_CALL_LOG);
        else if(id.equals("sms"))permissions.add(Manifest.permission.READ_SMS);
        else if(Build.VERSION.SDK_INT>=33){permissions.add(id.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:id.equals("videos")?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO);
            if(Build.VERSION.SDK_INT>=34&&!id.equals("audio"))permissions.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);
        }else permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if(checkSelfPermission(permissions.get(0))==PackageManager.PERMISSION_GRANTED){loadCategory(id);return;}
        requestPermissions(permissions.toArray(new String[0]),DATA_PERMISSION);
    }
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] grants){
        super.onRequestPermissionsResult(code,perms,grants);
        if(code==SETUP_PERMISSION){setupWaiting=false;main.post(()->nextPermission());return;}
        if(code==FILE_HUB_PERMISSION){if("fileHub".equals(screen))fileHub();return;}
        if(code==FILE_BROWSER_PERMISSION){String category=browserMediaCategory;browserMediaCategory=null;if(category!=null&&browserMediaAllowed(category))showFileGallery(category);else toast(UiText.t(44));return;}
        if(code==HOTSPOT_PERMISSION){
            String needed=Build.VERSION.SDK_INT>=33?Manifest.permission.NEARBY_WIFI_DEVICES:Manifest.permission.ACCESS_FINE_LOCATION;
            Runnable next=afterWifiPermission;afterWifiPermission=null;
            if(checkSelfPermission(needed)==PackageManager.PERMISSION_GRANTED&&next!=null)next.run();else alert(UiText.t(41),UiText.t(42));
        }
        if(code==CAMERA_PERMISSION){if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)scan();else toast(UiText.t(43));}
        if(code==DATA_PERMISSION){boolean allowed=false;for(int g:grants)allowed|=g==PackageManager.PERMISSION_GRANTED;
            if(allowed)loadCategory(pendingCategory);else if(isRecords(pendingCategory))alert(UiText.t(41),UiText.t(235));else toast(UiText.t(44));}
    }
    private void loading(String message){page("loading",message,UiText.t(45),1);ProgressBar p=new ProgressBar(this);body.addView(p);}
    private void loadCategory(String id){
        if(isRecords(id)){loadRecords(id);return;}
        busy=true;cancelled=false;loading(UiText.t(46));
        worker.execute(()->{
            try{
                List<Item> found=media(id);
                checkCancel();runOnUiThread(()->{if(isDestroyed())return;busy=false;if(!found.isEmpty())groups.put(id,found);categories();if(found.isEmpty())toast(UiText.t(47));
                    else if(Build.VERSION.SDK_INT>=34&&(id.equals("photos")||id.equals("videos"))&&checkSelfPermission(id.equals("photos")?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_MEDIA_VIDEO)!=PackageManager.PERMISSION_GRANTED)toast(UiText.t(48));});
            }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(49),friendly(e));});}
        });
    }
    private List<Item> media(String category)throws Exception{
        Uri collection=category.equals("photos")?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:category.equals("videos")?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        List<Item> out=new ArrayList<>();
        try(Cursor c=getContentResolver().query(collection,new String[]{"_id","_display_name","mime_type","_size"},null,null,"date_added DESC")){
            if(c!=null)while(c.moveToNext()){checkCancel();if(out.size()>=MAX_FILES)throw new IOException("TOO_MANY");out.add(new Item(ContentUris.withAppendedId(collection,c.getLong(0)),safeName(c.getString(1)),validMime(c.getString(2)),c.isNull(3)?-1:c.getLong(3)));}
        }return out;
    }
    private boolean isRecords(String id){return "contacts".equals(id)||"calls".equals(id)||"sms".equals(id);}
    private void loadRecords(String kind){
        if(busy)return;busy=true;cancelled=false;loading(UiText.t(46));
        worker.execute(()->{try{PersonalRecords.Result result=PersonalRecords.load(this,kind,()->checkCancel());
            runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();if(result.rows.isEmpty())toast(UiText.t(47));else if(kind.equals("sms")||kind.equals("calls")){if(result.limited)toast(UiText.t(239));exportRecords(kind,result.rows);}else chooseRecords(kind,result);});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(49),e instanceof SecurityException?UiText.t(235):UiText.t(244));});}});
    }
    private void chooseRecords(String kind,PersonalRecords.Result result){
        Set<String> chosen=new HashSet<>(selectedRecords.getOrDefault(kind,Collections.emptySet()));List<PersonalRecords.Row> visible=new ArrayList<>();Set<String> available=new HashSet<>();for(PersonalRecords.Row row:result.rows)available.add(row.id);chosen.retainAll(available);if(!kind.equals("contacts")&&!selectedRecords.containsKey(kind))chosen.addAll(available);
        LinearLayout layout=new LinearLayout(UiText.context(this));layout.setOrientation(1);layout.setPadding(dp(16),dp(8),dp(16),0);layout.setLayoutDirection(UiText.direction());
        EditText search=new EditText(UiText.context(this));search.setSingleLine(true);search.setHint(UiText.t(236));layout.addView(search);
        TextView note=label(kind.equals("contacts")?UiText.t(232):UiText.t(231),13,MUTED,false);layout.addView(note);if(result.limited)layout.addView(label(UiText.t(239),13,MUTED,false));
        TextView count=label("",15,BLUE,true);layout.addView(count);
        LinearLayout actions=new LinearLayout(this);layout.addView(actions);Button all=new Button(this);all.setText(UiText.t(237));actions.addView(all,new LinearLayout.LayoutParams(0,-2,1));Button none=new Button(this);none.setText(UiText.t(245));actions.addView(none,new LinearLayout.LayoutParams(0,-2,1));
        ListView list=new ListView(UiText.context(this));list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);layout.addView(list,new LinearLayout.LayoutParams(-1,Math.min(dp(340),getResources().getDisplayMetrics().heightPixels/3)));
        Runnable refresh=()->{String term=search.getText().toString().toLowerCase(Locale.ROOT);visible.clear();List<String> labels=new ArrayList<>();for(PersonalRecords.Row row:result.rows)if(row.label.toLowerCase(Locale.ROOT).contains(term)){visible.add(row);labels.add(row.label);}
            list.setAdapter(new ArrayAdapter<>(UiText.context(this),android.R.layout.simple_list_item_multiple_choice,labels));list.clearChoices();for(int n=0;n<visible.size();n++)list.setItemChecked(n,chosen.contains(visible.get(n).id));count.setText(chosen.size()+UiText.t(238));};
        list.setOnItemClickListener((parent,view,pos,id)->{String key=visible.get(pos).id;if(list.isItemChecked(pos))chosen.add(key);else chosen.remove(key);count.setText(chosen.size()+UiText.t(238));});
        all.setOnClickListener(v->{for(PersonalRecords.Row row:visible)chosen.add(row.id);refresh.run();});none.setOnClickListener(v->{chosen.clear();refresh.run();});
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refresh.run();
        new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(kind.equals("contacts")?24:kind.equals("calls")?229:230)).setView(layout)
            .setPositiveButton(UiText.t(36),(d,w)->{List<PersonalRecords.Row> rows=new ArrayList<>();for(PersonalRecords.Row row:result.rows)if(chosen.contains(row.id))rows.add(row);exportRecords(kind,rows);})
            .setNegativeButton(UiText.t(61),null).show();
    }
    private void exportRecords(String kind,List<PersonalRecords.Row> rows){
        if(rows.isEmpty()){groups.remove(kind);selectedRecords.remove(kind);categories();return;}
        busy=true;cancelled=false;loading(UiText.t(186));
        worker.execute(()->{try{File file=PersonalRecords.export(this,kind,rows,()->checkCancel());
            String name=kind.equals("contacts")?"contacts-selected.vcf":kind+"-selected-backup.json";String mime=kind.equals("contacts")?"text/x-vcard":"application/json";
            Set<String> ids=new HashSet<>();for(PersonalRecords.Row row:rows)ids.add(row.id);
            runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.put(kind,new ArrayList<>(Collections.singletonList(new Item(Uri.fromFile(file),name,mime,file.length()))));selectedRecords.put(kind,ids);categories();});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(49),e instanceof SecurityException?UiText.t(235):UiText.t(244));});}});
    }
    private void prepareSelection(){
        if(countSelected()==0){toast(UiText.t(50));return;}
        if(countSelected()>MAX_FILES){toast(UiText.t(51));return;}
        selection.clear();Set<String> unique=new HashSet<>();for(List<Item> list:groups.values())for(Item i:list)if(unique.add(i.uri.toString()))selection.add(i);
        if(!senderPaired){connectPage();return;}
        if(selectedUsbChannel!=null){SecureChannel channel=selectedUsbChannel;selectedUsbChannel=null;usbMode=true;transferPage(true);List<Item> items=new ArrayList<>(selection);job(false,()->sendFiles(channel,items));}
        else if(pendingPeer!=null)send(pendingPeer);else connectPage();
    }
    private void connectPage(){
        senderPaired=false;if(selectedUsbChannel!=null){selectedUsbChannel=null;stopLink();}
        page("connect",UiText.t(52),UiText.t(278),1);
        body.addView(new Phones(this),new LinearLayout.LayoutParams(-1,dp(160)));gap(18);
        text(UiText.t(53),16,INK,false);gap(22);
        button(UiText.t(54),true,()->scan());
        button(UiText.t(29),false,()->home());
        TextView manual=text(UiText.t(58),13,MUTED,false);manual.setPadding(0,dp(14),0,0);manual.setOnClickListener(v->manualPairing());
    }
    private void pairedWifi(Pairing peer){
        if(busy)return;busy=true;cancelled=false;page("pairVerify",UiText.t(64),UiText.t(278),1);
        int token=linkGeneration;
        worker.execute(()->{boolean ok=false;for(String host:peer.hosts){try{checkCancel();socket=transferNetwork.getSocketFactory().createSocket();socket.connect(new InetSocketAddress(host,PORT),4500);socket.setSoTimeout(10000);new SecureChannel(socket.getInputStream(),socket.getOutputStream(),peer.key,false);ok=true;break;}catch(Exception ignored){}finally{try{if(socket!=null)socket.close();}catch(Exception ignored){}}}
            final boolean ready=ok;runOnUiThread(()->{if(isDestroyed()||token!=linkGeneration)return;busy=false;if(ready&&!cancelled){pendingPeer=peer;senderPaired=true;usbMode=false;categories();}else{connectPage();alert(UiText.t(62),UiText.t(63));}});});
    }
    private void scan(){if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION);return;}startActivityForResult(new Intent(this,ScanActivity.class),SCAN);}
    private void manualPairing(){EditText e=new EditText(this);e.setHint("rebaritclone:v3:…");e.setTextDirection(View.TEXT_DIRECTION_LTR);new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(59)).setView(e).setPositiveButton(UiText.t(60),(d,w)->usePair(e.getText().toString())).setNegativeButton(UiText.t(61),null).show();}
    private void usePair(String value){
        try{Pairing peer=Pairing.parse(value);pendingPeer=peer;
            if(!peer.ssid.isEmpty()&&Build.VERSION.SDK_INT>=29)wifiPermission(()->connectHotspot(peer));
            else {transferNetwork=hotspot.currentWifi();if(transferNetwork==null)manualJoin(peer);else pairedWifi(peer);}
        }catch(Exception e){alert(UiText.t(62),UiText.t(63));}
    }
    private void wifiPermission(Runnable action){
        String permission=Build.VERSION.SDK_INT>=33?Manifest.permission.NEARBY_WIFI_DEVICES:Manifest.permission.ACCESS_FINE_LOCATION;
        if(checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED){action.run();return;}
        afterWifiPermission=action;
        requestPermissions(Build.VERSION.SDK_INT>=33?new String[]{permission}:new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,permission},HOTSPOT_PERMISSION);
    }
    private void connectHotspot(Pairing peer){
        linking=true;int token=++linkGeneration;
        page("link",UiText.t(64),UiText.t(65),1);
        text(peer.ssid,19,BLUE,true);button(UiText.t(66),false,()->{stopLink();manualJoin(peer);});button(UiText.t(29),false,()->{stopLink();connectPage();});
        hotspot.connect(peer,new HotspotLink.ClientCallback(){
            public void ready(Network network){if(isDestroyed()||token!=linkGeneration||busy)return;linking=false;transferNetwork=network;pairedWifi(peer);}
            public void failed(){if(isDestroyed()||token!=linkGeneration)return;if(busy){closeNetwork();return;}linking=false;manualJoin(peer);}
        });
    }
    private void manualJoin(Pairing peer){
        page("manual",UiText.t(67),UiText.t(68),1);
        if(!peer.ssid.isEmpty()){text(UiText.t(69)+peer.ssid,17,INK,true);gap(12);text(UiText.t(70)+peer.password,16,BLUE,false).setTextIsSelectable(true);}
        button(UiText.t(71),true,()->startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        button(UiText.t(72),true,()->{transferNetwork=hotspot.currentWifi();if(transferNetwork==null)toast(UiText.t(73));else pairedWifi(peer);});
        button(UiText.t(29),false,()->connectPage());
    }
    private void stopLink(){linkGeneration++;linking=false;hotspot.close();if(usb!=null)usb.close();transferNetwork=null;}
    private void beginHotspot(){
        if(busy||linking)return;
        if(Build.VERSION.SDK_INT<29&&folder==null){resumeFolder=true;chooseFolder();return;}
        wifiPermission(()->{
            android.net.wifi.WifiManager wm=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if(!wm.isWifiEnabled()){startActivityForResult(new Intent(Build.VERSION.SDK_INT>=29?Settings.Panel.ACTION_WIFI:Settings.ACTION_WIFI_SETTINGS),WIFI_SETTINGS);return;}
            if(Build.VERSION.SDK_INT<33&&!locationEnabled()){startActivityForResult(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS),LOCATION_SETTINGS);return;}
            lastHotspotError="";linking=true;int token=++linkGeneration;
            main.postDelayed(()->{if(!isDestroyed()&&token==linkGeneration&&linking&&!busy){lastHotspotError="HOTSPOT_TIMEOUT";hotspotFailure();}},45000);
            page("hotspot",UiText.t(74),UiText.t(75),1);
            button(UiText.t(29),false,()->{stopLink();receiverSetup();});
            hotspot.start(fastMode,new HotspotLink.HostCallback(){
                public void ready(String ssid,String password){if(isDestroyed()||token!=linkGeneration)return;hotspotSsid=ssid;hotspotPassword=password;waitForAddress(token,0);}
                public void failed(String reason){if(isDestroyed()||token!=linkGeneration)return;lastHotspotError=reason;linking=false;if(busy){closeNetwork();return;}hotspotFailure();}
            });
        });
    }
    private boolean locationEnabled(){
        android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
        return Build.VERSION.SDK_INT>=28?lm.isLocationEnabled():lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)||lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER);
    }
    private void hotspotFailure(){
        stopLink();hotspotSsid="";hotspotPassword="";
        page("receiver",fastMode?UiText.t(76):UiText.t(77),UiText.t(78),1);
        note(lastHotspotError+" • "+Build.MANUFACTURER+" "+Build.MODEL+" • Android "+Build.VERSION.RELEASE);
        button(UiText.t(79),true,()->beginHotspot());
        button(UiText.t(80),false,()->{fastMode=false;beginHotspot();});
        button(UiText.t(81),false,()->manualHost());
        button(UiText.t(29),false,()->home());
    }
    private void waitForAddress(int token,int attempt){
        if(isDestroyed()||token!=linkGeneration)return;
        if(!wifiAddresses().isEmpty()){linking=false;receive();return;}
        if(attempt>=15){lastHotspotError="LOCAL_ADDRESS_NOT_FOUND";stopLink();manualHost();return;}
        main.postDelayed(()->waitForAddress(token,attempt+1),1000);
    }
    private void manualHost(){
        stopLink();hotspotSsid="";hotspotPassword="";
        page("manualhost",UiText.t(83),UiText.t(84),1);
        if(!lastHotspotError.isEmpty())note(UiText.t(85)+lastHotspotError+"\n"+Build.MANUFACTURER+" "+Build.MODEL+" • Android "+Build.VERSION.RELEASE);
        button(UiText.t(86),true,()->{try{startActivity(new Intent("android.settings.TETHER_SETTINGS"));}catch(Exception e){startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));}});
        button(UiText.t(87),true,()->{if(Build.VERSION.SDK_INT<29&&folder==null)chooseFolder();else receive();});
        note(UiText.t(88));
        button(UiText.t(29),false,()->receiverSetup());
    }
    private void decodeImage(Uri uri){
        busy=true;loading(UiText.t(89));worker.execute(()->{
            try{
                BitmapFactory.Options opt=new BitmapFactory.Options();opt.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,opt);}
                opt.inSampleSize=1;while(opt.outWidth/opt.inSampleSize>1600||opt.outHeight/opt.inSampleSize>1600)opt.inSampleSize*=2;opt.inJustDecodeBounds=false;
                Bitmap bitmap;try(InputStream in=getContentResolver().openInputStream(uri)){bitmap=BitmapFactory.decodeStream(in,null,opt);}if(bitmap==null)throw new IOException("QR");
                int w=bitmap.getWidth(),h=bitmap.getHeight();int[] pixels=new int[w*h];bitmap.getPixels(pixels,0,w,0,0,w,h);bitmap.recycle();
                Map<DecodeHintType,Object> hints=new EnumMap<>(DecodeHintType.class);hints.put(DecodeHintType.TRY_HARDER,true);hints.put(DecodeHintType.POSSIBLE_FORMATS,Collections.singletonList(BarcodeFormat.QR_CODE));
                String payload=new MultiFormatReader().decode(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(w,h,pixels))),hints).getText();Pairing.parse(payload);
                runOnUiThread(()->{if(isDestroyed())return;busy=false;usePair(payload);});
            }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;connectPage();alert(UiText.t(90),UiText.t(91));});}
        });
    }
    private void startUsb(boolean receiving){
        if(busy)return;
        if(receiving&&Build.VERSION.SDK_INT<29&&folder==null){resumeUsbFolder=true;chooseFolder();return;}
        stopLink();usbMode=true;linking=true;int token=++linkGeneration;
        page("usb",UiText.t(92),UiText.t(93),1);
        body.addView(new CableArt(this),new LinearLayout.LayoutParams(-1,dp(150)));gap(12);
        summaryCard(receiving?UiText.t(94):UiText.t(95));
        note(UiText.t(96));
        status=summaryCard(UiText.t(97));status.setTextColor(BLUE);
        button(UiText.t(134),true,()->startUsb(receiving));
        button(UiText.t(29),false,()->{stopLink();if(receiving)usbReceiverSetup();else connectPage();});
        usb.start(receiving,new UsbLink.Listener(){
            public void ready(InputStream in,OutputStream out){
                if(isDestroyed()||token!=linkGeneration)return;linking=false;
                if(!receiving){busy=true;worker.execute(()->{try{SecureChannel channel=UsbSession.open(in,out,false);runOnUiThread(()->{if(isDestroyed()||token!=linkGeneration)return;busy=false;selectedUsbChannel=channel;senderPaired=true;categories();});}catch(Exception e){runOnUiThread(()->{if(isDestroyed()||token!=linkGeneration)return;busy=false;connectPage();alert(UiText.t(98),UiText.t(165));});}});return;}
                page("usbWaiting",UiText.t(97),UiText.t(280),1);button(UiText.t(111),false,()->cancel());
                job(true,()->{SecureChannel channel=UsbSession.open(in,out,true);runOnUiThread(()->{if(!isDestroyed()&&!cancelled){page("selectionWaiting",UiText.t(279),UiText.t(280),2);button(UiText.t(111),false,()->cancel());}});receiveFiles(channel);});
            }
            public void failed(String reason){if(isDestroyed()||token!=linkGeneration)return;linking=false;alert(UiText.t(98),reason);}
        });
    }
    private void usbReceiverSetup(){
        if(busy)return;stopLink();usbMode=true;
        page("usbReceiver",UiText.t(102),UiText.t(273),1);
        body.addView(new CableArt(this),new LinearLayout.LayoutParams(-1,dp(180)));gap(18);
        summaryCard(UiText.t(274));gap(10);summaryCard(UiText.t(275));gap(10);summaryCard(UiText.t(276));gap(16);
        button(UiText.t(277),true,()->startUsb(true));
        note(UiText.t(96));
        button(UiText.t(29),false,()->home());
    }
    private static class CableArt extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        CableArt(Context c){super(c);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
        protected void onDraw(Canvas c){float scale=Math.min(getWidth()/340f,getHeight()/175f);c.save();c.translate((getWidth()-340*scale)/2,(getHeight()-175*scale)/2);c.scale(scale,scale);
            p.setColor(0xffe9e8ff);c.drawRoundRect(0,0,340,175,24,24,p);
            for(int n=0;n<2;n++){float x=n==0?53:231;p.setColor(n==0?0xff627089:BLUE);c.drawRoundRect(x,18,x+56,126,10,10,p);p.setColor(Color.WHITE);c.drawRoundRect(x+5,24,x+51,117,6,6,p);p.setColor(0xffd5d9ed);c.drawRoundRect(x+18,28,x+38,32,2,2,p);p.setColor(n==0?0xff627089:BLUE);c.drawCircle(x+28,72,12,p);}
            p.setColor(BLUE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);Path cable=new Path();cable.moveTo(81,125);cable.lineTo(81,142);cable.cubicTo(81,165,259,165,259,142);cable.lineTo(259,125);c.drawPath(cable,p);p.setStyle(Paint.Style.FILL);c.drawRoundRect(73,121,89,132,3,3,p);c.drawRoundRect(251,121,267,132,3,3,p);p.setTextSize(16);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);c.drawText("USB-C",170,80,p);c.restore();}
    }
    private void receiverSetup(){
        page("receiver",UiText.t(99),UiText.t(100),1);
        body.addView(new Phones(this),new LinearLayout.LayoutParams(-1,dp(140)));gap(14);
        button(UiText.t(101),true,()->beginHotspot());
        button(UiText.t(103),false,()->manualHost());
        note(UiText.t(104));
        button(UiText.t(29),false,()->home());
    }
    private void chooseFolder(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);startActivityForResult(i,FOLDER);}
    private List<String> wifiAddresses(){
        LinkedHashSet<String> values=new LinkedHashSet<>();Set<String> clientInterfaces=new HashSet<>();
        if(hotspot!=null&&Pairing.local(hotspot.hostAddress()))values.add(hotspot.hostAddress());
        try{
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            for(Network n:cm.getAllNetworks()){NetworkCapabilities cap=cm.getNetworkCapabilities(n);LinkProperties lp=cm.getLinkProperties(n);
                if(cap!=null&&lp!=null&&cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)&&!cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN)){
                    clientInterfaces.add(lp.getInterfaceName());
                    if(hotspotSsid.isEmpty())for(LinkAddress la:lp.getLinkAddresses())if(la.getAddress() instanceof Inet4Address&&Pairing.local(la.getAddress().getHostAddress()))values.add(la.getAddress().getHostAddress());
                }
            }
            for(NetworkInterface ni:Collections.list(NetworkInterface.getNetworkInterfaces())){
                String name=ni.getName().toLowerCase(Locale.ROOT);
                if(!hotspotSsid.isEmpty()&&clientInterfaces.contains(ni.getName()))continue;
                if(!ni.isUp()||!(name.startsWith("wlan")||name.startsWith("swlan")||name.startsWith("ap")||name.startsWith("wlp")||name.startsWith("p2p")||name.startsWith("br")))continue;
                for(InetAddress a:Collections.list(ni.getInetAddresses()))if(a instanceof Inet4Address&&Pairing.local(a.getHostAddress()))values.add(a.getHostAddress());
            }
        }catch(Exception ignored){}List<String> result=new ArrayList<>(values);return result.subList(0,Math.min(result.size(),8));
    }
    private void qrPage(String payload){
        page("qr",UiText.t(105),UiText.t(106),1);
        try{
            int side=660;BitMatrix matrix=new QRCodeWriter().encode(payload,BarcodeFormat.QR_CODE,side,side);int[] pixels=new int[side*side];for(int y=0;y<side;y++)for(int x=0;x<side;x++)pixels[y*side+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
            Bitmap bitmap=Bitmap.createBitmap(pixels,side,side,Bitmap.Config.ARGB_8888);ImageView qr=new ImageView(this);qr.setImageBitmap(bitmap);qr.setContentDescription(UiText.t(107));qr.setScaleType(ImageView.ScaleType.FIT_CENTER);qr.setBackground(box(Color.WHITE,24));qr.setPadding(dp(8),dp(8),dp(8),dp(8));
            int width=Math.min(dp(280),getResources().getDisplayMetrics().widthPixels-dp(48));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(width,width);lp.gravity=Gravity.CENTER;body.addView(qr,lp);
        }catch(Exception e){throw new IllegalStateException(e);}
        gap(22);status=text(UiText.t(108),17,BLUE,true);status.setGravity(Gravity.CENTER);
        Switch mode=new Switch(this);mode.setText(UiText.t(109));mode.setChecked(fastMode);body.addView(mode);
        mode.setOnCheckedChangeListener((v,on)->{fastMode=on;getPreferences(0).edit().putBoolean("fast5",on).apply();restartAfterStop=true;cancel();});
        note(hotspot.hostInfo()+UiText.t(110));
        button(UiText.t(111),false,()->cancel());
        TextView copy=text(UiText.t(112),13,MUTED,false);copy.setGravity(Gravity.CENTER);copy.setPadding(0,dp(16),0,0);
        copy.setOnClickListener(v->{android.content.ClipboardManager c=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);ClipData clip=ClipData.newPlainText("rebaritclone pairing",payload);if(Build.VERSION.SDK_INT>=33){PersistableBundle extras=new PersistableBundle();extras.putBoolean("android.content.extra.IS_SENSITIVE",true);clip.getDescription().setExtras(extras);}c.setPrimaryClip(clip);toast(UiText.t(113));});
    }
    private void transferPage(boolean sending){
        lastNotification=0;transferNotification(sending?UiText.t(114):UiText.t(115),-1,false);
        page("transfer",sending?UiText.t(114):UiText.t(115),UiText.t(116),3);

        gap(16);percentage=text(UiText.t(118),64,BLUE,true);percentage.setGravity(Gravity.CENTER);gap(20);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);progress.setProgressBackgroundTintList(ColorStateList.valueOf(0xffe0e4f1));progress.setProgressTintList(ColorStateList.valueOf(BLUE));body.addView(progress,new LinearLayout.LayoutParams(-1,dp(14)));gap(26);
        status=text(UiText.t(119),17,INK,true);status.setVisibility(View.GONE);details=summaryCard(UiText.t(120));details.setLineSpacing(dp(10),1);gap(24);
        button(UiText.t(121),false,()->new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(122)).setMessage(UiText.t(123)).setPositiveButton(UiText.t(111),(d,w)->cancel()).setNegativeButton(UiText.t(124),null).show());
    }
    private void resultPage(boolean success,String message,boolean receiving){
        transferNotification(success?UiText.t(125):UiText.t(126),0,true);
        page("result",success?UiText.t(125):UiText.t(126),message,0);gap(24);
        TextView icon=text(success?"✓":"!",80,success?0xff12a875:0xffd68122,true);icon.setGravity(Gravity.CENTER);gap(20);
        text(completed+UiText.t(127),22,INK,true).setGravity(Gravity.CENTER);note(UiText.t(128));
        if(transferStats!=null){
            summaryCard(UiText.t(253)+(transferStats.total(0)-transferStats.remaining(0,completed)));gap(8);
            summaryCard(UiText.t(254)+(transferStats.total(1)-transferStats.remaining(1,completed)));gap(8);
            long seconds=transferStarted==0?0:Math.max(0,(SystemClock.elapsedRealtime()-transferStarted)/1000);
            text(UiText.t(255)+String.format(Locale.US,"%02d:%02d:%02d",seconds/3600,(seconds/60)%60,seconds%60),20,INK,true);
        }
        if(receiving&&!receivedFiles.isEmpty())button(UiText.t(256),true,()->showReceivedFiles());
        if(receiving&&receivedRecordBackup)note(UiText.t(231));
        if(receiving&&!receivedApps.isEmpty())button(UiText.t(129),true,()->installReceivedApps());
        if(receiving&&completed>0){note(Build.VERSION.SDK_INT>=29?UiText.t(130):UiText.t(131));
            if(lastContact!=null)button(UiText.t(132),true,()->importContacts());
        }
        button(UiText.t(133),false,()->home());
        if(!success)button(UiText.t(134),false,()->{if(receiving){if(usbMode)startUsb(true);else beginHotspot();}else connectPage();});
        if(!success)note(UiText.t(135));
    }
    private void showReceivedFiles(){
        List<Item> files=new ArrayList<>(receivedFiles.values());String[] names=new String[files.size()];
        for(int n=0;n<files.size();n++)names[n]=files.get(n).name;
        new AlertDialog.Builder(UiText.context(this)).setTitle(UiText.t(256)).setItems(names,(dialog,index)->{
            Item item=files.get(index);
            if(item.name.toLowerCase(Locale.ROOT).endsWith(".rbapp")||item.name.toLowerCase(Locale.ROOT).endsWith(".apk")){
                Intent install=new Intent(this,AppInstallActivity.class);install.putStringArrayListExtra("uris",new ArrayList<>(Collections.singletonList(item.uri.toString())));install.putStringArrayListExtra("names",new ArrayList<>(Collections.singletonList(item.name)));startActivity(install);return;
            }
            try{Intent view=new Intent(Intent.ACTION_VIEW).setDataAndType(item.uri,item.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);view.setClipData(ClipData.newRawUri("received file",item.uri));startActivity(view);}
            catch(ActivityNotFoundException|SecurityException e){alert(UiText.t(256),UiText.t(257));}
        }).setNegativeButton(UiText.t(29),null).show();
    }
    private void importContacts(){
        try{Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(lastContact,"text/x-vcard").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("contacts",lastContact));startActivity(i);}
        catch(Exception e){alert(UiText.t(132),UiText.t(136));}
    }
    private void tell(String value){runOnUiThread(()->{if(!isDestroyed()&&status!=null)status.setText(value);});}
    private void resetTotals(List<Item> items){if(transferStarted==0)transferStarted=SystemClock.elapsedRealtime();transferStats=stats(items);totalBytes=transferStats.totalBytes;finishedBytes=0;resumedBytes=0;totalKnown=transferStats.totalKnown;lastUpdate=0;startTime=SystemClock.elapsedRealtime();}
    private String eta(long remaining,double rate,long elapsed){
        if(remaining==0)return UiText.t(137);if(remaining<0||rate<=0||elapsed<3000)return UiText.t(138);
        long seconds=(long)Math.ceil(remaining/rate);return seconds>=3600?(seconds/3600)+UiText.t(139)+(seconds%3600/60)+UiText.t(140):seconds>=60?(seconds/60)+UiText.t(141)+(seconds%60)+UiText.t(142):seconds+UiText.t(142);
    }
    private void updateProgress(int index,int count,Item item,long bytes,boolean force){
        long now=SystemClock.elapsedRealtime();if(!force&&now-lastUpdate<200)return;lastUpdate=now;long moved=finishedBytes+bytes;
        int done=Math.min(count,index-1+(force?1:0));
        int percent=totalKnown&&totalBytes>0?(int)Math.min(done==count?1000:999,moved*1000.0/totalBytes):(int)(done*1000.0/Math.max(1,count));
        long remaining=transferStats.remainingBytes(moved),elapsed=now-startTime;
        double rate=Math.max(0,moved-resumedBytes)/Math.max(1,elapsed/1000.0);
        String all=TransferStats.size(totalBytes)+(totalKnown?"":UiText.t(143));
        String info=UiText.t(144)+all+UiText.t(145)+TransferStats.size(moved)+
            UiText.t(155)+String.format(Locale.US,"%.1f MB/s",rate/1000000.0)+UiText.t(156)+(remaining==0&&done<count?UiText.t(157):eta(remaining,rate,elapsed));
        final String display=info;
        runOnUiThread(()->{if(!screen.equals("transfer")||isDestroyed())return;transferNotification((percent/10)+"% • "+done+" / "+count,percent,false);progress.setProgress(percent);percentage.setText((percent/10)+UiText.t(158));status.setText(index+" / "+count+"  •  "+item.name);details.setText(display);});
    }
    interface Work{void run()throws Exception;}
    private void job(boolean receiving,Work work){
        if(busy)return;busy=true;cancelled=false;completed=0;lastContact=null;transferStats=null;transferStarted=0;hotspot.performance(fastMode&&!usbMode);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        worker.execute(()->{boolean ok=false;String message;
            try{checkCancel();work.run();ok=true;message=UiText.t(159);}
            catch(Exception e){message=cancelled?UiText.t(160):friendly(e);}
            finally{closeNetwork();}
            final boolean success=ok;final String result=message;
            runOnUiThread(()->{if(isDestroyed())return;stopLink();busy=false;getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(restartAfterStop){restartAfterStop=false;beginHotspot();}else{resultPage(success,result,receiving);if(success&&receiving&&!receivedApps.isEmpty())installReceivedApps();}});
        });
    }
    private String friendly(Exception e){
        if("SOURCE_CHANGED".equals(e.getMessage()))return UiText.t(161);
        if(e instanceof SecurityException)return UiText.t(162);
        if("TOO_MANY".equals(e.getMessage()))return UiText.t(163);
        if("DECLINED".equals(e.getMessage()))return UiText.t(164);
        if(usbMode)return UiText.t(165);
        if(e instanceof java.net.SocketTimeoutException)return UiText.t(166);
        if(e instanceof java.net.ConnectException||"CONNECT".equals(e.getMessage()))return UiText.t(167);
        if("PAIR".equals(e.getMessage()))return UiText.t(168);
        if(e instanceof EOFException||e instanceof java.net.SocketException)return UiText.t(169);
        return UiText.t(170);
    }
    private void cancel(){cancelled=true;closeNetwork();CountDownLatch a=approval;if(a!=null)a.countDown();if(approvalDialog!=null)approvalDialog.dismiss();tell(UiText.t(171));}
    private void closeNetwork(){if(usb!=null)usb.closeStreams();try{if(socket!=null)socket.close();}catch(Exception ignored){}try{if(listener!=null)listener.close();}catch(Exception ignored){}}
    private void checkCancel()throws IOException{if(cancelled||Thread.currentThread().isInterrupted())throw new IOException("Cancelled");}
    private void expect(SecureChannel c,int expected)throws Exception{byte[] p=c.read();if(p.length!=1||p[0]!=expected)throw new IOException("DECLINED");}
    private void send(Pairing peer){
        if(busy)return;usbMode=false;
        transferPage(true);List<Item> items=new ArrayList<>(selection);
        job(false,()->{
            for(int attempt=0;;attempt++)try{
            if(items.isEmpty()||items.size()>MAX_FILES)throw new IOException("TOO_MANY");SecureChannel channel=null;
            for(String host:peer.hosts){
                checkCancel();try{socket=transferNetwork.getSocketFactory().createSocket();socket.setSendBufferSize(1048576);socket.setReceiveBufferSize(1048576);socket.connect(new InetSocketAddress(host,PORT),4500);socket.setSoTimeout(10000);checkCancel();channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),peer.key,false);socket.setSoTimeout(180000);break;}
                catch(Exception e){try{socket.close();}catch(Exception ignored){}if(cancelled)throw e;}
            }
            if(channel==null)throw new IOException("CONNECT");
            sendFiles(channel,items);break;
            }catch(IOException e){if(cancelled||attempt>=2||!(e instanceof EOFException||e instanceof SocketException||e instanceof SocketTimeoutException||"CONNECT".equals(e.getMessage())))throw e;
                try{if(socket!=null)socket.close();}catch(Exception ignored){}tell(UiText.t(172));for(int wait=0;wait<20;wait++){checkCancel();Thread.sleep(100);}
            }
        });
    }
    private void sendFiles(SecureChannel channel,List<Item> items)throws Exception{
            if(items.isEmpty()||items.size()>MAX_FILES)throw new IOException("TOO_MANY");
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(buffer);String sig=manifest(items,true);if(sendingId.isEmpty()||!sig.equals(sendingManifest)){sendingId=UUID.randomUUID().toString();sendingManifest=sig;}
            out.writeUTF(sendingId);out.writeInt(items.size());channel.write(buffer.toByteArray());
            for(Item item:items){checkCancel();buffer.reset();out.writeUTF(safeName(item.name));out.writeUTF(validMime(item.mime));out.writeLong(item.size);channel.write(buffer.toByteArray());}
            tell(UiText.t(173));expect(channel,1);resetTotals(items);completed=0;int index=0;
            for(Item item:items){checkCancel();index++;final int position=index;final boolean[] first={true};long bytes;
                try(InputStream in=new BufferedInputStream(openSource(item.uri),1048576)){
                    if(in==null)throw new IOException("Source unavailable");
                    bytes=ResumableFile.send(channel,in,item.size,fastMode?1048576:262144,n->{checkCancel();if(n<0)return;if(first[0]){resumedBytes+=n;first[0]=false;}updateProgress(position,items.size(),item,n,false);});
                }
                completed++;updateProgress(index,items.size(),item,bytes,true);finishedBytes+=bytes;
            }expect(channel,3);channel.write(new byte[]{4});sendingId="";sendingManifest="";
    }

    private InputStream openSource(Uri uri)throws Exception{return "file".equals(uri.getScheme())?new FileInputStream(new File(uri.getPath())):getContentResolver().openInputStream(uri);}
    private void receive(){
        if(busy)return;usbMode=false;
        List<String> hosts=wifiAddresses();if(hosts.isEmpty()){alert(UiText.t(174),UiText.t(175));return;}
        String code=SecureChannel.newCode();pairText=hotspotSsid.isEmpty()?Pairing.encode(hosts,code):Pairing.encodeHotspot(hosts,code,hotspotSsid,hotspotPassword);byte[] key=SecureChannel.parseCode(code);
        page("waiting",UiText.t(176),UiText.t(45),1);
        job(true,()->{
            listener=new ServerSocket();checkCancel();listener.setReuseAddress(true);listener.bind(new InetSocketAddress(PORT));listener.setSoTimeout(1000);
            runOnUiThread(()->{if(!isDestroyed()&&!cancelled)qrPage(pairText);});
            for(;;){
            SecureChannel channel=null;long deadline=SystemClock.elapsedRealtime()+600000;
            while(channel==null){checkCancel();if(SystemClock.elapsedRealtime()>deadline)throw new SocketTimeoutException();
                try{socket=listener.accept();socket.setReceiveBufferSize(1048576);socket.setSendBufferSize(1048576);socket.setSoTimeout(10000);channel=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,true);}
                catch(SocketTimeoutException e){if(socket!=null)try{socket.close();}catch(Exception ignored){}}
                catch(Exception e){checkCancel();if(socket!=null)try{socket.close();}catch(Exception ignored){}}
            }
            socket.setSoTimeout(180000);checkCancel();
            runOnUiThread(()->{if(!isDestroyed()&&!cancelled){page("selectionWaiting",UiText.t(279),UiText.t(280),2);button(UiText.t(111),false,()->cancel());}});
            try{receiveFiles(channel);break;}
            catch(IOException e){if(cancelled||listener.isClosed()||!(e instanceof EOFException||e instanceof SocketException||e instanceof SocketTimeoutException))throw e;
                try{socket.close();}catch(Exception ignored){}tell(UiText.t(177));
            }
            }
        });
    }
    private void receiveFiles(SecureChannel channel)throws Exception{
            DataInputStream header=new DataInputStream(new ByteArrayInputStream(channel.read()));String session=header.readUTF();if(!session.matches("[a-f0-9-]{36}"))throw new IOException("Invalid session");int count=header.readInt();if(count<1||count>MAX_FILES||header.available()!=0)throw new IOException("TOO_MANY");
            List<Item> items=new ArrayList<>();
            for(int n=0;n<count;n++){checkCancel();DataInputStream meta=new DataInputStream(new ByteArrayInputStream(channel.read()));Item i=new Item();i.name=safeName(meta.readUTF());i.mime=validMime(meta.readUTF());i.size=meta.readLong();if(i.size< -1||meta.available()!=0)throw new IOException("Invalid metadata");items.add(i);}
            if(!(session.equals(receivingId)&&manifest(items,false).equals(receivingManifest))&&!confirm(items)){channel.write(new byte[]{0});throw new IOException("DECLINED");}checkCancel();
            String sig=manifest(items,false);
            if(!session.equals(receivingId)||!sig.equals(receivingManifest)){
                for(ResumableFile.Entry e:resumeEntries.values())e.partial.delete();resumeEntries.clear();receivedFiles.clear();receivedApps.clear();receivedRecordBackup=false;
                receivingId=session;receivingManifest=sig;receivingBatch=Long.toString(System.currentTimeMillis());receivingLegacy=null;
            }
            if(Build.VERSION.SDK_INT<29&&receivingLegacy==null){Uri parent=DocumentsContract.buildDocumentUriUsingTree(folder,DocumentsContract.getTreeDocumentId(folder));receivingLegacy=DocumentsContract.createDocument(getContentResolver(),parent,DocumentsContract.Document.MIME_TYPE_DIR,"rebaritclone-"+receivingBatch);if(receivingLegacy==null)throw new IOException("Folder unavailable");}
            channel.write(new byte[]{1});resetTotals(items);completed=0;runOnUiThread(()->{if(!isDestroyed())transferPage(false);});int index=0;
            for(Item item:items){checkCancel();index++;final int position=index;final boolean[] first={true};
                ResumableFile.Entry entry=resumeEntries.get(index);
                if(entry==null){entry=new ResumableFile.Entry(File.createTempFile("resume-",".part",getCacheDir()));resumeEntries.put(index,entry);}
                long bytes=ResumableFile.receive(channel,entry,item.size,n->{checkCancel();if(n<0)return;if(first[0]){resumedBytes+=n;first[0]=false;}updateProgress(position,count,item,n,false);},partial->{
                    SavedFile file=new SavedFile(item,receivingBatch,receivingLegacy);
                    try{
                        try(InputStream in=new BufferedInputStream(new FileInputStream(partial));OutputStream out=new BufferedOutputStream(getContentResolver().openOutputStream(file.uri,"w"),1048576)){
                            if(out==null)throw new IOException("Storage unavailable");byte[] data=new byte[1048576];int n;while((n=in.read(data))!=-1){checkCancel();out.write(data,0,n);}
                        }
                        file.commit(item.name);receivedFiles.put(file.uri.toString(),new Item(file.uri,item.name,item.mime,item.size));if(item.name.equals("calls-selected-backup.json")||item.name.equals("sms-selected-backup.json"))receivedRecordBackup=true;if(item.name.toLowerCase(Locale.ROOT).endsWith(".rbapp")||item.name.toLowerCase(Locale.ROOT).endsWith(".apk"))receivedApps.put(file.uri.toString(),item.name);if(item.name.toLowerCase(Locale.ROOT).endsWith(".vcf"))lastContact=file.uri;
                    }finally{if(!file.committed)file.discard();}
                });completed++;updateProgress(index,count,item,bytes,true);finishedBytes+=bytes;
            }channel.write(new byte[]{3});expect(channel,4);
    }

    private class SavedFile{
        Uri uri;boolean committed;
        SavedFile(Item item,String batch,Uri legacy)throws Exception{
            if(Build.VERSION.SDK_INT>=29){Uri collection;String directory;
                if(item.mime.startsWith("image/")){collection=MediaStore.Images.Media.EXTERNAL_CONTENT_URI;directory=Environment.DIRECTORY_PICTURES;}
                else if(item.mime.startsWith("video/")){collection=MediaStore.Video.Media.EXTERNAL_CONTENT_URI;directory=Environment.DIRECTORY_MOVIES;}
                else if(item.mime.startsWith("audio/")){collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;directory=Environment.DIRECTORY_MUSIC;}
                else{collection=MediaStore.Downloads.EXTERNAL_CONTENT_URI;directory=Environment.DIRECTORY_DOWNLOADS;}
                ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,item.name);values.put(MediaStore.MediaColumns.MIME_TYPE,item.mime);values.put(MediaStore.MediaColumns.RELATIVE_PATH,directory+"/rebaritclone/"+batch);values.put(MediaStore.MediaColumns.IS_PENDING,1);uri=getContentResolver().insert(collection,values);
            }else uri=DocumentsContract.createDocument(getContentResolver(),legacy,"application/octet-stream",item.name+".partial");
            if(uri==null)throw new IOException("Storage unavailable");
        }
        void commit(String name)throws Exception{
            if(Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.IS_PENDING,0);if(getContentResolver().update(uri,values,null,null)!=1)throw new IOException("Finalize failed");}
            else{Uri renamed=DocumentsContract.renameDocument(getContentResolver(),uri,name);if(renamed==null)throw new IOException("Finalize failed");uri=renamed;}
            committed=true;
        }
        void discard(){try{if(Build.VERSION.SDK_INT>=29)getContentResolver().delete(uri,null,null);else DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}
    }
    private boolean confirm(List<Item> items)throws InterruptedException{
        CountDownLatch latch=new CountDownLatch(1);approval=latch;boolean[] yes={false};long bytes=0;boolean unknown=false;
        for(Item i:items){if(i.size<0)unknown=true;else bytes+=i.size;}
        final long total=bytes;final boolean hasUnknown=unknown;
        runOnUiThread(()->{if(isDestroyed()||cancelled){latch.countDown();return;}
            Context themed=UiText.context(this);LinearLayout panel=new LinearLayout(themed);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(22),dp(22),dp(22),dp(18));panel.setLayoutDirection(UiText.direction());
            TextView icon=label("↓",36,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(box(BLUE,20));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(68),dp(68));ip.gravity=Gravity.CENTER_HORIZONTAL;panel.addView(icon,ip);
            TextView title=label(UiText.t(281),23,INK,true);title.setGravity(Gravity.CENTER);title.setPadding(0,dp(16),0,dp(4));panel.addView(title);
            TextView sub=label(UiText.t(282),14,MUTED,false);sub.setGravity(Gravity.CENTER);panel.addView(sub);
            LinearLayout stats=new LinearLayout(themed);stats.setGravity(Gravity.CENTER);stats.setPadding(0,dp(20),0,dp(18));
            TextView count=label(items.size()+UiText.t(178),20,BLUE,true);count.setGravity(Gravity.CENTER);count.setPadding(dp(18),dp(14),dp(18),dp(14));count.setBackground(box(0xffeeeefe,16));stats.addView(count,new LinearLayout.LayoutParams(0,-2,1));
            Space between=new Space(themed);stats.addView(between,new LinearLayout.LayoutParams(dp(10),1));
            TextView size=label(TransferStats.size(total)+(hasUnknown?UiText.t(179):""),20,BLUE,true);size.setGravity(Gravity.CENTER);size.setPadding(dp(18),dp(14),dp(18),dp(14));size.setBackground(box(0xffeeeefe,16));stats.addView(size,new LinearLayout.LayoutParams(0,-2,1));panel.addView(stats);
            LinearLayout files=new LinearLayout(themed);files.setOrientation(LinearLayout.VERTICAL);files.setPadding(dp(14),dp(8),dp(14),dp(8));files.setBackground(box(0xfff3f5fa,16));
            int shown=Math.min(3,items.size());for(int n=0;n<shown;n++){
                Item item=items.get(n);
                LinearLayout fileRow=new LinearLayout(themed);fileRow.setOrientation(LinearLayout.VERTICAL);fileRow.setPadding(0,dp(6),0,dp(6));
                TextView row=label("•  "+item.name,14,INK,false);row.setTextDirection(View.TEXT_DIRECTION_LTR);row.setSingleLine(true);row.setEllipsize(android.text.TextUtils.TruncateAt.END);fileRow.addView(row);
                TextView fileSize=label(TransferStats.size(item.size),12,MUTED,false);fileSize.setTextDirection(View.TEXT_DIRECTION_LTR);fileSize.setPadding(dp(18),dp(2),0,0);fileRow.addView(fileSize);
                files.addView(fileRow);
            }
            if(items.size()>shown){TextView more=label("+ "+(items.size()-shown)+" "+UiText.t(283),13,MUTED,true);more.setPadding(0,dp(6),0,dp(4));files.addView(more);}panel.addView(files);
            TextView prompt=label(UiText.t(180),15,INK,true);prompt.setGravity(Gravity.CENTER);prompt.setPadding(0,dp(18),0,dp(10));panel.addView(prompt);
            LinearLayout actions=new LinearLayout(themed);actions.setGravity(Gravity.CENTER);Button reject=new Button(themed);reject.setText(UiText.t(184));reject.setTextColor(BLUE);reject.setTextSize(16);reject.setAllCaps(false);reject.setTypeface(null,Typeface.BOLD);reject.setBackground(new RippleDrawable(ColorStateList.valueOf(0x184f46e5),box(0xffeaedff,17),null));actions.addView(reject,new LinearLayout.LayoutParams(0,dp(58),1));Space actionGap=new Space(themed);actions.addView(actionGap,new LinearLayout.LayoutParams(dp(10),1));Button receive=new Button(themed);receive.setText("↓  "+UiText.t(183));receive.setTextColor(Color.WHITE);receive.setTextSize(16);receive.setAllCaps(false);receive.setTypeface(null,Typeface.BOLD);receive.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),box(BLUE,17),null));actions.addView(receive,new LinearLayout.LayoutParams(0,dp(58),1));panel.addView(actions);
            approvalDialog=new AlertDialog.Builder(themed).setView(panel).setCancelable(false).create();
            reject.setOnClickListener(v->{approvalDialog.dismiss();latch.countDown();});receive.setOnClickListener(v->{yes[0]=true;approvalDialog.dismiss();latch.countDown();});approvalDialog.show();
        });
        boolean ready=latch.await(150,TimeUnit.SECONDS);approval=null;runOnUiThread(()->{if(approvalDialog!=null)approvalDialog.dismiss();});return ready&&yes[0]&&!cancelled;
    }
    private static String safeName(String name){if(name==null)name="file";name=name.replaceAll("[\\p{Cntrl}/\\\\]","_");if(name.isEmpty()||name.equals(".")||name.equals(".."))name="file";return name.length()>160?name.substring(0,160):name;}
    private static String validMime(String mime){return mime!=null&&mime.length()<128&&mime.matches("[a-zA-Z0-9.+_-]+/[a-zA-Z0-9.+_-]+")?mime:"application/octet-stream";}
    private Item inspect(Uri uri){Item item=new Item(uri,"file",validMime(getContentResolver().getType(uri)),-1);try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){if(c!=null&&c.moveToFirst()){item.name=safeName(c.getString(0));if(!c.isNull(1))item.size=c.getLong(1);}}return item;}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==UNINSTALL_APP){
            String done=uninstallCurrentPackage;uninstallCurrentPackage=null;
            if(result==RESULT_OK&&done!=null){
                if(uninstallSelected!=null)uninstallSelected.remove(done);
                if(uninstallApps!=null)uninstallApps.removeIf(a->a.packageName.equals(done));
                if(uninstallShown!=null)uninstallShown.removeIf(a->a.packageName.equals(done));
                if(uninstallAdapter!=null)uninstallAdapter.notifyDataSetChanged();
                if(uninstallHeader!=null)uninstallHeader.run();
                launchNextUninstall();
            }else{
                uninstallQueue.clear();
                toast("سڕینەوە وەستاندرا؛ ئەپە دیاریکراوەکان هەر دیاریکراو دەمێننەوە");
            }
            return;
        }
        if(request==SETUP_SETTINGS){if(setupActive)permissionSummary();return;}
        if(request==WIFI_SETTINGS||request==LOCATION_SETTINGS){
            android.net.wifi.WifiManager wm=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if((request==WIFI_SETTINGS&&wm.isWifiEnabled())||(request==LOCATION_SETTINGS&&locationEnabled()))beginHotspot();else{receiverSetup();note(UiText.t(185));}return;
        }
        if(request==FOLDER&&result!=RESULT_OK){resumeFolder=false;if(resumeUsbFolder){resumeUsbFolder=false;usbReceiverSetup();}else receiverSetup();return;}
        if(result!=RESULT_OK||data==null)return;
        if(request==FOLDER&&data.getData()!=null){folder=data.getData();if(resumeUsbFolder){resumeUsbFolder=false;startUsb(true);}else if(resumeFolder){resumeFolder=false;beginHotspot();}else receiverSetup();}
        if(request==SCAN){usePair(data.getStringExtra("pairing"));}
        if(request==QR_IMAGE&&data.getData()!=null)decodeImage(data.getData());
        if(request==FILES){List<Uri> uris=new ArrayList<>();if(data.getClipData()!=null){for(int n=0;n<data.getClipData().getItemCount();n++)uris.add(data.getClipData().getItemAt(n).getUri());}else if(data.getData()!=null)uris.add(data.getData());
            busy=true;cancelled=false;loading(UiText.t(186));worker.execute(()->{try{List<Item> list=new ArrayList<>();for(Uri uri:uris){checkCancel();list.add(inspect(uri));}runOnUiThread(()->{if(isDestroyed())return;busy=false;groups.put("files",list);categories();});}catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;categories();alert(UiText.t(187),friendly(e));});}});
        }
    }
    @Override public void onBackPressed(){if(setupActive){setupActive=false;setupWaiting=false;home();return;}if(linking){stopLink();home();return;}if(busy){new AlertDialog.Builder(UiText.context(this)).setMessage(UiText.t(188)).setPositiveButton(UiText.t(189),(d,w)->cancel()).setNegativeButton(UiText.t(190),null).show();}else if(screen.equals("home"))super.onBackPressed();else if(screen.equals("connect"))home();else if(screen.equals("gallery")){closeGallery();fileHub();}else if(screen.equals("fileHub"))categories();else home();}
    @Override protected void onDestroy(){if(onlineUpdate!=null)onlineUpdate.destroy();closeGallery();NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null&&busy)manager.cancel(74);stopLink();cancel();usb.destroy();worker.shutdownNow();super.onDestroy();}
    private static class Phones extends View{
        Paint p=new Paint(3);Phones(Context c){super(c);setContentDescription(UiText.t(191));}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float scale=Math.min(getWidth()/340f,getHeight()/180f);c.save();c.translate((getWidth()-340*scale)/2,(getHeight()-180*scale)/2);c.scale(scale,scale);
            p.setColor(0xffe8efff);c.drawCircle(170,90,84,p);phone(c,55,23,0xffd6e5ff);phone(c,207,8,0xff2563eb);
            p.setColor(BLUE);p.setStrokeWidth(5);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(147,85,193,85,p);c.drawLine(185,77,193,85,p);c.drawLine(185,93,193,85,p);
            p.setColor(0xff99baf9);c.drawLine(147,104,193,104,p);c.drawLine(147,104,155,96,p);c.drawLine(147,104,155,112,p);c.restore();}
        void phone(Canvas c,float x,float y,int color){p.setColor(color);c.drawRoundRect(x,y,x+77,y+140,14,14,p);p.setColor(Color.WHITE);c.drawRoundRect(x+7,y+8,x+70,y+131,10,10,p);p.setColor(INK);c.drawRoundRect(x+28,y+10,x+49,y+15,3,3,p);p.setColor(0xffeaf1ff);c.drawRoundRect(x+14,y+32,x+63,y+75,8,8,p);p.setColor(0xff93b7f6);c.drawRoundRect(x+14,y+86,x+53,y+92,3,3,p);p.setColor(0xffdbe6f8);c.drawRoundRect(x+14,y+100,x+61,y+106,3,3,p);}
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/OnlineUpdate.java`

``` java
package com.abdulla.clonephone;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.*;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.BooleanSupplier;

/** Checks while the app is visible; Android retains installation approval. */
@SuppressWarnings("deprecation")
final class OnlineUpdate {
    private static final String HOST="rebaritclone-update-admin.rebar4qwrna.workers.dev";
    private final Activity activity;
    private final BooleanSupplier busy;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private TextView label;
    private volatile boolean destroyed;
    private boolean visible,checking,downloading,manualRequested;
    private int promptedCode=-1;
    private JSONObject pending;
    private File ready;
    private AlertDialog dialog;
    private String message="";
    private final Runnable poll=()->{offer(false);check(false);schedule();};
    OnlineUpdate(Activity a,BooleanSupplier b){activity=a;busy=b;}
    String words(String ku,String en,String ar){return "en".equals(UiText.language())?en:"ar".equals(UiText.language())?ar:ku;}
    String menuTitle(){return words("وەشانی نوێ","New version","إصدار جديد");}
    private String version(){try{return activity.getPackageManager().getPackageInfo(activity.getPackageName(),0).versionName;}catch(Exception e){return "";}}
    void bind(TextView v){label=v;render();v.setOnClickListener(w->checkManually());}
    private void render(){if(label!=null)label.setText(words("وەشان ","Version ","الإصدار ")+version()+(message.isEmpty()?"":" · "+message));}
    private void status(String s){message=s;render();}
    private boolean canShow(){return visible&&!destroyed&&!busy.getAsBoolean()&&!activity.isFinishing()&&(dialog==null||!dialog.isShowing());}
    void checkManually(){if(downloading)return;if(pending!=null){offer(true);return;}check(true);}
    void resume(){visible=true;offer(false);check(false);schedule();}
    void pause(){visible=false;ui.removeCallbacks(poll);}
    private void schedule(){ui.removeCallbacks(poll);if(visible&&!destroyed)ui.postDelayed(poll,300000);}
    void destroy(){destroyed=true;pause();if(dialog!=null)dialog.dismiss();executor.shutdownNow();}
    private void notice(String text){if(!canShow())return;dialog=new AlertDialog.Builder(UiText.context(activity)).setTitle(menuTitle()).setMessage(text).setPositiveButton(android.R.string.ok,null).show();}
    private HttpURLConnection connect(String address)throws Exception{
        URL url=new URL(address);
        if(!"https".equals(url.getProtocol())||!HOST.equals(url.getHost())||(url.getPort()!=-1&&url.getPort()!=443))throw new IOException("Untrusted update URL");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setUseCaches(false);
        if(c.getResponseCode()!=200){c.disconnect();throw new IOException("Update unavailable");}return c;
    }
    private void validate(File file,int code)throws Exception{
        PackageManager pm=activity.getPackageManager();
        PackageInfo current=pm.getPackageInfo(activity.getPackageName(),PackageManager.GET_SIGNATURES);
        PackageInfo next=pm.getPackageArchiveInfo(file.getAbsolutePath(),PackageManager.GET_SIGNATURES);
        if(next==null||!current.packageName.equals(next.packageName)||next.versionCode!=code||code<=current.versionCode
            ||current.signatures==null||current.signatures.length==0||next.signatures==null||!new HashSet<>(Arrays.asList(current.signatures)).equals(new HashSet<>(Arrays.asList(next.signatures))))throw new IOException("Invalid update");
    }
    private void check(boolean manual){
        if(destroyed||downloading||!visible||busy.getAsBoolean())return;
        manualRequested|=manual;
        if(checking)return;
        checking=true;
        executor.execute(()->{
            HttpURLConnection c=null;
            try{
                c=connect("https://"+HOST+"/update.json");ByteArrayOutputStream json=new ByteArrayOutputStream();
                try(InputStream in=c.getInputStream()){byte[] bytes=new byte[4096];int n;while((n=in.read(bytes))!=-1){if(json.size()+n>65536)throw new IOException("Manifest too large");json.write(bytes,0,n);}}
                JSONObject manifest=new JSONObject(json.toString("UTF-8"));int code=manifest.getInt("versionCode");
                if(code<=0)throw new IOException("Invalid version");
                int installed=activity.getPackageManager().getPackageInfo(activity.getPackageName(),0).versionCode;
                if(code>installed){manifest.getString("apkUrl");manifest.getString("versionName");}
                ui.post(()->{
                    if(destroyed)return;
                    checking=false;boolean requested=manualRequested;manualRequested=false;
                    if(code<=installed){pending=null;ready=null;String latest=words("لە نوێترین وەشاندایت","You're on the latest version","أنت تستخدم أحدث إصدار");status(latest);if(requested)notice(latest);}
                    else{if(pending==null||pending.optInt("versionCode")!=code)ready=null;pending=manifest;status(words("وەشانی نوێ بەردەستە","Update available","يتوفر تحديث"));offer(requested);}
                });
            }catch(Exception e){ui.post(()->{if(destroyed)return;checking=false;boolean requested=manualRequested;manualRequested=false;String error=words("پشکنین سەرکەوتوو نەبوو؛ دووبارە هەوڵ بدە","Couldn't check. Try again.","تعذر التحقق. حاول مجدداً.");status(error);if(requested)notice(error);});}
            finally{if(c!=null)c.disconnect();}
        });
    }
    private void offer(boolean manual){
        if(pending==null||downloading||!canShow()||(!manual&&promptedCode==pending.optInt("versionCode")))return;
        final JSONObject release=pending;
        promptedCode=release.optInt("versionCode");
        String title=ready!=null?words("نوێکردنەوە ئامادەیە","Update ready","التحديث جاهز"):menuTitle();
        String details=words("وەشان ","Version ","الإصدار ")+release.optString("versionName")+"\n"+release.optString("notes","");
        dialog=new AlertDialog.Builder(UiText.context(activity)).setTitle(title).setMessage(details)
            .setPositiveButton(ready!=null?words("دامەزراندن","Install","تثبيت"):words("نوێکردنەوە","Update","تحديث"),(d,w)->{if(ready!=null)install();else download(release);})
            .setNegativeButton(words("دواتر","Later","لاحقاً"),null).show();
    }
    private void download(JSONObject release){
        if(downloading||destroyed)return;
        downloading=true;status(words("داگرتنی نوێکردنەوە…","Downloading update…","جارٍ تنزيل التحديث…"));
        executor.execute(()->{
            HttpURLConnection c=null;File part=new File(activity.getFilesDir(),"online-update.part");
            try{
                int code=release.getInt("versionCode");File target=new File(activity.getFilesDir(),"online-update.apk");
                boolean cached=false;if(target.isFile())try{validate(target,code);cached=true;}catch(Exception ignored){target.delete();}
                if(!cached){
                    c=connect(release.getString("apkUrl"));long expected=c.getContentLengthLong(),total=0;
                    try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(part)){byte[] bytes=new byte[65536];int n;while((n=in.read(bytes))!=-1){if(destroyed||Thread.currentThread().isInterrupted())throw new InterruptedIOException();total+=n;if(total>50L*1024*1024)throw new IOException("APK too large");out.write(bytes,0,n);}}
                    if(expected>=0&&total!=expected)throw new IOException("Incomplete APK");validate(part,code);
                    if(!part.renameTo(target))throw new IOException("Cannot save APK");
                }
                ui.post(()->{if(destroyed)return;downloading=false;ready=target;promptedCode=-1;status(words("نوێکردنەوە ئامادەیە","Update ready","التحديث جاهز"));offer(false);});
            }catch(Exception e){ui.post(()->{if(destroyed)return;downloading=false;String error=words("داگرتن سەرکەوتوو نەبوو؛ دووبارە هەوڵ بدە","Download failed. Try again.","فشل التنزيل. حاول مجدداً.");status(error);notice(error);});}
            finally{if(c!=null)c.disconnect();part.delete();}
        });
    }
    private void install(){
        Intent intent=new Intent(activity,AppInstallActivity.class);
        intent.putStringArrayListExtra("uris",new ArrayList<>(Collections.singletonList("content://"+activity.getPackageName()+".share/update")));
        intent.putStringArrayListExtra("names",new ArrayList<>(Collections.singletonList("REBAR IT Clone")));activity.startActivity(intent);
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/OwnApkProvider.java`

``` java
package com.abdulla.clonephone;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/** Read-only access to the installed base APK for the Android share sheet. */
public final class OwnApkProvider extends ContentProvider {
    private static final String TYPE="application/vnd.android.package-archive";

    private File file(Uri uri) throws FileNotFoundException {
        if(uri==null||!"content".equals(uri.getScheme())||getContext()==null
                ||!(getContext().getPackageName()+".share").equals(uri.getAuthority())
                ||!("/apk".equals(uri.getPath())||"/update".equals(uri.getPath())))throw new FileNotFoundException("Unknown APK");
        File apk="/update".equals(uri.getPath())?new File(getContext().getFilesDir(),"online-update.apk"):new File(getContext().getApplicationInfo().sourceDir);
        if(!apk.isFile())throw new FileNotFoundException("Installed APK is unavailable");
        return apk;
    }

    @Override public boolean onCreate(){return true;}
    @Override public String getType(Uri uri){try{file(uri);return TYPE;}catch(FileNotFoundException e){return null;}}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
        try{
            File apk=file(uri);
            String[] cols=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor result=new MatrixCursor(cols);
            Object[] row=new Object[cols.length];
            for(int i=0;i<cols.length;i++){
                if(OpenableColumns.DISPLAY_NAME.equals(cols[i]))row[i]="REBAR-IT-Clone-"+getContext().getPackageManager().getPackageInfo(getContext().getPackageName(),0).versionName+".apk";
                else if(OpenableColumns.SIZE.equals(cols[i]))row[i]=apk.length();
            }
            result.addRow(row);return result;
        }catch(Exception e){return null;}
    }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
        if(!"r".equals(mode))throw new FileNotFoundException("Read only");
        return ParcelFileDescriptor.open(file(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException("Read only");}
    @Override public int delete(Uri uri,String selection,String[] selectionArgs){throw new UnsupportedOperationException("Read only");}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] selectionArgs){throw new UnsupportedOperationException("Read only");}
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/P2pRetry.java`

``` java
package com.abdulla.clonephone;
/** Retry transient Android Wi-Fi Direct BUSY (2); do not retry permanent errors. */
public final class P2pRetry {
    public static long delay(int reason,int attempt){
        if(reason!=2||attempt<0||attempt>=3)return -1;
        return 750L<<attempt;
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/Pairing.java`

``` java
package com.abdulla.clonephone;

import java.util.*;
import java.nio.charset.StandardCharsets;

/** Strict local-only pairing data; never permits URLs to arbitrary services. */
public final class Pairing {
    public final List<String> hosts;
    public final byte[] key;
    public String ssid="", password="";
    public Pairing(List<String> hosts, byte[] key) { this.hosts=hosts;this.key=key; }
    public static boolean local(String host) {
        if(!host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}"))return false;
        String[] p=host.split("\\.");int[] n=new int[4];
        for(int i=0;i<4;i++){n[i]=Integer.parseInt(p[i]);if(n[i]>255)return false;}
        return n[0]==10 || (n[0]==192 && n[1]==168) || (n[0]==172 && n[1]>=16 && n[1]<=31);
    }
    public static String encode(List<String> hosts,String key) {
        if(hosts.isEmpty())throw new IllegalArgumentException("No Wi-Fi address");
        String s="rebaritclone:v2:"+String.join(",",hosts)+":"+key;
        parse(s);return s;
    }
    public static String encodeHotspot(List<String> hosts,String key,String ssid,String password) {
        String payload="rebaritclone:v3:"+String.join(",",hosts)+":"+key+":"+
            Base64.getUrlEncoder().withoutPadding().encodeToString(ssid.getBytes(StandardCharsets.UTF_8))+":"+
            Base64.getUrlEncoder().withoutPadding().encodeToString(password.getBytes(StandardCharsets.UTF_8));
        parse(payload);return payload;
    }
    public static Pairing parse(String s) {
        if(s==null||s.length()>700)throw new IllegalArgumentException("Invalid QR");
        String[] p=s.trim().split(":",-1);
        if(!p[0].equals("rebaritclone")||!((p.length==4&&p[1].equals("v2"))||(p.length==6&&p[1].equals("v3"))))throw new IllegalArgumentException("Use a rebaritclone QR");
        List<String> hosts=new ArrayList<>();
        for(String h:p[2].split(",")){if(!local(h)||hosts.size()>=8)throw new IllegalArgumentException("Invalid Wi-Fi address");if(!hosts.contains(h))hosts.add(h);}
        Pairing result=new Pairing(hosts,SecureChannel.parseCode(p[3]));
        if(p.length==6){
            result.ssid=new String(Base64.getUrlDecoder().decode(p[4]),StandardCharsets.UTF_8);
            result.password=new String(Base64.getUrlDecoder().decode(p[5]),StandardCharsets.UTF_8);
            if(result.ssid.isEmpty()||result.ssid.getBytes(StandardCharsets.UTF_8).length>32||result.password.length()<8||result.password.length()>63)throw new IllegalArgumentException("Invalid hotspot credentials");
        }
        return result;
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/PermissionPlan.java`

``` java
package com.abdulla.clonephone;
import java.util.*;
/** SDK/role-dependent sequence. No file access or consent is inferred here. */
public final class PermissionPlan {
    private static String p(String name){return "android.permission."+name;}
    public static List<String[]> forRole(int sdk,boolean receiving){
        List<String[]> steps=new ArrayList<>();
        if(sdk>=33)steps.add(new String[]{p("POST_NOTIFICATIONS")});
        steps.add(sdk>=33?new String[]{p("NEARBY_WIFI_DEVICES")}:new String[]{p("ACCESS_COARSE_LOCATION"),p("ACCESS_FINE_LOCATION")});
        if(!receiving){
            if(sdk>=33){
                steps.add(sdk>=34?new String[]{p("READ_MEDIA_IMAGES"),p("READ_MEDIA_VIDEO"),p("READ_MEDIA_VISUAL_USER_SELECTED")}:new String[]{p("READ_MEDIA_IMAGES"),p("READ_MEDIA_VIDEO")});
                steps.add(new String[]{p("READ_MEDIA_AUDIO")});
            }else steps.add(new String[]{p("READ_EXTERNAL_STORAGE")});
            for(String name:new String[]{"CAMERA","READ_CONTACTS","READ_CALL_LOG","READ_SMS"})steps.add(new String[]{p(name)});
        }
        return steps;
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/PersonalRecords.java`

``` java
package com.abdulla.clonephone;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.*;
import java.io.*;
import java.text.DateFormat;
import java.util.*;

final class PersonalRecords {
    static final int LIMIT=5000;
    interface Check {void run()throws IOException;}
    static class Row {String id,label,lookup;Row(String id,String label,String lookup){this.id=id;this.label=label;this.lookup=lookup;}}
    static class Result {final List<Row> rows=new ArrayList<>();boolean limited;}
    static Uri source(String kind){return "calls".equals(kind)?CallLog.Calls.CONTENT_URI:Telephony.Sms.CONTENT_URI;}
    static String[] fields(String kind){return "calls".equals(kind)?new String[]{"_id","number","name","date","duration","type","new","is_read"}:new String[]{"_id","address","body","date","date_sent","type","read","seen","status","thread_id","service_center"};}
    static Result load(Context context,String kind,Check check)throws Exception{
        Result result=new Result();ContentResolver resolver=context.getContentResolver();
        if("contacts".equals(kind)){
            try(Cursor c=resolver.query(ContactsContract.Contacts.CONTENT_URI,new String[]{"_id","lookup","display_name"},null,null,"display_name ASC")){
                if(c==null)throw new IOException("Provider unavailable");
                while(c.moveToNext()){check.run();if(result.rows.size()==LIMIT){result.limited=true;break;}result.rows.add(new Row(c.getString(0),value(c,2),c.getString(1)));}
            }
            Map<String,Row> byId=new HashMap<>();for(Row row:result.rows)byId.put(row.id,row);Set<String> added=new HashSet<>();
            try(Cursor c=resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{"contact_id","data1"},null,null,null)){
                if(c!=null)while(c.moveToNext()){check.run();String id=c.getString(0);if(byId.containsKey(id)&&added.add(id))byId.get(id).label+="\n"+value(c,1);}
            }
        }else{
            DateFormat dates=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,Locale.forLanguageTag(UiText.language()));
            String[] columns="calls".equals(kind)?new String[]{"_id","number","name","date","duration","type"}:new String[]{"_id","address","body","date","type"};
            try(Cursor c=resolver.query(source(kind),columns,null,null,"date DESC, _id DESC")){
                if(c==null)throw new IOException("Provider unavailable");
                while(c.moveToNext()){check.run();if(result.rows.size()==LIMIT){result.limited=true;break;}
                    String label;if("calls".equals(kind)){int type=c.getInt(5);label=value(c,2)+"  "+value(c,1)+"\n"+dates.format(new Date(c.getLong(3)))+" • "+UiText.t(type==1?240:type==2?241:type==3?242:243)+" • "+c.getLong(4)+UiText.t(142);}
                    else{String body=value(c,2);if(body.length()>100)body=body.substring(0,100)+"…";label=value(c,1)+" • "+dates.format(new Date(c.getLong(3)))+"\n"+body;}
                    result.rows.add(new Row(c.getString(0),label,null));
                }
            }
        }return result;
    }
    private static String value(Cursor c,int n){return c.isNull(n)?"":c.getString(n);}
    static File export(Context context,String kind,List<Row> chosen,Check check)throws Exception{
        File output=File.createTempFile("selected-"+kind+"-","contacts".equals(kind)?".vcf":".json",context.getCacheDir());
        try{
            if("contacts".equals(kind)){
                try(OutputStream out=new BufferedOutputStream(new FileOutputStream(output))){byte[] data=new byte[65536];
                    for(Row row:chosen){check.run();if(row.lookup==null)throw new IOException("Contact unavailable");Uri uri=Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI,Uri.encode(row.lookup));long bytes=0;
                        try(InputStream in=context.getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("Contact unavailable");int n;while((n=in.read(data))!=-1){check.run();out.write(data,0,n);bytes+=n;}}
                        if(bytes==0)throw new IOException("Contact unavailable");out.write('\n');
                    }
                }
            }else{
                String[] columns=fields(kind);int count=0;
                try(RecordJson json=new RecordJson(new FileOutputStream(output),kind)){
                    for(Row row:chosen){check.run();
                        try(Cursor c=context.getContentResolver().query(ContentUris.withAppendedId(source(kind),Long.parseLong(row.id)),columns,null,null,null)){
                            if(c==null||!c.moveToFirst())throw new IOException("Selected record no longer available");Map<String,Object> record=new LinkedHashMap<>();
                            for(int n=0;n<columns.length;n++){String field=columns[n];boolean text=field.equals("number")||field.equals("name")||field.equals("address")||field.equals("body")||field.equals("service_center");record.put(field,c.isNull(n)?null:text?c.getString(n):c.getLong(n));}
                            json.record(record);count++;
                        }
                    }if(count!=chosen.size())throw new IOException("Incomplete backup");
                }
            }check.run();return output;
        }catch(Exception e){output.delete();throw e;}
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/RecordJson.java`

``` java
package com.abdulla.clonephone;
import java.io.*;
import java.util.*;

/** UTF-8, versioned backup; no restore or messaging side effects. */
public final class RecordJson implements Closeable {
    private final Writer out;private int count;
    public RecordJson(OutputStream output,String kind)throws IOException{
        if(!"sms".equals(kind)&&!"calls".equals(kind))throw new IllegalArgumentException();
        out=new BufferedWriter(new OutputStreamWriter(output,"UTF-8"));out.write("{\"format\":\"rebaritclone-records\",\"version\":1,\"kind\":");string(kind);out.write(",\"records\":[");
    }
    public void record(Map<String,Object> values)throws IOException{
        if(count++>0)out.write(',');out.write('{');boolean first=true;
        for(Map.Entry<String,Object> entry:values.entrySet()){if(!first)out.write(',');first=false;string(entry.getKey());out.write(':');Object value=entry.getValue();
            if(value==null)out.write("null");else if(value instanceof Long||value instanceof Integer)out.write(value.toString());else if(value instanceof String)string((String)value);else throw new IOException("Unsupported value");}
        out.write('}');
    }
    private void string(String value)throws IOException{out.write('"');for(int i=0;i<value.length();i++){char c=value.charAt(i);if(c=='"'||c=='\\'){out.write('\\');out.write(c);}else if(c<32)out.write(String.format(Locale.ROOT,"\\u%04x",(int)c));else out.write(c);}out.write('"');}
    public int count(){return count;}
    public void close()throws IOException{out.write("],\"count\":"+count+"}");out.close();}
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/ResumableFile.java`

``` java
package com.abdulla.clonephone;

import java.io.*;
import java.security.*;

/** Resume only authenticated full records; verify retained prefix against the source. */
public final class ResumableFile {
    public interface Progress { void update(long bytes) throws Exception; }
    public interface Publisher { void publish(File file) throws Exception; }
    public static final class Entry {
        public final File partial;
        public boolean done;
        public long length;
        public byte[] digest;
        public Entry(File file){partial=file;}
    }
    private static MessageDigest hash() throws Exception{return MessageDigest.getInstance("SHA-256");}
    private static void prefix(InputStream in,long length,MessageDigest hash,Progress progress)throws Exception{
        byte[] b=new byte[262144];long n=0;
        while(n<length){int read=in.read(b,0,(int)Math.min(b.length,length-n));if(read<0)throw new IOException("SOURCE_CHANGED");if(read==0)continue;hash.update(b,0,read);n+=read;progress.update(-1);}
    }
    public static long send(SecureChannel channel,InputStream in,long size,int chunk,Progress progress)throws Exception{
        DataInputStream state=new DataInputStream(new ByteArrayInputStream(channel.read()));
        long offset=state.readLong();boolean done=state.readBoolean();byte[] expected=new byte[32];state.readFully(expected);
        if(state.available()!=0||offset<0||(size>=0&&offset>size))throw new IOException("Invalid resume offset");
        MessageDigest hash=hash();
        try{prefix(in,offset,hash,progress);}catch(Exception e){channel.write(new byte[]{0});throw e;}
        byte[] actual=((MessageDigest)hash.clone()).digest();
        if(!MessageDigest.isEqual(actual,expected)){channel.write(new byte[]{0});throw new IOException("SOURCE_CHANGED");}
        channel.write(new byte[]{1});progress.update(offset);
        if(done){if(in.read()!=-1)throw new IOException("SOURCE_CHANGED");return offset;}
        long bytes=offset;byte[] data=new byte[chunk];int n;
        while((n=in.read(data))!=-1){if(n==0)continue;progress.update(-1);hash.update(data,0,n);channel.writeBuffered(data,n);bytes+=n;progress.update(bytes);}
        if(size>=0&&bytes!=size)throw new IOException("SOURCE_CHANGED");
        channel.write(new byte[0]);channel.write(hash.digest());byte[] ack=channel.read();if(ack.length!=1||ack[0]!=2)throw new IOException("Invalid ACK");return bytes;
    }
    public static long receive(SecureChannel channel,Entry entry,long size,Progress progress,Publisher publisher)throws Exception{
        MessageDigest hash=hash();long offset=entry.done?entry.length:entry.partial.length();
        byte[] digest;
        if(entry.done)digest=entry.digest;
        else{if(offset>0)try(InputStream in=new BufferedInputStream(new FileInputStream(entry.partial))){prefix(in,offset,hash,progress);}digest=((MessageDigest)hash.clone()).digest();}
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(b);out.writeLong(offset);out.writeBoolean(entry.done);out.write(digest);channel.write(b.toByteArray());
        byte[] accept=channel.read();if(accept.length!=1||accept[0]!=1){if(!entry.done)try(RandomAccessFile f=new RandomAccessFile(entry.partial,"rw")){f.setLength(0);}throw new IOException("SOURCE_CHANGED");}
        progress.update(offset);if(entry.done)return offset;
        long bytes=offset;
        try(RandomAccessFile file=new RandomAccessFile(entry.partial,"rw")){
            file.seek(offset);
            for(;;){progress.update(-1);byte[] data=channel.read();if(data.length==0)break;if(size>=0&&data.length>size-bytes)throw new IOException("Size mismatch");
                long before=bytes;try{file.write(data);}catch(IOException e){file.setLength(before);throw e;}hash.update(data);bytes+=data.length;progress.update(bytes);
            }
            digest=hash.digest();if(!MessageDigest.isEqual(digest,channel.read())||(size>=0&&bytes!=size)){file.setLength(0);throw new IOException("Incomplete file");}file.getFD().sync();
        }
        publisher.publish(entry.partial);entry.length=bytes;entry.digest=digest;entry.done=true;entry.partial.delete();
        channel.write(new byte[]{2});return bytes;
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/ScanActivity.java`

``` java
package com.abdulla.clonephone;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Camera;
import android.view.*;
import android.widget.*;
import com.google.zxing.*;
import com.google.zxing.common.HybridBinarizer;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

@SuppressWarnings("deprecation")
public class ScanActivity extends Activity implements SurfaceHolder.Callback {
    private Camera camera;
    private SurfaceView preview;
    private TextView hint;
    private final ExecutorService decoder=Executors.newSingleThreadExecutor();
    private final AtomicBoolean decoding=new AtomicBoolean();
    private volatile boolean done, active;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);UiText.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setLayoutDirection(UiText.direction());root.setBackgroundColor(Color.rgb(15,25,42));
        hint=new TextView(this);hint.setText(UiText.t(221));hint.setTextColor(Color.WHITE);hint.setTextSize(20);hint.setGravity(Gravity.CENTER);hint.setPadding(24,40,24,24);root.addView(hint);
        preview=new SurfaceView(this);root.addView(preview,new LinearLayout.LayoutParams(-1,0,1));preview.getHolder().addCallback(this);
        TextView note=new TextView(this);note.setText(UiText.t(222));note.setTextColor(Color.WHITE);note.setGravity(Gravity.CENTER);note.setPadding(20,24,20,24);root.addView(note);
        Button back=new Button(this);back.setText(UiText.t(29));back.setOnClickListener(v->finish());root.addView(back);setContentView(root);
    }
    @Override protected void onResume(){super.onResume();active=true;if(preview.getHolder().getSurface().isValid())open();}
    @Override protected void onPause(){active=false;release();super.onPause();}
    @Override protected void onDestroy(){decoder.shutdownNow();super.onDestroy();}
    @Override public void surfaceCreated(SurfaceHolder h){if(active)open();}
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int height){}
    @Override public void surfaceDestroyed(SurfaceHolder h){release();}
    private void open(){
        if(camera!=null||done)return;
        try{
            int id=0;Camera.CameraInfo info=new Camera.CameraInfo();
            for(int i=0;i<Camera.getNumberOfCameras();i++){Camera.getCameraInfo(i,info);if(info.facing==Camera.CameraInfo.CAMERA_FACING_BACK){id=i;break;}}
            Camera.getCameraInfo(id,info);camera=Camera.open(id);Camera.Parameters p=camera.getParameters();
            Camera.Size best=null;
            for(Camera.Size s:p.getSupportedPreviewSizes())if(s.width<=1280&&(best==null||s.width*s.height>best.width*best.height))best=s;
            if(best!=null)p.setPreviewSize(best.width,best.height);
            List<String> modes=p.getSupportedFocusModes();if(modes!=null&&modes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE))p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            p.setPreviewFormat(android.graphics.ImageFormat.NV21);camera.setParameters(p);
            int rotation=getWindowManager().getDefaultDisplay().getRotation();int degrees=rotation==Surface.ROTATION_90?90:rotation==Surface.ROTATION_180?180:rotation==Surface.ROTATION_270?270:0;
            camera.setDisplayOrientation((info.orientation-degrees+360)%360);camera.setPreviewDisplay(preview.getHolder());
            camera.setPreviewCallback((data,c)->{
                if(done||!active||!decoding.compareAndSet(false,true))return;
                Camera.Size s=c.getParameters().getPreviewSize();byte[] frame=data.clone();
                try{decoder.execute(()->decode(frame,s.width,s.height));}catch(RejectedExecutionException e){decoding.set(false);}
            });camera.startPreview();
        }catch(Exception e){release();hint.setText(UiText.t(223));}
    }
    private void decode(byte[] data,int width,int height){
        try{
            MultiFormatReader reader=new MultiFormatReader();Map<DecodeHintType,Object> hints=new EnumMap<>(DecodeHintType.class);hints.put(DecodeHintType.POSSIBLE_FORMATS,Collections.singletonList(BarcodeFormat.QR_CODE));
            Result result=reader.decode(new BinaryBitmap(new HybridBinarizer(new PlanarYUVLuminanceSource(data,width,height,0,0,width,height,false))),hints);
            Pairing.parse(result.getText());
            if(active&&!done){done=true;runOnUiThread(()->{setResult(RESULT_OK,new Intent().putExtra("pairing",result.getText()));finish();});}
        }catch(Exception ignored){}finally{decoding.set(false);}
    }
    private void release(){if(camera!=null){try{camera.setPreviewCallback(null);camera.stopPreview();camera.release();}catch(Exception ignored){}camera=null;}}
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/SecureChannel.java`

``` java
package com.abdulla.clonephone;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.*;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Versioned, bounded encrypted records. Independent keys and counters per direction. */
public final class SecureChannel {
    public static final int MAX_FRAME = 1048576;
    private final DataInputStream input;
    private final DataOutputStream output;
    private final byte[] sendKey, receiveKey;
    private long sent, received;
    private final Cipher encrypt = Cipher.getInstance("AES/GCM/NoPadding");
    private final Cipher decrypt = Cipher.getInstance("AES/GCM/NoPadding");

    public SecureChannel(InputStream in, OutputStream out, byte[] master, boolean server) throws Exception {
        input = new DataInputStream(new BufferedInputStream(in, 524288)); output = new DataOutputStream(new BufferedOutputStream(out, 524288));
        byte[] session = new byte[32];
        if (server) {
            new SecureRandom().nextBytes(session);
            output.writeInt(0x43503034); output.write(session); output.flush();
        } else {
            if (input.readInt() != 0x43503034) throw new IOException("Protocol mismatch");
            input.readFully(session);
        }
        sendKey = derive(master, session, server ? "server" : "client");
        receiveKey = derive(master, session, server ? "client" : "server");
        if (server) {
            if (!MessageDigest.isEqual(read(), "HELLO".getBytes(StandardCharsets.UTF_8))) throw new IOException("Pairing failed");
            write("READY".getBytes(StandardCharsets.UTF_8));
        } else {
            write("HELLO".getBytes(StandardCharsets.UTF_8));
            if (!MessageDigest.isEqual(read(), "READY".getBytes(StandardCharsets.UTF_8))) throw new IOException("Pairing failed");
        }
    }
    private static byte[] derive(byte[] master, byte[] session, String direction) throws Exception {
        javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(master, "HmacSHA256"));
        mac.update(session);
        return mac.doFinal(("rebaritclone-v4-" + direction).getBytes(StandardCharsets.UTF_8));
    }
    private byte[] nonce(long counter) { return ByteBuffer.allocate(12).putInt(0).putLong(counter).array(); }
    public void write(byte[] plain) throws Exception { writeBuffered(plain, plain.length); output.flush(); }
    public void writeBuffered(byte[] plain, int length) throws Exception {
        if (length < 0 || length > plain.length || length > MAX_FRAME || sent == Long.MAX_VALUE) throw new IOException("Frame limit");
        encrypt.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(sendKey, "AES"), new GCMParameterSpec(128, nonce(sent++)));
        byte[] encrypted = encrypt.doFinal(plain, 0, length);
        output.writeInt(encrypted.length); output.write(encrypted);
    }
    public byte[] read() throws Exception {
        int size = input.readInt();
        if (size < 16 || size > MAX_FRAME + 16 || received == Long.MAX_VALUE) throw new IOException("Frame limit");
        byte[] encrypted = new byte[size]; input.readFully(encrypted);
        decrypt.init(Cipher.DECRYPT_MODE, new SecretKeySpec(receiveKey, "AES"), new GCMParameterSpec(128, nonce(received++)));
        return decrypt.doFinal(encrypted);
    }
    public static String newCode() {
        byte[] key = new byte[16]; new SecureRandom().nextBytes(key);
        StringBuilder s = new StringBuilder(); for (byte b : key) s.append(String.format("%02X", b)); return s.toString();
    }
    public static byte[] parseCode(String text) {
        text = text.replaceAll("[\\s-]", "");
        if (!text.matches("[0-9a-fA-F]{32}")) throw new IllegalArgumentException("Pairing code must be 32 hex characters");
        byte[] key = new byte[16]; for (int i=0; i<16; i++) key[i]=(byte)Integer.parseInt(text.substring(i*2,i*2+2),16); return key;
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/TransferStats.java`

``` java
package com.abdulla.clonephone;
import java.util.Locale;

/** Manifest counts; a current file remains pending until its final acknowledgement. */
public final class TransferStats {
    public final long totalBytes;
    public final boolean totalKnown;
    public final int count;
    private final int[][] prefix;
    public TransferStats(String[] names,String[] mimes,long[] sizes){
        if(names.length!=mimes.length||names.length!=sizes.length)throw new IllegalArgumentException();
        count=sizes.length;prefix=new int[count+1][4];long total=0;boolean known=true;
        for(int n=0;n<count;n++){System.arraycopy(prefix[n],0,prefix[n+1],0,4);prefix[n+1][kind(names[n],mimes[n])]++;if(sizes[n]<0)known=false;else total=Math.addExact(total,sizes[n]);}
        totalBytes=total;totalKnown=known;
    }
    public static int kind(String name,String mime){
        String n=name==null?"":name.toLowerCase(Locale.ROOT),m=mime==null?"":mime.toLowerCase(Locale.ROOT);
        if(m.startsWith("image/")||n.matches(".*\\.(jpg|jpeg|png|webp|heic|heif|gif|bmp|avif)$"))return 0;
        if(m.startsWith("video/")||n.matches(".*\\.(mp4|mkv|mov|webm|avi|3gp|m4v)$"))return 1;
        if(n.endsWith(".apk")||n.endsWith(".rbapp"))return 2;return 3;
    }
    public int total(int kind){return prefix[count][kind];}
    public int remaining(int kind,int completed){return total(kind)-prefix[Math.max(0,Math.min(count,completed))][kind];}
    public long remainingBytes(long moved){return totalKnown?Math.max(0,totalBytes-Math.max(0,moved)):-1;}
    /** Human-readable real file size. Uses the most suitable unit instead of forcing everything to GB. */
    public static String size(long bytes){
        if(bytes<0)return "—";
        if(bytes<1024)return bytes+" B";
        final String[] units={"KB","MB","GB","TB"};
        double value=bytes;
        int unit=-1;
        do{value/=1024.0;unit++;}while(value>=1024.0&&unit<units.length-1);
        if(value>=100)return String.format(Locale.US,"%.0f %s",value,units[unit]);
        if(value>=10)return String.format(Locale.US,"%.1f %s",value,units[unit]);
        return String.format(Locale.US,"%.2f %s",value,units[unit]);
    }
    /** Kept for source compatibility with older code. */
    public static String gb(long bytes){return size(bytes);}
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/Translations.java`

``` java
package com.abdulla.clonephone;
/** Generated from localization catalogs. Do not hand-edit. */
public final class Translations {
    public static final int COUNT=312;
    private static final String[][] TEXT={
        {"٩.١ • بێ ئینتەرنێت","8.4 • Offline","8.4 • بدون إنترنت"},
        {"١  هەڵبژاردن     •     ٢  پەیوەندی     •     ٣  گواستنەوە","1  Select     •     2  Connect     •     3  Transfer","١  الاختيار     •     ٢  الاتصال     •     ٣  النقل"},
        {"باشە","OK","حسنًا"},
        {"داتاکەت بگوازەوە","Transfer your data","انقل بياناتك"},
        {"لە مۆبایلی کۆنەوە بۆ مۆبایلی نوێ، بە چەند هەنگاوێکی سادە.","Move from your old phone to your new phone in a few simple steps.","انقل بياناتك من هاتفك القديم إلى الجديد بخطوات بسيطة."},
        {"من مۆبایلە کۆنەکەم","Old phone","الهاتف القديم"},
        {"داتاکان لەم مۆبایلەوە دەنێرم","Send data from this phone","إرسال البيانات من هذا الهاتف"},
        {"من مۆبایلە تازەکەم","New phone","الهاتف الجديد"},
        {"داتاکان بۆ ئەم مۆبایلە وەردەگرم","Receive data on this phone","استقبال البيانات على هذا الهاتف"},
        {"هۆتسپۆت یان کەیبڵ • بەبێ سیمکارت و ئینتەرنێت","Hotspot or cable • No SIM or internet needed","نقطة اتصال أو كابل • دون شريحة أو إنترنت"},
        {"وەرگرتن بە USB-C","Receive via USB-C","الاستقبال عبر USB-C"},
        {"چی دەگوازرێتەوە؟","What can I transfer?","ما الذي يمكن نقله؟"},
        {"داتای بەردەست","Supported data","البيانات المدعومة"},
        {"وێنە، ڤیدیۆ، دەنگ، فایل، ئەپەکان و ژمارەکان بە VCF. SMS و مێژووی پەیوەندی بە فایلێکی پاشەکەوت دەنێردرێن، نە گەڕاندنەوە بۆ Phone و Messages.\n\nداتای ناوخۆی ئەپ، WhatsApp، هەژمار و ڕێکخستن ناگوازرێنەوە. ئەپەکە لە هەردوو مۆبایل نوێ بکەرەوە.","Photos, videos, audio, files, apps and contacts as VCF. SMS and call history are transferred as backup files, not restored into Phone or Messages.\n\nPrivate app data, WhatsApp data, accounts and settings are not transferred. Update both phones.","الصور والفيديو والصوت والملفات والتطبيقات وجهات الاتصال بصيغة VCF. تُنقل الرسائل وسجل المكالمات كملفات احتياطية ولا تُستعاد داخل الهاتف أو الرسائل.\n\nلا تُنقل بيانات التطبيقات الخاصة أو واتساب أو الحسابات أو الإعدادات. حدّث التطبيق على الهاتفين."},
        {"چی بنێرین؟","What would you like to send?","ماذا تريد أن ترسل؟"},
        {"بەشێک هەڵبژێرە، یان فایلەکان بە دەستی خۆت دیاری بکە.","Choose a category or select files manually.","اختر فئة أو حدد الملفات يدويًا."},
        {"وێنەکان","Photos","الصور"},
        {"هەموو وێنە ڕێگەپێدراوەکان","All photos you have allowed access to","جميع الصور التي سمحت بالوصول إليها"},
        {"ڤیدیۆکان","Videos","الفيديو"},
        {"ڤیدیۆکانی مۆبایل","Videos on this phone","مقاطع الفيديو على هذا الهاتف"},
        {"دەنگ و موزیک","Audio and music","الصوت والموسيقى"},
        {"فایلە دەنگییەکان","Audio files","الملفات الصوتية"},
        {"ئەپەکان (APK)","Apps (APK)","التطبيقات (APK)"},
        {"APKی ئەپەکان بۆ ناردن و دامەزراندن هەڵبژێرە","Select app APKs to send and install","اختر APK للتطبيقات لإرسالها وتثبيتها"},
        {"ژمارەکان","Contacts","جهات الاتصال"},
        {"ناو و ژمارە، بە فایلێکی VCF","Names and numbers in a VCF file","الأسماء والأرقام في ملف VCF"},
        {"فایلەکان","Files","الملفات"},
        {"بە دەستی خۆت هەڵبژێرە","Select manually","حدد يدويًا"},
        {"بەردەوام بە  ←","Continue  →","متابعة  ←"},
        {"گەڕانەوە","Back","رجوع"},
        {"SMS و مێژووی پەیوەندی بە یەک کرتە هەمووی هەڵدەبژێردرێت؛ کرتەی دووەم لایاندەبات. ئەپ و ژمارەکان تاک‌تاک هەڵبژێرە.","Tap SMS or recent calls to select all available records. Tap again to clear. Apps and contacts offer individual selection.","اضغط على الرسائل أو المكالمات الأخيرة لتحديد كل السجلات المتاحة. اضغط مجددًا لإلغاء التحديد. يمكن اختيار التطبيقات وجهات الاتصال بشكل فردي."},
        {" فایل • "," files • "," ملفات • "},
        {" + قەبارەی نەزانراو"," + unknown size"," + حجم غير معروف"},
        {"لیستی ئەپەکان ئامادە دەکرێت","Loading app list","جارٍ تحميل قائمة التطبيقات"},
        {"هیچ ئەپێکی گونجاو نەدۆزرایەوە.","No suitable apps found.","لم يتم العثور على تطبيقات مناسبة."},
        {"ئەپەکان هەڵبژێرە — تەنها دامەزراندن","Select apps — installation files only","حدد التطبيقات — ملفات التثبيت فقط"},
        {"زیادکردن","Add","إضافة"},
        {"لیستی ئەپەکان","App list","قائمة التطبيقات"},
        {"ئەپە هەڵبژێردراوەکان ئامادە دەکرێن","Preparing selected apps","جارٍ تجهيز التطبيقات المحددة"},
        {"هەندێک ئەپ ئامادە نەبوون","Some apps could not be prepared","تعذر تجهيز بعض التطبيقات"},
        {"فایلەکانی ئەم ئەپانە بەردەست نەبوون یان بۆشایی بەس نەبوو:\n","These app files were unavailable, or storage was insufficient:\n","ملفات هذه التطبيقات غير متاحة أو مساحة التخزين غير كافية:\n"},
        {"ڕێگە پێویستە","Permission required","الإذن مطلوب"},
        {"بۆ هۆتسپۆتی بەخۆکار ڕێگەی وایفای پێویستە. دەتوانیت هۆتسپۆت بە دەستی خۆت چالاک بکەیت.","Automatic hotspot setup needs Wi-Fi permission. You can also turn on the hotspot manually.","يتطلب إعداد نقطة الاتصال تلقائيًا إذن Wi-Fi. يمكنك تشغيلها يدويًا أيضًا."},
        {"دەتوانیت وێنەی QR هەڵبژێریت یان کۆدی پەیوەندی بلکێنیت.","You can choose a QR image or paste the pairing code.","يمكنك اختيار صورة QR أو لصق رمز الاقتران."},
        {"ڕێگە نەدرا؛ دەتوانیت «فایلەکان» بەکاربهێنیت.","Permission denied. You can use Files instead.","لم يُمنح الإذن. يمكنك استخدام الملفات بدلًا من ذلك."},
        {"تکایە کەمێک چاوەڕێ بکە…","Please wait…","يرجى الانتظار…"},
        {"داتا ئامادە دەکرێت","Preparing data","جارٍ تجهيز البيانات"},
        {"هیچ داتایەکی ڕێگەپێدراو نەدۆزرایەوە.","No accessible data found.","لم يتم العثور على بيانات يمكن الوصول إليها."},
        {"تەنها ئەو وێنە و ڤیدیۆیانە زیاد کران کە ڕێگەت پێداون.","Only the photos and videos you allowed were added.","أُضيفت فقط الصور ومقاطع الفيديو التي سمحت بالوصول إليها."},
        {"داتا ئامادە نەبوو","Could not prepare data","تعذر تجهيز البيانات"},
        {"سەرەتا داتایەک هەڵبژێرە.","Select some data first.","حدد البيانات أولًا."},
        {"لە هەر جارێکدا تا ١٠ هەزار فایل بنێرە.","Send up to 10,000 files per transfer.","يمكن إرسال ما يصل إلى 10,000 ملف في كل عملية نقل."},
        {"بە مۆبایلی نوێ ببەستەوە","Connect to the new phone","اتصل بالهاتف الجديد"},
        {"١. لە مۆبایلی وەرگر «مۆبایلی نوێ» دابگرە.\n٢. QR ی ئەو مۆبایلە سکان بکە.\n٣. داواکاری پەیوەستبوونی ئەندرۆید قبووڵ بکە.\n\nسیمکارت، داتا و ئینتەرنێت پێویست نین.","1. Tap New phone on the receiving phone.\n2. Scan its QR code.\n3. Accept the Android connection request.\n\nNo SIM, mobile data or internet is needed.","١. اضغط على الهاتف الجديد في هاتف الاستقبال.\n٢. امسح رمز QR الظاهر عليه.\n٣. وافق على طلب الاتصال من أندرويد.\n\nلا تحتاج إلى شريحة أو بيانات هاتف أو إنترنت."},
        {"سکانی QR — وایفای","Scan QR — Wi-Fi","مسح QR — Wi-Fi"},
        {"ناردن بە کەیبڵی USB-C","Send via USB-C cable","الإرسال عبر كابل USB-C"},
        {"هەڵبژاردنی وێنەی QR","Choose QR image","اختيار صورة QR"},
        {"گەڕانەوە بۆ داتاکان","Back to data selection","العودة لاختيار البيانات"},
        {"ڕێگای جێگرەوە: لکاندنی کۆدی پەیوەندی","Alternative: paste pairing code","طريقة بديلة: لصق رمز الاقتران"},
        {"کۆدی پەیوەندی بلکێنە","Paste pairing code","الصق رمز الاقتران"},
        {"پەیوەستبوون","Connect","اتصال"},
        {"پاشگەزبوونەوە","Cancel","إلغاء"},
        {"QR نەگونجاوە","Invalid QR code","رمز QR غير صالح"},
        {"QR ی ناو ئەپی rebaritclone ی مۆبایلی نوێ سکان بکە؛ ئەپەکە لە هەردوو مۆبایل نوێ بکەرەوە.","Scan the QR code inside rebaritclone on the new phone. Update the app on both phones.","امسح رمز QR داخل rebaritclone على الهاتف الجديد. حدّث التطبيق على الهاتفين."},
        {"پەیوەستبوون بە هۆتسپۆت","Connecting to hotspot","جارٍ الاتصال بنقطة الاتصال"},
        {"داواکاری پەیوەستبوونی ئەندرۆید قبووڵ بکە. ئەم تۆڕە ئینتەرنێتی نییە و پێویستیشی پێ نییە.","Accept the Android connection request. This network does not provide or require internet.","وافق على طلب الاتصال من أندرويد. هذه الشبكة لا توفر الإنترنت ولا تحتاج إليه."},
        {"پەیوەستبوون بە دەستی خۆم","Connect manually","الاتصال يدويًا"},
        {"بە هۆتسپۆتەکە ببەستەوە","Join the hotspot","اتصل بنقطة الاتصال"},
        {"لە ڕێکخستنی وایفای، هۆتسپۆتی مۆبایلی نوێ هەڵبژێرە. ئەگەر وتی «ئینتەرنێتی نییە»، بە پەیوەستی بمێنەوە.","In Wi-Fi settings, select the new phone's hotspot. Stay connected if Android says No internet.","في إعدادات Wi-Fi، اختر نقطة اتصال الهاتف الجديد. ابقَ متصلًا إذا ظهرت عبارة لا يوجد إنترنت."},
        {"ناوی هۆتسپۆت: ","Hotspot name: ","اسم نقطة الاتصال: "},
        {"وشەی نهێنی: ","Password: ","كلمة المرور: "},
        {"کردنەوەی وایفای","Open Wi-Fi settings","فتح إعدادات Wi-Fi"},
        {"پەیوەست بووم — ناردن","Connected — Send","تم الاتصال — إرسال"},
        {"سەرەتا بە هۆتسپۆتی مۆبایلی نوێ ببەستەوە.","Connect to the new phone's hotspot first.","اتصل بنقطة اتصال الهاتف الجديد أولًا."},
        {"هۆتسپۆت دروست دەکرێت","Creating hotspot","جارٍ إنشاء نقطة الاتصال"},
        {"هۆتسپۆتێکی ناوخۆیی بۆ گواستنەوە، بەبێ ئینتەرنێت.","A local hotspot for offline transfer.","نقطة اتصال محلية للنقل دون إنترنت."},
        {"5 GHz ئامادە نەبوو","5 GHz unavailable","تعذر تشغيل 5 GHz"},
        {"هۆتسپۆت ئامادە نەبوو","Hotspot unavailable","تعذر تشغيل نقطة الاتصال"},
        {"دەتوانیت هەوڵ بدەیتەوە، یان ڕێگایەکی تر هەڵبژێریت. 5 GHz پێویستی بە پشتگیری هەردوو مۆبایلەکە هەیە.","Retry or choose another method. Both phones must support 5 GHz.","أعد المحاولة أو اختر طريقة أخرى. يجب أن يدعم الهاتفان نطاق 5 GHz."},
        {"هەوڵدانەوە","Retry","إعادة المحاولة"},
        {"بەردەوامبوون بە هۆتسپۆتی ئاسایی","Continue with a standard hotspot","المتابعة بنقطة اتصال عادية"},
        {"ڕێکخستنی هۆتسپۆتی 5 GHz بە دەست","Set up a 5 GHz hotspot manually","إعداد نقطة اتصال 5 GHz يدويًا"},
        {"وەرگرتن بە USB-C","Receive via USB-C","الاستقبال عبر USB-C"},
        {"هۆتسپۆت بە دەستی خۆت چالاک بکە","Turn on the hotspot manually","شغّل نقطة الاتصال يدويًا"},
        {"ئەم مۆبایلە هۆتسپۆتی بەخۆکار ئامادە نەکرد. لە ڕێکخستنەکان هۆتسپۆت چالاک بکە؛ داتای سیمکارت پێویست نییە. لە ئەندرۆیدی کۆندا چالاککردنی Locationیش ڕەنگە پێویست بێت.","Automatic hotspot setup failed on this phone. Enable it in Settings; mobile data is not needed. Older Android versions may also require Location to be on.","تعذر إعداد نقطة الاتصال تلقائيًا على هذا الهاتف. شغّلها من الإعدادات؛ لا تحتاج إلى بيانات الهاتف. قد تتطلب إصدارات أندرويد القديمة تشغيل الموقع أيضًا."},
        {"هۆکاری شکستی پەیوەستبوونی بەخۆکار: ","Automatic connection error: ","سبب فشل الاتصال التلقائي: "},
        {"ڕێکخستنی هۆتسپۆت","Hotspot settings","إعدادات نقطة الاتصال"},
        {"چالاکم کرد — پیشاندانی QR","Enabled — Show QR","تم التشغيل — عرض QR"},
        {"لە مۆبایلی کۆن سەرەتا بە وایفای بە هۆتسپۆتەکە ببەستەوە، پاشان QR سکان بکە. بۆ خێرایی زیاتر، ئەگەر هەردوو مۆبایل پشتگیری دەکەن، 5 GHz هەڵبژێرە.","Connect the old phone to this hotspot using Wi-Fi, then scan the QR code. For higher speed, choose 5 GHz if both phones support it.","اتصل بهذه النقطة من الهاتف القديم عبر Wi-Fi، ثم امسح QR. لسرعة أعلى، اختر 5 GHz إذا كان الهاتفان يدعمانه."},
        {"QR دەخوێندرێتەوە","Reading QR code","جارٍ قراءة رمز QR"},
        {"QR نەخوێندرایەوە","Could not read QR code","تعذرت قراءة رمز QR"},
        {"وێنەیەکی ڕوون لە QR ی ناو ئەپەکە هەڵبژێرە.","Choose a clear image of the QR code shown in the app.","اختر صورة واضحة لرمز QR الظاهر في التطبيق."},
        {"گواستنەوە بە کەیبڵ","Transfer by cable","النقل بالكابل"},
        {"کەیبڵێکی USB-C کە داتا بگوازێتەوە ببەستە بە هەردوو مۆبایلەکە.","Connect both phones with a USB-C cable that supports data transfer.","صل الهاتفين بكابل USB-C يدعم نقل البيانات."},
        {"لە مۆبایلی نوێ، USB controlled by → This device هەڵبژێرە یان OTG چالاک بکە. لە مۆبایلی کۆن «ناردن بە کەیبڵ» هەڵبژێرە.","On the new phone, select USB controlled by → This device, or enable OTG. On the old phone, choose Send via USB-C cable.","على الهاتف الجديد، اختر التحكم في USB ← هذا الجهاز أو شغّل OTG. على الهاتف القديم، اختر الإرسال عبر كابل USB-C."},
        {"لە مۆبایلی نوێ «وەرگرتن بە کەیبڵ» هەڵبژێرە. داواکاری USB لە هەردوو مۆبایلەکە قبووڵ بکە.","On the new phone, choose Receive via USB-C cable. Accept the USB permission requests on both phones.","على الهاتف الجديد، اختر الاستقبال عبر كابل USB-C. وافق على طلبات إذن USB على الهاتفين."},
        {"تاقیکردنەوەیی • پێویستی بە پشتگیری USB Host و Accessory هەیە. USB debugging پێویست نییە. ئەگەر ئامێر نەدۆزرایەوە، لە کۆنەکە USB / File transfer هەڵبژێرە و دووبارە هەوڵ بدە.","Experimental • Requires USB Host and Accessory support. USB debugging is not needed. If no device is found, choose USB / File transfer on the old phone and retry.","تجريبي • يتطلب دعم USB Host وAccessory. لا يحتاج إلى تصحيح أخطاء USB. إذا لم يُعثر على الجهاز، اختر USB / نقل الملفات على الهاتف القديم وأعد المحاولة."},
        {"چاوەڕوانی کەیبڵ و ڕێگەی USB…","Waiting for cable and USB permission…","بانتظار الكابل وإذن USB…"},
        {"پەیوەندی USB نەبەسترا","USB connection failed","فشل اتصال USB"},
        {"گواستنەوە بە هۆتسپۆت","Transfer via hotspot","النقل عبر نقطة الاتصال"},
        {"سیمکارت و ئینتەرنێت پێویست نین. مۆبایلی کۆن بە هۆتسپۆتی ئەم مۆبایلەوە دەبەسترێت.","No SIM or internet needed. The old phone connects to this phone's hotspot.","لا تحتاج إلى شريحة أو إنترنت. يتصل الهاتف القديم بنقطة اتصال هذا الهاتف."},
        {"دەستپێکردنی هۆتسپۆت","Start hotspot","تشغيل نقطة الاتصال"},
        {"وەرگرتن بە کەیبڵی USB-C","Receive via USB-C cable","الاستقبال عبر كابل USB-C"},
        {"هۆتسپۆت بە دەستی خۆم چالاک دەکەم","Set up hotspot manually","إعداد نقطة الاتصال يدويًا"},
        {"ئەگەر داتای سیمکارت کوژاوە بێت یان سیمکارتت نەبێت، هەر دەتوانیت فایل بگوازیتەوە.","You can transfer files with mobile data turned off or without a SIM.","يمكنك نقل الملفات مع إيقاف بيانات الهاتف أو دون شريحة."},
        {"ئەم QR ـە سکان بکە","Scan this QR code","امسح رمز QR هذا"},
        {"لە مۆبایلی کۆن دوگمەی «سکانی QR» دابگرە.","Tap Scan QR on the old phone.","اضغط على مسح QR في الهاتف القديم."},
        {"QR بۆ پەیوەستکردنی مۆبایلی کۆن","QR code to connect the old phone","رمز QR لربط الهاتف القديم"},
        {"چاوەڕوانی مۆبایلی کۆن…","Waiting for the old phone…","بانتظار الهاتف القديم…"},
        {"Ultra Fast / Wi‑Fi Direct","Ultra Fast / Wi-Fi Direct","فائق السرعة / Wi-Fi Direct"},
        {"\nئەو باندەی کە هەردوو مۆبایل و سیستەم پشتگیری دەکەن بەخۆکار هەڵدەبژێردرێت.","\nThe strongest band supported by both phones and Android is chosen automatically.","\nيُختار تلقائياً أقوى نطاق يدعمه الهاتفان ونظام Android."},
        {"ڕاگرتن","Stop","إيقاف"},
        {"کۆپی کردنی کۆدی پەیوەندی","Copy pairing code","نسخ رمز الاقتران"},
        {"کۆپی کرا؛ تەنها لە مۆبایلی خۆت بەکاری بهێنە.","Copied. Use it only on your own phone.","تم النسخ. استخدمه على هاتفك فقط."},
        {"داتاکەت دەنێردرێت","Sending your data","جارٍ إرسال بياناتك"},
        {"داتاکەت وەردەگیرێت","Receiving your data","جارٍ استقبال بياناتك"},
        {"هەردوو ئەپەکە کراوە بهێڵەوە تا تەواو دەبێت.","Keep both apps open until the transfer finishes.","أبقِ التطبيق مفتوحًا على الهاتفين حتى يكتمل النقل."},
        {"USB-C • گواستنەوەی ڕاستەوخۆ","USB-C • Direct transfer","USB-C • نقل مباشر"},
        {"٠٪","0%","٠٪"},
        {"پەیوەندی دەبەسترێت…","Connecting…","جارٍ الاتصال…"},
        {"ئامادەکردنی ژمارە و قەبارەی فایلەکان…","Preparing file counts and sizes…","جارٍ تجهيز أعداد الملفات وأحجامها…"},
        {"ڕاگرتنی گواستنەوە","Stop transfer","إيقاف النقل"},
        {"گواستنەوە ڕابگیرێت؟","Stop this transfer?","هل تريد إيقاف النقل؟"},
        {"فایلە تەواوکراوەکان دەمێننەوە.","Completed files will be kept.","ستبقى الملفات المكتملة محفوظة."},
        {"بەردەوام بە","Continue","متابعة"},
        {"تەواو بوو!","Done!","تم!"},
        {"گواستنەوە تەواو نەبوو","Transfer incomplete","لم يكتمل النقل"},
        {" فایل تەواو کراوە"," files completed"," ملفات مكتملة"},
        {"فایلە سەرەکییەکان لە مۆبایلی کۆن ناسڕێنەوە.","Original files on the old phone are not deleted.","لا تُحذف الملفات الأصلية من الهاتف القديم."},
        {"دامەزراندنی ئەپە وەرگیراوەکان","Install received apps","تثبيت التطبيقات المستلمة"},
        {"وێنە و ڤیدیۆ لە گەلەری؛ فایلەکان لە Downloads / rebaritclone.","Photos and videos are in Gallery; other files are in Downloads / rebaritclone.","الصور والفيديو في المعرض؛ والملفات الأخرى في Downloads / rebaritclone."},
        {"فایلەکان لە فۆڵدەری هەڵبژێردراو پاشەکەوت کران.","Files were saved in the selected folder.","حُفظت الملفات في المجلد المحدد."},
        {"هاوردەکردنی ژمارەکان","Import contacts","استيراد جهات الاتصال"},
        {"گەڕانەوە بۆ سەرەتا","Back to home","العودة للرئيسية"},
        {"بەردەوامبوون لە شوێنی پچڕان","Resume interrupted transfer","استئناف النقل المنقطع"},
        {"هەمان فایلەکان هەڵبژێردراو بهێڵەوە. ئەگەر تۆڕ پچڕاوە، QRی نوێ سکان بکە. ئەپەکان مەخەوە.","Keep the same files selected. If the network disconnected, scan a new QR code. Do not close the apps.","أبقِ الملفات نفسها محددة. إذا انقطعت الشبكة، امسح رمز QR جديدًا. لا تغلق التطبيقين."},
        {"لە ئەپی Contacts، Import هەڵبژێرە و فایلە وەرگیراوەکەی contacts.vcf بکەرەوە.","In Contacts, choose Import and open the received contacts.vcf file.","في تطبيق جهات الاتصال، اختر استيراد وافتح ملف contacts.vcf المستلم."},
        {"٠ چرکە","0 seconds","٠ ثانية"},
        {"لە خەمڵاندندایە…","Estimating…","جارٍ التقدير…"},
        {" کاتژمێر و "," h and "," ساعة و "},
        {" خولەک"," min"," دقيقة"},
        {" خولەک و "," min and "," دقيقة و "},
        {" چرکە"," sec"," ثانية"},
        {" + نەزانراو"," + unknown"," + غير معروف"},
        {"قەبارەی گشتی: ","Total size: ","الحجم الإجمالي: "},
        {"\nگوازراوە: ","\nTransferred: ","\nتم نقل: "},
        {"\nماوە: ","\nRemaining: ","\nالمتبقي: "},
        {"قەبارەی تەواو دیار نییە","Full size is unknown","الحجم الكامل غير معروف"},
        {"\n\nفایلەکان: ","\n\nFiles: ","\n\nالملفات: "},
        {" تەواو • "," done • "," مكتمل • "},
        {" ماوە / "," remaining / "," متبقٍ / "},
        {"\nوێنە: ","\nPhotos: ","\nالصور: "},
        {"\nڤیدیۆ: ","\nVideos: ","\nالفيديو: "},
        {"\nئەپ: ","\nApps: ","\nالتطبيقات: "},
        {"\nفایلی تر: ","\nOther files: ","\nالملفات الأخرى: "},
        {"\n\nخێرایی ناوەند: ","\n\nAverage speed: ","\n\nمتوسط السرعة: "},
        {"\nکاتی خەمڵێنراوی ماوە: ","\nEstimated time left: ","\nالوقت المتبقي المقدر: "},
        {"پشکنین و پاشەکەوتکردنی فایل…","Verifying and saving file…","جارٍ التحقق من الملف وحفظه…"},
        {"٪","%","٪"},
        {"داتاکەت بە سەرکەوتوویی گوازرایەوە.","Your data was transferred successfully.","نُقلت بياناتك بنجاح."},
        {"گواستنەوە بە داواکاری تۆ ڕاگیرا.","Transfer stopped at your request.","توقف النقل بناءً على طلبك."},
        {"فایلە سەرچاوەکە گۆڕاوە؛ بۆ پاراستنی داتا بەردەوامبوون ڕاگیرا.","The source file changed. Resume was stopped to protect your data.","تغيّر الملف الأصلي. أُوقف الاستئناف لحماية بياناتك."},
        {"ڕێگەی دەستگەیشتن بە داتا نەدراوە. دووبارە داتاکان هەڵبژێرە.","Data access permission was denied. Select the data again.","لم يُمنح إذن الوصول إلى البيانات. حدد البيانات مجددًا."},
        {"ژمارەی فایلەکان زۆرە؛ لە «فایلەکان» بەش بەش بیاننێرە. سنوور: ١٠ هەزار فایل لە هەر جارێکدا.","Too many files. Send smaller batches using Files. Limit: 10,000 files per transfer.","عدد الملفات كبير جدًا. أرسلها على دفعات من قسم الملفات. الحد: 10,000 ملف لكل عملية نقل."},
        {"وەرگرتن ڕەتکرایەوە یان کاتی ڕەزامەندی بەسەرچوو.","Receiving was declined or the approval request timed out.","رُفض الاستقبال أو انتهت مهلة الموافقة."},
        {"پەیوەندی USB وەستا. کەیبڵی داتا، ڕێگەی USB و بۆشایی مۆبایل بپشکنە؛ فایلە تەواوکراوەکان دەمێننەوە.","USB transfer stopped. Check the data cable, USB permission and free space. Completed files are kept.","توقف نقل USB. تحقق من كابل البيانات وإذن USB والمساحة المتاحة. تبقى الملفات المكتملة محفوظة."},
        {"کاتی چاوەڕوانی بەسەرچوو. هەردوو مۆبایلەکە بە هەمان وایفای ببەستەوە و QRێکی نوێ سکان بکە.","Timed out. Connect both phones to the same Wi-Fi and scan a new QR code.","انتهت المهلة. صل الهاتفين بشبكة Wi-Fi نفسها وامسح QR جديدًا."},
        {"پەیوەندی نەبەسترا. هەمان وایفای بەکاربهێنە، یان یەک مۆبایل بکە بە هۆتسپۆت و ئەوی تر پێوە ببەستە. VPN بکوژێنەوە و QRێکی نوێ سکان بکە.","Could not connect. Use the same Wi-Fi, or connect one phone to the other's hotspot. Turn off VPN and scan a new QR code.","تعذر الاتصال. استخدم شبكة Wi-Fi نفسها أو اتصل بنقطة اتصال الهاتف الآخر. أوقف VPN وامسح QR جديدًا."},
        {"کۆدی پەیوەندی کۆنە یان هەڵەیە. لە مۆبایلی نوێ QRێکی نوێ دروست بکە.","The pairing code is old or incorrect. Generate a new QR code on the new phone.","رمز الاقتران قديم أو غير صحيح. أنشئ رمز QR جديدًا على الهاتف الجديد."},
        {"پەیوەندی پچڕا. هەردوو ئەپەکە کراوە بهێڵەوە و «بەردەوامبوون لە شوێنی پچڕان» دابگرە.","Connection lost. Keep both apps open and tap Resume interrupted transfer.","انقطع الاتصال. أبقِ التطبيقين مفتوحين واضغط على استئناف النقل المنقطع."},
        {"گواستنەوە وەستا. بۆشایی مۆبایل، ڕێگەی فایلەکان و پەیوەندی وایفای بپشکنە؛ فایلە تەواوکراوەکان دەمێننەوە.","Transfer stopped. Check free space, file permissions and Wi-Fi. Completed files are kept.","توقف النقل. تحقق من المساحة وإذن الملفات وWi-Fi. تبقى الملفات المكتملة محفوظة."},
        {"ڕاگرتن…","Stopping…","جارٍ الإيقاف…"},
        {"پەیوەندی پچڕا؛ هەوڵی بەردەوامبوونەوە…","Connection lost; trying to resume…","انقطع الاتصال؛ جارٍ محاولة الاستئناف…"},
        {"چاوەڕوانی ڕەزامەندی مۆبایلی نوێ…","Waiting for approval on the new phone…","بانتظار الموافقة على الهاتف الجديد…"},
        {"وایفای پێویستە","Wi-Fi required","يلزم اتصال Wi-Fi"},
        {"سەرەتا بە وایفای پەیوەست بە یان هۆتسپۆت چالاک بکە، پاشان دووبارە «پیشاندانی QR» دابگرە.","Connect to Wi-Fi or enable the hotspot, then tap Show QR again.","اتصل بشبكة Wi-Fi أو شغّل نقطة الاتصال، ثم اضغط على عرض QR مجددًا."},
        {"QR ئامادە دەکرێت","Preparing QR code","جارٍ تجهيز رمز QR"},
        {"پەیوەندی پچڕا؛ چاوەڕوانی بەردەوامبوونەوە…","Connection lost; waiting to resume…","انقطع الاتصال؛ بانتظار الاستئناف…"},
        {" فایل\n"," files\n"," ملفات\n"},
        {" + داتای قەبارەنەزانراو"," + files with unknown size"," + ملفات بحجم غير معروف"},
        {"\nداتاکان بۆ ئەم مۆبایلە وەربگیرێن؟","\nReceive this data on this phone?","\nهل تريد استقبال هذه البيانات على هذا الهاتف؟"},
        {"\n\nدوای وەرگرتن دامەزراندنی ئەپەکان دەست پێ دەکات؛ پەنجەرەی Install خۆت قبووڵ دەکەیت.","\n\nApp installation starts after receiving. You approve the Android Install prompt.","\n\nيبدأ تثبيت التطبيقات بعد الاستقبال. أنت توافق على نافذة التثبيت من أندرويد."},
        {"مۆبایلی کۆن پەیوەست بوو","Old phone connected","اتصل الهاتف القديم"},
        {"وەرگرتن","Receive","استقبال"},
        {"ڕەتکردنەوە","Decline","رفض"},
        {"بۆ دەستپێکردن وایفای و ڕێکخستنە پێویستەکان چالاک بکە.","Enable Wi-Fi and the required settings to start.","شغّل Wi-Fi والإعدادات المطلوبة للبدء."},
        {"فایلەکان ئامادە دەکرێن","Preparing files","جارٍ تجهيز الملفات"},
        {"فایل نەخوێندرایەوە","Could not read file","تعذرت قراءة الملف"},
        {"ئەم کارە ڕابگریت؟","Stop this operation?","هل تريد إيقاف هذه العملية؟"},
        {"بەڵێ","Yes","نعم"},
        {"نەخێر","No","لا"},
        {"دوو مۆبایل بۆ گواستنەوەی داتا","Two phones transferring data","هاتفان لنقل البيانات"},
        {"ڕێگەی USB ڕەتکرایەوە.","USB permission denied.","لم يُمنح إذن USB."},
        {"مۆبایلی نوێ پشتگیری USB Host/OTG ناکات.","The new phone does not support USB Host/OTG.","الهاتف الجديد لا يدعم USB Host/OTG."},
        {"USB نەدۆزرایەوە. کەیبڵی داتا بەکاربهێنە و لە مۆبایلی نوێ USB controlled by / This device هەڵبژێرە یان OTG چالاک بکە.","No USB device found. Use a data cable and select USB controlled by / This device on the new phone, or enable OTG.","لم يُعثر على جهاز USB. استخدم كابل بيانات واختر التحكم في USB / هذا الجهاز على الهاتف الجديد، أو شغّل OTG."},
        {"پەیوەندی USB ئامادە نەبوو: ","USB setup failed: ","فشل إعداد USB: "},
        {"ئەم پەیوەندییە پشتگیری USB Accessory نەکرد یان ڕێگە نەدرا. USB controlled by / This device لە مۆبایلی نوێ تاقی بکەرەوە.","USB Accessory is unsupported or permission was denied. Try USB controlled by / This device on the new phone.","USB Accessory غير مدعوم أو لم يُمنح الإذن. جرّب التحكم في USB / هذا الجهاز على الهاتف الجديد."},
        {"لە پەنجەرەی ئەندرۆید Install / Update قبووڵ بکە.","Approve Install / Update in the Android prompt.","وافق على تثبيت / تحديث في نافذة أندرويد."},
        {"داواکاری دامەزراندن بەردەست نەبوو.","Install request unavailable.","طلب التثبيت غير متاح."},
        {"دامەزرا","Installed","تم التثبيت"},
        {"بەردەوامبوون / هەوڵدانەوە","Continue / Retry","متابعة / إعادة المحاولة"},
        {"ئەم ئەپە جێبهێڵە","Skip this app","تخطي هذا التطبيق"},
        {"بە داواکاری تۆ جێهێڵرا","Skipped at your request","تم التخطي بناءً على طلبك"},
        {"تەنها فایلەکانی دامەزراندنە؛ هەژمار و داتای ناوخۆی ئەپ ناگوازرێتەوە. هەندێک ئەپ لە مۆبایلی نوێ ناگونجێت.","Installation files only; app accounts and private data are not transferred. Some apps may be incompatible with the new phone.","ملفات التثبيت فقط؛ لا تُنقل حسابات التطبيقات أو بياناتها الخاصة. قد لا تتوافق بعض التطبيقات مع الهاتف الجديد."},
        {"دامەزراندن ڕاگیرا؛ بۆ بەردەوامبوون دوگمەکە دابگرە.","Installation paused. Tap Continue to resume.","توقف التثبيت. اضغط على متابعة للاستئناف."},
        {"لیستی دامەزراندن تەواو بوو.","Installation list finished.","انتهت قائمة التثبيت."},
        {" ئەپ دامەزرا • "," apps installed • "," تطبيقات مثبّتة • "},
        {" ئەپ جێهێڵرا"," apps skipped"," تطبيقات تم تخطيها"},
        {"پەنجەرەی Install نەکرایەوە.","Could not open the Install prompt.","تعذر فتح نافذة التثبيت."},
        {"ڕێگەی Allow from this source بۆ rebaritclone چالاک بکە، پاشان بگەڕێوە.","Enable Allow from this source for rebaritclone, then come back.","فعّل السماح من هذا المصدر لتطبيق rebaritclone، ثم ارجع."},
        {"ڕێکخستنی دامەزراندن نەکرایەوە.","Could not open installation settings.","تعذر فتح إعدادات التثبيت."},
        {"ئەپ بۆ دامەزراندن ئامادە دەکرێت…","Preparing app for installation…","جارٍ تجهيز التطبيق للتثبيت…"},
        {"ئەپ دامەزرا نەکرا: ","App could not be installed: ","تعذر تثبيت التطبيق: "},
        {"ڕێگەی دامەزراندن نەدرا؛ دەتوانیت دواتر هەوڵ بدەیتەوە.","Install permission denied. You can retry later.","لم يُمنح إذن التثبيت. يمكنك المحاولة لاحقًا."},
        {"دامەزراندن هەڵوەشێندرایەوە.","Installation cancelled.","أُلغي التثبيت."},
        {"بۆشایی مۆبایل بەس نییە.","Not enough free space.","مساحة التخزين غير كافية."},
        {"ئەپەکە لەگەڵ وەشانی دامەزراو ناگونجێت؛ هیچ ئەپێک خۆکارانە ناسڕێتەوە.","The app conflicts with the installed version. No app will be uninstalled automatically.","يتعارض التطبيق مع الإصدار المثبّت. لن يُحذف أي تطبيق تلقائيًا."},
        {"ئەم ئەپە لەگەڵ ئەندرۆید یان جۆری ئەم مۆبایلە ناگونجێت.","This app is incompatible with this Android version or phone.","هذا التطبيق غير متوافق مع إصدار أندرويد أو هذا الهاتف."},
        {"ئەندرۆید ڕێگەی دامەزراندنی نەدا.","Android blocked installation.","حظر أندرويد التثبيت."},
        {"دامەزراندن سەرکەوتوو نەبوو.","Installation failed.","فشل التثبيت."},
        {"دامەزراندن ڕابگیرێت؟ فایلە وەرگیراوەکان دەمێننەوە.","Stop installation? Received files will be kept.","هل تريد إيقاف التثبيت؟ ستبقى الملفات المستلمة محفوظة."},
        {"QR ی مۆبایلی نوێ بخە بەرامبەر کامێرا","Point the camera at the new phone's QR code","وجّه الكاميرا إلى رمز QR على الهاتف الجديد"},
        {"کامێرا تەنها بۆ خوێندنەوەی QR بەکاردێت","The camera is used only to scan QR codes","تُستخدم الكاميرا لمسح رموز QR فقط"},
        {"کامێرا نەکرایەوە؛ بگەڕێوە و وێنەی QR هەڵبژێرە.","Could not open camera. Go back and choose a QR image.","تعذر فتح الكاميرا. ارجع واختر صورة QR."},
        {"هۆتسپۆتی ناوخۆ • باندەکە لە ئەندرۆید بەردەست نییە","Local hotspot • Android did not report the band","نقطة اتصال محلية • لم يحدد أندرويد النطاق"},
        {"زانیاری باندی ئەم پەیوەندییە بەردەست نییە","Band information for this connection is unavailable","معلومات نطاق هذا الاتصال غير متاحة"},
        {"باندی 2.4 GHz؛ بۆ خێرایی زیاتر 5 GHz تاقی بکەرەوە.","2.4 GHz band. Try 5 GHz for higher speed.","نطاق 2.4 GHz. جرّب 5 GHz لسرعة أعلى."},
        {"خێرایی Link خێرایی ڕاستەقینەی ناردن نییە.","Link speed is not the actual file transfer speed.","سرعة الارتباط ليست سرعة نقل الملفات الفعلية."},
        {"زانیاری باندی وایفای بەردەست نییە","Wi-Fi band information unavailable","معلومات نطاق Wi-Fi غير متاحة"},
        {"مێژووی پەیوەندی","Recent calls","سجل المكالمات"},
        {"نامەکانی SMS","SMS messages","رسائل SMS"},
        {"تەنها فایلێکی پاشەکەوت دەنێردرێت؛ ناچێتە ناو Phone یان Messages. WhatsApp، RCS و MMS تێدا نین.","Transfers a backup file only; it is not restored into Phone or Messages. WhatsApp, RCS and MMS are not included.","يُنقل ملف نسخة احتياطية فقط؛ ولا يُستعاد داخل الهاتف أو الرسائل. لا يشمل واتساب أو RCS أو MMS."},
        {"ناوەکان تاک‌تاک هەڵبژێرە — VCF","Select individual contacts — VCF","حدد جهات الاتصال — VCF"},
        {"یەک کرتە: هەموو پەیوەندییە بەردەستەکان — فایلێکی پاشەکەوت","One tap: select all available calls — backup file","ضغطة واحدة: تحديد كل المكالمات المتاحة — ملف نسخ احتياطي"},
        {"یەک کرتە: هەموو نامە بەردەستەکان هەڵبژێرە — پاشەکەوت","One tap: select all available SMS — backup","نقرة واحدة: تحديد كل الرسائل المتاحة — نسخة احتياطية"},
        {"ڕێگەی خوێندنەوە نەدرا. ئەندرۆید یان دامەزرێنەری ئەپ ڕەنگە دەستگەیشتن بە SMS و مێژووی پەیوەندی سنووردار بکات. دەتوانیت فایلێکی پاشەکەوتی پێشووت لە «فایلەکان» هەڵبژێریت.","Read permission was not granted. Android or the app installer may restrict SMS and call-log access. You can select an existing backup through Files.","لم يُمنح إذن القراءة. قد يقيّد أندرويد أو مثبّت التطبيق الوصول إلى الرسائل وسجل المكالمات. يمكنك اختيار نسخة احتياطية موجودة من الملفات."},
        {"گەڕان بە ناو، ژمارە یان دەق","Search name, number or text","البحث بالاسم أو الرقم أو النص"},
        {"هەڵبژاردنی هەمووی نیشاندراو","Select all shown","تحديد كل النتائج المعروضة"},
        {" دانە هەڵبژێردراوە"," selected"," محدد"},
        {"تەنها ٥٠٠٠ تۆمار نیشان دەدرێت. بۆ SMS و پەیوەندییەکان نوێترینەکانن.","Showing at most 5,000 records. Calls and SMS show the most recent records.","تُعرض 5,000 سجلات كحد أقصى. للمكالمات والرسائل، تُعرض أحدث السجلات."},
        {"هاتوو","Incoming","واردة"},
        {"دەرچوو","Outgoing","صادرة"},
        {"لەدەستچوو","Missed","فائتة"},
        {"جۆری تر","Other","أخرى"},
        {"هەندێک تۆمار نەخوێندرایەوە، گۆڕاوە یان بۆشایی بەس نییە. هەڵبژاردنی پێشووت پارێزراوە؛ هەوڵ بدەرەوە.","Some records could not be read, changed, or storage is insufficient. Your previous selection was kept; retry.","تعذرت قراءة بعض السجلات أو تغيرت أو المساحة غير كافية. احتُفظ باختيارك السابق؛ أعد المحاولة."},
        {"لابردنی هەموو هەڵبژاردنەکان","Clear selection","إلغاء تحديد الكل"},
        {"ڕێگەپێدانەکانی ئەپ","App permissions","أذونات التطبيق"},
        {"داواکارییەکانی ئەندرۆید بە نۆرە دەردەکەون؛ بۆ ئەو بەشانەی دەتەوێت بەکاریان بهێنیت Allow دابگرە.","Android prompts appear one at a time. Tap Allow for the features you want to use.","تظهر طلبات أندرويد بالتتابع. اضغط سماح للميزات التي تريد استخدامها."},
        {"بۆ هەموو وێنەکان Allow all هەڵبژێرە. فایلەکان لە هەڵبژێری سیستەم هەڵبژێرە؛ فایلە پارێزراوەکانی سیستەم بەردەست نین. پەنجەرەی Allow پێویستی بە Display over other apps نییە.","For all photos, choose Allow all. Choose documents in the system file picker; protected system files are unavailable. Allow dialogs do not need Display over other apps.","لكل الصور اختر السماح بالكل. اختر المستندات من منتقي ملفات النظام؛ ملفات النظام المحمية غير متاحة. نوافذ السماح لا تحتاج إذن الظهور فوق التطبيقات."},
        {"هەندێک ڕێگە نەدراوە یان تەنها چەند وێنەیەک ڕێگەپێدراون. دەتوانیت بەردەوام بیت یان لە ڕێکخستنەکان دەستکاری بکەیت. ڕێگەی SMS و مێژووی پەیوەندی ڕەنگە لەلایەن ئەندرۆیدەوە سنووردار بێت.","Some permissions are missing or only selected photos are allowed. Continue with available features or change app settings. Android may restrict SMS and call-log access.","بعض الأذونات غير ممنوحة أو يسمح بصور محددة فقط. تابع بالميزات المتاحة أو غيّر إعدادات التطبيق. قد يقيّد أندرويد الوصول إلى الرسائل وسجل المكالمات."},
        {"کردنەوەی ڕێکخستنی ئەپ","Open app settings","فتح إعدادات التطبيق"},
        {"گواستنەوەی فایلەکان","File transfers","نقل الملفات"},
        {"وایفای دایرێکت سەرقاڵ بوو؛ بەخۆکار ڕێگای هۆتسپۆتی ئاسایی تاقی کرایەوە. 5 GHz مسۆگەر نییە.","Wi-Fi Direct stayed busy; automatically tried the normal hotspot route. 5 GHz is not guaranteed.","بقي Wi-Fi Direct مشغولاً؛ جُرّبت نقطة الاتصال العادية تلقائياً. نطاق 5 GHz غير مضمون."},
        {"وێنەی گوازراوە: ","Photos transferred: ","الصور المنقولة: "},
        {"ڤیدیۆی گوازراوە: ","Videos transferred: ","الفيديوهات المنقولة: "},
        {"ماوەی گواستنەوە (کاتژمێر:خولەک:چرکە): ","Transfer duration (hh:mm:ss): ","مدة النقل (ساعة:دقيقة:ثانية): "},
        {"پیشاندانی فایلەکان","Show files","عرض الملفات"},
        {"ئەپێکی گونجاو بۆ کردنەوەی ئەم فایلە بەردەست نییە یان ڕێگە نەدراوە. فایلەکە لە شوێنی وەرگرتن پاشەکەوت کراوە.","No suitable app is available to open this file, or access was denied. The file is saved in the receive location.","لا يتوفر تطبيق مناسب لفتح هذا الملف أو تم رفض الوصول. الملف محفوظ في موقع الاستلام."},
        {"بەبێ ئینتەرنێت • مۆبایل بۆ مۆبایل","Offline • Phone to phone","بدون إنترنت • من هاتف إلى هاتف"},
        {"داتاکانت بە ئاسانی بگوازەرەوە","Transfer your data with ease","انقل بياناتك بسهولة"},
        {"داتاکانت لە مۆبایلی کۆنەوە بۆ نوێ بگوازەرەوە","Move data from your old phone to your new phone","انقل بياناتك من هاتفك القديم إلى الجديد"},
        {"گواستنەوەی فایل","File transfer","نقل الملفات"},
        {"هەڵبژاردەکان","Options","الخيارات"},
        {"وێنە، ڤیدیۆ، دەنگ، ئەپ و فایلەکان بۆ ناردن هەڵبژێرە","Choose photos, videos, audio, apps and files to send","اختر الصور والفيديو والصوت والتطبيقات والملفات لإرسالها"},
        {"مۆبایل بۆ مۆبایل","Phone to phone","من هاتف إلى هاتف"},
        {"وێنە و ڤیدیۆ","Photos and videos","الصور والفيديوهات"},
        {"هەموو بابەتەکان","All items","كل العناصر"},
        {"زۆرترین 10000 فایل نیشان دەدرێت.","Showing up to 10,000 files.","يتم عرض ما يصل إلى 10000 ملف."},
        {"بێ ئینتەرنێت","Offline","بدون إنترنت"},
        {"هەڵبژاردن","Select","اختيار"},
        {"پەیوەندی","Connect","اتصال"},
        {"گواستنەوە","Transfer","نقل"},
        {"هەڵبژێردراوە","Selected","محدد"},
        {"دوو مۆبایلەکە بە کەیبڵی USB-C پەیوەست بکە.","Connect both phones with a USB-C data cable.","صل الهاتفين بكابل USB-C لنقل البيانات."},
        {"١  کەیبڵی گواستنەوەی داتا بەکاربهێنە؛ کەیبڵی تەنها شەحن بەس نییە.","1  Use a data cable; a charge-only cable will not work.","١  استخدم كابل بيانات؛ كابل الشحن فقط لا يكفي."},
        {"٢  لە مۆبایلە کۆنەکە ناردن بە USB-C هەڵبژێرە؛ دوای پەیوەندی داتا دیاری بکە.","2  Choose Send via USB-C on the old phone; select data after connecting.","٢  اختر الإرسال عبر USB-C على الهاتف القديم؛ حدد البيانات بعد الاتصال."},
        {"٣  لێرە دەستپێکردن دابگرە و داواکاری ڕێگەدانی USB قبووڵ بکە.","3  Start here and accept the USB permission requests.","٣  اضغط ابدأ هنا ووافق على طلبات إذن USB."},
        {"دەستپێکردنی وەرگرتن بە USB","Start USB receiving","بدء الاستقبال عبر USB"},
        {"سەرەتا بە مۆبایلە تازەکە پەیوەست ببە؛ پاشان داتا هەڵبژێرە.","Connect to the new phone first, then select your data.","اتصل بالهاتف الجديد أولاً، ثم اختر بياناتك."},
        {"پەیوەست بوو","Connected","تم الاتصال"},
        {"لە مۆبایلە کۆنەکە داتا هەڵبژێرە و ناردن دەست پێ بکە.","Select data on the old phone and start sending.","اختر البيانات على الهاتف القديم وابدأ الإرسال."},
        {"داتاکان بۆ وەرگرتن ئامادەن","Data is ready to receive","البيانات جاهزة للاستقبال"},
        {"مۆبایلی کۆن پەیوەست بوو","The old phone is connected","الهاتف القديم متصل"},
        {"فایلی تر","more files","ملفات أخرى"},
        {"وێنە و ڤیدیۆ","Photos and videos","الصور والفيديو"},
        {"فایل، APK و دەنگ","Files, APKs and audio","الملفات وAPK والصوت"},
        {"ژمارەکان و نامەکان","Contacts and messages","جهات الاتصال والرسائل"},
        {"پشتیوانی Wi‑Fi 6/6E لە مۆبایلەکەدا هەیە؛ Wi‑Fi Direct خۆکار بەهێزترین باندی ڕێگەپێدراو هەڵدەبژێرێت.","This phone supports Wi-Fi 6/6E; Wi-Fi Direct automatically chooses the strongest permitted band.","يدعم الهاتف Wi-Fi 6/6E؛ يختار Wi-Fi Direct تلقائياً أقوى نطاق مسموح."},
        {"پشتیوانی 5 GHz هەیە؛ Wi‑Fi Direct خۆکار باندی بەردەست هەڵدەبژێرێت.","This phone supports 5 GHz; Wi-Fi Direct automatically chooses an available band.","يدعم الهاتف 5 GHz؛ يختار Wi-Fi Direct تلقائياً نطاقاً متاحاً."},
        {"باندی خێرا لە مۆبایلەکەدا پشتیوانی ناکرێت؛ سیستەم باندی بەردەست بەکار دەهێنێت.","No fast Wi-Fi band is reported; the system uses an available band.","لا يظهر دعم لنطاق Wi-Fi سريع؛ يستخدم النظام نطاقاً متاحاً."},
        {"دابەزاندنی بەرنامە","Download app","تنزيل التطبيق"},
        {"QR کۆدەکە سکان بکە یان لینکەکە بکەرەوە. هەموو وەشانەکان و نوێترین APK لە هەمان پەڕە بەردەستن.","Scan the QR code or open the link. All versions and the newest APK are available on the same page.","امسح رمز QR أو افتح الرابط. جميع الإصدارات وأحدث APK متاحة في الصفحة نفسها."},
        {"QR کۆدی دابەزاندنی rebaritclone","rebaritclone download QR code","رمز QR لتنزيل rebaritclone"},
        {"کردنەوەی پەڕەی دابەزاندن","Open download page","فتح صفحة التنزيل"},
        {"کۆپیکردنی لینک","Copy link","نسخ الرابط"},
        {"وەشانی ئێستا: ","Current version: ","الإصدار الحالي: "},
        {"لینکی دابەزاندن کۆپی کرا.","Download link copied.","تم نسخ رابط التنزيل."},
        {"نەتوانرا پەڕەی دابەزاندن بکرێتەوە.","Could not open the download page.","تعذر فتح صفحة التنزيل."},
        {"نوێکردنەوەی نوێ بەردەستە","New update available","يتوفر تحديث جديد"},
        {"چاکسازی و بەهێزکردنی کارکردن.","Improvements and performance enhancements.","تحسينات وتعزيزات للأداء."},
        {"وەشانی نوێ: ","New version: ","الإصدار الجديد: "},
        {"دابەزاندنی نوێکردنەوە","Download update","تنزيل التحديث"},
        {"دواتر","Later","لاحقاً"},
        {"گەڕان لە فایلەکانی مۆبایل","Search local files","بحث في الملفات المحلية"},
        {"بەڵگەنامەکان","Documents","المستندات"},
        {"فایلەکانی APK","APK files","ملفات APK"},
        {"فایلەکانی تر","Other files","ملفات أخرى"},
        {"دابەزاندنەکان","Downloads","التنزيلات"},
        {"هەڵبژێردراو: ","Selected: ","المحدد: "},
        {"فایلە هەڵبژێردراوەکان بنێرە","Send selected files","إرسال الملفات المحددة"},
        {"بەرنامەکە بنێرە بە Bluetooth یان Share","Share app via Bluetooth or another app","مشاركة التطبيق عبر البلوتوث أو تطبيق آخر"},
        {"نەتوانرا پەڕەی ناردنی بەرنامە بکرێتەوە.","Could not open the app sharing menu.","تعذر فتح قائمة مشاركة التطبيق."},
    };
    public static String get(String language,int id){return TEXT[id]["en".equals(language)?1:"ar".equals(language)?2:0];}
    public static boolean rtl(String language){return !"en".equals(language);}
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/UiText.java`

``` java
package com.abdulla.clonephone;
import android.content.Context;
import android.content.res.Configuration;
import android.os.LocaleList;
import android.app.Activity;
import android.view.ContextThemeWrapper;
import java.util.Locale;

final class UiText {
    private static volatile String language="ckb";
    static void init(Context context){language=valid(context.getSharedPreferences("language",0).getString("selected","ckb"));}
    private static String valid(String value){return "en".equals(value)||"ar".equals(value)?value:"ckb";}
    static String language(){return language;}
    static void select(Context context,String value){language=valid(value);context.getSharedPreferences("language",0).edit().putString("selected",language).apply();}
    static String t(int id){return Translations.get(language,id);}
    static int direction(){return Translations.rtl(language)?1:0;}
    static Context context(Activity activity){
        // Keep the Activity as the base: its WindowManager carries the window token.
        // A standalone createConfigurationContext loses that association and can
        // throw BadTokenException when AlertDialog.show() adds its window.
        Configuration config=new Configuration();
        Locale locale=Locale.forLanguageTag(language);
        config.setLocales(new LocaleList(locale));
        config.setLayoutDirection(locale);
        ContextThemeWrapper localized=new ContextThemeWrapper(activity,activity.getTheme());
        localized.applyOverrideConfiguration(config);
        return localized;
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/UsbLink.java`

``` java
package com.abdulla.clonephone;

import android.app.PendingIntent;
import android.content.*;
import android.hardware.usb.*;
import android.os.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Experimental AOA link: new phone is USB host, old phone is accessory. */
final class UsbLink {
    interface Listener{void ready(InputStream in,OutputStream out);void failed(String reason);}
    private final Context context;
    private final UsbManager manager;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final String action;
    private final Set<String> requested=new HashSet<>();
    private boolean host,running,opening,registered;
    private volatile int generation;
    private long deadline;
    private Listener listener;
    private volatile UsbDeviceConnection connection;
    private volatile ParcelFileDescriptor descriptor;
    private volatile InputStream input;
    private volatile OutputStream output;
    UsbLink(Context context){this.context=context;manager=(UsbManager)context.getSystemService(Context.USB_SERVICE);action=context.getPackageName()+".USB_PERMISSION";}
    private final BroadcastReceiver permissions=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){if(!running||!action.equals(i.getAction()))return;if(!i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false)){fail(UiText.t(192));return;}poll();}
    };
    void start(boolean asHost,Listener callback){
        close();host=asHost;listener=callback;running=true;deadline=SystemClock.elapsedRealtime()+120000;requested.clear();
        if(host&&!context.getPackageManager().hasSystemFeature("android.hardware.usb.host")){fail(UiText.t(193));return;}
        IntentFilter filter=new IntentFilter(action);
        if(Build.VERSION.SDK_INT>=33)context.registerReceiver(permissions,filter,Context.RECEIVER_NOT_EXPORTED);else context.registerReceiver(permissions,filter);
        registered=true;poll();
    }
    private PendingIntent permissionIntent(){
        return PendingIntent.getBroadcast(context,generation,new Intent(action).setPackage(context.getPackageName()),PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0));
    }
    private void poll(){
        if(!running||opening)return;
        if(SystemClock.elapsedRealtime()>deadline){fail(UiText.t(194));return;}
        try{
            if(host){
                List<UsbDevice> devices=new ArrayList<>(manager.getDeviceList().values());
                // Prefer an already-switched AOA device; never switch an unrelated hub/storage device.
                devices.sort((a,b)->Boolean.compare(aoa(b),aoa(a)));
                for(UsbDevice d:devices){
                    if(!aoa(d)&&!phoneLike(d))continue;
                    if(!manager.hasPermission(d)){if(requested.add(d.getDeviceName()))manager.requestPermission(d,permissionIntent());continue;}
                    opening=true;int token=generation;executor.execute(()->openHost(d,token));return;
                }
            }else{
                UsbAccessory[] list=manager.getAccessoryList();
                if(list!=null)for(UsbAccessory accessory:list){
                    if(!"rebaritclone".equals(accessory.getManufacturer())||!"Phone Transfer".equals(accessory.getModel()))continue;
                    if(!manager.hasPermission(accessory)){if(requested.add(accessory.toString()))manager.requestPermission(accessory,permissionIntent());continue;}
                    descriptor=manager.openAccessory(accessory);if(descriptor==null)throw new IOException("USB accessory unavailable");
                    input=new BufferedInputStream(new FileInputStream(descriptor.getFileDescriptor()),16384);output=new FileOutputStream(descriptor.getFileDescriptor());running=false;listener.ready(input,output);return;
                }
            }
        }catch(Exception e){fail(UiText.t(195)+e.getClass().getSimpleName());return;}
        main.postDelayed(this::poll,750);
    }
    private static boolean aoa(UsbDevice d){int p=d.getProductId();return d.getVendorId()==0x18d1&&(p==0x2d00||p==0x2d01||p==0x2d04||p==0x2d05);}
    private static boolean phoneLike(UsbDevice d){
        for(int n=0;n<d.getInterfaceCount();n++){int cls=d.getInterface(n).getInterfaceClass();if(cls==6||cls==255)return true;}return d.getInterfaceCount()==0&&d.getDeviceClass()==0;
    }
    private void openHost(UsbDevice d,int token){
        UsbDeviceConnection c=null;
        try{
            c=manager.openDevice(d);if(c==null)throw new IOException("Permission/open failed");
            if(!aoa(d)){
                if(token!=generation){c.close();return;}
                byte[] version=new byte[2];int n=c.controlTransfer(0xc0,51,0,0,version,2,2000);if(n!=2||(version[0]==0&&version[1]==0))throw new IOException("AOA unsupported");
                String[] strings={"rebaritclone","Phone Transfer","Offline phone transfer","1.0","","rebaritclone-usb"};
                for(int k=0;k<strings.length;k++){if(token!=generation){c.close();return;}byte[] value=(strings[k]+"\0").getBytes(StandardCharsets.UTF_8);if(c.controlTransfer(0x40,52,0,k,value,value.length,2000)<0)throw new IOException("AOA setup failed");}
                if(c.controlTransfer(0x40,53,0,0,null,0,2000)<0)throw new IOException("AOA start failed");c.close();
                main.post(()->{if(token==generation){opening=false;requested.remove(d.getDeviceName());main.postDelayed(this::poll,1000);}});return;
            }
            UsbEndpoint read=null,write=null;UsbInterface chosen=null;
            for(int i=0;i<d.getInterfaceCount();i++){
                UsbInterface face=d.getInterface(i);
                if(face.getInterfaceClass()!=255||face.getInterfaceSubclass()!=255)continue;
                for(int j=0;j<face.getEndpointCount();j++){UsbEndpoint ep=face.getEndpoint(j);if(ep.getType()!=UsbConstants.USB_ENDPOINT_XFER_BULK)continue;if(ep.getDirection()==UsbConstants.USB_DIR_IN)read=ep;else write=ep;}
                if(read!=null&&write!=null){chosen=face;break;}
            }
            if(chosen==null||!c.claimInterface(chosen,true))throw new IOException("AOA bulk interface unavailable");
            final UsbDeviceConnection link=c;final UsbEndpoint readEp=read,writeEp=write;
            InputStream in=new InputStream(){
                private final byte[] buffer=new byte[16384];private int offset,count;
                public int read()throws IOException{byte[] one=new byte[1];int n=read(one,0,1);return n<0?-1:one[0]&255;}
                public int read(byte[] b,int start,int length)throws IOException{
                    if(length==0)return 0;if(offset==count){int n=link.bulkTransfer(readEp,buffer,buffer.length,180000);if(n<=0)throw new EOFException("USB disconnected or timed out");offset=0;count=n;}
                    int n=Math.min(length,count-offset);System.arraycopy(buffer,offset,b,start,n);offset+=n;return n;
                }
                public void close(){link.close();}
            };
            OutputStream out=new OutputStream(){
                public void write(int b)throws IOException{write(new byte[]{(byte)b});}
                public void write(byte[] b,int offset,int length)throws IOException{while(length>0){int n=link.bulkTransfer(writeEp,b,offset,Math.min(length,16384),180000);if(n<=0)throw new IOException("USB disconnected or timed out");offset+=n;length-=n;}}
                public void close(){link.close();}
            };
            main.post(()->{if(token!=generation){link.close();return;}connection=link;input=in;output=out;opening=false;running=false;listener.ready(in,out);});
        }catch(Exception e){if(c!=null)c.close();main.post(()->{if(token==generation)fail(UiText.t(196));});}
    }
    private void fail(String message){Listener callback=listener;close();if(callback!=null)callback.failed(message);}
    void close(){generation++;running=false;opening=false;main.removeCallbacksAndMessages(null);if(registered){try{context.unregisterReceiver(permissions);}catch(Exception ignored){}registered=false;}closeStreams();}
    void closeStreams(){
        try{if(connection!=null)connection.close();}catch(Exception ignored){}connection=null;
        try{if(descriptor!=null)descriptor.close();}catch(Exception ignored){}descriptor=null;
        try{if(input!=null)input.close();}catch(Exception ignored){}input=null;
        try{if(output!=null)output.close();}catch(Exception ignored){}output=null;
    }
    void destroy(){close();executor.shutdownNow();}
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/UsbSession.java`

``` java
package com.abdulla.clonephone;
import java.io.*;
import java.security.SecureRandom;
/** A physically connected, user-approved USB peer is the trust boundary. */
public final class UsbSession {
    public static SecureChannel open(InputStream in,OutputStream out,boolean receiver)throws Exception{
        byte[] key=new byte[16];
        if(receiver){new SecureRandom().nextBytes(key);DataOutputStream wire=new DataOutputStream(out);wire.writeInt(0x52425531);wire.write(key);wire.flush();}
        else{DataInputStream wire=new DataInputStream(in);if(wire.readInt()!=0x52425531)throw new IOException("USB_PEER");wire.readFully(key);}
        return new SecureChannel(in,out,key,receiver);
    }
}
```

------------------------------------------------------------------------

## `app/src/main/java/com/abdulla/clonephone/VipDesign.kt`

``` kotlin
package com.abdulla.clonephone

import android.graphics.Color

/** Modern design tokens shared by the Java screens while the app migrates incrementally to Kotlin. */
object VipDesign {
    @JvmField val BG = Color.rgb(5, 11, 18)
    @JvmField val SURFACE = Color.rgb(13, 24, 34)
    @JvmField val SURFACE_2 = Color.rgb(18, 34, 46)
    @JvmField val TEXT = Color.rgb(244, 250, 255)
    @JvmField val MUTED = Color.rgb(142, 166, 184)
    @JvmField val CYAN = Color.rgb(0, 218, 255)
    @JvmField val VIOLET = Color.rgb(124, 77, 255)
    @JvmField val GREEN = Color.rgb(0, 229, 155)
    @JvmField val RED = Color.rgb(255, 78, 103)
    @JvmField val LINE = Color.rgb(34, 56, 72)
}
```

------------------------------------------------------------------------

## `app/src/main/res/drawable/app_icon.xml`

``` xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
 <path android:fillColor="#050B12" android:pathData="M0,0h108v108h-108z"/>
 <path android:fillColor="#0D1822" android:pathData="M54,7A47,47 0,1 0,54 101A47,47 0,1 0,54 7"/>
 <path android:strokeColor="#00DAFF" android:strokeWidth="2.5" android:fillColor="#00000000" android:pathData="M54,12A42,42 0,1 0,54 96A42,42 0,1 0,54 12"/>
 <path android:strokeColor="#7C4DFF" android:strokeWidth="1.5" android:fillColor="#00000000" android:pathData="M54,17A37,37 0,1 0,54 91A37,37 0,1 0,54 17"/>
 <path android:fillColor="#F4FAFF" android:pathData="M32,31h25c12,0 20,7 20,18c0,8 -4,14 -12,17l14,18h-15l-12,-16h-7v16h-13zM45,42v15h11c5,0 8,-3 8,-8c0,-4 -3,-7 -8,-7z"/>
 <path android:fillColor="#00E59B" android:pathData="M22,55l8,-8v5h10v6h-10v5z"/>
 <path android:fillColor="#00DAFF" android:pathData="M86,55l-8,-8v5h-10v6h10v5z"/>
</vector>
```

------------------------------------------------------------------------

## `app/src/main/res/values/styles.xml`

``` xml
<resources>
    <style name="AppTheme" parent="android:style/Theme.Material.NoActionBar">
        <item name="android:fontFamily">sans</item>
        <item name="android:colorAccent">#00DAFF</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:statusBarColor">#050B12</item>
        <item name="android:navigationBarColor">#050B12</item>
        <item name="android:windowActionModeOverlay">true</item>
        <item name="android:windowNoTitle">true</item>
    </style>
</resources>
```

------------------------------------------------------------------------

## `app/src/main/res/xml/usb_accessory.xml`

``` xml
<resources><usb-accessory manufacturer="rebaritclone" model="Phone Transfer" version="1.0" /></resources>
```

------------------------------------------------------------------------

## `build-local.sh`

``` bash
#!/usr/bin/env bash
# Optional SDK-only Linux/macOS build: no Gradle downloads needed.
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:?Set ANDROID_HOME to Android SDK with platform 35 and build-tools 35.0.0}"
: "${JAVA_HOME:?Set JAVA_HOME to JDK 17}"
sdk_tools="$ANDROID_HOME/build-tools/35.0.0"
android_api="$ANDROID_HOME/platforms/android-35/android.jar"
build_dir="$PWD/build/manual"
rm -rf "$build_dir/classes" "$build_dir/dex"
mkdir -p "$build_dir/classes" "$build_dir/dex"
"$JAVA_HOME/bin/javac" --release 8 -cp "$android_api:app/libs/zxing-core-3.5.3.jar" -d "$build_dir/classes" app/src/main/java/com/abdulla/clonephone/*.java
"$sdk_tools/aapt2" compile --dir app/src/main/res -o "$build_dir/resources.zip"
sed 's/<manifest /<manifest package="com.abdulla.clonephone" /' app/src/main/AndroidManifest.xml > "$build_dir/AndroidManifest.xml"
"$sdk_tools/aapt2" link -o "$build_dir/base.apk" -I "$android_api" -A app/src/main/assets --manifest "$build_dir/AndroidManifest.xml" --min-sdk-version 26 --target-sdk-version 34 --version-code 36 --version-name 9.3 "$build_dir/resources.zip"
"$JAVA_HOME/bin/jar" cf "$build_dir/classes.jar" -C "$build_dir/classes" .
"$sdk_tools/d8" --release --min-api 26 --lib "$android_api" --output "$build_dir/dex" "$build_dir/classes.jar" app/libs/zxing-core-3.5.3.jar
"$JAVA_HOME/bin/jar" uf "$build_dir/base.apk" -C "$build_dir/dex" classes.dex
"$sdk_tools/zipalign" -f -p 4 "$build_dir/base.apk" "$build_dir/aligned.apk"
"$sdk_tools/apksigner" sign --ks test-signing/debug.keystore --ks-pass pass:android --key-pass pass:android --out "$build_dir/REBAR-IT-Clone-9.3.apk" "$build_dir/aligned.apk"
"$sdk_tools/apksigner" verify --verbose "$build_dir/REBAR-IT-Clone-9.3.apk"
echo "APK: $build_dir/REBAR-IT-Clone-9.3.apk"
```

------------------------------------------------------------------------

## `build.gradle`

``` groovy
plugins {
    id 'com.android.application' version '8.7.3' apply false
    id 'org.jetbrains.kotlin.android' version '2.0.21' apply false
}
```

------------------------------------------------------------------------

## `gradle.properties`

``` properties
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=false
```

------------------------------------------------------------------------

## `gradle/wrapper/gradle-wrapper.properties`

``` properties
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.9-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```

------------------------------------------------------------------------

## `localization/ckb.json`

``` json
[
  "٧.٢ • بێ ئینتەرنێت",
  "١  هەڵبژاردن     •     ٢  پەیوەندی     •     ٣  گواستنەوە",
  "باشە",
  "داتاکەت بگوازەوە",
  "لە مۆبایلی کۆنەوە بۆ مۆبایلی نوێ، بە چەند هەنگاوێکی سادە.",
  "من مۆبایلە کۆنەکەم",
  "داتاکان لەم مۆبایلەوە دەنێرم",
  "من مۆبایلە تازەکەم",
  "داتاکان بۆ ئەم مۆبایلە وەردەگرم",
  "هۆتسپۆت یان کەیبڵ • بەبێ سیمکارت و ئینتەرنێت",
  "وەرگرتن بە USB-C",
  "چی دەگوازرێتەوە؟",
  "داتای بەردەست",
  "وێنە، ڤیدیۆ، دەنگ، فایل، ئەپەکان و ژمارەکان بە VCF. SMS و مێژووی پەیوەندی بە فایلێکی پاشەکەوت دەنێردرێن، نە گەڕاندنەوە بۆ Phone و Messages.\n\nداتای ناوخۆی ئەپ، WhatsApp، هەژمار و ڕێکخستن ناگوازرێنەوە. ئەپەکە لە هەردوو مۆبایل نوێ بکەرەوە.",
  "چی بنێرین؟",
  "بەشێک هەڵبژێرە، یان فایلەکان بە دەستی خۆت دیاری بکە.",
  "وێنەکان",
  "هەموو وێنە ڕێگەپێدراوەکان",
  "ڤیدیۆکان",
  "ڤیدیۆکانی مۆبایل",
  "دەنگ و موزیک",
  "فایلە دەنگییەکان",
  "ئەپەکان (APK)",
  "APKی ئەپەکان بۆ ناردن و دامەزراندن هەڵبژێرە",
  "ژمارەکان",
  "ناو و ژمارە، بە فایلێکی VCF",
  "فایلەکان",
  "بە دەستی خۆت هەڵبژێرە",
  "بەردەوام بە  ←",
  "گەڕانەوە",
  "بەشێکی هەڵبژێردراو دابگرە بۆ لابردنی. بۆ تەنها چەند وێنەیەک، «فایلەکان» بەکاربهێنە.",
  " فایل • ",
  " + قەبارەی نەزانراو",
  "لیستی ئەپەکان ئامادە دەکرێت",
  "هیچ ئەپێکی گونجاو نەدۆزرایەوە.",
  "ئەپەکان هەڵبژێرە — تەنها دامەزراندن",
  "زیادکردن",
  "لیستی ئەپەکان",
  "ئەپە هەڵبژێردراوەکان ئامادە دەکرێن",
  "هەندێک ئەپ ئامادە نەبوون",
  "فایلەکانی ئەم ئەپانە بەردەست نەبوون یان بۆشایی بەس نەبوو:\n",
  "ڕێگە پێویستە",
  "بۆ هۆتسپۆتی بەخۆکار ڕێگەی وایفای پێویستە. دەتوانیت هۆتسپۆت بە دەستی خۆت چالاک بکەیت.",
  "دەتوانیت وێنەی QR هەڵبژێریت یان کۆدی پەیوەندی بلکێنیت.",
  "ڕێگە نەدرا؛ دەتوانیت «فایلەکان» بەکاربهێنیت.",
  "تکایە کەمێک چاوەڕێ بکە…",
  "داتا ئامادە دەکرێت",
  "هیچ داتایەکی ڕێگەپێدراو نەدۆزرایەوە.",
  "تەنها ئەو وێنە و ڤیدیۆیانە زیاد کران کە ڕێگەت پێداون.",
  "داتا ئامادە نەبوو",
  "سەرەتا داتایەک هەڵبژێرە.",
  "لە هەر جارێکدا تا ١٠ هەزار فایل بنێرە.",
  "بە مۆبایلی نوێ ببەستەوە",
  "١. لە مۆبایلی نوێ «دەستپێکردنی هۆتسپۆت» دابگرە.\n٢. QR ی ئەو مۆبایلە سکان بکە.\n٣. داواکاری پەیوەستبوونی ئەندرۆید قبووڵ بکە.\n\nسیمکارت، داتا و ئینتەرنێت پێویست نین.",
  "سکانی QR — وایفای",
  "ناردن بە کەیبڵی USB-C",
  "هەڵبژاردنی وێنەی QR",
  "گەڕانەوە بۆ داتاکان",
  "ڕێگای جێگرەوە: لکاندنی کۆدی پەیوەندی",
  "کۆدی پەیوەندی بلکێنە",
  "پەیوەستبوون",
  "پاشگەزبوونەوە",
  "QR نەگونجاوە",
  "QR ی ناو ئەپی rebaritclone ی مۆبایلی نوێ سکان بکە؛ هەردووکیان وەشانی ٣.٠ یان لەسەر بێت.",
  "پەیوەستبوون بە هۆتسپۆت",
  "داواکاری پەیوەستبوونی ئەندرۆید قبووڵ بکە. ئەم تۆڕە ئینتەرنێتی نییە و پێویستیشی پێ نییە.",
  "پەیوەستبوون بە دەستی خۆم",
  "بە هۆتسپۆتەکە ببەستەوە",
  "لە ڕێکخستنی وایفای، هۆتسپۆتی مۆبایلی نوێ هەڵبژێرە. ئەگەر وتی «ئینتەرنێتی نییە»، بە پەیوەستی بمێنەوە.",
  "ناوی هۆتسپۆت: ",
  "وشەی نهێنی: ",
  "کردنەوەی وایفای",
  "پەیوەست بووم — ناردن",
  "سەرەتا بە هۆتسپۆتی مۆبایلی نوێ ببەستەوە.",
  "هۆتسپۆت دروست دەکرێت",
  "هۆتسپۆتێکی ناوخۆیی بۆ گواستنەوە، بەبێ ئینتەرنێت.",
  "5 GHz ئامادە نەبوو",
  "هۆتسپۆت ئامادە نەبوو",
  "دەتوانیت هەوڵ بدەیتەوە، یان ڕێگایەکی تر هەڵبژێریت. 5 GHz پێویستی بە پشتگیری هەردوو مۆبایلەکە هەیە.",
  "هەوڵدانەوە",
  "بەردەوامبوون بە هۆتسپۆتی ئاسایی",
  "ڕێکخستنی هۆتسپۆتی 5 GHz بە دەست",
  "وەرگرتن بە USB-C",
  "هۆتسپۆت بە دەستی خۆت چالاک بکە",
  "ئەم مۆبایلە هۆتسپۆتی بەخۆکار ئامادە نەکرد. لە ڕێکخستنەکان هۆتسپۆت چالاک بکە؛ داتای سیمکارت پێویست نییە. لە ئەندرۆیدی کۆندا چالاککردنی Locationیش ڕەنگە پێویست بێت.",
  "هۆکاری شکستی پەیوەستبوونی بەخۆکار: ",
  "ڕێکخستنی هۆتسپۆت",
  "چالاکم کرد — پیشاندانی QR",
  "لە مۆبایلی کۆن سەرەتا بە وایفای بە هۆتسپۆتەکە ببەستەوە، پاشان QR سکان بکە. بۆ خێرایی زیاتر، ئەگەر هەردوو مۆبایل پشتگیری دەکەن، 5 GHz هەڵبژێرە.",
  "QR دەخوێندرێتەوە",
  "QR نەخوێندرایەوە",
  "وێنەیەکی ڕوون لە QR ی ناو ئەپەکە هەڵبژێرە.",
  "گواستنەوە بە کەیبڵ",
  "کەیبڵێکی USB-C کە داتا بگوازێتەوە ببەستە بە هەردوو مۆبایلەکە.",
  "لە مۆبایلی نوێ، USB controlled by → This device هەڵبژێرە یان OTG چالاک بکە. لە مۆبایلی کۆن «ناردن بە کەیبڵ» هەڵبژێرە.",
  "لە مۆبایلی نوێ «وەرگرتن بە کەیبڵ» هەڵبژێرە. داواکاری USB لە هەردوو مۆبایلەکە قبووڵ بکە.",
  "تاقیکردنەوەیی • پێویستی بە پشتگیری USB Host و Accessory هەیە. USB debugging پێویست نییە. ئەگەر ئامێر نەدۆزرایەوە، لە کۆنەکە USB / File transfer هەڵبژێرە و دووبارە هەوڵ بدە.",
  "چاوەڕوانی کەیبڵ و ڕێگەی USB…",
  "پەیوەندی USB نەبەسترا",
  "گواستنەوە بە هۆتسپۆت",
  "سیمکارت و ئینتەرنێت پێویست نین. مۆبایلی کۆن بە هۆتسپۆتی ئەم مۆبایلەوە دەبەسترێت.",
  "دەستپێکردنی هۆتسپۆت",
  "وەرگرتن بە کەیبڵی USB-C",
  "هۆتسپۆت بە دەستی خۆم چالاک دەکەم",
  "ئەگەر داتای سیمکارت کوژاوە بێت یان سیمکارتت نەبێت، هەر دەتوانیت فایل بگوازیتەوە.",
  "ئەم QR ـە سکان بکە",
  "لە مۆبایلی کۆن دوگمەی «سکانی QR» دابگرە.",
  "QR بۆ پەیوەستکردنی مۆبایلی کۆن",
  "چاوەڕوانی مۆبایلی کۆن…",
  "Ultra Fast / Wi‑Fi Direct",
  "\nئەو باندەی کە هەردوو مۆبایل و سیستەم پشتگیری دەکەن بەخۆکار هەڵدەبژێردرێت.",
  "ڕاگرتن",
  "کۆپی کردنی کۆدی پەیوەندی",
  "کۆپی کرا؛ تەنها لە مۆبایلی خۆت بەکاری بهێنە.",
  "داتاکەت دەنێردرێت",
  "داتاکەت وەردەگیرێت",
  "هەردوو ئەپەکە کراوە بهێڵەوە تا تەواو دەبێت.",
  "USB-C • گواستنەوەی ڕاستەوخۆ",
  "٠٪",
  "پەیوەندی دەبەسترێت…",
  "ئامادەکردنی ژمارە و قەبارەی فایلەکان…",
  "ڕاگرتنی گواستنەوە",
  "گواستنەوە ڕابگیرێت؟",
  "فایلە تەواوکراوەکان دەمێننەوە.",
  "بەردەوام بە",
  "تەواو بوو!",
  "گواستنەوە تەواو نەبوو",
  " فایل تەواو کراوە",
  "فایلە سەرەکییەکان لە مۆبایلی کۆن ناسڕێنەوە.",
  "دامەزراندنی ئەپە وەرگیراوەکان",
  "وێنە و ڤیدیۆ لە گەلەری؛ فایلەکان لە Downloads / rebaritclone.",
  "فایلەکان لە فۆڵدەری هەڵبژێردراو پاشەکەوت کران.",
  "هاوردەکردنی ژمارەکان",
  "گەڕانەوە بۆ سەرەتا",
  "بەردەوامبوون لە شوێنی پچڕان",
  "هەمان فایلەکان هەڵبژێردراو بهێڵەوە. ئەگەر تۆڕ پچڕاوە، QRی نوێ سکان بکە. ئەپەکان مەخەوە.",
  "لە ئەپی Contacts، Import هەڵبژێرە و فایلە وەرگیراوەکەی contacts.vcf بکەرەوە.",
  "٠ چرکە",
  "لە خەمڵاندندایە…",
  " کاتژمێر و ",
  " خولەک",
  " خولەک و ",
  " چرکە",
  " + نەزانراو",
  "قەبارەی گشتی: ",
  "\nگوازراوە: ",
  "\nماوە: ",
  "قەبارەی تەواو دیار نییە",
  "\n\nفایلەکان: ",
  " تەواو • ",
  " ماوە / ",
  "\nوێنە: ",
  "\nڤیدیۆ: ",
  "\nئەپ: ",
  "\nفایلی تر: ",
  "\n\nخێرایی ناوەند: ",
  "\nکاتی خەمڵێنراوی ماوە: ",
  "پشکنین و پاشەکەوتکردنی فایل…",
  "٪",
  "داتاکەت بە سەرکەوتوویی گوازرایەوە.",
  "گواستنەوە بە داواکاری تۆ ڕاگیرا.",
  "فایلە سەرچاوەکە گۆڕاوە؛ بۆ پاراستنی داتا بەردەوامبوون ڕاگیرا.",
  "ڕێگەی دەستگەیشتن بە داتا نەدراوە. دووبارە داتاکان هەڵبژێرە.",
  "ژمارەی فایلەکان زۆرە؛ لە «فایلەکان» بەش بەش بیاننێرە. سنوور: ١٠ هەزار فایل لە هەر جارێکدا.",
  "وەرگرتن ڕەتکرایەوە یان کاتی ڕەزامەندی بەسەرچوو.",
  "پەیوەندی USB وەستا. کەیبڵی داتا، ڕێگەی USB و بۆشایی مۆبایل بپشکنە؛ فایلە تەواوکراوەکان دەمێننەوە.",
  "کاتی چاوەڕوانی بەسەرچوو. هەردوو مۆبایلەکە بە هەمان وایفای ببەستەوە و QRێکی نوێ سکان بکە.",
  "پەیوەندی نەبەسترا. هەمان وایفای بەکاربهێنە، یان یەک مۆبایل بکە بە هۆتسپۆت و ئەوی تر پێوە ببەستە. VPN بکوژێنەوە و QRێکی نوێ سکان بکە.",
  "کۆدی پەیوەندی کۆنە یان هەڵەیە. لە مۆبایلی نوێ QRێکی نوێ دروست بکە.",
  "پەیوەندی پچڕا. هەردوو ئەپەکە کراوە بهێڵەوە و «بەردەوامبوون لە شوێنی پچڕان» دابگرە.",
  "گواستنەوە وەستا. بۆشایی مۆبایل، ڕێگەی فایلەکان و پەیوەندی وایفای بپشکنە؛ فایلە تەواوکراوەکان دەمێننەوە.",
  "ڕاگرتن…",
  "پەیوەندی پچڕا؛ هەوڵی بەردەوامبوونەوە…",
  "چاوەڕوانی ڕەزامەندی مۆبایلی نوێ…",
  "وایفای پێویستە",
  "سەرەتا بە وایفای پەیوەست بە یان هۆتسپۆت چالاک بکە، پاشان دووبارە «پیشاندانی QR» دابگرە.",
  "QR ئامادە دەکرێت",
  "پەیوەندی پچڕا؛ چاوەڕوانی بەردەوامبوونەوە…",
  " فایل\n",
  " + داتای قەبارەنەزانراو",
  "\nداتاکان بۆ ئەم مۆبایلە وەربگیرێن؟",
  "\n\nدوای وەرگرتن دامەزراندنی ئەپەکان دەست پێ دەکات؛ پەنجەرەی Install خۆت قبووڵ دەکەیت.",
  "مۆبایلی کۆن پەیوەست بوو",
  "وەرگرتن",
  "ڕەتکردنەوە",
  "بۆ دەستپێکردن وایفای و ڕێکخستنە پێویستەکان چالاک بکە.",
  "فایلەکان ئامادە دەکرێن",
  "فایل نەخوێندرایەوە",
  "ئەم کارە ڕابگریت؟",
  "بەڵێ",
  "نەخێر",
  "دوو مۆبایل بۆ گواستنەوەی داتا",
  "ڕێگەی USB ڕەتکرایەوە.",
  "مۆبایلی نوێ پشتگیری USB Host/OTG ناکات.",
  "USB نەدۆزرایەوە. کەیبڵی داتا بەکاربهێنە و لە مۆبایلی نوێ USB controlled by / This device هەڵبژێرە یان OTG چالاک بکە.",
  "پەیوەندی USB ئامادە نەبوو: ",
  "ئەم پەیوەندییە پشتگیری USB Accessory نەکرد یان ڕێگە نەدرا. USB controlled by / This device لە مۆبایلی نوێ تاقی بکەرەوە.",
  "لە پەنجەرەی ئەندرۆید Install / Update قبووڵ بکە.",
  "داواکاری دامەزراندن بەردەست نەبوو.",
  "دامەزرا",
  "بەردەوامبوون / هەوڵدانەوە",
  "ئەم ئەپە جێبهێڵە",
  "بە داواکاری تۆ جێهێڵرا",
  "تەنها فایلەکانی دامەزراندنە؛ هەژمار و داتای ناوخۆی ئەپ ناگوازرێتەوە. هەندێک ئەپ لە مۆبایلی نوێ ناگونجێت.",
  "دامەزراندن ڕاگیرا؛ بۆ بەردەوامبوون دوگمەکە دابگرە.",
  "لیستی دامەزراندن تەواو بوو.",
  " ئەپ دامەزرا • ",
  " ئەپ جێهێڵرا",
  "پەنجەرەی Install نەکرایەوە.",
  "ڕێگەی Allow from this source بۆ rebaritclone چالاک بکە، پاشان بگەڕێوە.",
  "ڕێکخستنی دامەزراندن نەکرایەوە.",
  "ئەپ بۆ دامەزراندن ئامادە دەکرێت…",
  "ئەپ دامەزرا نەکرا: ",
  "ڕێگەی دامەزراندن نەدرا؛ دەتوانیت دواتر هەوڵ بدەیتەوە.",
  "دامەزراندن هەڵوەشێندرایەوە.",
  "بۆشایی مۆبایل بەس نییە.",
  "ئەپەکە لەگەڵ وەشانی دامەزراو ناگونجێت؛ هیچ ئەپێک خۆکارانە ناسڕێتەوە.",
  "ئەم ئەپە لەگەڵ ئەندرۆید یان جۆری ئەم مۆبایلە ناگونجێت.",
  "ئەندرۆید ڕێگەی دامەزراندنی نەدا.",
  "دامەزراندن سەرکەوتوو نەبوو.",
  "دامەزراندن ڕابگیرێت؟ فایلە وەرگیراوەکان دەمێننەوە.",
  "QR ی مۆبایلی نوێ بخە بەرامبەر کامێرا",
  "کامێرا تەنها بۆ خوێندنەوەی QR بەکاردێت",
  "کامێرا نەکرایەوە؛ بگەڕێوە و وێنەی QR هەڵبژێرە.",
  "هۆتسپۆتی ناوخۆ • باندەکە لە ئەندرۆید بەردەست نییە",
  "زانیاری باندی ئەم پەیوەندییە بەردەست نییە",
  "باندی 2.4 GHz؛ بۆ خێرایی زیاتر 5 GHz تاقی بکەرەوە.",
  "خێرایی Link خێرایی ڕاستەقینەی ناردن نییە.",
  "زانیاری باندی وایفای بەردەست نییە",
  "مێژووی پەیوەندی",
  "نامەکانی SMS",
  "تەنها فایلێکی پاشەکەوت دەنێردرێت؛ ناچێتە ناو Phone یان Messages. WhatsApp، RCS و MMS تێدا نین.",
  "ناوەکان تاک‌تاک هەڵبژێرە — VCF",
  "پەیوەندییەکان هەڵبژێرە — فایلێکی پاشەکەوت",
  "یەک کرتە: هەموو نامە بەردەستەکان هەڵبژێرە — پاشەکەوت",
  "ڕێگەی خوێندنەوە نەدرا. ئەندرۆید یان دامەزرێنەری ئەپ ڕەنگە دەستگەیشتن بە SMS و مێژووی پەیوەندی سنووردار بکات. دەتوانیت فایلێکی پاشەکەوتی پێشووت لە «فایلەکان» هەڵبژێریت.",
  "گەڕان بە ناو، ژمارە یان دەق",
  "هەڵبژاردنی هەمووی نیشاندراو",
  " دانە هەڵبژێردراوە",
  "تەنها ٥٠٠٠ تۆمار نیشان دەدرێت. بۆ SMS و پەیوەندییەکان نوێترینەکانن.",
  "هاتوو",
  "دەرچوو",
  "لەدەستچوو",
  "جۆری تر",
  "هەندێک تۆمار نەخوێندرایەوە، گۆڕاوە یان بۆشایی بەس نییە. هەڵبژاردنی پێشووت پارێزراوە؛ هەوڵ بدەرەوە.",
  "لابردنی هەموو هەڵبژاردنەکان",
  "ڕێگەپێدانەکانی ئەپ",
  "داواکارییەکانی ئەندرۆید بە نۆرە دەردەکەون؛ بۆ ئەو بەشانەی دەتەوێت بەکاریان بهێنیت Allow دابگرە.",
  "بۆ هەموو وێنەکان Allow all هەڵبژێرە. فایلەکان لە هەڵبژێری سیستەم هەڵبژێرە؛ فایلە پارێزراوەکانی سیستەم بەردەست نین. پەنجەرەی Allow پێویستی بە Display over other apps نییە.",
  "هەندێک ڕێگە نەدراوە یان تەنها چەند وێنەیەک ڕێگەپێدراون. دەتوانیت بەردەوام بیت یان لە ڕێکخستنەکان دەستکاری بکەیت. ڕێگەی SMS و مێژووی پەیوەندی ڕەنگە لەلایەن ئەندرۆیدەوە سنووردار بێت.",
  "کردنەوەی ڕێکخستنی ئەپ",
  "گواستنەوەی فایلەکان",
  "وایفای دایرێکت سەرقاڵ بوو؛ بەخۆکار ڕێگای هۆتسپۆتی ئاسایی تاقی کرایەوە. 5 GHz مسۆگەر نییە.",
  "وێنەی گوازراوە: ",
  "ڤیدیۆی گوازراوە: ",
  "ماوەی گواستنەوە (کاتژمێر:خولەک:چرکە): ",
  "پیشاندانی فایلەکان",
  "ئەپێکی گونجاو بۆ کردنەوەی ئەم فایلە بەردەست نییە یان ڕێگە نەدراوە. فایلەکە لە شوێنی وەرگرتن پاشەکەوت کراوە.",
  "بەبێ ئینتەرنێت • مۆبایل بۆ مۆبایل",
  "داتاکانت بە ئاسانی بگوازەرەوە",
  "داتاکانت لە مۆبایلی کۆنەوە بۆ نوێ بگوازەرەوە",
  "گواستنەوەی فایل",
  "هەڵبژاردەکان",
  "وێنە، ڤیدیۆ، ئەپ و فایلەکان بنێرە یان وەربگرە",
  "مۆبایل بۆ مۆبایل",
  "وێنە و ڤیدیۆ",
  "هەموو بابەتەکان",
  "زۆرترین 10000 فایل نیشان دەدرێت.",
  "بێ ئینتەرنێت",
  "هەڵبژاردن",
  "پەیوەندی",
  "گواستنەوە",
  "هەڵبژێردراوە",
  "دوو مۆبایلەکە بە کەیبڵی USB-C پەیوەست بکە.",
  "١  کەیبڵی گواستنەوەی داتا بەکاربهێنە؛ کەیبڵی تەنها شەحن بەس نییە.",
  "٢  لە مۆبایلی کۆن فایلەکان هەڵبژێرە، پاشان «ناردن بە کەیبڵی USB-C» دابگرە.",
  "٣  لێرە دەستپێکردن دابگرە و داواکاری ڕێگەدانی USB قبووڵ بکە.",
  "دەستپێکردنی وەرگرتن بە USB",
  "سەرەتا بە مۆبایلە تازەکە پەیوەست ببە؛ پاشان داتا هەڵبژێرە.",
  "پەیوەست بوو",
  "لە مۆبایلە کۆنەکە داتا هەڵبژێرە و ناردن دەست پێ بکە.",
  "داتاکان بۆ وەرگرتن ئامادەن",
  "مۆبایلی کۆن پەیوەست بوو",
  "فایلی تر",
  "وێنە و ڤیدیۆ",
  "فایل، APK و دەنگ",
  "ژمارەکان و نامەکان",
  "پشتیوانی Wi‑Fi 6/6E لە مۆبایلەکەدا هەیە؛ Wi‑Fi Direct خۆکار بەهێزترین باندی ڕێگەپێدراو هەڵدەبژێرێت.",
  "پشتیوانی 5 GHz هەیە؛ Wi‑Fi Direct خۆکار باندی بەردەست هەڵدەبژێرێت.",
  "باندی خێرا لە مۆبایلەکەدا پشتیوانی ناکرێت؛ سیستەم باندی بەردەست بەکار دەهێنێت.",
  "دابەزاندنی بەرنامە",
  "QR کۆدەکە سکان بکە یان لینکەکە بکەرەوە. هەموو وەشانەکان و نوێترین APK لە هەمان پەڕە بەردەستن.",
  "QR کۆدی دابەزاندنی rebaritclone",
  "کردنەوەی پەڕەی دابەزاندن",
  "کۆپیکردنی لینک",
  "وەشانی ئێستا: ",
  "لینکی دابەزاندن کۆپی کرا.",
  "نەتوانرا پەڕەی دابەزاندن بکرێتەوە.",
  "نوێکردنەوەی نوێ بەردەستە",
  "چاکسازی و بەهێزکردنی کارکردن.",
  "وەشانی نوێ: ",
  "دابەزاندنی نوێکردنەوە",
  "دواتر",
  "گەڕان لە فایلەکانی مۆبایل",
  "بەڵگەنامەکان",
  "فایلەکانی APK",
  "فایلەکانی تر",
  "دابەزاندنەکان",
  "هەڵبژێردراو: ",
  "فایلە هەڵبژێردراوەکان بنێرە",
  "بەرنامەکە بنێرە بە Bluetooth یان Share",
  "نەتوانرا پەڕەی ناردنی بەرنامە بکرێتەوە."
]
```

------------------------------------------------------------------------

## `localization/generate.py`

``` python
from pathlib import Path
import json
root=Path(__file__).resolve().parent
ckb=json.loads((root/'ckb.json').read_text())
rows={}
for line in (root/'translations.tsv').read_text().splitlines():
 n,en,ar=line.split('|');rows[int(n)]=[en.replace('\\n','\n'),ar.replace('\\n','\n')]
assert set(rows)==set(range(len(ckb)))
ckb[0]='٩.١ • بێ ئینتەرنێت'
ckb[63]='QR ی ناو ئەپی rebaritclone ی مۆبایلی نوێ سکان بکە؛ ئەپەکە لە هەردوو مۆبایل نوێ بکەرەوە.'
ckb[30]='SMS و مێژووی پەیوەندی بە یەک کرتە هەمووی هەڵدەبژێردرێت؛ کرتەی دووەم لایاندەبات. ئەپ و ژمارەکان تاک‌تاک هەڵبژێرە.'
ckb[233]='یەک کرتە: هەموو پەیوەندییە بەردەستەکان — فایلێکی پاشەکەوت'
ckb[263]='وێنە، ڤیدیۆ، دەنگ، ئەپ و فایلەکان بۆ ناردن هەڵبژێرە' 
ckb[53]='١. لە مۆبایلی وەرگر «مۆبایلی نوێ» دابگرە.\n٢. QR ی ئەو مۆبایلە سکان بکە.\n٣. داواکاری پەیوەستبوونی ئەندرۆید قبووڵ بکە.\n\nسیمکارت، داتا و ئینتەرنێت پێویست نین.'
ckb[275]='٢  لە مۆبایلە کۆنەکە ناردن بە USB-C هەڵبژێرە؛ دوای پەیوەندی داتا دیاری بکە.'
# Arabic fragments retain spaces at both ends when inserted between numbers.
rows[139][1]=' ساعة و ';rows[141][1]=' دقيقة و '
lines=['package com.abdulla.clonephone;','/** Generated from localization catalogs. Do not hand-edit. */','public final class Translations {','    public static final int COUNT='+str(len(ckb))+';','    private static final String[][] TEXT={']
for i,k in enumerate(ckb):lines.append('        {'+','.join(json.dumps(v,ensure_ascii=False) for v in [k,*rows[i]])+'},')
lines+=['    };','    public static String get(String language,int id){return TEXT[id]["en".equals(language)?1:"ar".equals(language)?2:0];}','    public static boolean rtl(String language){return !"en".equals(language);}','}']
(root.parent/'app/src/main/java/com/abdulla/clonephone/Translations.java').write_text('\n'.join(lines)+'\n')
```

------------------------------------------------------------------------

## `localization/translations.tsv`

``` tsv
0|8.4 • Offline|8.4 • بدون إنترنت
1|1  Select     •     2  Connect     •     3  Transfer|١  الاختيار     •     ٢  الاتصال     •     ٣  النقل
2|OK|حسنًا
3|Transfer your data|انقل بياناتك
4|Move from your old phone to your new phone in a few simple steps.|انقل بياناتك من هاتفك القديم إلى الجديد بخطوات بسيطة.
5|Old phone|الهاتف القديم
6|Send data from this phone|إرسال البيانات من هذا الهاتف
7|New phone|الهاتف الجديد
8|Receive data on this phone|استقبال البيانات على هذا الهاتف
9|Hotspot or cable • No SIM or internet needed|نقطة اتصال أو كابل • دون شريحة أو إنترنت
10|Receive via USB-C|الاستقبال عبر USB-C
11|What can I transfer?|ما الذي يمكن نقله؟
12|Supported data|البيانات المدعومة
13|Photos, videos, audio, files, apps and contacts as VCF. SMS and call history are transferred as backup files, not restored into Phone or Messages.\n\nPrivate app data, WhatsApp data, accounts and settings are not transferred. Update both phones.|الصور والفيديو والصوت والملفات والتطبيقات وجهات الاتصال بصيغة VCF. تُنقل الرسائل وسجل المكالمات كملفات احتياطية ولا تُستعاد داخل الهاتف أو الرسائل.\n\nلا تُنقل بيانات التطبيقات الخاصة أو واتساب أو الحسابات أو الإعدادات. حدّث التطبيق على الهاتفين.
14|What would you like to send?|ماذا تريد أن ترسل؟
15|Choose a category or select files manually.|اختر فئة أو حدد الملفات يدويًا.
16|Photos|الصور
17|All photos you have allowed access to|جميع الصور التي سمحت بالوصول إليها
18|Videos|الفيديو
19|Videos on this phone|مقاطع الفيديو على هذا الهاتف
20|Audio and music|الصوت والموسيقى
21|Audio files|الملفات الصوتية
22|Apps (APK)|التطبيقات (APK)
23|Select app APKs to send and install|اختر APK للتطبيقات لإرسالها وتثبيتها
24|Contacts|جهات الاتصال
25|Names and numbers in a VCF file|الأسماء والأرقام في ملف VCF
26|Files|الملفات
27|Select manually|حدد يدويًا
28|Continue  →|متابعة  ←
29|Back|رجوع
30|Tap SMS or recent calls to select all available records. Tap again to clear. Apps and contacts offer individual selection.|اضغط على الرسائل أو المكالمات الأخيرة لتحديد كل السجلات المتاحة. اضغط مجددًا لإلغاء التحديد. يمكن اختيار التطبيقات وجهات الاتصال بشكل فردي.
31| files • | ملفات • 
32| + unknown size| + حجم غير معروف
33|Loading app list|جارٍ تحميل قائمة التطبيقات
34|No suitable apps found.|لم يتم العثور على تطبيقات مناسبة.
35|Select apps — installation files only|حدد التطبيقات — ملفات التثبيت فقط
36|Add|إضافة
37|App list|قائمة التطبيقات
38|Preparing selected apps|جارٍ تجهيز التطبيقات المحددة
39|Some apps could not be prepared|تعذر تجهيز بعض التطبيقات
40|These app files were unavailable, or storage was insufficient:\n|ملفات هذه التطبيقات غير متاحة أو مساحة التخزين غير كافية:\n
41|Permission required|الإذن مطلوب
42|Automatic hotspot setup needs Wi-Fi permission. You can also turn on the hotspot manually.|يتطلب إعداد نقطة الاتصال تلقائيًا إذن Wi-Fi. يمكنك تشغيلها يدويًا أيضًا.
43|You can choose a QR image or paste the pairing code.|يمكنك اختيار صورة QR أو لصق رمز الاقتران.
44|Permission denied. You can use Files instead.|لم يُمنح الإذن. يمكنك استخدام الملفات بدلًا من ذلك.
45|Please wait…|يرجى الانتظار…
46|Preparing data|جارٍ تجهيز البيانات
47|No accessible data found.|لم يتم العثور على بيانات يمكن الوصول إليها.
48|Only the photos and videos you allowed were added.|أُضيفت فقط الصور ومقاطع الفيديو التي سمحت بالوصول إليها.
49|Could not prepare data|تعذر تجهيز البيانات
50|Select some data first.|حدد البيانات أولًا.
51|Send up to 10,000 files per transfer.|يمكن إرسال ما يصل إلى 10,000 ملف في كل عملية نقل.
52|Connect to the new phone|اتصل بالهاتف الجديد
53|1. Tap New phone on the receiving phone.\n2. Scan its QR code.\n3. Accept the Android connection request.\n\nNo SIM, mobile data or internet is needed.|١. اضغط على الهاتف الجديد في هاتف الاستقبال.\n٢. امسح رمز QR الظاهر عليه.\n٣. وافق على طلب الاتصال من أندرويد.\n\nلا تحتاج إلى شريحة أو بيانات هاتف أو إنترنت.
54|Scan QR — Wi-Fi|مسح QR — Wi-Fi
55|Send via USB-C cable|الإرسال عبر كابل USB-C
56|Choose QR image|اختيار صورة QR
57|Back to data selection|العودة لاختيار البيانات
58|Alternative: paste pairing code|طريقة بديلة: لصق رمز الاقتران
59|Paste pairing code|الصق رمز الاقتران
60|Connect|اتصال
61|Cancel|إلغاء
62|Invalid QR code|رمز QR غير صالح
63|Scan the QR code inside rebaritclone on the new phone. Update the app on both phones.|امسح رمز QR داخل rebaritclone على الهاتف الجديد. حدّث التطبيق على الهاتفين.
64|Connecting to hotspot|جارٍ الاتصال بنقطة الاتصال
65|Accept the Android connection request. This network does not provide or require internet.|وافق على طلب الاتصال من أندرويد. هذه الشبكة لا توفر الإنترنت ولا تحتاج إليه.
66|Connect manually|الاتصال يدويًا
67|Join the hotspot|اتصل بنقطة الاتصال
68|In Wi-Fi settings, select the new phone's hotspot. Stay connected if Android says No internet.|في إعدادات Wi-Fi، اختر نقطة اتصال الهاتف الجديد. ابقَ متصلًا إذا ظهرت عبارة لا يوجد إنترنت.
69|Hotspot name: |اسم نقطة الاتصال: 
70|Password: |كلمة المرور: 
71|Open Wi-Fi settings|فتح إعدادات Wi-Fi
72|Connected — Send|تم الاتصال — إرسال
73|Connect to the new phone's hotspot first.|اتصل بنقطة اتصال الهاتف الجديد أولًا.
74|Creating hotspot|جارٍ إنشاء نقطة الاتصال
75|A local hotspot for offline transfer.|نقطة اتصال محلية للنقل دون إنترنت.
76|5 GHz unavailable|تعذر تشغيل 5 GHz
77|Hotspot unavailable|تعذر تشغيل نقطة الاتصال
78|Retry or choose another method. Both phones must support 5 GHz.|أعد المحاولة أو اختر طريقة أخرى. يجب أن يدعم الهاتفان نطاق 5 GHz.
79|Retry|إعادة المحاولة
80|Continue with a standard hotspot|المتابعة بنقطة اتصال عادية
81|Set up a 5 GHz hotspot manually|إعداد نقطة اتصال 5 GHz يدويًا
82|Receive via USB-C|الاستقبال عبر USB-C
83|Turn on the hotspot manually|شغّل نقطة الاتصال يدويًا
84|Automatic hotspot setup failed on this phone. Enable it in Settings; mobile data is not needed. Older Android versions may also require Location to be on.|تعذر إعداد نقطة الاتصال تلقائيًا على هذا الهاتف. شغّلها من الإعدادات؛ لا تحتاج إلى بيانات الهاتف. قد تتطلب إصدارات أندرويد القديمة تشغيل الموقع أيضًا.
85|Automatic connection error: |سبب فشل الاتصال التلقائي: 
86|Hotspot settings|إعدادات نقطة الاتصال
87|Enabled — Show QR|تم التشغيل — عرض QR
88|Connect the old phone to this hotspot using Wi-Fi, then scan the QR code. For higher speed, choose 5 GHz if both phones support it.|اتصل بهذه النقطة من الهاتف القديم عبر Wi-Fi، ثم امسح QR. لسرعة أعلى، اختر 5 GHz إذا كان الهاتفان يدعمانه.
89|Reading QR code|جارٍ قراءة رمز QR
90|Could not read QR code|تعذرت قراءة رمز QR
91|Choose a clear image of the QR code shown in the app.|اختر صورة واضحة لرمز QR الظاهر في التطبيق.
92|Transfer by cable|النقل بالكابل
93|Connect both phones with a USB-C cable that supports data transfer.|صل الهاتفين بكابل USB-C يدعم نقل البيانات.
94|On the new phone, select USB controlled by → This device, or enable OTG. On the old phone, choose Send via USB-C cable.|على الهاتف الجديد، اختر التحكم في USB ← هذا الجهاز أو شغّل OTG. على الهاتف القديم، اختر الإرسال عبر كابل USB-C.
95|On the new phone, choose Receive via USB-C cable. Accept the USB permission requests on both phones.|على الهاتف الجديد، اختر الاستقبال عبر كابل USB-C. وافق على طلبات إذن USB على الهاتفين.
96|Experimental • Requires USB Host and Accessory support. USB debugging is not needed. If no device is found, choose USB / File transfer on the old phone and retry.|تجريبي • يتطلب دعم USB Host وAccessory. لا يحتاج إلى تصحيح أخطاء USB. إذا لم يُعثر على الجهاز، اختر USB / نقل الملفات على الهاتف القديم وأعد المحاولة.
97|Waiting for cable and USB permission…|بانتظار الكابل وإذن USB…
98|USB connection failed|فشل اتصال USB
99|Transfer via hotspot|النقل عبر نقطة الاتصال
100|No SIM or internet needed. The old phone connects to this phone's hotspot.|لا تحتاج إلى شريحة أو إنترنت. يتصل الهاتف القديم بنقطة اتصال هذا الهاتف.
101|Start hotspot|تشغيل نقطة الاتصال
102|Receive via USB-C cable|الاستقبال عبر كابل USB-C
103|Set up hotspot manually|إعداد نقطة الاتصال يدويًا
104|You can transfer files with mobile data turned off or without a SIM.|يمكنك نقل الملفات مع إيقاف بيانات الهاتف أو دون شريحة.
105|Scan this QR code|امسح رمز QR هذا
106|Tap Scan QR on the old phone.|اضغط على مسح QR في الهاتف القديم.
107|QR code to connect the old phone|رمز QR لربط الهاتف القديم
108|Waiting for the old phone…|بانتظار الهاتف القديم…
109|Ultra Fast / Wi-Fi Direct|فائق السرعة / Wi-Fi Direct
110|\nThe strongest band supported by both phones and Android is chosen automatically.|\nيُختار تلقائياً أقوى نطاق يدعمه الهاتفان ونظام Android.
111|Stop|إيقاف
112|Copy pairing code|نسخ رمز الاقتران
113|Copied. Use it only on your own phone.|تم النسخ. استخدمه على هاتفك فقط.
114|Sending your data|جارٍ إرسال بياناتك
115|Receiving your data|جارٍ استقبال بياناتك
116|Keep both apps open until the transfer finishes.|أبقِ التطبيق مفتوحًا على الهاتفين حتى يكتمل النقل.
117|USB-C • Direct transfer|USB-C • نقل مباشر
118|0%|٠٪
119|Connecting…|جارٍ الاتصال…
120|Preparing file counts and sizes…|جارٍ تجهيز أعداد الملفات وأحجامها…
121|Stop transfer|إيقاف النقل
122|Stop this transfer?|هل تريد إيقاف النقل؟
123|Completed files will be kept.|ستبقى الملفات المكتملة محفوظة.
124|Continue|متابعة
125|Done!|تم!
126|Transfer incomplete|لم يكتمل النقل
127| files completed| ملفات مكتملة
128|Original files on the old phone are not deleted.|لا تُحذف الملفات الأصلية من الهاتف القديم.
129|Install received apps|تثبيت التطبيقات المستلمة
130|Photos and videos are in Gallery; other files are in Downloads / rebaritclone.|الصور والفيديو في المعرض؛ والملفات الأخرى في Downloads / rebaritclone.
131|Files were saved in the selected folder.|حُفظت الملفات في المجلد المحدد.
132|Import contacts|استيراد جهات الاتصال
133|Back to home|العودة للرئيسية
134|Resume interrupted transfer|استئناف النقل المنقطع
135|Keep the same files selected. If the network disconnected, scan a new QR code. Do not close the apps.|أبقِ الملفات نفسها محددة. إذا انقطعت الشبكة، امسح رمز QR جديدًا. لا تغلق التطبيقين.
136|In Contacts, choose Import and open the received contacts.vcf file.|في تطبيق جهات الاتصال، اختر استيراد وافتح ملف contacts.vcf المستلم.
137|0 seconds|٠ ثانية
138|Estimating…|جارٍ التقدير…
139| h and | ساعة و
140| min| دقيقة
141| min and | دقيقة و
142| sec| ثانية
143| + unknown| + غير معروف
144|Total size: |الحجم الإجمالي: 
145|\nTransferred: |\nتم نقل: 
146|\nRemaining: |\nالمتبقي: 
147|Full size is unknown|الحجم الكامل غير معروف
148|\n\nFiles: |\n\nالملفات: 
149| done • | مكتمل • 
150| remaining / | متبقٍ / 
151|\nPhotos: |\nالصور: 
152|\nVideos: |\nالفيديو: 
153|\nApps: |\nالتطبيقات: 
154|\nOther files: |\nالملفات الأخرى: 
155|\n\nAverage speed: |\n\nمتوسط السرعة: 
156|\nEstimated time left: |\nالوقت المتبقي المقدر: 
157|Verifying and saving file…|جارٍ التحقق من الملف وحفظه…
158|%|٪
159|Your data was transferred successfully.|نُقلت بياناتك بنجاح.
160|Transfer stopped at your request.|توقف النقل بناءً على طلبك.
161|The source file changed. Resume was stopped to protect your data.|تغيّر الملف الأصلي. أُوقف الاستئناف لحماية بياناتك.
162|Data access permission was denied. Select the data again.|لم يُمنح إذن الوصول إلى البيانات. حدد البيانات مجددًا.
163|Too many files. Send smaller batches using Files. Limit: 10,000 files per transfer.|عدد الملفات كبير جدًا. أرسلها على دفعات من قسم الملفات. الحد: 10,000 ملف لكل عملية نقل.
164|Receiving was declined or the approval request timed out.|رُفض الاستقبال أو انتهت مهلة الموافقة.
165|USB transfer stopped. Check the data cable, USB permission and free space. Completed files are kept.|توقف نقل USB. تحقق من كابل البيانات وإذن USB والمساحة المتاحة. تبقى الملفات المكتملة محفوظة.
166|Timed out. Connect both phones to the same Wi-Fi and scan a new QR code.|انتهت المهلة. صل الهاتفين بشبكة Wi-Fi نفسها وامسح QR جديدًا.
167|Could not connect. Use the same Wi-Fi, or connect one phone to the other's hotspot. Turn off VPN and scan a new QR code.|تعذر الاتصال. استخدم شبكة Wi-Fi نفسها أو اتصل بنقطة اتصال الهاتف الآخر. أوقف VPN وامسح QR جديدًا.
168|The pairing code is old or incorrect. Generate a new QR code on the new phone.|رمز الاقتران قديم أو غير صحيح. أنشئ رمز QR جديدًا على الهاتف الجديد.
169|Connection lost. Keep both apps open and tap Resume interrupted transfer.|انقطع الاتصال. أبقِ التطبيقين مفتوحين واضغط على استئناف النقل المنقطع.
170|Transfer stopped. Check free space, file permissions and Wi-Fi. Completed files are kept.|توقف النقل. تحقق من المساحة وإذن الملفات وWi-Fi. تبقى الملفات المكتملة محفوظة.
171|Stopping…|جارٍ الإيقاف…
172|Connection lost; trying to resume…|انقطع الاتصال؛ جارٍ محاولة الاستئناف…
173|Waiting for approval on the new phone…|بانتظار الموافقة على الهاتف الجديد…
174|Wi-Fi required|يلزم اتصال Wi-Fi
175|Connect to Wi-Fi or enable the hotspot, then tap Show QR again.|اتصل بشبكة Wi-Fi أو شغّل نقطة الاتصال، ثم اضغط على عرض QR مجددًا.
176|Preparing QR code|جارٍ تجهيز رمز QR
177|Connection lost; waiting to resume…|انقطع الاتصال؛ بانتظار الاستئناف…
178| files\n| ملفات\n
179| + files with unknown size| + ملفات بحجم غير معروف
180|\nReceive this data on this phone?|\nهل تريد استقبال هذه البيانات على هذا الهاتف؟
181|\n\nApp installation starts after receiving. You approve the Android Install prompt.|\n\nيبدأ تثبيت التطبيقات بعد الاستقبال. أنت توافق على نافذة التثبيت من أندرويد.
182|Old phone connected|اتصل الهاتف القديم
183|Receive|استقبال
184|Decline|رفض
185|Enable Wi-Fi and the required settings to start.|شغّل Wi-Fi والإعدادات المطلوبة للبدء.
186|Preparing files|جارٍ تجهيز الملفات
187|Could not read file|تعذرت قراءة الملف
188|Stop this operation?|هل تريد إيقاف هذه العملية؟
189|Yes|نعم
190|No|لا
191|Two phones transferring data|هاتفان لنقل البيانات
192|USB permission denied.|لم يُمنح إذن USB.
193|The new phone does not support USB Host/OTG.|الهاتف الجديد لا يدعم USB Host/OTG.
194|No USB device found. Use a data cable and select USB controlled by / This device on the new phone, or enable OTG.|لم يُعثر على جهاز USB. استخدم كابل بيانات واختر التحكم في USB / هذا الجهاز على الهاتف الجديد، أو شغّل OTG.
195|USB setup failed: |فشل إعداد USB: 
196|USB Accessory is unsupported or permission was denied. Try USB controlled by / This device on the new phone.|USB Accessory غير مدعوم أو لم يُمنح الإذن. جرّب التحكم في USB / هذا الجهاز على الهاتف الجديد.
197|Approve Install / Update in the Android prompt.|وافق على تثبيت / تحديث في نافذة أندرويد.
198|Install request unavailable.|طلب التثبيت غير متاح.
199|Installed|تم التثبيت
200|Continue / Retry|متابعة / إعادة المحاولة
201|Skip this app|تخطي هذا التطبيق
202|Skipped at your request|تم التخطي بناءً على طلبك
203|Installation files only; app accounts and private data are not transferred. Some apps may be incompatible with the new phone.|ملفات التثبيت فقط؛ لا تُنقل حسابات التطبيقات أو بياناتها الخاصة. قد لا تتوافق بعض التطبيقات مع الهاتف الجديد.
204|Installation paused. Tap Continue to resume.|توقف التثبيت. اضغط على متابعة للاستئناف.
205|Installation list finished.|انتهت قائمة التثبيت.
206| apps installed • | تطبيقات مثبّتة • 
207| apps skipped| تطبيقات تم تخطيها
208|Could not open the Install prompt.|تعذر فتح نافذة التثبيت.
209|Enable Allow from this source for rebaritclone, then come back.|فعّل السماح من هذا المصدر لتطبيق rebaritclone، ثم ارجع.
210|Could not open installation settings.|تعذر فتح إعدادات التثبيت.
211|Preparing app for installation…|جارٍ تجهيز التطبيق للتثبيت…
212|App could not be installed: |تعذر تثبيت التطبيق: 
213|Install permission denied. You can retry later.|لم يُمنح إذن التثبيت. يمكنك المحاولة لاحقًا.
214|Installation cancelled.|أُلغي التثبيت.
215|Not enough free space.|مساحة التخزين غير كافية.
216|The app conflicts with the installed version. No app will be uninstalled automatically.|يتعارض التطبيق مع الإصدار المثبّت. لن يُحذف أي تطبيق تلقائيًا.
217|This app is incompatible with this Android version or phone.|هذا التطبيق غير متوافق مع إصدار أندرويد أو هذا الهاتف.
218|Android blocked installation.|حظر أندرويد التثبيت.
219|Installation failed.|فشل التثبيت.
220|Stop installation? Received files will be kept.|هل تريد إيقاف التثبيت؟ ستبقى الملفات المستلمة محفوظة.
221|Point the camera at the new phone's QR code|وجّه الكاميرا إلى رمز QR على الهاتف الجديد
222|The camera is used only to scan QR codes|تُستخدم الكاميرا لمسح رموز QR فقط
223|Could not open camera. Go back and choose a QR image.|تعذر فتح الكاميرا. ارجع واختر صورة QR.
224|Local hotspot • Android did not report the band|نقطة اتصال محلية • لم يحدد أندرويد النطاق
225|Band information for this connection is unavailable|معلومات نطاق هذا الاتصال غير متاحة
226|2.4 GHz band. Try 5 GHz for higher speed.|نطاق 2.4 GHz. جرّب 5 GHz لسرعة أعلى.
227|Link speed is not the actual file transfer speed.|سرعة الارتباط ليست سرعة نقل الملفات الفعلية.
228|Wi-Fi band information unavailable|معلومات نطاق Wi-Fi غير متاحة
229|Recent calls|سجل المكالمات
230|SMS messages|رسائل SMS
231|Transfers a backup file only; it is not restored into Phone or Messages. WhatsApp, RCS and MMS are not included.|يُنقل ملف نسخة احتياطية فقط؛ ولا يُستعاد داخل الهاتف أو الرسائل. لا يشمل واتساب أو RCS أو MMS.
232|Select individual contacts — VCF|حدد جهات الاتصال — VCF
233|One tap: select all available calls — backup file|ضغطة واحدة: تحديد كل المكالمات المتاحة — ملف نسخ احتياطي
234|One tap: select all available SMS — backup|نقرة واحدة: تحديد كل الرسائل المتاحة — نسخة احتياطية
235|Read permission was not granted. Android or the app installer may restrict SMS and call-log access. You can select an existing backup through Files.|لم يُمنح إذن القراءة. قد يقيّد أندرويد أو مثبّت التطبيق الوصول إلى الرسائل وسجل المكالمات. يمكنك اختيار نسخة احتياطية موجودة من الملفات.
236|Search name, number or text|البحث بالاسم أو الرقم أو النص
237|Select all shown|تحديد كل النتائج المعروضة
238| selected| محدد
239|Showing at most 5,000 records. Calls and SMS show the most recent records.|تُعرض 5,000 سجلات كحد أقصى. للمكالمات والرسائل، تُعرض أحدث السجلات.
240|Incoming|واردة
241|Outgoing|صادرة
242|Missed|فائتة
243|Other|أخرى
244|Some records could not be read, changed, or storage is insufficient. Your previous selection was kept; retry.|تعذرت قراءة بعض السجلات أو تغيرت أو المساحة غير كافية. احتُفظ باختيارك السابق؛ أعد المحاولة.
245|Clear selection|إلغاء تحديد الكل
246|App permissions|أذونات التطبيق
247|Android prompts appear one at a time. Tap Allow for the features you want to use.|تظهر طلبات أندرويد بالتتابع. اضغط سماح للميزات التي تريد استخدامها.
248|For all photos, choose Allow all. Choose documents in the system file picker; protected system files are unavailable. Allow dialogs do not need Display over other apps.|لكل الصور اختر السماح بالكل. اختر المستندات من منتقي ملفات النظام؛ ملفات النظام المحمية غير متاحة. نوافذ السماح لا تحتاج إذن الظهور فوق التطبيقات.
249|Some permissions are missing or only selected photos are allowed. Continue with available features or change app settings. Android may restrict SMS and call-log access.|بعض الأذونات غير ممنوحة أو يسمح بصور محددة فقط. تابع بالميزات المتاحة أو غيّر إعدادات التطبيق. قد يقيّد أندرويد الوصول إلى الرسائل وسجل المكالمات.
250|Open app settings|فتح إعدادات التطبيق
251|File transfers|نقل الملفات
252|Wi-Fi Direct stayed busy; automatically tried the normal hotspot route. 5 GHz is not guaranteed.|بقي Wi-Fi Direct مشغولاً؛ جُرّبت نقطة الاتصال العادية تلقائياً. نطاق 5 GHz غير مضمون.
253|Photos transferred: |الصور المنقولة: 
254|Videos transferred: |الفيديوهات المنقولة: 
255|Transfer duration (hh:mm:ss): |مدة النقل (ساعة:دقيقة:ثانية): 
256|Show files|عرض الملفات
257|No suitable app is available to open this file, or access was denied. The file is saved in the receive location.|لا يتوفر تطبيق مناسب لفتح هذا الملف أو تم رفض الوصول. الملف محفوظ في موقع الاستلام.
258|Offline • Phone to phone|بدون إنترنت • من هاتف إلى هاتف
259|Transfer your data with ease|انقل بياناتك بسهولة
260|Move data from your old phone to your new phone|انقل بياناتك من هاتفك القديم إلى الجديد
261|File transfer|نقل الملفات
262|Options|الخيارات
263|Choose photos, videos, audio, apps and files to send|اختر الصور والفيديو والصوت والتطبيقات والملفات لإرسالها
264|Phone to phone|من هاتف إلى هاتف
265|Photos and videos|الصور والفيديوهات
266|All items|كل العناصر
267|Showing up to 10,000 files.|يتم عرض ما يصل إلى 10000 ملف.
268|Offline|بدون إنترنت
269|Select|اختيار
270|Connect|اتصال
271|Transfer|نقل
272|Selected|محدد
273|Connect both phones with a USB-C data cable.|صل الهاتفين بكابل USB-C لنقل البيانات.
274|1  Use a data cable; a charge-only cable will not work.|١  استخدم كابل بيانات؛ كابل الشحن فقط لا يكفي.
275|2  Choose Send via USB-C on the old phone; select data after connecting.|٢  اختر الإرسال عبر USB-C على الهاتف القديم؛ حدد البيانات بعد الاتصال.
276|3  Start here and accept the USB permission requests.|٣  اضغط ابدأ هنا ووافق على طلبات إذن USB.
277|Start USB receiving|بدء الاستقبال عبر USB
278|Connect to the new phone first, then select your data.|اتصل بالهاتف الجديد أولاً، ثم اختر بياناتك.
279|Connected|تم الاتصال
280|Select data on the old phone and start sending.|اختر البيانات على الهاتف القديم وابدأ الإرسال.
281|Data is ready to receive|البيانات جاهزة للاستقبال
282|The old phone is connected|الهاتف القديم متصل
283|more files|ملفات أخرى
284|Photos and videos|الصور والفيديو
285|Files, APKs and audio|الملفات وAPK والصوت
286|Contacts and messages|جهات الاتصال والرسائل
287|This phone supports Wi-Fi 6/6E; Wi-Fi Direct automatically chooses the strongest permitted band.|يدعم الهاتف Wi-Fi 6/6E؛ يختار Wi-Fi Direct تلقائياً أقوى نطاق مسموح.
288|This phone supports 5 GHz; Wi-Fi Direct automatically chooses an available band.|يدعم الهاتف 5 GHz؛ يختار Wi-Fi Direct تلقائياً نطاقاً متاحاً.
289|No fast Wi-Fi band is reported; the system uses an available band.|لا يظهر دعم لنطاق Wi-Fi سريع؛ يستخدم النظام نطاقاً متاحاً.
290|Download app|تنزيل التطبيق
291|Scan the QR code or open the link. All versions and the newest APK are available on the same page.|امسح رمز QR أو افتح الرابط. جميع الإصدارات وأحدث APK متاحة في الصفحة نفسها.
292|rebaritclone download QR code|رمز QR لتنزيل rebaritclone
293|Open download page|فتح صفحة التنزيل
294|Copy link|نسخ الرابط
295|Current version: |الإصدار الحالي: 
296|Download link copied.|تم نسخ رابط التنزيل.
297|Could not open the download page.|تعذر فتح صفحة التنزيل.
298|New update available|يتوفر تحديث جديد
299|Improvements and performance enhancements.|تحسينات وتعزيزات للأداء.
300|New version: |الإصدار الجديد: 
301|Download update|تنزيل التحديث
302|Later|لاحقاً
303|Search local files|بحث في الملفات المحلية
304|Documents|المستندات
305|APK files|ملفات APK
306|Other files|ملفات أخرى
307|Downloads|التنزيلات
308|Selected: |المحدد: 
309|Send selected files|إرسال الملفات المحددة
310|Share app via Bluetooth or another app|مشاركة التطبيق عبر البلوتوث أو تطبيق آخر
311|Could not open the app sharing menu.|تعذر فتح قائمة مشاركة التطبيق.
```

------------------------------------------------------------------------

## `settings.gradle`

``` groovy
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name = 'rebaritclone'
include ':app'
```

------------------------------------------------------------------------

## `tests/AppBundleTest.java`

``` java
import com.abdulla.clonephone.AppBundle;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
public class AppBundleTest {
 static byte[] zip(String... names)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();try(ZipOutputStream z=new ZipOutputStream(b)){for(String name:names){z.putNextEntry(new ZipEntry(name));z.write(new byte[]{1,2,3});z.closeEntry();}}return b.toByteArray();}
 static void reject(byte[] data)throws Exception{try{AppBundle.read(new ByteArrayInputStream(data),(name,in)->{byte[] b=new byte[4096];while(in.read(b)!=-1){}});throw new AssertionError("accepted invalid container");}catch(IOException expected){}}
 public static void main(String[] args)throws Exception{
  Path dir=Files.createTempDirectory("apps-test-");byte[] base=Files.readAllBytes(Paths.get(args[0]));byte[] split=new byte[1048576+37];new Random(17).nextBytes(split);
  File a=dir.resolve("base.apk").toFile(),b=dir.resolve("split.apk").toFile(),bundle=dir.resolve("app.rbapp").toFile();Files.write(a.toPath(),base);Files.write(b.toPath(),split);
  AppBundle.write(Arrays.asList(a,b),bundle);Map<String,byte[]> decoded=new HashMap<>();
  AppBundle.read(new FileInputStream(bundle),(name,in)->{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[16384];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);decoded.put(name,out.toByteArray());});
  if(decoded.size()!=2||!Arrays.equals(base,decoded.get("base.apk"))||!Arrays.equals(split,decoded.get("split-1.apk")))throw new AssertionError("APK bytes changed");
  reject(zip("../base.apk"));reject(zip("split-1.apk"));reject(zip("base.apk","extra.txt"));reject(new byte[]{1,2,3});
  byte[] duplicate=zip("base.apk","baze.apk");for(int i=0;i<duplicate.length-8;i++)if(duplicate[i]=='b'&&duplicate[i+1]=='a'&&duplicate[i+2]=='z'&&duplicate[i+3]=='e')duplicate[i+2]='s';reject(duplicate);
  String[] many=new String[257];many[0]="base.apk";for(int i=1;i<many.length;i++)many[i]="split-"+i+".apk";reject(zip(many));
  byte[] truncated=Files.readAllBytes(bundle.toPath());reject(Arrays.copyOf(truncated,truncated.length/2));
  try{AppBundle.read(new FileInputStream(bundle),(name,in)->{});throw new AssertionError("non-draining sink accepted");}catch(IOException expected){}
  AppBundle.write(Collections.singletonList(a),bundle);AppBundle.read(new FileInputStream(bundle),(name,in)->{byte[] buf=new byte[16384];while(in.read(buf)!=-1){}});
  System.out.println("PASS: real signed APK and split byte preservation; base-only bundle; missing-base, traversal, duplicate, extra-file, count-limit, truncated ZIP and incomplete staging rejection");
 }
}
```

------------------------------------------------------------------------

## `tests/FastStreamTest.java`

``` java
import com.abdulla.clonephone.SecureChannel;
import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
public class FastStreamTest{
 public static void main(String[] args)throws Exception{
  byte[] key=SecureChannel.parseCode(SecureChannel.newCode());byte[] block=new byte[262144];new Random(17).nextBytes(block);ExecutorService pool=Executors.newSingleThreadExecutor();long start=System.nanoTime();
  try(ServerSocket listener=new ServerSocket(0)){
   Future<Long> received=pool.submit(()->{try(Socket socket=listener.accept()){
    socket.setSoTimeout(10000);SecureChannel c=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,true);MessageDigest hash=MessageDigest.getInstance("SHA-256");long bytes=0;
    for(;;){byte[] p=c.read();if(p.length==0)break;hash.update(p);bytes+=p.length;}
    if(!MessageDigest.isEqual(hash.digest(),c.read()))throw new AssertionError("digest");c.write(new byte[]{2});return bytes;
   }});
   try(Socket socket=new Socket("127.0.0.1",listener.getLocalPort())){
    socket.setSoTimeout(10000);SecureChannel c=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,false);MessageDigest hash=MessageDigest.getInstance("SHA-256");
    for(int i=0;i<256;i++){hash.update(block);c.writeBuffered(block,block.length);}
    // A short tail catches truncated/final buffered data; no full-block copy required.
    hash.update(block,0,37);c.writeBuffered(block,37);c.write(new byte[0]);c.write(hash.digest());if(c.read()[0]!=2)throw new AssertionError();
   }
   if(received.get()!=67108864L+37)throw new AssertionError("length");
  }finally{pool.shutdownNow();}
  System.out.printf("PASS: 64 MiB + 37-byte buffered encrypted transfer and SHA-256 validation; host loopback %.2f seconds (not a phone speed measurement)%n",(System.nanoTime()-start)/1e9);
 }
}
```

------------------------------------------------------------------------

## `tests/ManifestTest.java`

``` java
import com.abdulla.clonephone.SecureChannel;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/** V2 manifests are separate encrypted records, so large selections do not exceed one frame. */
public class ManifestTest {
 public static void main(String[] args)throws Exception{
  byte[] key=SecureChannel.parseCode(SecureChannel.newCode());ExecutorService pool=Executors.newSingleThreadExecutor();
  try(ServerSocket listener=new ServerSocket(0)){
   Future<Integer> result=pool.submit(()->{
    try(Socket socket=listener.accept()){
     socket.setSoTimeout(5000);SecureChannel c=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,true);
     DataInputStream h=new DataInputStream(new ByteArrayInputStream(c.read()));int n=h.readInt();if(n!=2000)throw new AssertionError();
     for(int i=0;i<n;i++){DataInputStream meta=new DataInputStream(new ByteArrayInputStream(c.read()));String name=meta.readUTF();if(!name.equals("وێنەی تاقیکردنەوە-"+i+"-"+String.join("",Collections.nCopies(100,"x"))+".jpg"))throw new AssertionError();if(!meta.readUTF().equals("image/jpeg")||meta.readLong()!=i||meta.available()!=0)throw new AssertionError();}
     c.write(new byte[]{1});try{c.read();throw new AssertionError();}catch(EOFException expected){}return n;
    }
   });
   try(Socket socket=new Socket("127.0.0.1",listener.getLocalPort())){
    socket.setSoTimeout(5000);SecureChannel c=new SecureChannel(socket.getInputStream(),socket.getOutputStream(),key,false);
    ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);out.writeInt(2000);c.write(bytes.toByteArray());
    for(int i=0;i<2000;i++){bytes.reset();out.writeUTF("وێنەی تاقیکردنەوە-"+i+"-"+String.join("",Collections.nCopies(100,"x"))+".jpg");out.writeUTF("image/jpeg");out.writeLong(i);c.write(bytes.toByteArray());}
    if(!Arrays.equals(c.read(),new byte[]{1}))throw new AssertionError();
   }
   if(result.get(10,TimeUnit.SECONDS)!=2000)throw new AssertionError();
  }finally{pool.shutdownNow();}
  System.out.println("PASS: 2000-file Unicode manifest exceeding old 128 KiB limit; mid-session disconnect detected");
 }
}
```

------------------------------------------------------------------------

## `tests/P2pRetryTest.java`

``` java
import com.abdulla.clonephone.P2pRetry;
public class P2pRetryTest {
 public static void main(String[] args){
  int attempts=0;long wait=0;
  while(true){long delay=P2pRetry.delay(2,attempts);if(delay<0)break;wait+=delay;attempts++;if(attempts>10)throw new AssertionError("unbounded retry");}
  if(attempts!=3||wait!=5250)throw new AssertionError("busy retry budget");
  for(int reason:new int[]{-1,0,1,3})for(int attempt=0;attempt<5;attempt++)if(P2pRetry.delay(reason,attempt)!=-1)throw new AssertionError("permanent error retried");
  if(P2pRetry.delay(2,-1)!=-1)throw new AssertionError("invalid attempt");
  System.out.println("PASS: BUSY bounded to 3 retries / 5250 ms; permanent errors stop immediately");
 }
}
```

------------------------------------------------------------------------

## `tests/PairingTest.java`

``` java
import com.abdulla.clonephone.*;
import com.google.zxing.*;
import com.google.zxing.common.*;
import com.google.zxing.qrcode.QRCodeWriter;
import java.util.*;

public class PairingTest {
 static void check(boolean ok){if(!ok)throw new AssertionError();}
 static void bad(String value){try{Pairing.parse(value);throw new AssertionError(value);}catch(IllegalArgumentException expected){}}
 public static void main(String[] args)throws Exception{
  String key=SecureChannel.newCode();
  String hotspot=Pairing.encodeHotspot(Arrays.asList("192.168.43.1"),key,"Rebar ڕێبەر", "safe12345");
  Pairing hp=Pairing.parse(hotspot);check(hp.ssid.equals("Rebar ڕێبەر")&&hp.password.equals("safe12345"));
  bad("rebaritclone:v3:192.168.43.1:"+key+":@@:@@");
  String payload=Pairing.encode(Arrays.asList("192.168.43.1","10.0.0.5"),key);
  Pairing p=Pairing.parse(payload);check(p.hosts.size()==2);check(Arrays.equals(p.key,SecureChannel.parseCode(key)));
  bad("https://example.com");bad("rebaritclone:v2:127.0.0.1:"+key);bad("rebaritclone:v2:8.8.8.8:"+key);bad("rebaritclone:v2:192.168.999.1:"+key);bad("rebaritclone:v2:172.32.1.1:"+key);bad("rebaritclone:v2:192.168.0.1:1234");bad("rebaritclone:v1:192.168.0.1:"+key);
  for(String qrPayload:new String[]{payload,hotspot})for(int size:new int[]{280,660}){
   BitMatrix matrix=new QRCodeWriter().encode(qrPayload,BarcodeFormat.QR_CODE,size,size);
   for(int rotate=0;rotate<4;rotate++){
    int[] pixels=new int[size*size];byte[] frame=new byte[size*size*3/2];
    for(int y=0;y<size;y++)for(int x=0;x<size;x++){
     int a=x,b=y;for(int r=0;r<rotate;r++){int old=a;a=size-1-b;b=old;}
     boolean black=matrix.get(a,b);pixels[y*size+x]=black?0xff000000:0xffffffff;frame[y*size+x]=(byte)(black?0:255);
    }
    String image=new MultiFormatReader().decode(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(size,size,pixels)))).getText();
    String camera=new MultiFormatReader().decode(new BinaryBitmap(new HybridBinarizer(new PlanarYUVLuminanceSource(frame,size,size,0,0,size,size,false)))).getText();
    check(image.equals(qrPayload));check(camera.equals(qrPayload));
   }
  }
  System.out.println("PASS: strict private-address pairing, invalid input rejection, QR image and camera luminance roundtrips at two sizes in four orientations");
 }
}
```

------------------------------------------------------------------------

## `tests/PermissionPlanTest.java`

``` java
import com.abdulla.clonephone.PermissionPlan;
import java.util.*;
public class PermissionPlanTest {
 static Set<String> permissions(int sdk,boolean receiver){Set<String> all=new HashSet<>();for(String[] step:PermissionPlan.forRole(sdk,receiver)){if(step.length==0)throw new AssertionError("empty prompt");for(String p:step){if(!all.add(p))throw new AssertionError("duplicate request");}}return all;}
 static void has(Set<String> p,String name,boolean expected){if(p.contains("android.permission."+name)!=expected)throw new AssertionError(name+" "+expected);}
 public static void main(String[] args){
  for(int sdk:new int[]{26,28,29,31,32,33,34,35,36})for(boolean receiver:new boolean[]{true,false}){
   Set<String> p=permissions(sdk,receiver);
   has(p,"POST_NOTIFICATIONS",sdk>=33);has(p,"NEARBY_WIFI_DEVICES",sdk>=33);
   has(p,"ACCESS_FINE_LOCATION",sdk<33);has(p,"ACCESS_COARSE_LOCATION",sdk<33);
   has(p,"READ_EXTERNAL_STORAGE",!receiver&&sdk<33);
   has(p,"READ_MEDIA_IMAGES",!receiver&&sdk>=33);has(p,"READ_MEDIA_VIDEO",!receiver&&sdk>=33);has(p,"READ_MEDIA_AUDIO",!receiver&&sdk>=33);
   has(p,"READ_MEDIA_VISUAL_USER_SELECTED",!receiver&&sdk>=34);
   for(String permission:new String[]{"CAMERA","READ_CONTACTS","READ_CALL_LOG","READ_SMS"})has(p,permission,!receiver);
   for(String permission:new String[]{"SYSTEM_ALERT_WINDOW","MANAGE_EXTERNAL_STORAGE","WRITE_SETTINGS","SEND_SMS"})has(p,permission,false);
  }
  System.out.println("PASS: receiver/sender least-required permissions, SDK boundaries 26–36, no duplicate prompts, no protected-file/overlay/SMS-send permissions");
 }
}
```

------------------------------------------------------------------------

## `tests/ProtocolTest.java`

``` java
import com.abdulla.clonephone.SecureChannel;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class ProtocolTest {
    static void check(boolean ok) { if(!ok)throw new AssertionError(); }
    static void roundTrip(boolean wrongKey,boolean tamper) throws Exception {
        byte[] key=SecureChannel.parseCode(SecureChannel.newCode());
        byte[] payload=new byte[65536];new Random(5).nextBytes(payload);
        ExecutorService pool=Executors.newSingleThreadExecutor();
        try(ServerSocket server=new ServerSocket(0)) {
            Future<Boolean> result=pool.submit(()->{
                try(Socket s=server.accept()){
                    s.setSoTimeout(3000);
                    SecureChannel c=new SecureChannel(s.getInputStream(),s.getOutputStream(),key,true);
                    for(int n=0;n<32;n++){byte[] p=c.read();check(Arrays.equals(p,payload));c.write(p);}
                    check(c.read().length==0);c.write(new byte[]{3});return true;
                }catch(Exception e){if(wrongKey||tamper)return false;throw e;}
            });
            try(Socket s=new Socket("127.0.0.1",server.getLocalPort())){
                s.setSoTimeout(3000);byte[] clientKey=key.clone();if(wrongKey)clientKey[0]^=1;
                final boolean[] corrupt={false};
                OutputStream out=new FilterOutputStream(s.getOutputStream()){
                    @Override public void write(byte[] b,int off,int len)throws IOException{
                        byte[] copy=Arrays.copyOfRange(b,off,off+len);
                        if(corrupt[0]&&copy.length>16){copy[copy.length-1]^=1;corrupt[0]=false;}
                        this.out.write(copy);
                    }
                };
                try{
                    SecureChannel c=new SecureChannel(s.getInputStream(),out,clientKey,false);corrupt[0]=tamper;
                    for(int n=0;n<32;n++){c.write(payload);check(Arrays.equals(c.read(),payload));}
                    c.write(new byte[0]);check(Arrays.equals(c.read(),new byte[]{3}));check(!wrongKey&&!tamper);
                }catch(Exception e){if(!wrongKey&&!tamper)throw e;}
            }
            check(result.get(5,TimeUnit.SECONDS)==(!wrongKey&&!tamper));
        }finally{pool.shutdownNow();}
    }
    public static void main(String[] args)throws Exception{
        String code=SecureChannel.newCode();check(SecureChannel.parseCode(code).length==16);
        try{SecureChannel.parseCode("123456");throw new AssertionError();}catch(IllegalArgumentException expected){}
        roundTrip(false,false);roundTrip(true,false);roundTrip(false,true);
        System.out.println("PASS: 2 MiB encrypted duplex transfer, empty/end records, invalid code, wrong key, tamper rejection");
    }
}
```

------------------------------------------------------------------------

## `tests/RecordJsonTest.java`

``` java
import com.abdulla.clonephone.RecordJson;
import java.io.*;
import java.util.*;
public class RecordJsonTest {
 public static void main(String[] args)throws Exception{
  List<Map<String,Object>> rows=new ArrayList<>();
  for(int i=1;i<=3;i++){Map<String,Object> r=new LinkedHashMap<>();r.put("_id",(long)i);r.put("address","+96407701234567");r.put("body",i==2?"UNSELECTED":"سڵاو مرحبا 😀 \"quoted\" \\ newline\n\t\u0000");r.put("date",1700000000000L+i);r.put("service_center",null);rows.add(r);}
  try(RecordJson backup=new RecordJson(new FileOutputStream(args[0]),"sms")){for(Map<String,Object> row:rows)if(!row.get("_id").equals(2L))backup.record(row);if(backup.count()!=2)throw new AssertionError();}
  try(RecordJson empty=new RecordJson(new FileOutputStream(args[1]),"calls")){}
  System.out.println("Wrote synthetic selected-record fixtures for independent JSON parsing");
 }
}
```

------------------------------------------------------------------------

## `tests/ResumeTest.java`

``` java
import com.abdulla.clonephone.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class ResumeTest {
 static byte[] source=new byte[3*1048576+37];
 static byte[] key;
 static AtomicInteger published=new AtomicInteger();
 static void transfer(ResumableFile.Entry entry,boolean interrupt,boolean lostAck,byte[] data)throws Exception{
  ExecutorService pool=Executors.newSingleThreadExecutor();
  try(ServerSocket listener=new ServerSocket(0)){
   Future<Long> server=pool.submit(()->{try(Socket s=listener.accept()){
    s.setSoTimeout(3000);SecureChannel c=new SecureChannel(s.getInputStream(),s.getOutputStream(),key,true);
    return ResumableFile.receive(c,entry,data.length,n->{if(interrupt&&n>=1048576){s.close();throw new EOFException("intentional disconnect");}},file->{
     if(!Arrays.equals(data,Files.readAllBytes(file.toPath())))throw new AssertionError("wrong published bytes");published.incrementAndGet();if(lostAck)s.close();
    });
   }});
   Exception clientError=null;
   try(Socket s=new Socket("127.0.0.1",listener.getLocalPort())){
    s.setSoTimeout(3000);SecureChannel c=new SecureChannel(s.getInputStream(),s.getOutputStream(),key,false);
    ResumableFile.send(c,new ByteArrayInputStream(data),data.length,262144,n->{});
   }catch(Exception e){clientError=e;}
   Exception serverError=null;try{server.get(8,TimeUnit.SECONDS);}catch(ExecutionException e){serverError=(Exception)e.getCause();}
   if(interrupt||lostAck){if(clientError==null||serverError==null)throw new AssertionError("expected disconnect");}
   else if(clientError!=null||serverError!=null)throw new AssertionError("unexpected failure",clientError!=null?clientError:serverError);
  }finally{pool.shutdownNow();}
 }
 public static void main(String[] args)throws Exception{
  new Random(123).nextBytes(source);key=SecureChannel.parseCode(SecureChannel.newCode());
  File f=File.createTempFile("resume-test-",".part");ResumableFile.Entry e=new ResumableFile.Entry(f);
  transfer(e,true,false,source);if(e.done||f.length()!=1048576)throw new AssertionError("checkpoint not preserved");
  transfer(e,false,true,source);if(!e.done||published.get()!=1)throw new AssertionError("commit before ACK");
  transfer(e,false,false,source);if(published.get()!=1)throw new AssertionError("duplicate publish");
  // Corrupt retained prefix: neither side may append or publish it.
  ResumableFile.Entry bad=new ResumableFile.Entry(File.createTempFile("resume-bad-",".part"));Files.write(bad.partial.toPath(),new byte[1048576]);
  try{transfer(bad,false,false,source);throw new AssertionError("corrupt prefix accepted");}catch(AssertionError expected){if(!"unexpected failure".equals(expected.getMessage()))throw expected;}
  if(bad.partial.length()!=0||bad.done||published.get()!=1)throw new AssertionError("bad prefix retained");
  transfer(bad,false,false,source);if(published.get()!=2)throw new AssertionError();
  ResumableFile.Entry empty=new ResumableFile.Entry(File.createTempFile("resume-empty-",".part"));transfer(empty,false,false,new byte[0]);transfer(empty,false,false,new byte[0]);if(published.get()!=3)throw new AssertionError("empty file duplicated");
  System.out.println("PASS: mid-file disconnect, exact checkpoint, encrypted resume, SHA-256, lost ACK deduplication, corrupt prefix reset, retry and short tail");
 }
}
```

------------------------------------------------------------------------

## `tests/TransferStatsTest.java`

``` java
import com.abdulla.clonephone.TransferStats;
public class TransferStatsTest {
 public static void main(String[] args){
  TransferStats s=new TransferStats(new String[]{"one.jpg","two.mp4","three.heic","app.rbapp","notes.txt"},new String[]{"image/jpeg","video/mp4","application/octet-stream","application/x-rebaritclone-app","text/plain"},new long[]{1000000000L,2000000000L,500000000L,0,0});
  if(s.totalBytes!=3500000000L||!s.totalKnown||s.total(0)!=2||s.total(1)!=1||s.total(2)!=1||s.total(3)!=1)throw new AssertionError("totals");
  if(s.remaining(0,0)!=2||s.remaining(0,1)!=1||s.remaining(1,1)!=1||s.remaining(1,2)!=0)throw new AssertionError("completion boundary");
  if(s.remainingBytes(1250000000L)!=2250000000L||s.remainingBytes(4000000000L)!=0)throw new AssertionError("partial/resumed bytes");
  if(s.remaining(0,5)!=0||s.remaining(3,5)!=0)throw new AssertionError("end");
  TransferStats u=new TransferStats(new String[]{"clip"},new String[]{"video/mp4"},new long[]{-1});if(u.totalKnown||u.remainingBytes(1)!=-1)throw new AssertionError("unknown size fabricated");
  TransferStats z=new TransferStats(new String[]{},new String[]{},new long[]{});if(z.count!=0||z.totalBytes!=0||z.remaining(0,0)!=0)throw new AssertionError("empty");
  if(!"1.000 GB".equals(TransferStats.gb(1000000000L))||!"<0.001 GB".equals(TransferStats.gb(100)))throw new AssertionError("units");
  System.out.println("PASS: mixed media counts, unacknowledged/acknowledged boundaries, partial/resumed bytes, unknown size, empty selection and decimal GB formatting");
 }
}
```

------------------------------------------------------------------------

## `tests/TranslationsTest.java`

``` java
import com.abdulla.clonephone.Translations;
public class TranslationsTest {
 public static void main(String[] args){
  for(int i=0;i<Translations.COUNT;i++){
   for(String lang:new String[]{"ckb","en","ar"})if(Translations.get(lang,i)==null||Translations.get(lang,i).isEmpty())throw new AssertionError("Missing "+lang+" "+i);
   if(Translations.get("en",i).matches("(?s).*[\\u0600-\\u06ff].*"))throw new AssertionError("Kurdish/Arabic leaked into English "+i);
  }
  if(Translations.rtl("en")||!Translations.rtl("ar")||!Translations.rtl("ckb"))throw new AssertionError("direction");
  if(!Translations.get("unknown",5).equals(Translations.get("ckb",5)))throw new AssertionError("fallback");
  if(!Translations.get("en",13).contains("\n\n")||!Translations.get("ar",145).startsWith("\n"))throw new AssertionError("newline");
  for(int id:new int[]{31,69,70,139,141,144,145,146,148,149,150,151,152,153,154,155,156,206})for(String lang:new String[]{"ckb","en","ar"})if(!Translations.get(lang,id).endsWith(" "))throw new AssertionError("fragment spacing "+lang+" "+id);
  System.out.println("PASS: all "+Translations.COUNT+" strings present in Kurdish/English/Arabic, English isolation, RTL/LTR, fallback, newlines and dynamic-text spacing");
 }
}
```

------------------------------------------------------------------------

## `tests/UsbSessionTest.java`

``` java
import com.abdulla.clonephone.*;
import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
public class UsbSessionTest{
 static InputStream fragmented(InputStream in){return new FilterInputStream(in){public int read(byte[] b,int off,int len)throws IOException{return super.read(b,off,Math.min(len,16384));}};}
 public static void main(String[] args)throws Exception{
  ExecutorService pool=Executors.newSingleThreadExecutor();byte[] data=new byte[1048576];new Random(51).nextBytes(data);
  try(ServerSocket listener=new ServerSocket(0)){
   Future<Long> receiver=pool.submit(()->{try(Socket s=listener.accept()){
    s.setSoTimeout(5000);SecureChannel channel=UsbSession.open(fragmented(s.getInputStream()),s.getOutputStream(),true);MessageDigest hash=MessageDigest.getInstance("SHA-256");long count=0;
    for(;;){byte[] block=channel.read();if(block.length==0)break;hash.update(block);count+=block.length;}
    if(!MessageDigest.isEqual(hash.digest(),channel.read()))throw new AssertionError("digest");channel.write(new byte[]{3});if(channel.read()[0]!=4)throw new AssertionError("receipt");return count;
   }});
   try(Socket s=new Socket("127.0.0.1",listener.getLocalPort())){
    s.setSoTimeout(5000);SecureChannel channel=UsbSession.open(fragmented(s.getInputStream()),s.getOutputStream(),false);MessageDigest hash=MessageDigest.getInstance("SHA-256");
    for(int i=0;i<8;i++){channel.writeBuffered(data,data.length);hash.update(data);}channel.writeBuffered(data,13);hash.update(data,0,13);channel.write(new byte[0]);channel.write(hash.digest());if(channel.read()[0]!=3)throw new AssertionError();channel.write(new byte[]{4});
   }
   if(receiver.get()!=8L*1048576+13)throw new AssertionError("size");
  }finally{pool.shutdownNow();}
  try{UsbSession.open(new ByteArrayInputStream(new byte[]{0,0,0,0}),new ByteArrayOutputStream(),false);throw new AssertionError("header accepted");}catch(IOException expected){}
  System.out.println("PASS: USB session bootstrap, 1 MiB encrypted frames, 16 KiB fragmented reads, tail/digest/final ACK, invalid-header rejection; simulated streams only");
 }
}
```

------------------------------------------------------------------------

## `third-party/ZXing-LICENSE.txt`

``` text
                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

========================================================================
jai-imageio
========================================================================

Copyright (c) 2005 Sun Microsystems, Inc.
Copyright © 2010-2014 University of Manchester
Copyright © 2010-2015 Stian Soiland-Reyes
Copyright © 2015 Peter Hull
All Rights Reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

- Redistribution of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

- Redistribution in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the
  distribution.

Neither the name of Sun Microsystems, Inc. or the names of
contributors may be used to endorse or promote products derived
from this software without specific prior written permission.

This software is provided "AS IS," without a warranty of any
kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN") AND ITS LICENSORS SHALL
NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS
DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR
ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND
REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR
INABILITY TO USE THIS SOFTWARE, EVEN IF SUN HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

You acknowledge that this software is not designed or intended for
use in the design, construction, operation or maintenance of any
nuclear facility.
```
