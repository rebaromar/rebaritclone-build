# REBARIT CLONE — پڕۆژەی تەواوی 19.1

ئەم پەکەجە سۆرسی کۆتایی، APKـی بڵاوکراوە، پشکنینەکان و ڕێگای build و بڵاوکردنەوەی نوێکردنەوە لەخۆ دەگرێت.

- وەشان: 19.1 / versionCode 191
- پەکیج: com.abdulla.clonephone
- سکانکردنی QR و پەیوەستبوونی خۆکار بە Wi-Fi Direct یان بلوتووس.
- فایلەکان بە Wi-Fi دەگوازرێنەوە؛ بلوتووس بۆ ناساندن و ئاڵوگۆڕی زانیاری پەیوەندییە.
- کلیلی واژۆی سەرەکی پارێزراوە؛ APKـەکە دەتوانێت ئەپی 18.9 نوێ بکاتەوە.

## فایلەکان

ClonePhone/: سۆرسی کراوە بۆ Android Studio، لەگەڵ Gradle wrapper، تاقیکردنەوەکان، ڕیسۆرسەکان و کلیلی واژۆی پڕۆژە.
APK/REBARIT-19.1.apk: هەمان APKـی بڵاوکراوە لە سێرڤەری نوێکردنەوە.
.github/workflows/build-apk.yml: ڕێگای دروستکردن، پشکنینی واژۆ و بڵاوکردنەوەی GitHub Actions.
rebaritclone-source.zip: سۆرسی پاک و ئامادەی workflowـی GitHub.
release-version.txt و release-notes.txt: وەشان و گۆڕانکارییەکان.
Changes/: لیستی فایلە گۆڕاوەکان و patchـی گۆڕانکارییەکان لە 18.9 بۆ 19.1.
Validation/: بەڵگەی build، واژۆ، زانیاری نوێکردنەوە و پشکنینەکان.

## Build

Open ClonePhone/ in Android Studio, or use JDK 17 and Android SDK 35:

    cd ClonePhone
    chmod +x gradlew
    ./gradlew --no-daemon assembleDebug

Use app/build.gradle and the preserved signing configuration for version 19.1.
The legacy build-local.sh is an older SDK-only helper; the verified 19.1 build uses Gradle as above.

For GitHub Actions, retain the root workflow and rebaritclone-source.zip. If editing the expanded ClonePhone/ source, rebuild rebaritclone-source.zip with ClonePhone/ as its top-level directory before pushing. Keep build outputs, .gradle caches and local.properties out of that source ZIP.

The existing repository's UPDATE_ADMIN_PASSWORD secret remains managed by GitHub and is not exported in this bundle. Publication from a different repository requires configuring that secret there.

## Verification

Gradle build and all 48 automatic-pairing protocol checks passed. The published APK package, version and original 18.9 certificate were verified. Real Android discovery and two-phone transfer were not tested.

Repository: https://github.com/rebaromar/rebaritclone-build
Published commit: e704da68cd910b7216afd191dab9b4fba16a367a
Workflow: https://github.com/rebaromar/rebaritclone-build/actions/runs/37380538666
Published APK: https://rebaritclone-update-admin.rebar4qwrna.workers.dev/apk/fd604049-e1be-4315-ba8f-a15a369063f3.apk
