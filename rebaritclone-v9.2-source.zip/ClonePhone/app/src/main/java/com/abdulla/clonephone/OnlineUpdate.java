package com.abdulla.clonephone;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.*;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.BooleanSupplier;

/** Checks while the app is visible; Android retains installation approval. */
@SuppressWarnings("deprecation")
final class OnlineUpdate {
    private static final String HOST="rebaritclone-update-admin.rebar4qwrna.workers.dev";
    private final Activity activity;
    private final BooleanSupplier busy;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private TextView label;
    private volatile boolean destroyed;
    private boolean visible,checking,prompted;
    private File ready;
    private String message="";
    private final Runnable poll=()->{offer(false);check();schedule();};
    OnlineUpdate(Activity a,BooleanSupplier b){activity=a;busy=b;}
    String words(String ku,String en,String ar){return "en".equals(UiText.language())?en:"ar".equals(UiText.language())?ar:ku;}
    private String version(){try{return activity.getPackageManager().getPackageInfo(activity.getPackageName(),0).versionName;}catch(Exception e){return "";}}
    void bind(TextView v){label=v;render();v.setOnClickListener(w->{if(ready!=null)offer(true);else check();});}
    private void render(){if(label!=null)label.setText(words("وەشان ","Version ","الإصدار ")+version()+(message.isEmpty()?"":" · "+message));}
    private void status(String s){ui.post(()->{if(!destroyed){message=s;render();}});}
    void resume(){visible=true;offer(false);check();schedule();}
    void pause(){visible=false;ui.removeCallbacks(poll);}
    private void schedule(){ui.removeCallbacks(poll);if(visible&&!destroyed)ui.postDelayed(poll,300000);}
    void destroy(){destroyed=true;pause();executor.shutdownNow();}
    private HttpURLConnection connect(String address)throws Exception{
        URL url=new URL(address);
        if(!"https".equals(url.getProtocol())||!HOST.equals(url.getHost())||(url.getPort()!=-1&&url.getPort()!=443))throw new IOException("Untrusted update URL");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setUseCaches(false);
        if(c.getResponseCode()!=200){c.disconnect();throw new IOException("Update unavailable");}return c;
    }
    private void validate(File file,int code)throws Exception{
        PackageManager pm=activity.getPackageManager();
        PackageInfo current=pm.getPackageInfo(activity.getPackageName(),PackageManager.GET_SIGNATURES);
        PackageInfo next=pm.getPackageArchiveInfo(file.getAbsolutePath(),PackageManager.GET_SIGNATURES);
        if(next==null||!current.packageName.equals(next.packageName)||next.versionCode!=code||code<=current.versionCode
            ||current.signatures==null||current.signatures.length==0||next.signatures==null||!new HashSet<>(Arrays.asList(current.signatures)).equals(new HashSet<>(Arrays.asList(next.signatures))))throw new IOException("Invalid update");
    }
    private void check(){
        if(destroyed||checking||ready!=null||!visible||busy.getAsBoolean())return;
        checking=true;
        executor.execute(()->{
            HttpURLConnection c=null;File part=new File(activity.getFilesDir(),"online-update.part");
            try{
                c=connect("https://"+HOST+"/update.json");ByteArrayOutputStream json=new ByteArrayOutputStream();
                try(InputStream in=c.getInputStream()){byte[] bytes=new byte[4096];int n;while((n=in.read(bytes))!=-1){if(json.size()+n>65536)throw new IOException("Manifest too large");json.write(bytes,0,n);}}
                c.disconnect();c=null;JSONObject manifest=new JSONObject(json.toString("UTF-8"));int code=manifest.getInt("versionCode");
                if(code<=activity.getPackageManager().getPackageInfo(activity.getPackageName(),0).versionCode){status("");return;}
                File target=new File(activity.getFilesDir(),"online-update.apk");
                boolean cached=false;if(target.isFile())try{validate(target,code);cached=true;}catch(Exception ignored){target.delete();}
                if(!cached){
                    status(words("داگرتنی نوێکردنەوە…","Downloading update…","جارٍ تنزيل التحديث…"));
                    c=connect(manifest.getString("apkUrl"));long expected=c.getContentLengthLong(),total=0;
                    try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(part)){byte[] bytes=new byte[65536];int n;while((n=in.read(bytes))!=-1){if(destroyed||Thread.currentThread().isInterrupted())throw new InterruptedIOException();total+=n;if(total>50L*1024*1024)throw new IOException("APK too large");out.write(bytes,0,n);}}
                    if(expected>=0&&total!=expected)throw new IOException("Incomplete APK");validate(part,code);
                    if(!part.renameTo(target))throw new IOException("Cannot save APK");
                }
                ui.post(()->{if(!destroyed){ready=target;message=words("نوێکردنەوە ئامادەیە","Update ready","التحديث جاهز");render();offer(false);}});
            }catch(Exception e){status(words("دووبارە هەوڵی نوێکردنەوە بدە","Tap to retry update","اضغط لإعادة التحديث"));}
            finally{if(c!=null)c.disconnect();part.delete();ui.post(()->checking=false);}
        });
    }
    private void offer(boolean manual){
        if(ready==null||!visible||destroyed||busy.getAsBoolean()||activity.isFinishing()||(!manual&&prompted))return;
        prompted=true;
        new AlertDialog.Builder(UiText.context(activity)).setTitle(words("نوێکردنەوە ئامادەیە","Update ready","التحديث جاهز"))
            .setMessage(words("داگرتن تەواو بوو. بۆ دامەزراندن بەردەوام بە.","Download complete. Continue to install.","اكتمل التنزيل. تابع للتثبيت."))
            .setPositiveButton(words("دامەزراندن","Install","تثبيت"),(d,w)->{
                Intent intent=new Intent(activity,AppInstallActivity.class);
                intent.putStringArrayListExtra("uris",new ArrayList<>(Collections.singletonList("content://"+activity.getPackageName()+".share/update")));
                intent.putStringArrayListExtra("names",new ArrayList<>(Collections.singletonList("REBAR IT Clone")));activity.startActivity(intent);
            }).setNegativeButton(words("دواتر","Later","لاحقاً"),null).show();
    }
}
